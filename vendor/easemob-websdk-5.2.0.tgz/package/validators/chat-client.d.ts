/**
 * ChatClient 参数与 DNSConfig 校验
 */
import { z } from './validator';
export declare const initConfigSchema: z.ZodEffects<z.ZodObject<{
    appKey: z.ZodOptional<z.ZodString>;
    appId: z.ZodOptional<z.ZodString>;
    enableUserInfoSync: z.ZodOptional<z.ZodBoolean>;
    enableSyncData: z.ZodOptional<z.ZodArray<z.ZodEnum<["conversation", "contact", "group"]>, "many">>;
    enableDeliveryReceipt: z.ZodOptional<z.ZodBoolean>;
    deleteConversationOnGroupDestroyed: z.ZodOptional<z.ZodBoolean>;
    syncConversationListConfig: z.ZodOptional<z.ZodObject<{
        includeEmpty: z.ZodOptional<z.ZodBoolean>;
    }, "strict", z.ZodTypeAny, {
        includeEmpty?: boolean | undefined;
    }, {
        includeEmpty?: boolean | undefined;
    }>>;
    useCustomAttachmentUpload: z.ZodOptional<z.ZodBoolean>;
    useFixedDeviceId: z.ZodOptional<z.ZodBoolean>;
    deviceId: z.ZodOptional<z.ZodString>;
    serviceConfig: z.ZodOptional<z.ZodObject<{
        dnsConfigUrls: z.ZodOptional<z.ZodArray<z.ZodString, "atleastone">>;
        serverUrls: z.ZodOptional<z.ZodObject<{
            restApiUrl: z.ZodOptional<z.ZodString>;
            wsUrl: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        }, {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        serverUrls?: {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        } | undefined;
        dnsConfigUrls?: [string, ...string[]] | undefined;
    }, {
        serverUrls?: {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        } | undefined;
        dnsConfigUrls?: [string, ...string[]] | undefined;
    }>>;
    useReplacedMessageContents: z.ZodOptional<z.ZodBoolean>;
    customDeviceName: z.ZodOptional<z.ZodString>;
    customOSPlatform: z.ZodOptional<z.ZodNumber>;
    uiKitVersion: z.ZodOptional<z.ZodString>;
    loginExtensionInfo: z.ZodOptional<z.ZodString>;
    managers: z.ZodOptional<z.ZodArray<z.ZodUnknown, "many">>;
    platformAdapterOptions: z.ZodOptional<z.ZodObject<{
        prefer: z.ZodOptional<z.ZodEnum<["web", "wechat-miniapp", "qq-miniapp", "toutiao-miniapp", "baidu-miniapp", "alipay-miniapp", "dingtalk-miniapp", "lark-miniapp", "kuaishou-miniapp", "jd-miniapp", "360-miniapp", "harmony-miniapp", "quickapp", "uniapp", "react-native", "electron-renderer", "electron-main", "unknown"]>>;
        runtimeInput: z.ZodOptional<z.ZodType<object, z.ZodTypeDef, object>>;
        transportAdapter: z.ZodOptional<z.ZodType<object, z.ZodTypeDef, object>>;
        overrides: z.ZodOptional<z.ZodType<object | ((...args: ReadonlyArray<unknown>) => unknown), z.ZodTypeDef, object | ((...args: ReadonlyArray<unknown>) => unknown)>>;
    }, "strict", z.ZodTypeAny, {
        transportAdapter?: object | undefined;
        runtimeInput?: object | undefined;
        prefer?: "unknown" | "web" | "wechat-miniapp" | "qq-miniapp" | "toutiao-miniapp" | "baidu-miniapp" | "alipay-miniapp" | "dingtalk-miniapp" | "lark-miniapp" | "kuaishou-miniapp" | "jd-miniapp" | "360-miniapp" | "harmony-miniapp" | "quickapp" | "uniapp" | "react-native" | "electron-renderer" | "electron-main" | undefined;
        overrides?: object | ((...args: ReadonlyArray<unknown>) => unknown) | undefined;
    }, {
        transportAdapter?: object | undefined;
        runtimeInput?: object | undefined;
        prefer?: "unknown" | "web" | "wechat-miniapp" | "qq-miniapp" | "toutiao-miniapp" | "baidu-miniapp" | "alipay-miniapp" | "dingtalk-miniapp" | "lark-miniapp" | "kuaishou-miniapp" | "jd-miniapp" | "360-miniapp" | "harmony-miniapp" | "quickapp" | "uniapp" | "react-native" | "electron-renderer" | "electron-main" | undefined;
        overrides?: object | ((...args: ReadonlyArray<unknown>) => unknown) | undefined;
    }>>;
}, "passthrough", z.ZodTypeAny, z.objectOutputType<{
    appKey: z.ZodOptional<z.ZodString>;
    appId: z.ZodOptional<z.ZodString>;
    enableUserInfoSync: z.ZodOptional<z.ZodBoolean>;
    enableSyncData: z.ZodOptional<z.ZodArray<z.ZodEnum<["conversation", "contact", "group"]>, "many">>;
    enableDeliveryReceipt: z.ZodOptional<z.ZodBoolean>;
    deleteConversationOnGroupDestroyed: z.ZodOptional<z.ZodBoolean>;
    syncConversationListConfig: z.ZodOptional<z.ZodObject<{
        includeEmpty: z.ZodOptional<z.ZodBoolean>;
    }, "strict", z.ZodTypeAny, {
        includeEmpty?: boolean | undefined;
    }, {
        includeEmpty?: boolean | undefined;
    }>>;
    useCustomAttachmentUpload: z.ZodOptional<z.ZodBoolean>;
    useFixedDeviceId: z.ZodOptional<z.ZodBoolean>;
    deviceId: z.ZodOptional<z.ZodString>;
    serviceConfig: z.ZodOptional<z.ZodObject<{
        dnsConfigUrls: z.ZodOptional<z.ZodArray<z.ZodString, "atleastone">>;
        serverUrls: z.ZodOptional<z.ZodObject<{
            restApiUrl: z.ZodOptional<z.ZodString>;
            wsUrl: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        }, {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        serverUrls?: {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        } | undefined;
        dnsConfigUrls?: [string, ...string[]] | undefined;
    }, {
        serverUrls?: {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        } | undefined;
        dnsConfigUrls?: [string, ...string[]] | undefined;
    }>>;
    useReplacedMessageContents: z.ZodOptional<z.ZodBoolean>;
    customDeviceName: z.ZodOptional<z.ZodString>;
    customOSPlatform: z.ZodOptional<z.ZodNumber>;
    uiKitVersion: z.ZodOptional<z.ZodString>;
    loginExtensionInfo: z.ZodOptional<z.ZodString>;
    managers: z.ZodOptional<z.ZodArray<z.ZodUnknown, "many">>;
    platformAdapterOptions: z.ZodOptional<z.ZodObject<{
        prefer: z.ZodOptional<z.ZodEnum<["web", "wechat-miniapp", "qq-miniapp", "toutiao-miniapp", "baidu-miniapp", "alipay-miniapp", "dingtalk-miniapp", "lark-miniapp", "kuaishou-miniapp", "jd-miniapp", "360-miniapp", "harmony-miniapp", "quickapp", "uniapp", "react-native", "electron-renderer", "electron-main", "unknown"]>>;
        runtimeInput: z.ZodOptional<z.ZodType<object, z.ZodTypeDef, object>>;
        transportAdapter: z.ZodOptional<z.ZodType<object, z.ZodTypeDef, object>>;
        overrides: z.ZodOptional<z.ZodType<object | ((...args: ReadonlyArray<unknown>) => unknown), z.ZodTypeDef, object | ((...args: ReadonlyArray<unknown>) => unknown)>>;
    }, "strict", z.ZodTypeAny, {
        transportAdapter?: object | undefined;
        runtimeInput?: object | undefined;
        prefer?: "unknown" | "web" | "wechat-miniapp" | "qq-miniapp" | "toutiao-miniapp" | "baidu-miniapp" | "alipay-miniapp" | "dingtalk-miniapp" | "lark-miniapp" | "kuaishou-miniapp" | "jd-miniapp" | "360-miniapp" | "harmony-miniapp" | "quickapp" | "uniapp" | "react-native" | "electron-renderer" | "electron-main" | undefined;
        overrides?: object | ((...args: ReadonlyArray<unknown>) => unknown) | undefined;
    }, {
        transportAdapter?: object | undefined;
        runtimeInput?: object | undefined;
        prefer?: "unknown" | "web" | "wechat-miniapp" | "qq-miniapp" | "toutiao-miniapp" | "baidu-miniapp" | "alipay-miniapp" | "dingtalk-miniapp" | "lark-miniapp" | "kuaishou-miniapp" | "jd-miniapp" | "360-miniapp" | "harmony-miniapp" | "quickapp" | "uniapp" | "react-native" | "electron-renderer" | "electron-main" | undefined;
        overrides?: object | ((...args: ReadonlyArray<unknown>) => unknown) | undefined;
    }>>;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    appKey: z.ZodOptional<z.ZodString>;
    appId: z.ZodOptional<z.ZodString>;
    enableUserInfoSync: z.ZodOptional<z.ZodBoolean>;
    enableSyncData: z.ZodOptional<z.ZodArray<z.ZodEnum<["conversation", "contact", "group"]>, "many">>;
    enableDeliveryReceipt: z.ZodOptional<z.ZodBoolean>;
    deleteConversationOnGroupDestroyed: z.ZodOptional<z.ZodBoolean>;
    syncConversationListConfig: z.ZodOptional<z.ZodObject<{
        includeEmpty: z.ZodOptional<z.ZodBoolean>;
    }, "strict", z.ZodTypeAny, {
        includeEmpty?: boolean | undefined;
    }, {
        includeEmpty?: boolean | undefined;
    }>>;
    useCustomAttachmentUpload: z.ZodOptional<z.ZodBoolean>;
    useFixedDeviceId: z.ZodOptional<z.ZodBoolean>;
    deviceId: z.ZodOptional<z.ZodString>;
    serviceConfig: z.ZodOptional<z.ZodObject<{
        dnsConfigUrls: z.ZodOptional<z.ZodArray<z.ZodString, "atleastone">>;
        serverUrls: z.ZodOptional<z.ZodObject<{
            restApiUrl: z.ZodOptional<z.ZodString>;
            wsUrl: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        }, {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        serverUrls?: {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        } | undefined;
        dnsConfigUrls?: [string, ...string[]] | undefined;
    }, {
        serverUrls?: {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        } | undefined;
        dnsConfigUrls?: [string, ...string[]] | undefined;
    }>>;
    useReplacedMessageContents: z.ZodOptional<z.ZodBoolean>;
    customDeviceName: z.ZodOptional<z.ZodString>;
    customOSPlatform: z.ZodOptional<z.ZodNumber>;
    uiKitVersion: z.ZodOptional<z.ZodString>;
    loginExtensionInfo: z.ZodOptional<z.ZodString>;
    managers: z.ZodOptional<z.ZodArray<z.ZodUnknown, "many">>;
    platformAdapterOptions: z.ZodOptional<z.ZodObject<{
        prefer: z.ZodOptional<z.ZodEnum<["web", "wechat-miniapp", "qq-miniapp", "toutiao-miniapp", "baidu-miniapp", "alipay-miniapp", "dingtalk-miniapp", "lark-miniapp", "kuaishou-miniapp", "jd-miniapp", "360-miniapp", "harmony-miniapp", "quickapp", "uniapp", "react-native", "electron-renderer", "electron-main", "unknown"]>>;
        runtimeInput: z.ZodOptional<z.ZodType<object, z.ZodTypeDef, object>>;
        transportAdapter: z.ZodOptional<z.ZodType<object, z.ZodTypeDef, object>>;
        overrides: z.ZodOptional<z.ZodType<object | ((...args: ReadonlyArray<unknown>) => unknown), z.ZodTypeDef, object | ((...args: ReadonlyArray<unknown>) => unknown)>>;
    }, "strict", z.ZodTypeAny, {
        transportAdapter?: object | undefined;
        runtimeInput?: object | undefined;
        prefer?: "unknown" | "web" | "wechat-miniapp" | "qq-miniapp" | "toutiao-miniapp" | "baidu-miniapp" | "alipay-miniapp" | "dingtalk-miniapp" | "lark-miniapp" | "kuaishou-miniapp" | "jd-miniapp" | "360-miniapp" | "harmony-miniapp" | "quickapp" | "uniapp" | "react-native" | "electron-renderer" | "electron-main" | undefined;
        overrides?: object | ((...args: ReadonlyArray<unknown>) => unknown) | undefined;
    }, {
        transportAdapter?: object | undefined;
        runtimeInput?: object | undefined;
        prefer?: "unknown" | "web" | "wechat-miniapp" | "qq-miniapp" | "toutiao-miniapp" | "baidu-miniapp" | "alipay-miniapp" | "dingtalk-miniapp" | "lark-miniapp" | "kuaishou-miniapp" | "jd-miniapp" | "360-miniapp" | "harmony-miniapp" | "quickapp" | "uniapp" | "react-native" | "electron-renderer" | "electron-main" | undefined;
        overrides?: object | ((...args: ReadonlyArray<unknown>) => unknown) | undefined;
    }>>;
}, z.ZodTypeAny, "passthrough">>, z.objectOutputType<{
    appKey: z.ZodOptional<z.ZodString>;
    appId: z.ZodOptional<z.ZodString>;
    enableUserInfoSync: z.ZodOptional<z.ZodBoolean>;
    enableSyncData: z.ZodOptional<z.ZodArray<z.ZodEnum<["conversation", "contact", "group"]>, "many">>;
    enableDeliveryReceipt: z.ZodOptional<z.ZodBoolean>;
    deleteConversationOnGroupDestroyed: z.ZodOptional<z.ZodBoolean>;
    syncConversationListConfig: z.ZodOptional<z.ZodObject<{
        includeEmpty: z.ZodOptional<z.ZodBoolean>;
    }, "strict", z.ZodTypeAny, {
        includeEmpty?: boolean | undefined;
    }, {
        includeEmpty?: boolean | undefined;
    }>>;
    useCustomAttachmentUpload: z.ZodOptional<z.ZodBoolean>;
    useFixedDeviceId: z.ZodOptional<z.ZodBoolean>;
    deviceId: z.ZodOptional<z.ZodString>;
    serviceConfig: z.ZodOptional<z.ZodObject<{
        dnsConfigUrls: z.ZodOptional<z.ZodArray<z.ZodString, "atleastone">>;
        serverUrls: z.ZodOptional<z.ZodObject<{
            restApiUrl: z.ZodOptional<z.ZodString>;
            wsUrl: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        }, {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        serverUrls?: {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        } | undefined;
        dnsConfigUrls?: [string, ...string[]] | undefined;
    }, {
        serverUrls?: {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        } | undefined;
        dnsConfigUrls?: [string, ...string[]] | undefined;
    }>>;
    useReplacedMessageContents: z.ZodOptional<z.ZodBoolean>;
    customDeviceName: z.ZodOptional<z.ZodString>;
    customOSPlatform: z.ZodOptional<z.ZodNumber>;
    uiKitVersion: z.ZodOptional<z.ZodString>;
    loginExtensionInfo: z.ZodOptional<z.ZodString>;
    managers: z.ZodOptional<z.ZodArray<z.ZodUnknown, "many">>;
    platformAdapterOptions: z.ZodOptional<z.ZodObject<{
        prefer: z.ZodOptional<z.ZodEnum<["web", "wechat-miniapp", "qq-miniapp", "toutiao-miniapp", "baidu-miniapp", "alipay-miniapp", "dingtalk-miniapp", "lark-miniapp", "kuaishou-miniapp", "jd-miniapp", "360-miniapp", "harmony-miniapp", "quickapp", "uniapp", "react-native", "electron-renderer", "electron-main", "unknown"]>>;
        runtimeInput: z.ZodOptional<z.ZodType<object, z.ZodTypeDef, object>>;
        transportAdapter: z.ZodOptional<z.ZodType<object, z.ZodTypeDef, object>>;
        overrides: z.ZodOptional<z.ZodType<object | ((...args: ReadonlyArray<unknown>) => unknown), z.ZodTypeDef, object | ((...args: ReadonlyArray<unknown>) => unknown)>>;
    }, "strict", z.ZodTypeAny, {
        transportAdapter?: object | undefined;
        runtimeInput?: object | undefined;
        prefer?: "unknown" | "web" | "wechat-miniapp" | "qq-miniapp" | "toutiao-miniapp" | "baidu-miniapp" | "alipay-miniapp" | "dingtalk-miniapp" | "lark-miniapp" | "kuaishou-miniapp" | "jd-miniapp" | "360-miniapp" | "harmony-miniapp" | "quickapp" | "uniapp" | "react-native" | "electron-renderer" | "electron-main" | undefined;
        overrides?: object | ((...args: ReadonlyArray<unknown>) => unknown) | undefined;
    }, {
        transportAdapter?: object | undefined;
        runtimeInput?: object | undefined;
        prefer?: "unknown" | "web" | "wechat-miniapp" | "qq-miniapp" | "toutiao-miniapp" | "baidu-miniapp" | "alipay-miniapp" | "dingtalk-miniapp" | "lark-miniapp" | "kuaishou-miniapp" | "jd-miniapp" | "360-miniapp" | "harmony-miniapp" | "quickapp" | "uniapp" | "react-native" | "electron-renderer" | "electron-main" | undefined;
        overrides?: object | ((...args: ReadonlyArray<unknown>) => unknown) | undefined;
    }>>;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    appKey: z.ZodOptional<z.ZodString>;
    appId: z.ZodOptional<z.ZodString>;
    enableUserInfoSync: z.ZodOptional<z.ZodBoolean>;
    enableSyncData: z.ZodOptional<z.ZodArray<z.ZodEnum<["conversation", "contact", "group"]>, "many">>;
    enableDeliveryReceipt: z.ZodOptional<z.ZodBoolean>;
    deleteConversationOnGroupDestroyed: z.ZodOptional<z.ZodBoolean>;
    syncConversationListConfig: z.ZodOptional<z.ZodObject<{
        includeEmpty: z.ZodOptional<z.ZodBoolean>;
    }, "strict", z.ZodTypeAny, {
        includeEmpty?: boolean | undefined;
    }, {
        includeEmpty?: boolean | undefined;
    }>>;
    useCustomAttachmentUpload: z.ZodOptional<z.ZodBoolean>;
    useFixedDeviceId: z.ZodOptional<z.ZodBoolean>;
    deviceId: z.ZodOptional<z.ZodString>;
    serviceConfig: z.ZodOptional<z.ZodObject<{
        dnsConfigUrls: z.ZodOptional<z.ZodArray<z.ZodString, "atleastone">>;
        serverUrls: z.ZodOptional<z.ZodObject<{
            restApiUrl: z.ZodOptional<z.ZodString>;
            wsUrl: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        }, {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        }>>;
    }, "strip", z.ZodTypeAny, {
        serverUrls?: {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        } | undefined;
        dnsConfigUrls?: [string, ...string[]] | undefined;
    }, {
        serverUrls?: {
            restApiUrl?: string | undefined;
            wsUrl?: string | undefined;
        } | undefined;
        dnsConfigUrls?: [string, ...string[]] | undefined;
    }>>;
    useReplacedMessageContents: z.ZodOptional<z.ZodBoolean>;
    customDeviceName: z.ZodOptional<z.ZodString>;
    customOSPlatform: z.ZodOptional<z.ZodNumber>;
    uiKitVersion: z.ZodOptional<z.ZodString>;
    loginExtensionInfo: z.ZodOptional<z.ZodString>;
    managers: z.ZodOptional<z.ZodArray<z.ZodUnknown, "many">>;
    platformAdapterOptions: z.ZodOptional<z.ZodObject<{
        prefer: z.ZodOptional<z.ZodEnum<["web", "wechat-miniapp", "qq-miniapp", "toutiao-miniapp", "baidu-miniapp", "alipay-miniapp", "dingtalk-miniapp", "lark-miniapp", "kuaishou-miniapp", "jd-miniapp", "360-miniapp", "harmony-miniapp", "quickapp", "uniapp", "react-native", "electron-renderer", "electron-main", "unknown"]>>;
        runtimeInput: z.ZodOptional<z.ZodType<object, z.ZodTypeDef, object>>;
        transportAdapter: z.ZodOptional<z.ZodType<object, z.ZodTypeDef, object>>;
        overrides: z.ZodOptional<z.ZodType<object | ((...args: ReadonlyArray<unknown>) => unknown), z.ZodTypeDef, object | ((...args: ReadonlyArray<unknown>) => unknown)>>;
    }, "strict", z.ZodTypeAny, {
        transportAdapter?: object | undefined;
        runtimeInput?: object | undefined;
        prefer?: "unknown" | "web" | "wechat-miniapp" | "qq-miniapp" | "toutiao-miniapp" | "baidu-miniapp" | "alipay-miniapp" | "dingtalk-miniapp" | "lark-miniapp" | "kuaishou-miniapp" | "jd-miniapp" | "360-miniapp" | "harmony-miniapp" | "quickapp" | "uniapp" | "react-native" | "electron-renderer" | "electron-main" | undefined;
        overrides?: object | ((...args: ReadonlyArray<unknown>) => unknown) | undefined;
    }, {
        transportAdapter?: object | undefined;
        runtimeInput?: object | undefined;
        prefer?: "unknown" | "web" | "wechat-miniapp" | "qq-miniapp" | "toutiao-miniapp" | "baidu-miniapp" | "alipay-miniapp" | "dingtalk-miniapp" | "lark-miniapp" | "kuaishou-miniapp" | "jd-miniapp" | "360-miniapp" | "harmony-miniapp" | "quickapp" | "uniapp" | "react-native" | "electron-renderer" | "electron-main" | undefined;
        overrides?: object | ((...args: ReadonlyArray<unknown>) => unknown) | undefined;
    }>>;
}, z.ZodTypeAny, "passthrough">>;
export declare const authContextSchema: z.ZodObject<{
    userId: z.ZodString;
    token: z.ZodString;
}, "strip", z.ZodTypeAny, {
    userId: string;
    token: string;
}, {
    userId: string;
    token: string;
}>;
export declare const loginOptionsSchema: z.ZodObject<{
    timeoutMs: z.ZodOptional<z.ZodNumber>;
}, "strict", z.ZodTypeAny, {
    timeoutMs?: number | undefined;
}, {
    timeoutMs?: number | undefined;
}>;
export declare const renewTokenSchema: z.ZodString;
export declare const getRTCTokenInfoParamsSchema: z.ZodOptional<z.ZodObject<{
    channelName: z.ZodOptional<z.ZodString>;
}, "strip", z.ZodTypeAny, {
    channelName?: string | undefined;
}, {
    channelName?: string | undefined;
}>>;
export declare const rtcUidListSchema: z.ZodEffects<z.ZodArray<z.ZodNumber, "atleastone">, number[], [number, ...number[]]>;
export declare const dnsHostSchema: z.ZodObject<{
    protocol: z.ZodString;
    domain: z.ZodOptional<z.ZodString>;
    ip: z.ZodOptional<z.ZodString>;
    port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
}, "passthrough", z.ZodTypeAny, z.objectOutputType<{
    protocol: z.ZodString;
    domain: z.ZodOptional<z.ZodString>;
    ip: z.ZodOptional<z.ZodString>;
    port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    protocol: z.ZodString;
    domain: z.ZodOptional<z.ZodString>;
    ip: z.ZodOptional<z.ZodString>;
    port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
}, z.ZodTypeAny, "passthrough">>;
export declare const dnsConfigResponseSchema: z.ZodObject<{
    app_key: z.ZodOptional<z.ZodString>;
    rest: z.ZodObject<{
        hosts: z.ZodArray<z.ZodObject<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">>, "atleastone">;
    }, "strip", z.ZodTypeAny, {
        hosts: [z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }, {
        hosts: [z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }>;
    'msync-wx': z.ZodObject<{
        hosts: z.ZodArray<z.ZodObject<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">>, "atleastone">;
    }, "strip", z.ZodTypeAny, {
        hosts: [z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }, {
        hosts: [z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }>;
    'sync-ws': z.ZodOptional<z.ZodObject<{
        hosts: z.ZodArray<z.ZodObject<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">>, "atleastone">;
    }, "strip", z.ZodTypeAny, {
        hosts: [z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }, {
        hosts: [z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }>>;
    enableReportLogs: z.ZodOptional<z.ZodEnum<["true", "false"]>>;
    reportInterval: z.ZodOptional<z.ZodNumber>;
    enableDataReport: z.ZodOptional<z.ZodEnum<["true", "false"]>>;
    enableMd5Check: z.ZodOptional<z.ZodEnum<["true", "false"]>>;
    uploadinparts_enable: z.ZodOptional<z.ZodEnum<["true", "false"]>>;
}, "passthrough", z.ZodTypeAny, z.objectOutputType<{
    app_key: z.ZodOptional<z.ZodString>;
    rest: z.ZodObject<{
        hosts: z.ZodArray<z.ZodObject<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">>, "atleastone">;
    }, "strip", z.ZodTypeAny, {
        hosts: [z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }, {
        hosts: [z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }>;
    'msync-wx': z.ZodObject<{
        hosts: z.ZodArray<z.ZodObject<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">>, "atleastone">;
    }, "strip", z.ZodTypeAny, {
        hosts: [z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }, {
        hosts: [z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }>;
    'sync-ws': z.ZodOptional<z.ZodObject<{
        hosts: z.ZodArray<z.ZodObject<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">>, "atleastone">;
    }, "strip", z.ZodTypeAny, {
        hosts: [z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }, {
        hosts: [z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }>>;
    enableReportLogs: z.ZodOptional<z.ZodEnum<["true", "false"]>>;
    reportInterval: z.ZodOptional<z.ZodNumber>;
    enableDataReport: z.ZodOptional<z.ZodEnum<["true", "false"]>>;
    enableMd5Check: z.ZodOptional<z.ZodEnum<["true", "false"]>>;
    uploadinparts_enable: z.ZodOptional<z.ZodEnum<["true", "false"]>>;
}, z.ZodTypeAny, "passthrough">, z.objectInputType<{
    app_key: z.ZodOptional<z.ZodString>;
    rest: z.ZodObject<{
        hosts: z.ZodArray<z.ZodObject<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">>, "atleastone">;
    }, "strip", z.ZodTypeAny, {
        hosts: [z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }, {
        hosts: [z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }>;
    'msync-wx': z.ZodObject<{
        hosts: z.ZodArray<z.ZodObject<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">>, "atleastone">;
    }, "strip", z.ZodTypeAny, {
        hosts: [z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }, {
        hosts: [z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }>;
    'sync-ws': z.ZodOptional<z.ZodObject<{
        hosts: z.ZodArray<z.ZodObject<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, "passthrough", z.ZodTypeAny, z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">>, "atleastone">;
    }, "strip", z.ZodTypeAny, {
        hosts: [z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectOutputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }, {
        hosts: [z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">, ...z.objectInputType<{
            protocol: z.ZodString;
            domain: z.ZodOptional<z.ZodString>;
            ip: z.ZodOptional<z.ZodString>;
            port: z.ZodOptional<z.ZodUnion<[z.ZodString, z.ZodNumber]>>;
        }, z.ZodTypeAny, "passthrough">[]];
    }>>;
    enableReportLogs: z.ZodOptional<z.ZodEnum<["true", "false"]>>;
    reportInterval: z.ZodOptional<z.ZodNumber>;
    enableDataReport: z.ZodOptional<z.ZodEnum<["true", "false"]>>;
    enableMd5Check: z.ZodOptional<z.ZodEnum<["true", "false"]>>;
    uploadinparts_enable: z.ZodOptional<z.ZodEnum<["true", "false"]>>;
}, z.ZodTypeAny, "passthrough">>;
