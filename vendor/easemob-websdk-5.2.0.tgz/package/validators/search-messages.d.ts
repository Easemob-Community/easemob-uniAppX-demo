/**
 * 服务端消息搜索参数校验
 */
import { z } from './validator';
export declare const searchMessagesSchema: z.ZodObject<{
    option: z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<{
        keywordList: z.ZodEffects<z.ZodArray<z.ZodString, "many">, string[], string[]>;
        keywordListMatchType: z.ZodOptional<z.ZodEnum<["or", "and"]>>;
        conversationId: z.ZodOptional<z.ZodString>;
        conversationType: z.ZodOptional<z.ZodEnum<["singleChat", "groupChat", "chatRoom"]>>;
        msgTypes: z.ZodOptional<z.ZodArray<z.ZodEnum<["txt", "img", "video", "file", "loc", "custom", "combine"]>, "many">>;
        startTime: z.ZodOptional<z.ZodNumber>;
        endTime: z.ZodOptional<z.ZodNumber>;
        searchScope: z.ZodOptional<z.ZodEnum<["none", "with", "only"]>>;
        direction: z.ZodOptional<z.ZodEnum<["up", "down"]>>;
    }, "strip", z.ZodTypeAny, {
        keywordList: string[];
        conversationId?: string | undefined;
        conversationType?: "singleChat" | "groupChat" | "chatRoom" | undefined;
        startTime?: number | undefined;
        endTime?: number | undefined;
        keywordListMatchType?: "or" | "and" | undefined;
        msgTypes?: ("file" | "video" | "custom" | "combine" | "txt" | "img" | "loc")[] | undefined;
        searchScope?: "none" | "with" | "only" | undefined;
        direction?: "up" | "down" | undefined;
    }, {
        keywordList: string[];
        conversationId?: string | undefined;
        conversationType?: "singleChat" | "groupChat" | "chatRoom" | undefined;
        startTime?: number | undefined;
        endTime?: number | undefined;
        keywordListMatchType?: "or" | "and" | undefined;
        msgTypes?: ("file" | "video" | "custom" | "combine" | "txt" | "img" | "loc")[] | undefined;
        searchScope?: "none" | "with" | "only" | undefined;
        direction?: "up" | "down" | undefined;
    }>, {
        keywordList: string[];
        conversationId?: string | undefined;
        conversationType?: "singleChat" | "groupChat" | "chatRoom" | undefined;
        startTime?: number | undefined;
        endTime?: number | undefined;
        keywordListMatchType?: "or" | "and" | undefined;
        msgTypes?: ("file" | "video" | "custom" | "combine" | "txt" | "img" | "loc")[] | undefined;
        searchScope?: "none" | "with" | "only" | undefined;
        direction?: "up" | "down" | undefined;
    }, {
        keywordList: string[];
        conversationId?: string | undefined;
        conversationType?: "singleChat" | "groupChat" | "chatRoom" | undefined;
        startTime?: number | undefined;
        endTime?: number | undefined;
        keywordListMatchType?: "or" | "and" | undefined;
        msgTypes?: ("file" | "video" | "custom" | "combine" | "txt" | "img" | "loc")[] | undefined;
        searchScope?: "none" | "with" | "only" | undefined;
        direction?: "up" | "down" | undefined;
    }>, {
        keywordList: string[];
        conversationId?: string | undefined;
        conversationType?: "singleChat" | "groupChat" | "chatRoom" | undefined;
        startTime?: number | undefined;
        endTime?: number | undefined;
        keywordListMatchType?: "or" | "and" | undefined;
        msgTypes?: ("file" | "video" | "custom" | "combine" | "txt" | "img" | "loc")[] | undefined;
        searchScope?: "none" | "with" | "only" | undefined;
        direction?: "up" | "down" | undefined;
    }, {
        keywordList: string[];
        conversationId?: string | undefined;
        conversationType?: "singleChat" | "groupChat" | "chatRoom" | undefined;
        startTime?: number | undefined;
        endTime?: number | undefined;
        keywordListMatchType?: "or" | "and" | undefined;
        msgTypes?: ("file" | "video" | "custom" | "combine" | "txt" | "img" | "loc")[] | undefined;
        searchScope?: "none" | "with" | "only" | undefined;
        direction?: "up" | "down" | undefined;
    }>, {
        keywordList: string[];
        conversationId?: string | undefined;
        conversationType?: "singleChat" | "groupChat" | "chatRoom" | undefined;
        startTime?: number | undefined;
        endTime?: number | undefined;
        keywordListMatchType?: "or" | "and" | undefined;
        msgTypes?: ("file" | "video" | "custom" | "combine" | "txt" | "img" | "loc")[] | undefined;
        searchScope?: "none" | "with" | "only" | undefined;
        direction?: "up" | "down" | undefined;
    }, {
        keywordList: string[];
        conversationId?: string | undefined;
        conversationType?: "singleChat" | "groupChat" | "chatRoom" | undefined;
        startTime?: number | undefined;
        endTime?: number | undefined;
        keywordListMatchType?: "or" | "and" | undefined;
        msgTypes?: ("file" | "video" | "custom" | "combine" | "txt" | "img" | "loc")[] | undefined;
        searchScope?: "none" | "with" | "only" | undefined;
        direction?: "up" | "down" | undefined;
    }>;
    pageNum: z.ZodDefault<z.ZodNumber>;
    pageSize: z.ZodDefault<z.ZodNumber>;
}, "strip", z.ZodTypeAny, {
    option: {
        keywordList: string[];
        conversationId?: string | undefined;
        conversationType?: "singleChat" | "groupChat" | "chatRoom" | undefined;
        startTime?: number | undefined;
        endTime?: number | undefined;
        keywordListMatchType?: "or" | "and" | undefined;
        msgTypes?: ("file" | "video" | "custom" | "combine" | "txt" | "img" | "loc")[] | undefined;
        searchScope?: "none" | "with" | "only" | undefined;
        direction?: "up" | "down" | undefined;
    };
    pageSize: number;
    pageNum: number;
}, {
    option: {
        keywordList: string[];
        conversationId?: string | undefined;
        conversationType?: "singleChat" | "groupChat" | "chatRoom" | undefined;
        startTime?: number | undefined;
        endTime?: number | undefined;
        keywordListMatchType?: "or" | "and" | undefined;
        msgTypes?: ("file" | "video" | "custom" | "combine" | "txt" | "img" | "loc")[] | undefined;
        searchScope?: "none" | "with" | "only" | undefined;
        direction?: "up" | "down" | undefined;
    };
    pageSize?: number | undefined;
    pageNum?: number | undefined;
}>;
