/**
 * 创建消息方法参数校验
 */
import { z } from './validator';
export declare const createTextMessageSchema: z.ZodType<{
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    content: string;
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    targetLanguages?: string[] | undefined;
}, z.ZodTypeDef, {
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    content: string;
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    targetLanguages?: string[] | undefined;
}>;
export declare const createImageMessageSchema: z.ZodType<{
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    width?: number | undefined;
    height?: number | undefined;
    isGif?: boolean | undefined;
    filename?: string | undefined;
    filetype?: string | undefined;
    thumbnailUrl?: string | undefined;
    fileLength?: number | undefined;
    data?: File | {
        path: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | {
        uri: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | undefined;
    isOriginalImage?: boolean | undefined;
    originalUrl?: string | undefined;
}, z.ZodTypeDef, {
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    width?: number | undefined;
    height?: number | undefined;
    isGif?: boolean | undefined;
    filename?: string | undefined;
    filetype?: string | undefined;
    thumbnailUrl?: string | undefined;
    fileLength?: number | undefined;
    data?: File | {
        path: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | {
        uri: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | undefined;
    isOriginalImage?: boolean | undefined;
    originalUrl?: string | undefined;
}>;
export declare const createFileMessageSchema: z.ZodType<{
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    filename?: string | undefined;
    filetype?: string | undefined;
    fileSize?: number | undefined;
    fileLength?: number | undefined;
    data?: File | {
        path: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | {
        uri: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | undefined;
    originalUrl?: string | undefined;
}, z.ZodTypeDef, {
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    filename?: string | undefined;
    filetype?: string | undefined;
    fileSize?: number | undefined;
    fileLength?: number | undefined;
    data?: File | {
        path: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | {
        uri: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | undefined;
    originalUrl?: string | undefined;
}>;
export declare const createVoiceMessageSchema: z.ZodType<{
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    duration: number;
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    filename?: string | undefined;
    filetype?: string | undefined;
    fileLength?: number | undefined;
    data?: File | {
        path: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | {
        uri: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | undefined;
    originalUrl?: string | undefined;
}, z.ZodTypeDef, {
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    duration: number;
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    filename?: string | undefined;
    filetype?: string | undefined;
    fileLength?: number | undefined;
    data?: File | {
        path: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | {
        uri: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | undefined;
    originalUrl?: string | undefined;
}>;
export declare const createVideoMessageSchema: z.ZodType<{
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    duration: number;
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    width?: number | undefined;
    height?: number | undefined;
    filename?: string | undefined;
    filetype?: string | undefined;
    thumbnailUrl?: string | undefined;
    fileLength?: number | undefined;
    data?: File | {
        path: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | {
        uri: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | undefined;
    originalUrl?: string | undefined;
}, z.ZodTypeDef, {
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    duration: number;
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    width?: number | undefined;
    height?: number | undefined;
    filename?: string | undefined;
    filetype?: string | undefined;
    thumbnailUrl?: string | undefined;
    fileLength?: number | undefined;
    data?: File | {
        path: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | {
        uri: string;
        type?: string | undefined;
        name?: string | undefined;
        size?: number | undefined;
    } | undefined;
    originalUrl?: string | undefined;
}>;
export declare const createLocationMessageSchema: z.ZodType<{
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    latitude: number;
    longitude: number;
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    address?: string | undefined;
    buildingName?: string | undefined;
}, z.ZodTypeDef, {
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    latitude: number;
    longitude: number;
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    address?: string | undefined;
    buildingName?: string | undefined;
}>;
export declare const createCmdMessageSchema: z.ZodType<{
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    action: string;
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
}, z.ZodTypeDef, {
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    action: string;
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
}>;
export declare const createCustomMessageSchema: z.ZodType<{
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    event: string;
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    params?: Record<string, string> | undefined;
}, z.ZodTypeDef, {
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    event: string;
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    params?: Record<string, string> | undefined;
}>;
export declare const createMessageEnvelopeSchema: z.ZodType<{
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
}, z.ZodTypeDef, {
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
}>;
export declare const createCombineMessageSchema: z.ZodType<{
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    title: string;
    summary: string;
    messageList: z.objectOutputType<{
        type: z.ZodString;
        sender: z.ZodObject<{
            userId: z.ZodString;
            nickname: z.ZodOptional<z.ZodString>;
            avatarUrl: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            userId: string;
            nickname?: string | undefined;
            avatarUrl?: string | undefined;
        }, {
            userId: string;
            nickname?: string | undefined;
            avatarUrl?: string | undefined;
        }>;
        conversationId: z.ZodString;
        conversationType: z.ZodEnum<["singleChat", "groupChat", "chatRoom"]>;
        timestamp: z.ZodNumber;
        body: z.ZodUnion<[z.ZodRecord<z.ZodString, z.ZodUnknown>, z.ZodArray<z.ZodRecord<z.ZodString, z.ZodUnknown>, "many">]>;
        combineLevel: z.ZodOptional<z.ZodNumber>;
    }, z.ZodTypeAny, "passthrough">[];
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    compatibleText?: string | undefined;
}, z.ZodTypeDef, {
    conversationId: string;
    conversationType: "singleChat" | "groupChat" | "chatRoom";
    title: string;
    summary: string;
    messageList: z.objectInputType<{
        type: z.ZodString;
        sender: z.ZodObject<{
            userId: z.ZodString;
            nickname: z.ZodOptional<z.ZodString>;
            avatarUrl: z.ZodOptional<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            userId: string;
            nickname?: string | undefined;
            avatarUrl?: string | undefined;
        }, {
            userId: string;
            nickname?: string | undefined;
            avatarUrl?: string | undefined;
        }>;
        conversationId: z.ZodString;
        conversationType: z.ZodEnum<["singleChat", "groupChat", "chatRoom"]>;
        timestamp: z.ZodNumber;
        body: z.ZodUnion<[z.ZodRecord<z.ZodString, z.ZodUnknown>, z.ZodArray<z.ZodRecord<z.ZodString, z.ZodUnknown>, "many">]>;
        combineLevel: z.ZodOptional<z.ZodNumber>;
    }, z.ZodTypeAny, "passthrough">[];
    ext?: Record<string, unknown> | undefined;
    timestamp?: number | undefined;
    receiverList?: [string, ...string[]] | undefined;
    deliverOnlineOnly?: boolean | undefined;
    webhookEnv?: string | undefined;
    priority?: "normal" | "high" | "low" | undefined;
    needReadReceipt?: boolean | undefined;
    isChatThread?: boolean | undefined;
    compatibleText?: string | undefined;
}>;
