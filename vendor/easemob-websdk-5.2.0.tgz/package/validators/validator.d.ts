/**
 * 统一参数校验器
 *
 * 基于 zod schema，统一参数校验和错误处理
 */
import { z, ZodSchema } from 'zod';
import { ValidationError } from '../utils/errors';
/**
 * 参数校验结果
 */
export interface ValidationResult<T> {
    success: boolean;
    data?: T;
    error?: ValidationError;
}
/**
 * 统一参数校验器
 */
export declare class Validator {
    /**
     * 校验参数
     *
     * @param schema Zod schema
     * @param data 要校验的数据
     * @returns 校验结果
     */
    static validate<T>(schema: ZodSchema<T>, data: unknown): ValidationResult<T>;
    /**
     * 校验参数（抛出异常版本）
     *
     * @param schema Zod schema
     * @param data 要校验的数据
     * @returns 校验后的数据
     * @throws ValidationError 如果校验失败
     */
    static validateOrThrow<T>(schema: ZodSchema<T>, data: unknown): T;
    /**
     * 安全解析（不抛出异常）
     *
     * @param schema Zod schema
     * @param data 要校验的数据
     * @returns 校验结果，包含 success 标志
     */
    static safeParse<T>(schema: ZodSchema<T>, data: unknown): ValidationResult<T>;
}
/**
 * 导出常用的 Zod schema 辅助函数
 */
export { z };
