/**
 * [zh-CN] 好友自动同步相关公共类型定义，供 ContactManager、事件系统与文档生成复用。
 * [en-US] Public type definitions for friend auto-sync, shared across ContactManager, event system, and doc generation.
 */
import type { ErrorCode } from '../utils/error-codes';
import type { UserInfo } from './user-info';
/**
 * [zh-CN] 好友展示对象。
 * [en-US] Friend view object.
 */
export interface Contact {
    /** [zh-CN] 好友用户 ID。 [en-US] The user ID of the friend. */
    readonly userId: string;
    /** [zh-CN] 好友资料视图，直接复用统一 `UserInfo`。 [en-US] Friend profile view, backed by the shared `UserInfo` model. */
    readonly userInfo: UserInfo;
    /** [zh-CN] 当前用户给该好友的备注。 [en-US] Remark set by the current user for this friend. */
    readonly remark: string;
    /** [zh-CN] 好友关系建立时间戳。 [en-US] Timestamp when the friend relationship was established. */
    readonly addTs: number;
}
/**
 * [zh-CN] 好友资料变化事件载荷。
 * [en-US] Payload for friend profile change events.
 */
export interface ContactInfoUpdatedEvent {
    /** [zh-CN] 最新好友资料。 [en-US] The latest friend profile. */
    readonly userInfo: UserInfo;
    /** [zh-CN] 当前会话中可用的好友快照。 [en-US] Friend snapshot if available in the current conversation. */
    readonly contact?: Contact;
}
/**
 * [zh-CN] 好友写操作的统一目标。
 * [en-US] Unified target object for friend mutation APIs.
 */
export interface ContactMutationTarget {
    /** [zh-CN] 目标用户 ID。 [en-US] Target user ID. */
    readonly userId: string;
}
/**
 * [zh-CN] 添加好友的输入参数。
 * [en-US] Input parameters for adding a friend.
 */
export interface AddContactParams extends ContactMutationTarget {
    /** [zh-CN] 可选的验证消息。 [en-US] Optional verification message. */
    readonly message?: string;
}
/**
 * [zh-CN] 更新好友备注的输入参数。
 * [en-US] Input parameters for updating a friend's remark.
 */
export interface SetContactRemarkParams extends ContactMutationTarget {
    /** [zh-CN] 好友备注，允许空字符串以清空备注。 [en-US] Friend remark. An empty string clears the remark. */
    readonly remark: string;
}
/**
 * [zh-CN] 黑名单增删接口的输入参数。
 * [en-US] Input parameters for block list mutation APIs.
 */
export interface BlocklistMutationParams {
    /** [zh-CN] 待处理的用户 ID 列表。 [en-US] List of user IDs to mutate. */
    readonly userIds: ReadonlyArray<string>;
}
/**
 * [zh-CN] 黑名单添加成功结果。
 * [en-US] Result of a successful block list addition.
 */
export interface BlocklistAddResult {
    /** [zh-CN] 成功加入黑名单的用户资料列表。 [en-US] List of profiles belonging to users that were successfully added to the block list. */
    readonly succeeded: ReadonlyArray<UserInfo>;
    /** [zh-CN] 加入失败的用户资料列表。 [en-US] List of profiles belonging to users that failed to be added to the block list. */
    readonly failed: ReadonlyArray<UserInfo>;
}
/**
 * [zh-CN] 会话级黑名单快照。
 * [en-US] conversation-scoped block list snapshot.
 */
export interface BlocklistSnapshot {
    /** [zh-CN] 当前黑名单条目列表。 [en-US] List of current block list entries. */
    readonly items: ReadonlyArray<UserInfo>;
    /** [zh-CN] 当前会话是否已完成服务端加载。 [en-US] Whether the server-side block list data is loaded in the current conversation. */
    readonly loaded: boolean;
    /** [zh-CN] 快照来源。 [en-US] Snapshot source. */
    readonly source: 'server' | 'mutation_patch';
}
/**
 * [zh-CN] 好友 roster 事件的标准化公开载荷。
 * [en-US] Normalized public payload for contact roster events.
 */
export interface ContactRosterEventPayload {
    /** [zh-CN] 事件发送方用户 ID。 [en-US] User ID of the event sender. */
    readonly from: string;
    /** [zh-CN] 事件接收方用户 ID。 [en-US] User ID of the event recipient. */
    readonly to: string;
    /** [zh-CN] 服务端附带的邀请附言或事件原因。 [en-US] Invitation message or event reason provided by the server. */
    readonly message: string;
    /** [zh-CN] 事件目标用户的资料视图；对外事件会在派发前补齐，至少包含 `userId`。 [en-US] Profile view of the event target. It is enriched before public dispatch and always includes at least `userId`. */
    readonly userInfo: UserInfo;
}
/**
 * [zh-CN] 好友快照来源。
 * [en-US] Source of a friend snapshot.
 */
export type ContactSyncSource = 'cache' | 'sync';
/**
 * [zh-CN] 好友同步决策结果。
 * [en-US] Decision result for friend sync.
 */
export type ContactSyncDecision = 'skip' | 'incremental' | 'full';
/**
 * [zh-CN] 好友同步失败阶段。
 * [en-US] Failure stage of friend sync.
 */
export type ContactSyncStage = 'metadata' | 'socket_connect' | 'sync_page' | 'decode' | 'cancelled';
/**
 * [zh-CN] 好友快照，包含列表、来源、版本和完整性信息。
 * [en-US] Friend snapshot containing list, source, version, and completeness metadata.
 */
export interface ContactSnapshot {
    /** [zh-CN] 当前快照中的好友列表。 [en-US] List of friends in the current snapshot. */
    readonly items: ReadonlyArray<Contact>;
    /** [zh-CN] 当前快照来自缓存还是同步结果。 [en-US] Whether the snapshot comes from cache or sync result. */
    readonly source: ContactSyncSource;
    /** [zh-CN] 当前快照对应的好友版本号。 [en-US] Friend version associated with the snapshot. */
    readonly version: string;
    /** [zh-CN] 当前快照是否可作为完整好友结果使用。 [en-US] Whether the snapshot is complete enough to serve as the full friend result. */
    readonly complete: boolean;
}
/**
 * [zh-CN] 好友同步错误对象。
 * [en-US] Friend sync error object.
 */
export interface ContactSyncError {
    /** [zh-CN] SDK 错误码。 [en-US] SDK error code. */
    readonly code: ErrorCode;
    /** [zh-CN] 错误发生阶段。 [en-US] Stage where the error occurred. */
    readonly stage: ContactSyncStage;
    /** [zh-CN] 面向调用方的错误消息。 [en-US] Error message intended for the caller. */
    readonly message: string;
    /** [zh-CN] 当前错误是否建议重试。 [en-US] Whether retry is recommended for this error. */
    readonly retryable: boolean;
}
/**
 * [zh-CN] 好友同步内部完成载荷；公开同步事件已统一到 ChatClient 级 `onSyncDataFinished`。
 * [en-US] Internal payload for friend sync completion. Public sync events are unified under the ChatClient-level `onSyncDataFinished` event.
 */
export interface ContactSyncFinishPayload {
    /** [zh-CN] 失败时返回错误详情。 [en-US] Error details if the sync failed. */
    readonly error: ContactSyncError;
}
