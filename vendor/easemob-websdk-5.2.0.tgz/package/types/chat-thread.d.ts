import type { Message } from './index';
import type { MessageSnippet } from '../cache/cache-types';
/**
 * [zh-CN] Thread 消息上下文。
 * [en-US] Context of a message that belongs to a chat thread.
 */
export interface ChatThreadMessageContext {
    /** [zh-CN] Thread 父消息 ID。 [en-US] Parent message ID of the chat thread. */
    readonly messageId: string;
    /** [zh-CN] Thread 所属父群组 ID。 [en-US] Parent group ID of the chat thread. */
    readonly parentId: string;
    /** [zh-CN] Thread 名称。 [en-US] Chat thread name. */
    readonly chatThreadName?: string;
}
/**
 * [zh-CN] Thread 概览。
 * [en-US] Chat thread overview attached to a parent group message.
 */
export interface ChatThreadOverview {
    /** [zh-CN] Thread ID。 [en-US] Chat thread ID. */
    readonly chatThreadId: string;
    /** [zh-CN] Thread 所属父群组 ID。 [en-US] Parent group ID of the chat thread. */
    readonly parentId: string;
    /** [zh-CN] Thread 名称。 [en-US] Chat thread name. */
    readonly name?: string;
    /** [zh-CN] Thread 最后一条回复摘要。 [en-US] Last threaded reply message. */
    readonly lastMessage?: Message | null;
    /** [zh-CN] Thread 创建时间戳，单位毫秒。 [en-US] Creation timestamp in milliseconds. */
    readonly createdAt?: number;
    /** [zh-CN] Thread 更新时间戳，单位毫秒。 [en-US] Update timestamp in milliseconds. */
    readonly updatedAt?: number;
    /** [zh-CN] Thread 回复消息数量。 [en-US] Number of threaded replies. */
    readonly messageCount?: number;
}
/**
 * [zh-CN] 创建 ChatThread 的参数。
 * [en-US] Parameters for creating a chat thread.
 */
export interface CreateChatThreadParams {
    /** [zh-CN] 所属群组 ID。 [en-US] Parent group ID. */
    readonly parentId: string;
    /** [zh-CN] 消息话题名称。 [en-US] Message thread name. */
    readonly name: string;
    /** [zh-CN] 父消息 ID。 [en-US] Parent message ID. */
    readonly messageId: string;
}
/**
 * [zh-CN] 创建消息话题的返回结果。
 * [en-US] Result returned after creating a message thread.
 */
export interface CreateChatThreadResult {
    /** [zh-CN] 新建的消息话题的 ID。 [en-US] The ID of the new message thread. */
    readonly chatThreadId: string;
}
/**
 * [zh-CN] 获取群组内话题列表的分页参数。
 * [en-US] Pagination parameters for retrieving the message thread list within a group.
 */
export interface GetChatThreadListParams {
    /** [zh-CN] 消息话题所属群组 ID。 [en-US] Parent group ID. */
    readonly parentId: string;
    /** [zh-CN] 每页获取的话题数量，默认 20，范围 1-50。 [en-US] The number of message threads to return per page. The value range is 1-50, with 20 as the default. */
    readonly pageSize?: number;
    /** [zh-CN] 开始获取数据的游标位置。首次调用时传空字符串或 `null`；后续调用时传入上一次返回的 `cursor` 作为下一次获取数据的起始位置。如果当前页为最后一页，返回结果中的 `cursor` 为空字符串。 [en-US] The position from which to start retrieving data. For the first call, pass an empty string or `null`. In subsequent calls, you can pass the latest `cursor` as the starting position for the next data retrieval. If the current page is the last page, the `cursor` in the result is an empty string.  */
    readonly cursor?: string;
}
/**
 * [zh-CN] 查询当前用户已加入话题列表的参数。
 * [en-US] Parameters for retrieving message threads joined by the current user.
 */
export interface GetJoinedChatThreadListParams {
    /** [zh-CN] 可选的父级群组 ID。 [en-US] Optional parent group ID. */
    readonly parentId?: string;
    /** [zh-CN] 每页获取的话题数量，默认 20，范围 1-50。 [en-US] The number of message threads to return per page. The value range is 1-50, with 20 as the default. */
    readonly pageSize?: number;
    /** [zh-CN] 开始获取数据的游标位置。首次调用时传空字符串或 `null`；后续调用时传入上一次返回的 `cursor` 作为下一次获取数据的起始位置。如果当前页为最后一页，返回结果中的 `cursor` 为空字符串。[en-US] The position from which to start retrieving data. For the first call, pass an empty string or `null`. In subsequent calls, you can pass the latest `cursor` as the starting position for the next data retrieval. If the current page is the last page, the `cursor` in the result is an empty string.  */
    readonly cursor?: string;
}
/**
 * [zh-CN] 获取话题详情的参数。
 * [en-US] Parameters for retrieving message thread details.
 */
export interface GetChatThreadInfoParams {
    /** [zh-CN] 消息话题 ID。 [en-US] Message thread ID. */
    readonly chatThreadId: string;
}
/**
 * [zh-CN] 获取话题成员列表的分页参数。
 * [en-US] Pagination parameters for retrieving message thread members.
 */
export interface GetChatThreadMemberListParams {
    /** [zh-CN] 消息话题 ID。 [en-US] Message thread ID. */
    readonly chatThreadId: string;
    /** [zh-CN] 每页获取的话题成员数量，默认 20，范围 1-50。 [en-US] The number of message thread members to return per page. The value range is 1-50, with 20 as the default. */
    readonly pageSize?: number;
    /** [zh-CN] 开始获取数据的游标位置。首次调用时传空字符串或 `null`；后续调用时传入上一次返回的 `cursor` 作为下一次获取数据的起始位置。如果当前页为最后一页，返回结果中的 `cursor` 为空字符串。 [en-US] The position from which to start retrieving data. For the first call, pass an empty string or `null`. In subsequent calls, you can pass the latest `cursor` as the starting position for the next data retrieval. */
    readonly cursor?: string;
}
/**
 * [zh-CN] 获取当前 ChatThread 成员列表的分页参数。
 * [en-US] Pagination parameters for retrieving members of the current chat thread.
 */
export interface ChatThreadMemberListQuery {
    /** [zh-CN] 每页获取的成员数量，默认 20，范围 1-50。 [en-US] Number of members to return per page. The default is 20 and the value range is 1-50. */
    readonly pageSize?: number;
    /** [zh-CN] 分页游标。首次调用时不传或传空字符串；后续调用时传入上一次返回的 `cursor`。 [en-US] Pagination cursor. Omit it or pass an empty string on the first call, then pass the `cursor` returned by the previous call. */
    readonly cursor?: string;
}
/**
 * [zh-CN] 批量获取话题最后一条消息的参数。
 * [en-US] Parameters for retrieving the last messages of message threads in batch.
 */
export interface GetChatThreadLastMessageListParams {
    /** [zh-CN] 消息话题 ID 列表，最多 20 个。 [en-US] Message ID list, up to 20 items. */
    readonly chatThreadIds: ReadonlyArray<string>;
}
/**
 * [zh-CN] ChatThread 生命周期操作的目标。
 * [en-US] Target for chat thread lifecycle operations.
 */
export interface ChatThreadMutationTarget {
    /** [zh-CN] 子区 ID。 [en-US] Chat thread ID. */
    readonly chatThreadId: string;
}
/**
 * [zh-CN] 更新 ChatThread 名称的参数。
 * [en-US] Parameters for updating a chat thread name.
 */
export interface UpdateChatThreadNameParams extends ChatThreadMutationTarget {
    /** [zh-CN] 新子区名称。 [en-US] New chat thread name. */
    readonly name: string;
}
/**
 * [zh-CN] 移除 ChatThread 成员的参数。
 * [en-US] Parameters for removing a member from a chat thread.
 */
/**
 * [zh-CN] 移除话题成员的参数。
 * [en-US] Parameters for removing a member from a message thread.
 */
export interface RemoveChatThreadMemberParams extends ChatThreadMutationTarget {
    /** [zh-CN] 被移除成员的用户 ID。 [en-US] User ID of the member to remove. */
    readonly memberId: string;
}
/**
 * [zh-CN] 话题摘要。
 * [en-US] Summary of a message thread.
 */
export interface ChatThreadSummary {
    /** [zh-CN] 话题 ID。 [en-US] Message thread ID. */
    readonly chatThreadId: string;
    /** [zh-CN] 话题所属的父级群组 ID。 [en-US] Parent group ID that the message thread belongs to. */
    readonly parentId: string;
    /** [zh-CN] 话题名称。 [en-US] Message thread name. */
    readonly name: string;
    /** [zh-CN] 话题创建者的用户 ID。 [en-US] User ID of the message thread owner. */
    readonly ownerId?: string;
    /** [zh-CN] 话题内的成员总数。 [en-US] Total number of members in the message thread. */
    readonly memberCount?: number;
    /** [zh-CN] 话题内的消息总数。 [en-US] Total number of messages in the message thread. */
    readonly messageCount?: number;
    /** [zh-CN] 话题关联的根消息 ID（父消息 ID）。 [en-US] Root message ID (parent message ID) associated with the message thread. */
    readonly messageId?: string;
    /** [zh-CN] 话题内最后一条消息的摘要。 [en-US] Snippet of the last message in the message thread. */
    readonly lastMessage?: MessageSnippet | null;
    /** [zh-CN] 话题创建的时间戳。 [en-US] Creation timestamp of the message thread. */
    readonly createdAt?: number;
}
/**
 * [zh-CN] 话题详情。
 * [en-US] Detailed information of a message thread.
 */
export type ChatThreadDetail = ChatThreadSummary;
/**
 * [zh-CN] 话题列表的分页返回结果。
 * [en-US] Paginated list result of message threads.
 */
export interface ChatThreadListResult {
    /** [zh-CN] 当前页话题列表。 [en-US] Message threads retrieved in the current page. */
    readonly items: ReadonlyArray<ChatThreadSummary>;
    /** [zh-CN] 下一页的分页游标。如果当前页为最后一页，返回结果中的 `cursor` 为空字符串。 [en-US] Cursor for the the next data retrieval. If the current page is the last page, the `cursor` in the result is an empty string.*/
    readonly cursor: string;
}
/**
 * [zh-CN] 话题成员条目。
 * [en-US] Message thread member entry.
 */
export interface ChatThreadMemberEntry {
    /** [zh-CN] 成员用户 ID。 [en-US] User ID of the member. */
    readonly memberId: string;
    /** [zh-CN] 成员加入话题的时间戳。 [en-US] Timestamp when the member joined the message thread. */
    readonly joinedAt?: number;
}
/**
 * [zh-CN] 话题成员列表的分页返回结果。
 * [en-US] Paginated list result of message thread members.
 */
export interface ChatThreadMemberListResult {
    /** [zh-CN] 当前页的成员数据列表。 [en-US] Member retrieved in the current page. */
    readonly items: ReadonlyArray<ChatThreadMemberEntry>;
    /** [zh-CN] 下一页的分页游标。 [en-US] Cursor for the the next data retrieval. */
    readonly cursor: string;
}
/**
 * [zh-CN] 话题最后一条消息条目。
 * [en-US] Last message entry for a message thread.
 */
export interface ChatThreadLastMessageEntry {
    /** [zh-CN] 话题 ID。 [en-US] Message thread ID. */
    readonly chatThreadId: string;
    /** [zh-CN] 最后一条消息的摘要；若当前话题没有任何消息则返回 null。 [en-US] Snippet of the last message, or `null` if no messages are available. */
    readonly lastMessage: MessageSnippet | null;
}
/**
 * [zh-CN] 批量查询话题最后一条消息的返回结果。
 * [en-US] Batch retrieval result for the last message in the message thread.
 */
export interface ChatThreadLastMessageListResult {
    /** [zh-CN] 批量查询到的最后一条消息结果列表。 [en-US] List of retrieved last message entries. */
    readonly items: ReadonlyArray<ChatThreadLastMessageEntry>;
}
/**
 * [zh-CN] 话题公开事件的基础公共载荷。
 * [en-US] Base payload for public message thread events.
 */
export interface ChatThreadBaseEventPayload {
    /** [zh-CN] 话题 ID。 [en-US] Message thread ID. */
    readonly chatThreadId: string;
    /** [zh-CN] 话题所属的父级群组 ID。 [en-US] Parent group ID that the message thread belongs to. */
    readonly parentId: string;
    /** [zh-CN] 触发该事件的操作者用户 ID。 [en-US] User ID of the operator who triggered the event. */
    readonly operatorId?: string;
    /** [zh-CN] 事件发生的时间戳。 [en-US] Timestamp when the event occurred. */
    readonly timestamp: number;
}
/**
 * [zh-CN] 话题创建事件的订阅载荷。
 * [en-US] Subscription payload of the message thread creation event.
 */
export interface ChatThreadCreatedEventPayload extends ChatThreadBaseEventPayload {
    /** [zh-CN] 话题名称。 [en-US] Message thread name. */
    readonly chatThreadName?: string;
    /** [zh-CN] 触发创建话题的父消息 ID。 [en-US] Parent message ID that triggered the creation. */
    readonly messageId?: string;
    /** [zh-CN] 归一化后的标准话题摘要数据。 [en-US] Normalized message thread summary object. */
    readonly thread?: ChatThreadSummary;
}
/**
 * [zh-CN] 话题解散/删除事件的订阅载荷。
 * [en-US] Subscription payload of the message thread disbandment event.
 */
export type ChatThreadDestroyedEventPayload = ChatThreadBaseEventPayload;
/**
 * [zh-CN] 话题元数据或状态更新事件的订阅载荷。
 * [en-US] Subscription payload of the update event of message thread metadata or status.
 */
export interface ChatThreadUpdatedEventPayload extends ChatThreadBaseEventPayload {
    /** [zh-CN] 话题更新后的名称。 [en-US] Updated message thread name. */
    readonly chatThreadName?: string;
    /** [zh-CN] 话题关联的父消息 ID。 [en-US] Parent message ID associated with the message thread. */
    readonly messageId?: string;
    /** [zh-CN] 话题更新后的消息总数。 [en-US] Updated total message count in the message thread. */
    readonly messageCount?: number;
    /** [zh-CN] 话题更新后的最后一条消息摘要。 [en-US] Updated last message snippet in the message thread. */
    readonly lastMessage?: MessageSnippet | null;
    /** [zh-CN] 归一化后的标准话题摘要数据。 [en-US] Normalized message thread summary object. */
    readonly thread?: ChatThreadSummary;
}
/**
 * [zh-CN] 当前登录用户被移出话题时的事件载荷。
 * [en-US] Payload for the event triggered when the current user is removed from the message thread.
 *
 */
export interface ChatThreadUserRemovedEventPayload extends ChatThreadBaseEventPayload {
    /** [zh-CN] 被移出的成员用户 ID。 [en-US] User ID of the member who was removed. */
    readonly memberId?: string;
}
/**
 * [zh-CN] 话题公开事件的回调处理器映射表。
 * [en-US] Event handler mapping table for public message thread events.
 */
export interface ChatThreadEventHandlerMap {
    /** [zh-CN] 消息话题创建事件处理器。 [en-US] Handler for chat thread creation events. */
    readonly onChatThreadCreated?: (event: ChatThreadCreatedEventPayload) => void | Promise<void>;
    /** [zh-CN] 消息话题销毁事件处理器。 [en-US] Handler for chat thread destruction events. */
    readonly onChatThreadDestroyed?: (event: ChatThreadDestroyedEventPayload) => void | Promise<void>;
    /** [zh-CN] 消息话题更新事件处理器。 [en-US] Handler for chat thread update events. */
    readonly onChatThreadUpdated?: (event: ChatThreadUpdatedEventPayload) => void | Promise<void>;
    /** [zh-CN] 消息话题成员移除事件处理器。 [en-US] Handler for chat thread member removal events. */
    readonly onChatThreadUserRemoved?: (event: ChatThreadUserRemovedEventPayload) => void | Promise<void>;
}
/** @internal thread 原始通知的操作类型枚举。 */
export type ChatThreadRawNotifyOperation = 'create' | 'update' | 'update_msg' | 'delete' | 'join' | 'leave' | 'kick';
/** @internal thread 底层通道的原始通知载荷结构体。 */
export interface ChatThreadRawNotifyPayload {
    readonly id: string;
    readonly name?: string;
    readonly muc_parent_id: string;
    readonly msg_parent_id?: string;
    readonly timestamp?: number;
    readonly from?: string;
    readonly userIds?: ReadonlyArray<string>;
    readonly operation: ChatThreadRawNotifyOperation;
    readonly last_message?: Record<string, unknown>;
    readonly message_count?: number;
}
/** @internal thread 底层通道的原始通知事件包装体。 */
export interface ChatThreadRawNotifyEvent {
    readonly eventName: 'onChatThreadChange';
    readonly payload: ChatThreadRawNotifyPayload;
}
