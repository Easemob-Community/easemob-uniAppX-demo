/**
 * [zh-CN] SDK 日志级别。
 * [en-US] SDK log level.
 */
export type LogLevel = 'DEBUG' | 'WARN' | 'ERROR';
/**
 * [zh-CN] SDK 生成并完成脱敏的结构化日志条目。该对象为只读视图，SDK 不提供运行时深冻结保证。
 * [en-US] A structured log entry generated and sanitized by the SDK. This is a readonly view; the SDK does not guarantee runtime deep freezing.
 */
export interface LogEntry {
    /** [zh-CN] 日志产生时间，使用 ISO 8601 字符串。 [en-US] The log creation time as an ISO 8601 string. */
    readonly timestamp: string;
    /** [zh-CN] 日志级别。 [en-US] The log level. */
    readonly level: LogLevel;
    /** [zh-CN] SDK 日志正文。 [en-US] The SDK log message. */
    readonly message: string;
    /** [zh-CN] 已按 SDK 日志规则脱敏的附加参数。 [en-US] Additional arguments sanitized according to the SDK logging rules. */
    readonly args: ReadonlyArray<unknown>;
}
