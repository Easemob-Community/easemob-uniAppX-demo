/**
 * 连接相关类型定义
 */
/**
 * [zh-CN] 连接状态常量。
 * [en-US] Connection status constants.
 */
export declare const ConnectionStatus: {
    readonly DISCONNECTED: "disconnected";
    readonly CONNECTING: "connecting";
    readonly CONNECTED: "connected";
    readonly RECONNECTING: "reconnecting";
    readonly RECONNECT_FAILED: "reconnectFailed";
};
/**
 * [zh-CN] SDK 连接状态。
 * [en-US] SDK connection status.
 */
export type ConnectionStatus = (typeof ConnectionStatus)[keyof typeof ConnectionStatus];
/**
 * [zh-CN] 连接事件名称常量。
 * [en-US] Connection event name constants.
 */
export declare const ConnectionEventName: {
    readonly CONNECTING: "onConnecting";
    readonly CONNECTED: "onConnected";
    readonly DISCONNECTED: "onDisconnected";
    readonly RECONNECT_FAILED: "onReconnectFailed";
    readonly TOKEN_WILL_EXPIRE: "onTokenWillExpire";
    readonly TOKEN_EXPIRED: "onTokenExpired";
    readonly OFFLINE_MESSAGE_SYNC_START: "onOfflineMessageSyncStart";
    readonly OFFLINE_MESSAGE_SYNC_FINISH: "onOfflineMessageSyncFinish";
};
/**
 * [zh-CN] 连接事件名称。
 * [en-US] Connection event name.
 */
export type ConnectionEventName = (typeof ConnectionEventName)[keyof typeof ConnectionEventName];
/** @internal 内部事件名称常量。 */
export declare const InternalEventName: {
    readonly SEND_TIMEOUT: "onSendTimeout";
    readonly GROUP_NOTIFY: "onGroupNotify";
    readonly CHATROOM_NOTIFY: "onChatRoomNotify";
    readonly CHAT_THREAD_NOTIFY: "onChatThreadNotify";
    readonly USER_INFO_NOTIFY: "onUserInfoNotify";
    readonly MESSAGE_SENT: "__internal:onMessageSent";
};
/** @internal 内部事件名称类型。 */
export type InternalEventName = (typeof InternalEventName)[keyof typeof InternalEventName];
/**
 * [zh-CN] 连接状态变化原因常量。
 * [en-US] Connection state change reason constants.
 */
export declare const ConnectionEventReason: {
    readonly LOGIN: "login";
    readonly RECONNECT: "reconnect";
    readonly ONLINE: "online";
    readonly OFFLINE_RECOVER: "offline-recover";
    readonly HEARTBEAT_FAILED: "heartbeat-failed";
    readonly SEND_TIMEOUT: "send-timeout";
    readonly CLOSE: "close";
    readonly ERROR: "error";
    readonly TIMEOUT: "timeout";
    readonly LIMIT: "limit";
    readonly OFFLINE: "offline";
    readonly TOKEN_EXPIRED: "token-expired";
};
/**
 * [zh-CN] 连接状态变化原因。
 * [en-US] Reason for a connection state change.
 */
export type ConnectionEventReason = (typeof ConnectionEventReason)[keyof typeof ConnectionEventReason];
/**
 * [zh-CN] 连接事件载荷。
 * [en-US] Connection event payload.
 */
export interface ConnectionEventPayload {
    /** [zh-CN] 当前连接状态。 [en-US] Current connection status. */
    readonly state: ConnectionStatus;
    /** [zh-CN] 触发本次事件的原因。 [en-US] Reason that triggered this event. */
    readonly reason: ConnectionEventReason;
    /** [zh-CN] 当前重连尝试次数。 [en-US] Current reconnection attempt number. */
    readonly attempt: number;
    /** [zh-CN] 允许的最大重连次数。 [en-US] Maximum allowed reconnection attempts. */
    readonly maxAttempts: number;
    /** [zh-CN] 是否处于登录阶段。 [en-US] Whether the SDK is in the login phase. */
    readonly isLoginPhase: boolean;
    /** [zh-CN] 当前网络是否在线。 [en-US] Whether the network is currently online. */
    readonly isOnline: boolean;
    /** [zh-CN] 触发事件的错误码。 [en-US] Error code that triggered the event. */
    readonly errorCode?: number;
    /** [zh-CN] 触发事件的错误消息。 [en-US] Error message that triggered the event. */
    readonly errorMessage?: string;
    /** [zh-CN] 事件时间戳，单位毫秒。 [en-US] Event timestamp in milliseconds. */
    readonly timestamp: number;
}
/**
 * [zh-CN] 消息发送超时事件载荷。
 * [en-US] Message send timeout event payload.
 */
export interface SendTimeoutEventPayload {
    /** [zh-CN] 固定为发送超时原因。 [en-US] Always the send-timeout reason. */
    readonly reason: typeof ConnectionEventReason.SEND_TIMEOUT;
    /** [zh-CN] 事件时间戳，单位毫秒。 [en-US] Event timestamp in milliseconds. */
    readonly timestamp: number;
}
/**
 * [zh-CN] Token 生命周期事件载荷；此类事件不携带 token 或鉴权信息。
 * [en-US] Token lifecycle event payload; these events do not include token or authentication data.
 */
export type TokenLifecycleEventPayload = undefined;
