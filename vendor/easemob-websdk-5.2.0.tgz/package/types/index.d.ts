/**
 * IM SDK Web - 类型定义
 *
 * 所有公共类型定义，不使用 namespace，支持自动生成类型声明文件
 */
import type { ConnectionStatus } from './connection';
import type { ChatThreadMessageContext, ChatThreadOverview } from './chat-thread';
import type { ChatConversationType } from './message-conversation';
import type { Sender } from './sender';
export * from './chat-client';
export * from './log';
export * from './sync-data';
export * from './connection';
export { ChatEventName, ChatRoomDispatchEventName, ContactEventName, GroupEventName, LogEventName, PresenceEventName, PushEventName, UserInfoEventName, } from './event-system';
export type { ChatEventHandlerMap, // Chat 事件处理器映射
ChatEventPayloadMap, // Chat 事件载荷映射
ContactEventHandlerMap, // 联系人事件处理器映射
ContactEventPayloadMap, // 联系人事件载荷映射
ChatRoomDispatchEventName as ChatRoomDispatchEventNameType, // ChatRoom 内部事件名称
ChatRoomInternalEventHandlerMap, // ChatRoom 内部事件处理器映射
ChatRoomInternalEventPayloadMap, // ChatRoom 内部事件载荷映射
ConnectionEventHandlerMap, // 连接事件处理器映射
ConnectionEventPayloadMap, // 连接事件载荷映射
EventHandlerId, // 事件处理器 ID
EventHandlerMap, // 通用事件处理器映射
EventName, // 统一事件名称
EventPayloadMap, // 事件载荷映射
GroupEventHandlerMap, // 群组事件处理器映射
GroupEventPayloadMap, // 群组事件载荷映射
LogEventHandlerMap, // 日志事件处理器映射
LogEventPayloadMap, // 日志事件载荷映射
PushEventHandlerMap, PushEventPayloadMap, UserInfoEventHandlerMap, // 用户资料事件处理器映射
UserInfoEventPayloadMap, } from './event-system';
export * from './manager';
export * from './message-create';
export * from './message-conversation';
export * from './chat-manager';
export * from './presence';
export * from './push';
export * from './contact';
export * from './chatroom';
export * from './group';
export * from './multi-device';
export * from './user-info';
export * from './chat-thread';
export type { Sender } from './sender';
/**
 * [zh-CN] SDK 支持的消息类型。
 * [en-US] Message types supported by the SDK.
 */
export type MessageType = 'text' | 'image' | 'file' | 'voice' | 'video' | 'location' | 'custom' | 'cmd' | 'combine' | 'multi_body';
/**
 * [zh-CN] 图片资源类型常量。
 * [en-US] Image resource type constants.
 */
export declare const ImageType: {
    readonly ORIGINAL: "original";
    readonly LARGE: "large";
};
/**
 * [zh-CN] 图片资源类型。
 * [en-US] Image resource type.
 */
export type ImageType = (typeof ImageType)[keyof typeof ImageType];
/**
 * [zh-CN] 流式消息状态常量。
 * [en-US] Stream message status constants.
 */
export declare const StreamMessageStatus: {
    readonly START: "STREAM_START";
    readonly START_COMPLETED: "STREAM_START_COMPLETED";
    readonly IN_PROGRESS: "STREAM_IN_PROGRESS";
    readonly COMPLETED: "STREAM_COMPLETED";
    /** @internal [zh-CN] 服务端全文兜底状态，不通过 onStreamMessage 对外派发。 [en-US] Server full-text fallback status; never emitted through onStreamMessage. */
    readonly FULL: "STREAM_FULL";
    readonly ERROR: "STREAM_ERROR";
};
/**
 * [zh-CN] 流式消息状态。
 * [en-US] Stream message status.
 */
export type StreamMessageStatus = (typeof StreamMessageStatus)[keyof typeof StreamMessageStatus];
/**
 * [zh-CN] 消息发送状态。
 * [en-US] Message sending status.
 */
export type MessageSendStatus = 'sending' | 'sent' | 'failed';
/**
 * [zh-CN] 消息方向。
 * [en-US] Message direction.
 */
export type MessageDirect = 'SEND' | 'RECEIVE';
/**
 * [zh-CN] 消息优先级。
 * [en-US] Message priority.
 */
export type MessagePriority = 'high' | 'normal' | 'low';
/**
 * [zh-CN] 消息修改信息。
 * [en-US] Message modification information.
 */
export interface MessageModifiedInfo {
    /** [zh-CN] 最后一次修改消息的操作者用户 ID。 [en-US] User ID of the user who last modified the message. */
    operatorId: string;
    /** [zh-CN] 消息已被修改的次数。 [en-US] Number of times the message has been modified. */
    operationCount: number;
    /** [zh-CN] 最后一次修改消息的时间戳，单位毫秒。 [en-US] Timestamp in milliseconds when the message was last modified. */
    operationTime: number;
}
/**
 * 连接状态（联合类型，不使用 enum）
 * 由 src/types/connection.ts 统一定义
 */
/**
 * [zh-CN] 小程序或 uni-app 本地文件对象。
 * [en-US] Local file descriptor for Mini Program or uni-app runtimes.
 */
export interface MiniAppFile {
    /** [zh-CN] 本地文件路径。 [en-US] Local file path. */
    path: string;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    size?: number;
    /** [zh-CN] 文件名称。 [en-US] File name. */
    name?: string;
    /** [zh-CN] 文件 MIME 类型。 [en-US] File MIME type. */
    type?: string;
}
/**
 * [zh-CN] React Native 本地文件对象。
 * [en-US] Local file descriptor for React Native runtimes.
 */
export interface ReactNativeFile {
    /** [zh-CN] React Native 文件 URI。 [en-US] React Native file URI. */
    uri: string;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    size?: number;
    /** [zh-CN] 文件名称。 [en-US] File name. */
    name?: string;
    /** [zh-CN] 文件 MIME 类型。 [en-US] File MIME type. */
    type?: string;
}
/**
 * [zh-CN] 跨端文件对象，可以是 Web `File`、小程序文件或 React Native 文件。
 * [en-US] Cross-platform file descriptor represented by a Web `File`, Mini Program file, or React Native file.
 */
export type CompatibleFile = File | MiniAppFile | ReactNativeFile;
/**
 * [zh-CN] 文本消息体。
 * [en-US] Text message body.
 */
export interface TextMessageBody {
    /** [zh-CN] 消息文本内容。 [en-US] Message text content. */
    content: string;
    /** [zh-CN] 发送前自动翻译的目标语言代码列表，不传或空数组不翻译。 [en-US] Target language codes for automatic translation before sending; omitted or empty arrays disable translation. */
    targetLanguages?: string[];
    /** [zh-CN] 语言代码到译文的映射，由自动发送翻译或接收解码填充；主动翻译 API 仅返回结果。 [en-US] Language-to-text map populated by automatic translation on send or incoming decoding; the explicit translation API only returns results. */
    translations?: Record<string, string>;
}
/**
 * [zh-CN] 图片消息体。
 * [en-US] Image message body.
 */
export interface ImageMessageBody {
    /** [zh-CN] 本地可用地址；远端消息中为空字符串。 [en-US] Locally accessible URL; an empty string for remote messages. */
    localUrl: string;
    /** [zh-CN] 文件名，发送前由 SDK 自动补全。 [en-US] File name, populated by the SDK before sending. */
    filename?: string;
    /** [zh-CN] 文件 MIME 类型，发送前由 SDK 自动补全。 [en-US] File MIME type, populated by the SDK before sending. */
    filetype?: string;
    /** [zh-CN] 图片宽度，单位像素。 [en-US] Image width in pixels. */
    width?: number;
    /** [zh-CN] 图片高度，单位像素。 [en-US] Image height in pixels. */
    height?: number;
    /** [zh-CN] 是否为 GIF 图片。 [en-US] Whether the image is a GIF. */
    isGif: boolean;
    /** [zh-CN] 是否按原图语义发送。 [en-US] Whether to send the original image. */
    isOriginalImage: boolean;
    /** [zh-CN] 原图远程地址。 [en-US] Remote URL of the original image. */
    originalImageUrl?: string;
    /** [zh-CN] 大图远程地址。 [en-US] Remote URL of the large image. */
    bigImageUrl?: string;
    /** [zh-CN] 附件下载密钥。 [en-US] Attachment download secret. */
    secret?: string;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    fileLength?: number;
    /** [zh-CN] 缩略图地址。 [en-US] Thumbnail URL. */
    thumbnailUrl?: string;
}
/**
 * [zh-CN] 文件消息体。
 * [en-US] File message body.
 */
export interface FileMessageBody {
    /** [zh-CN] 服务端或本地可用的文件地址。 [en-US] Server or locally accessible file URL. */
    url?: string;
    /** [zh-CN] 文件名，发送前由 SDK 自动补全。 [en-US] File name, populated by the SDK before sending. */
    filename?: string;
    /** [zh-CN] 文件 MIME 类型，发送前由 SDK 自动补全。 [en-US] File MIME type, populated by the SDK before sending. */
    filetype?: string;
    /** [zh-CN] 待发送文件大小，单位字节。 [en-US] Size of the file to send, in bytes. */
    fileSize?: number;
    /** [zh-CN] 服务端返回的文件大小，单位字节。 [en-US] Server-reported file size in bytes. */
    fileLength?: number;
    /** [zh-CN] 附件下载密钥。 [en-US] Attachment download secret. */
    secret?: string;
}
/**
 * [zh-CN] 语音消息体。
 * [en-US] Voice message body.
 */
export interface VoiceMessageBody {
    /** [zh-CN] 服务端或本地可用的语音地址。 [en-US] Server or locally accessible voice URL. */
    url?: string;
    /** [zh-CN] 文件名，发送前由 SDK 自动补全。 [en-US] File name, populated by the SDK before sending. */
    filename?: string;
    /** [zh-CN] 文件 MIME 类型，发送前由 SDK 自动补全。 [en-US] File MIME type, populated by the SDK before sending. */
    filetype?: string;
    /** [zh-CN] 语音时长，单位秒。 [en-US] Voice duration in seconds. */
    duration: number;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    fileLength?: number;
    /** [zh-CN] 附件下载密钥。 [en-US] Attachment download secret. */
    secret?: string;
}
/**
 * [zh-CN] 视频消息体。
 * [en-US] Video message body.
 */
export interface VideoMessageBody {
    /** [zh-CN] 服务端或本地可用的视频地址。 [en-US] Server or locally accessible video URL. */
    url?: string;
    /** [zh-CN] 文件名，发送前由 SDK 自动补全。 [en-US] File name, populated by the SDK before sending. */
    filename?: string;
    /** [zh-CN] 文件 MIME 类型，发送前由 SDK 自动补全。 [en-US] File MIME type, populated by the SDK before sending. */
    filetype?: string;
    /** [zh-CN] 视频时长，单位秒。 [en-US] Video duration in seconds. */
    duration: number;
    /** [zh-CN] 视频宽度，单位像素。 [en-US] Video width in pixels. */
    width?: number;
    /** [zh-CN] 视频高度，单位像素。 [en-US] Video height in pixels. */
    height?: number;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    fileLength?: number;
    /** [zh-CN] 附件下载密钥。 [en-US] Attachment download secret. */
    secret?: string;
    /** [zh-CN] 视频缩略图地址。 [en-US] Video thumbnail URL. */
    thumbnailUrl?: string;
}
/**
 * [zh-CN] 位置消息体。
 * [en-US] Location message body.
 */
export interface LocationMessageBody {
    /** [zh-CN] 纬度。 [en-US] Latitude. */
    latitude: number;
    /** [zh-CN] 经度。 [en-US] Longitude. */
    longitude: number;
    /** [zh-CN] 地址描述。 [en-US] Address description. */
    address?: string;
    /** [zh-CN] 建筑名称。 [en-US] Building name. */
    buildingName?: string;
}
/**
 * [zh-CN] 命令消息体。
 * [en-US] Command message body.
 */
export interface CmdMessageBody {
    /** [zh-CN] 命令动作名称。 [en-US] Command action name. */
    action: string;
    /** [zh-CN] 是否仅投递给在线用户。 [en-US] Whether to deliver only to online users. */
    deliverOnlineOnly?: boolean;
}
/**
 * [zh-CN] 自定义消息体。
 * [en-US] Custom message body.
 */
export interface CustomMessageBody {
    /** [zh-CN] 自定义事件名称。 [en-US] Custom event name. */
    event: string;
    /** [zh-CN] 自定义字符串参数。 [en-US] Custom string parameters. */
    params?: Record<string, string>;
}
/**
 * 合并消息中的子消息结构
 */
/**
 * [zh-CN] 合并消息体。
 * [en-US] Combined message body.
 */
export interface CombineMessageBody {
    /** [zh-CN] 合并消息标题。 [en-US] Combined message title. */
    title: string;
    /** [zh-CN] 合并消息摘要。 [en-US] Combined message summary. */
    summary: string;
    /** [zh-CN] 子消息列表，仅在发送或详情解码场景提供。 [en-US] Child messages, provided only when sending or decoding details. */
    messageList?: ReadonlyArray<Message>;
    /** [zh-CN] 合并消息详情下载地址。 [en-US] Download URL for the combined message details. */
    url?: string;
    /** [zh-CN] 合并消息详情文件名。 [en-US] File name of the combined message details. */
    filename: string;
    /** [zh-CN] 合并消息详情文件类型。 [en-US] File type of the combined message details. */
    filetype: string;
    /** [zh-CN] 合并消息详情文件大小，单位字节。 [en-US] Size of the combined message details in bytes. */
    fileLength?: number;
    /** [zh-CN] 合并消息详情下载密钥。 [en-US] Download secret for the combined message details. */
    secret?: string;
    /** [zh-CN] 当前合并消息嵌套层级。 [en-US] Current nesting level of the combined message. */
    combineLevel: number;
}
/**
 * [zh-CN] 复合消息中的一段可组合内容。`type` 只出现在复合消息的分段上。
 * [en-US] One segment inside a multi_body message. `type` exists only on these segments.
 */
export type MultiBodySegment = ({
    type: 'text';
} & TextMessageBody) | ({
    type: 'image';
} & ImageMessageBody) | ({
    type: 'file';
} & FileMessageBody) | ({
    type: 'voice';
} & VoiceMessageBody) | ({
    type: 'video';
} & VideoMessageBody) | ({
    type: 'location';
} & LocationMessageBody) | ({
    type: 'custom';
} & CustomMessageBody);
/**
 * [zh-CN] 复合消息正文。分段按发送顺序排列，至少 2 段。
 * [en-US] Body of a multi_body message. Segments stay in send order and there are at least two.
 */
export type MultiBody = ReadonlyArray<MultiBodySegment>;
/**
 * [zh-CN] 所有消息体的联合类型。
 * [en-US] Union of all message body types.
 */
export type MessageBody = TextMessageBody | ImageMessageBody | FileMessageBody | VoiceMessageBody | VideoMessageBody | LocationMessageBody | CmdMessageBody | CustomMessageBody | CombineMessageBody | MultiBody;
/**
 * [zh-CN] 消息对象。
 * [en-US] Message object.
 */
export interface Message {
    /** [zh-CN] 服务端消息 ID。 [en-US] Server-assigned message ID. */
    msgServerId: string;
    /** [zh-CN] 本地消息 ID。 [en-US] Local message ID. */
    msgLocalId: string;
    /** [zh-CN] 发送方标识。自己其他设备发给当前设备时为 `当前用户ID/来源设备ID`，其他场景为用户 ID。 [en-US] Sender identifier. For a message sent from another device of the current user to this device, the value is `currentUserId/sourceDeviceId`; otherwise, it is the user ID. */
    from: string;
    /** [zh-CN] 接收方标识：指定当前用户的其他设备时为 `当前用户ID/目标设备ID`，普通单聊为用户 ID，群聊为群组 ID，聊天室为聊天室 ID。 [en-US] Recipient identifier: `currentUserId/targetDeviceId` when targeting another device of the current user, user ID for regular one-to-one chat, group ID for group chat, or chat room ID for chat room. */
    to: string;
    /** [zh-CN] 发送者资料摘要。 [en-US] Sender profile summary. */
    sender: Sender;
    /** [zh-CN] 会话 ID；当前用户设备间单聊使用 `当前用户ID/对端设备ID`。 [en-US] Conversation ID. One-to-one conversations between devices of the current user use `currentUserId/peerDeviceId`. */
    conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    conversationType: ChatConversationType;
    /** [zh-CN] 消息类型。 [en-US] Message type. */
    type: MessageType;
    /** [zh-CN] 消息发送状态；`sent` 表示服务端已接受消息，不表示对端已读。 [en-US] Message sending status. `sent` means the server accepted the message, not that the peer has read it. */
    sendStatus: MessageSendStatus;
    /** [zh-CN] 消息扩展字段。 [en-US] Message extension payload. */
    ext: Record<string, unknown>;
    /** [zh-CN] 消息时间戳，单位毫秒。 [en-US] Message timestamp in milliseconds. */
    timestamp: number;
    /** [zh-CN] 消息体。复合消息时这里直接是分段数组。 [en-US] Message body. For a multi_body message, this is the segment array. */
    body: MessageBody;
    /** [zh-CN] 消息方向。 [en-US] Message direction. */
    direct?: MessageDirect;
    /** [zh-CN] 是否为在线消息；`false` 表示离线消息。 [en-US] Whether the message is online; `false` for offline. */
    isOnline?: boolean;
    /** [zh-CN] 群聊或聊天室定向消息的接收者列表。 [en-US] Recipient IDs for a targeted group or chat-room message. */
    receiverList?: string[];
    /** [zh-CN] 是否仅投递给在线用户。 [en-US] Whether to deliver only to online users. */
    deliverOnlineOnly?: boolean;
    /** [zh-CN] 发送消息协议中的 webhookEnv 字段。 [en-US] Webhook environment identifier in the message sending protocol.*/
    webhookEnv?: string;
    /** [zh-CN] 消息优先级。 [en-US] Message priority. */
    priority?: MessagePriority;
    /** [zh-CN] 是否为广播消息，主要用于聊天室下行场景。 [en-US] Whether this is a broadcast message, primarily for chat-room inbound scenarios. */
    isBroadcast?: boolean;
    /** [zh-CN] 内容是否被审核替换。 [en-US] Whether the content was replaced by moderation. */
    isContentReplaced?: boolean;
    /** [zh-CN] 合并消息层级，仅 `type=combine` 时有意义。 [en-US] Combined message level; only valid when `type=combine`. */
    combineLevel?: number;
    /** [zh-CN] 流式消息元信息，仅流式消息回调场景提供。 [en-US] Stream message metadata, provided only in stream-message callbacks. */
    stream?: StreamMessageMeta;
    /** [zh-CN] 消息的表情回应列表。 [en-US] Message Reaction list. */
    reactions?: MessageReaction[];
    /** [zh-CN] 群消息已读人数。 [en-US] Number of users who have read the group message. */
    groupReadCount?: number;
    /** [zh-CN] 单聊发送消息是否已被对端阅读；仅发送方单聊消息有意义，`undefined` 表示未知或不适用。 [en-US] Whether an outgoing one-to-one message has been read by the peer. Only meaningful for outgoing one-to-one messages; `undefined` means unknown or not applicable. */
    isPeerRead?: boolean;
    /** [zh-CN] 是否需要消息已读回执。 [en-US] Whether message read receipts are requested. */
    needReadReceipt?: boolean;
    /** [zh-CN] 是否为 Thread 回复消息。 [en-US] Whether this message is a chat thread reply. */
    isChatThread?: boolean;
    /** [zh-CN] Thread 消息上下文；接收 Thread 回复消息时返回。 [en-US] Chat thread context returned when receiving a thread reply message. */
    chatThread?: ChatThreadMessageContext;
    /** [zh-CN] Thread 概览；父群消息携带 Thread 概览时返回。 [en-US] Chat thread overview returned when a parent group message carries thread overview data. */
    chatThreadOverview?: ChatThreadOverview;
    /** [zh-CN] 消息修改信息；消息被编辑后返回或下发。 [en-US] Message modification information returned or delivered after the message is edited. */
    modifiedInfo?: MessageModifiedInfo;
}
/**
 * [zh-CN] 消息表情回应。
 * [en-US] Message reaction.
 */
export interface MessageReaction {
    /** [zh-CN] 表情标识。[en-US] Reaction emoji identifier. */
    reaction: string;
    /** [zh-CN] 该表情的回应人数。 [en-US] Number of users who reacted with this emoji. */
    count: number;
    /** [zh-CN] Reaction 更新操作列表。[en-US] List of update operations for this Reaction. */
    op?: ReadonlyArray<{
        /** [zh-CN] 操作者用户 ID。[en-US] User ID of the operator. */
        operator: string;
        /** [zh-CN] 操作类型：create 表示添加，delete 表示删除。[en-US] Operation type: `create` means addition, `delete` means removal. */
        reactionType: 'create' | 'delete';
    }>;
    /** [zh-CN] 回应的用户 ID 列表。[en-US] List of user IDs who have added this Reaction. */
    userList: string[];
    /** [zh-CN] 当前用户是否已添加该表情。[en-US] Whether the current user has added this Reaction.  */
    isAddedBySelf?: boolean;
}
/**
 * [zh-CN] 合并消息对象。
 * [en-US] Combined message object.
 */
export interface CombineMessage extends Message {
    /** [zh-CN] 固定为合并消息类型。 [en-US] Always the combined message type. */
    type: 'combine';
    /** [zh-CN] 合并消息体。 [en-US] Combined message body. */
    body: CombineMessageBody;
}
/**
 * [zh-CN] 流式消息的分片、状态和文本元信息。
 * [en-US] Chunk, status, and text metadata for a stream message.
 */
export interface StreamMessageMeta {
    /** [zh-CN] 业务自定义流类型。 [en-US] Business-defined stream type. */
    customType?: string;
    /** [zh-CN] 当前分片序号。 [en-US] Sequence number of the current chunk. */
    seq: number;
    /** [zh-CN] 当前对外流式消息状态；单片完成为 `STREAM_START_COMPLETED`，不会回调内部 `STREAM_FULL`。 [en-US] Current public stream message status; a single completed chunk uses `STREAM_START_COMPLETED`, while internal `STREAM_FULL` is never emitted. */
    status: StreamMessageStatus;
    /** [zh-CN] 流式处理错误码；`0` 表示无错误。 [en-US] Stream processing error code; `0` means no error. */
    errorType: number;
    /** [zh-CN] 服务端返回的结束原因。 [en-US] Completion reason returned by the server. */
    finishReason?: number;
    /** [zh-CN] 当前分片新增的文本。 [en-US] Text added by the current chunk. */
    deltaText: string;
    /** [zh-CN] 截至当前分片累计的完整文本。 [en-US] Full text accumulated through the current chunk. */
    fullText: string;
}
/**
 * [zh-CN] 通过流式消息事件派发的文本消息。
 * [en-US] Text message dispatched through the stream message event.
 */
export interface StreamMessage extends Message {
    /** [zh-CN] 流式消息按文本消息语义提供。 [en-US] Stream messages use text message semantics. */
    type: 'text';
    /** [zh-CN] 流式文本消息体。 [en-US] Stream text message body. */
    body: TextMessageBody;
    /** [zh-CN] 必填的流式消息元信息。 [en-US] Required stream message metadata. */
    stream: StreamMessageMeta;
}
/**
 * [zh-CN] 文件上传进度。
 * [en-US] File upload progress.
 */
export interface FileUploadProgress {
    /** [zh-CN] 已上传字节数。复合消息按全部附件文件大小合计。 [en-US] Number of uploaded bytes. MultiBody messages use the combined size of all attachments. */
    loaded: number;
    /** [zh-CN] 附件总字节数。复合消息是各附件文件大小之和。 [en-US] Total attachment size in bytes. MultiBody messages use the sum of every attachment file size. */
    total?: number;
    /** [zh-CN] 相对全部附件总大小的上传百分比。 [en-US] Upload percentage relative to the total size of all attachments. */
    percent?: number;
}
/**
 * [zh-CN] 文件上传完成结果。
 * [en-US] File upload completion result.
 */
export interface FileUploadResult {
    /** [zh-CN] 文件远程地址。 [en-US] Remote file URL. */
    url?: string;
    /** [zh-CN] 是否按原图语义上传。 [en-US] Whether the upload uses original-image semantics. */
    isOriginalImage?: boolean;
    /** [zh-CN] 原图地址。 [en-US] Original image URL. */
    originalImageUrl?: string;
    /** [zh-CN] 大图地址。 [en-US] Large image URL. */
    bigImageUrl?: string;
    /** [zh-CN] 下载密钥。 [en-US] Download secret. */
    secret?: string;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    fileLength?: number;
    /** [zh-CN] 文件 MIME 类型。 [en-US] File MIME type. */
    filetype?: string;
    /** [zh-CN] 文件名。 [en-US] Filename. */
    filename?: string;
    /** [zh-CN] 缩略图地址。 [en-US] Thumbnail URL. */
    thumbnailUrl?: string;
    /** [zh-CN] 图片或视频宽度，单位像素。 [en-US] Image or video width in pixels. */
    width?: number;
    /** [zh-CN] 图片或视频高度，单位像素。 [en-US] Image or video height in pixels. */
    height?: number;
}
/**
 * [zh-CN] 发送消息的可选回调。
 * [en-US] Optional callbacks for sending a message.
 */
export interface SendMessageOptions {
    /** [zh-CN] 消息开始发送时触发。 [en-US] Triggered when the message starts sending.  */
    onSending?: (message: Message) => void;
    /** [zh-CN] 消息发送成功时触发。 [en-US] Triggered when the message is successfully sent.  */
    onSuccess?: (message: Message) => void;
    /** [zh-CN] 消息发送失败时触发。 [en-US] Triggered when the message fails to send. */
    onFailed?: (message: Message, error: Error) => void;
    /** [zh-CN] 附件上传进度回调。 [en-US] Triggered when the attachment upload progress updates.  */
    onFileUploadProgress?: (progress: FileUploadProgress) => void;
    /** [zh-CN] 附件上传完成回调。 [en-US] Triggered when the attachment upload completes successfully.  */
    onFileUploadComplete?: (result: FileUploadResult) => void;
    /** [zh-CN] 附件上传失败回调。 [en-US] Triggered when the attachment upload fails. */
    onFileUploadError?: (error: Error) => void;
    /** [zh-CN] 附件上传取消回调。 [en-US] Triggered when the attachment upload is cancelled. */
    onFileUploadCanceled?: () => void;
}
/**
 * [zh-CN] 下载并解析合并消息（Merged Message）的最小请求参数，通常来源于合并消息体中的 `url` 与 `secret`。
 * [en-US] Minimal request parameters for downloading and parsing a combined message, typically extracted from the `url` and `secret` properties of the combined message body.
 */
export interface DownloadCombineMessageParams {
    /** [zh-CN] 合并消息详情数据的下载 URL。 [en-US] The download URL for the combined message details. */
    url: string;
    /** [zh-CN] 下载安全密钥；若服务端未下发则无需传入。 [en-US] The download secret; omit if not provided by the server. */
    secret?: string;
    /** [zh-CN] 下载超时时间，单位为毫秒；若未指定则使用 SDK 默认配置。 [en-US] Download timeout in milliseconds; if unspecified, the SDK default will be used. */
    timeoutMs?: number;
    /** [zh-CN] 单次操作允许解码的最大消息条数；若未指定，默认最多支持 300 条。 [en-US] Maximum number of messages allowed to be decoded in a single operation. It defaults to a maximum of 300 items if unspecified. */
    maxItems?: number;
}
/**
 * [zh-CN] 当前连接的内存态信息；该对象不会持久化。
 * [en-US] In-memory state of the current connection; this object is not persisted.
 */
export interface Connection {
    /** [zh-CN] 当前连接状态。 [en-US] Current connection status. */
    status: ConnectionStatus;
    /** [zh-CN] 当前服务器地址。 [en-US] Current server URL. */
    serverUrl: string;
    /** [zh-CN] 当前用户 ID。 [en-US] Current user ID. */
    userId?: string;
    /** [zh-CN] 当前认证令牌。 [en-US] Current authentication token. */
    token?: string;
    /** [zh-CN] 最近一次连接成功的时间戳，单位毫秒。 [en-US] Timestamp of the latest successful connection, in milliseconds. */
    lastConnectedAt?: number;
    /** [zh-CN] 当前重连尝试次数。 [en-US] Current number of reconnection attempts. */
    reconnectAttempts: number;
    /** [zh-CN] 最近一次连接错误。 [en-US] Most recent connection error. */
    error?: Error;
}
/**
 * 类型守卫：判断是否为文本消息体
 */
export declare function isTextMessageBody(body: MessageBody): body is TextMessageBody;
/**
 * 类型守卫：判断是否为图片消息体
 */
export declare function isImageMessageBody(body: MessageBody): body is ImageMessageBody;
/**
 * 类型守卫：判断是否为文件消息体
 */
export declare function isFileMessageBody(body: MessageBody): body is FileMessageBody;
/**
 * 类型守卫：判断是否为语音消息体
 */
export declare function isVoiceMessageBody(body: MessageBody): body is VoiceMessageBody;
/**
 * 类型守卫：判断是否为视频消息体
 */
export declare function isVideoMessageBody(body: MessageBody): body is VideoMessageBody;
/**
 * 类型守卫：判断是否为位置消息体
 */
export declare function isLocationMessageBody(body: MessageBody): body is LocationMessageBody;
/**
 * 类型守卫：判断是否为命令消息体
 */
export declare function isCmdMessageBody(body: MessageBody): body is CmdMessageBody;
/**
 * 类型守卫：判断是否为自定义消息体
 */
export declare function isCustomMessageBody(body: MessageBody): body is CustomMessageBody;
/**
 * 类型守卫：判断是否为合并消息体
 */
export declare function isCombineMessageBody(body: MessageBody): body is CombineMessageBody;
/**
 * 类型守卫：判断是否为流式消息
 */
export declare function isStreamMessage(message: Message): message is StreamMessage;
