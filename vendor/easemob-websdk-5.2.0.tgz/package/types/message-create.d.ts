/**
 * [zh-CN] 创建消息方法的入参类型定义。
 * [en-US] Parameter type definitions for message creation APIs.
 */
import type { ChatConversationType, CompatibleFile, MultiBodySegment, Message, MessagePriority } from './index';
/**
 * [zh-CN] 创建消息的通用入参。
 * [en-US] Common parameters for creating messages.
 */
export interface CreateMessageBaseParams {
    /** [zh-CN] 会话 ID：单聊时为对端用户 ID；向当前用户的指定其他设备发消息时，可传 `当前用户ID/设备ID`；群聊时为群组 ID，聊天室时为聊天室 ID。 [en-US] Conversation ID. For one-to-one chat, this is the peer user ID; use `currentUserId/deviceId` to target another device of the current user; for group chat, the group ID; for chat room, the chat room ID. */
    conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    conversationType: ChatConversationType;
    /** [zh-CN] 消息扩展字段，需保持 JSON 可序列化。 [en-US] Message extension data. The value must be JSON-serializable. */
    ext?: Record<string, unknown>;
    /** [zh-CN] 本地时间戳，单位毫秒；不传时由 SDK 生成。 [en-US] Local timestamp in milliseconds. If omitted, the SDK generates it automatically. */
    timestamp?: number;
    /** [zh-CN] 群聊或聊天室定向消息的接收者列表；单聊不支持。 [en-US] Recipient IDs for a targeted group or chat-room message. Not supported for one-to-one chat. */
    receiverList?: string[];
    /** [zh-CN] 是否仅投递给在线用户。 [en-US] Whether to deliver only to online users. */
    deliverOnlineOnly?: boolean;
    /** [zh-CN] 消息协议中的 Webhook 环境标识。 [en-US] Webhook environment identifier in the message protocol. */
    webhookEnv?: string;
    /** [zh-CN] 消息优先级。 [en-US] Message priority. */
    priority?: MessagePriority;
    /** [zh-CN] 是否需要消息已读回执。单聊和群聊均可使用。 [en-US] Whether message read receipts are requested. Applies to both one-to-one and group chat. */
    needReadReceipt?: boolean;
    /** [zh-CN] 是否创建 Thread 回复消息，仅群聊 Thread 场景有效。 [en-US] Whether to create a chat thread reply message; only valid for group chat threads. */
    isChatThread?: boolean;
}
/**
 * [zh-CN] 创建文本消息的入参。
 * [en-US] Parameters for creating a text message.
 */
export interface CreateTextMessageParams extends CreateMessageBaseParams {
    /** [zh-CN] 文本消息内容。 [en-US] Text message content. */
    content: string;
    /** [zh-CN] 发送前自动翻译的目标语言列表；不传或空数组不翻译，翻译失败不发送。 [en-US] Target languages for automatic translation before sending; omitted or empty arrays disable translation, and translation failure prevents sending. */
    targetLanguages?: string[];
}
/**
 * [zh-CN] 创建图片消息的入参。`data` 与 `originalUrl` 至少传一个；传 `data` 时 SDK 会自动补齐文件信息，并在发送前解析图片宽高。
 * [en-US] Parameters for creating an image message. Either `data` or `originalUrl` must be provided. If `data` is supplied, the SDK will automatically populate file metadata and parse image dimensions before sending.
 */
export interface CreateImageMessageParams extends CreateMessageBaseParams {
    /** [zh-CN] 本地文件对象。 [en-US] Local file object. */
    data?: CompatibleFile;
    /** [zh-CN] 远程原图地址。 [en-US] URL of the remote original image. */
    originalUrl?: string;
    /** [zh-CN] 文件名；传 `data` 时可由 SDK 自动获取。 [en-US] File name. If `data` is provided, it can be auto-resolved by the SDK. */
    filename?: string;
    /** [zh-CN] 文件 MIME 类型；传 `data` 时可由 SDK 自动获取。 [en-US] MIME type of the file. If `data` is provided, it can be auto-resolved by the SDK. */
    filetype?: string;
    /** [zh-CN] 图片宽度，单位像素。 [en-US] Image width in pixels. */
    width?: number;
    /** [zh-CN] 图片高度，单位像素。 [en-US] Image height in pixels. */
    height?: number;
    /** [zh-CN] 是否为 GIF。 [en-US] Whether the image is a GIF animation. */
    isGif?: boolean;
    /** [zh-CN] 是否按原图语义发送。 [en-US] Whether to send with original image semantics. */
    isOriginalImage?: boolean;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    fileLength?: number;
    /** [zh-CN] 缩略图地址。 [en-US] Thumbnail URL. */
    thumbnailUrl?: string;
}
/**
 * [zh-CN] 创建文件消息的参数。`data` 与 `originalUrl` 至少提供一项；若提供 `data`，SDK 会自动补全文件信息。
 * [en-US] Parameters for creating a file message. Either `data` or `originalUrl` must be provided. If `data` is provided, the SDK will automatically parse and populate the file metadata.
 */
export interface CreateFileMessageParams extends CreateMessageBaseParams {
    /** [zh-CN] 本地文件对象。 [en-US] Local file object. */
    data?: CompatibleFile;
    /** [zh-CN] 远程文件地址。 [en-US] URL of the remote file. */
    originalUrl?: string;
    /** [zh-CN] 文件名；传 `data` 时可由 SDK 自动获取。 [en-US] File name. If `data` is provided, this can be automatically resolved by the SDK. */
    filename?: string;
    /** [zh-CN] 文件 MIME 类型；传 `data` 时可由 SDK 自动获取。 [en-US] File MIME type. If `data` is provided, this can be automatically resolved by the SDK.  */
    filetype?: string;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    fileSize?: number;
    /** [zh-CN] 文件长度，单位字节；兼容服务端字段。 [en-US] File length in bytes, used for server-side field compatibility.  */
    fileLength?: number;
}
/**
 * [zh-CN] 创建语音消息的入参。`data` 与 `originalUrl` 至少传一个。
 * [en-US] Parameters for creating a voice message. Either `data` or `originalUrl` must be provided.
 */
export interface CreateVoiceMessageParams extends CreateMessageBaseParams {
    /** [zh-CN] 本地语音文件对象。 [en-US] Local voice file object. */
    data?: CompatibleFile;
    /** [zh-CN] 远程语音地址。 [en-US] Remote voice URL. */
    originalUrl?: string;
    /** [zh-CN] 文件名；传 `data` 时可由 SDK 自动获取。 [en-US] File name. If `data` is provided, this can be automatically resolved by the SDK. */
    filename?: string;
    /** [zh-CN] 文件 MIME 类型；传 `data` 时可由 SDK 自动获取。 [en-US] File MIME type. If `data` is provided, this can be automatically resolved by the SDK. */
    filetype?: string;
    /** [zh-CN] 语音时长，单位秒。 [en-US] Voice duration in seconds. */
    duration: number;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    fileLength?: number;
}
/**
 * [zh-CN] 创建视频消息的入参。`data` 与 `originalUrl` 至少传一个。
 * [en-US] Parameters for creating a video message. Either `data` or `originalUrl` must be provided.
 */
export interface CreateVideoMessageParams extends CreateMessageBaseParams {
    /** [zh-CN] 本地视频文件对象。 [en-US] Local video file object. */
    data?: CompatibleFile;
    /** [zh-CN] 远程视频地址。 [en-US] Remote video URL. */
    originalUrl?: string;
    /** [zh-CN] 文件名；传 `data` 时可由 SDK 自动获取。 [en-US] File name. If `data` is provided, this can be automatically resolved by the SDK. */
    filename?: string;
    /** [zh-CN] 文件 MIME 类型；传 `data` 时可由 SDK 自动获取。 [en-US] File MIME type. If `data` is provided, this can be automatically resolved by the SDK. */
    filetype?: string;
    /** [zh-CN] 视频时长，单位秒。 [en-US] Video duration in seconds. */
    duration: number;
    /** [zh-CN] 视频宽度，单位像素。 [en-US] Video width in pixels. */
    width?: number;
    /** [zh-CN] 视频高度，单位像素。 [en-US] Video height in pixels. */
    height?: number;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    fileLength?: number;
    /** [zh-CN] 视频缩略图地址。 [en-US] Video thumbnail URL. */
    thumbnailUrl?: string;
}
/**
 * [zh-CN] 创建位置消息的入参。
 * [en-US] Parameters for creating a location message.
 */
export interface CreateLocationMessageParams extends CreateMessageBaseParams {
    /** [zh-CN] 纬度。 [en-US] Latitude. */
    latitude: number;
    /** [zh-CN] 经度。 [en-US] Longitude. */
    longitude: number;
    /** [zh-CN] 地址描述。 [en-US] Address description. */
    address?: string;
    /** [zh-CN] 建筑名称。 [en-US] Building name. */
    buildingName?: string;
}
/**
 * [zh-CN] 创建命令消息的入参。
 * [en-US] Parameters for creating a command message.
 */
export interface CreateCmdMessageParams extends CreateMessageBaseParams {
    /** [zh-CN] 命令动作。 [en-US] Command action. */
    action: string;
}
/**
 * [zh-CN] 创建自定义消息的入参。
 * [en-US] Parameters for creating a custom message.
 */
export interface CreateCustomMessageParams extends CreateMessageBaseParams {
    /** [zh-CN] 自定义事件名称。 [en-US] Custom event name. */
    event: string;
    /** [zh-CN] 自定义参数。 [en-US] Custom parameters. */
    params?: Record<string, string>;
}
/**
 * [zh-CN] 创建文本分段的入参。
 * [en-US] Parameters for creating a text segment.
 */
export interface CreateTextMessageBodyParams {
    /** [zh-CN] 文本内容，不能为空。 [en-US] Text content. An empty string is not allowed. */
    content: string;
    /** [zh-CN] 复合消息发送时不生效，这段文本不会被翻译。 [en-US] Has no effect when sending a multi_body message. This text segment is not translated. */
    targetLanguages?: string[];
}
/**
 * [zh-CN] 创建图片分段的入参。`data` 与 `originalUrl` 至少传一个。
 * [en-US] Parameters for creating an image segment. Either `data` or `originalUrl` is required.
 */
export interface CreateImageMessageBodyParams {
    /** [zh-CN] 本地图片文件。传入后必须把返回的同一个分段对象放进复合消息。 [en-US] Local image file. The returned segment object must be passed unchanged into the multi_body message. */
    data?: CompatibleFile;
    /** [zh-CN] 远程原图地址。 [en-US] Remote original image URL. */
    originalUrl?: string;
    /** [zh-CN] 文件名。传 `data` 时可由 SDK 在发送前补齐。 [en-US] File name. The SDK can fill it before sending when `data` is provided. */
    filename?: string;
    /** [zh-CN] 文件 MIME 类型。 [en-US] MIME type. */
    filetype?: string;
    /** [zh-CN] 图片宽度，单位像素。 [en-US] Image width in pixels. */
    width?: number;
    /** [zh-CN] 图片高度，单位像素。 [en-US] Image height in pixels. */
    height?: number;
    /** [zh-CN] 是否为 GIF。 [en-US] Whether the image is a GIF. */
    isGif?: boolean;
    /** [zh-CN] 是否按原图语义发送。 [en-US] Whether to send the original image. */
    isOriginalImage?: boolean;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    fileLength?: number;
    /** [zh-CN] 缩略图地址。 [en-US] Thumbnail URL. */
    thumbnailUrl?: string;
}
/**
 * [zh-CN] 创建文件分段的入参。`data` 与 `originalUrl` 至少传一个。
 * [en-US] Parameters for creating a file segment. Either `data` or `originalUrl` is required.
 */
export interface CreateFileMessageBodyParams {
    /** [zh-CN] 本地文件。 [en-US] Local file. */
    data?: CompatibleFile;
    /** [zh-CN] 远程文件地址。 [en-US] Remote file URL. */
    originalUrl?: string;
    /** [zh-CN] 文件名。 [en-US] File name. */
    filename?: string;
    /** [zh-CN] 文件 MIME 类型。 [en-US] MIME type. */
    filetype?: string;
    /** [zh-CN] 待发送文件大小，单位字节。 [en-US] File size in bytes. */
    fileSize?: number;
    /** [zh-CN] 文件长度，单位字节。 [en-US] File length in bytes. */
    fileLength?: number;
}
/**
 * [zh-CN] 创建语音分段的入参。`data` 与 `originalUrl` 至少传一个。
 * [en-US] Parameters for creating a voice segment. Either `data` or `originalUrl` is required.
 */
export interface CreateVoiceMessageBodyParams {
    /** [zh-CN] 本地语音文件。 [en-US] Local voice file. */
    data?: CompatibleFile;
    /** [zh-CN] 远程语音地址。 [en-US] Remote voice URL. */
    originalUrl?: string;
    /** [zh-CN] 文件名。 [en-US] File name. */
    filename?: string;
    /** [zh-CN] 文件 MIME 类型。 [en-US] MIME type. */
    filetype?: string;
    /** [zh-CN] 语音时长，单位秒。 [en-US] Voice duration in seconds. */
    duration: number;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    fileLength?: number;
}
/**
 * [zh-CN] 创建视频分段的入参。`data` 与 `originalUrl` 至少传一个。
 * [en-US] Parameters for creating a video segment. Either `data` or `originalUrl` is required.
 */
export interface CreateVideoMessageBodyParams {
    /** [zh-CN] 本地视频文件。 [en-US] Local video file. */
    data?: CompatibleFile;
    /** [zh-CN] 远程视频地址。 [en-US] Remote video URL. */
    originalUrl?: string;
    /** [zh-CN] 文件名。 [en-US] File name. */
    filename?: string;
    /** [zh-CN] 文件 MIME 类型。 [en-US] MIME type. */
    filetype?: string;
    /** [zh-CN] 视频时长，单位秒。 [en-US] Video duration in seconds. */
    duration: number;
    /** [zh-CN] 视频宽度，单位像素。 [en-US] Video width in pixels. */
    width?: number;
    /** [zh-CN] 视频高度，单位像素。 [en-US] Video height in pixels. */
    height?: number;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    fileLength?: number;
    /** [zh-CN] 视频缩略图地址。 [en-US] Video thumbnail URL. */
    thumbnailUrl?: string;
}
/**
 * [zh-CN] 创建位置分段的入参。
 * [en-US] Parameters for creating a location segment.
 */
export interface CreateLocationMessageBodyParams {
    /** [zh-CN] 纬度。 [en-US] Latitude. */
    latitude: number;
    /** [zh-CN] 经度。 [en-US] Longitude. */
    longitude: number;
    /** [zh-CN] 地址描述。 [en-US] Address description. */
    address?: string;
    /** [zh-CN] 建筑名称。 [en-US] Building name. */
    buildingName?: string;
}
/**
 * [zh-CN] 创建自定义分段的入参。
 * [en-US] Parameters for creating a custom segment.
 */
export interface CreateCustomMessageBodyParams {
    /** [zh-CN] 自定义事件名称。 [en-US] Custom event name. */
    event: string;
    /** [zh-CN] 自定义字符串参数。 [en-US] Custom string parameters. */
    params?: Record<string, string>;
}
/**
 * [zh-CN] 创建复合消息的入参。`bodies` 必须是分段工厂返回的对象，且为 2 到 20 段。
 * [en-US] Parameters for creating a multi_body message. `bodies` must be the objects returned by segment factories and contain 2 to 20 segments.
 */
export interface CreateMultiBodyMessageParams extends CreateMessageBaseParams {
    /** [zh-CN] 有序分段，2 到 20 项。不能包含命令、合并、复合消息或流式内容。 [en-US] Ordered segments, from 2 to 20. Command, combined, multi_body, and stream content is not allowed. */
    bodies: ReadonlyArray<MultiBodySegment>;
}
/**
 * [zh-CN] 创建合并消息的入参。
 * [en-US] Parameters for creating a combined message.
 */
export interface CreateCombineMessageParams extends CreateMessageBaseParams {
    /** [zh-CN] 合并消息标题。 [en-US] Title of the combined message. */
    title: string;
    /** [zh-CN] 合并消息摘要。 [en-US] Summary of the combined message. */
    summary: string;
    /** [zh-CN] 兼容展示文本，默认 `[聊天记录]`。 [en-US] Backward-compatible display text. Defaults to `[Chat History]`. */
    compatibleText?: string;
    /** [zh-CN] 被合并的消息列表。 [en-US] Messages included in the combined message. */
    messageList: ReadonlyArray<Message>;
}
