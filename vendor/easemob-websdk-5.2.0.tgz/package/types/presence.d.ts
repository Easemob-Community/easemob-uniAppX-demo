/**
 * [zh-CN] PresenceManager 对外类型定义，供在线状态 API 调用与文档生成使用。
 * [en-US] Public type definitions for PresenceManager, used by presence APIs and documentation generation.
 */
/**
 * [zh-CN] 单设备在线状态详情。
 * [en-US] Presence details for a single device.
 */
export interface PresenceStatusDetails {
    /** [zh-CN] 设备标识（如 web/mobile）。 [en-US] Device identifier (e.g., 'web'/'mobile'). */
    readonly device: string;
    /** [zh-CN] 设备在线状态值。 [en-US] Presence status value of the device. */
    readonly status: number;
}
/**
 * [zh-CN] 在线状态事件载荷。
 * [en-US] Presence event payload.
 */
export interface PresenceState {
    /** [zh-CN] 状态所属用户 ID。 [en-US] User ID.*/
    readonly userId: string;
    /** [zh-CN] 多设备状态详情列表。 [en-US] Presence details across multiple devices. */
    readonly statusDetails: ReadonlyArray<PresenceStatusDetails>;
    /** [zh-CN] 扩展描述字段。 [en-US] Extension field. */
    readonly ext: string;
    /** [zh-CN] 状态更新时间（毫秒时间戳）。 [en-US] Status update time (Unix timestamp in milliseconds).  */
    readonly lastTime: number;
    /** [zh-CN] 订阅到期时间（毫秒时间戳）。 [en-US] Subscription expiration time (Unix timestamp in milliseconds).  */
    readonly expire: number;
}
/**
 * [zh-CN] 在线状态业务对象（对齐 Android Presence 语义）。
 * [en-US] Presence business object aligned with Android Presence semantics.
 */
export interface PresenceInfo {
    /** [zh-CN] 状态发布者（用户 ID）。 [en-US] Publisher of this presence state (user ID). */
    readonly publisher: string;
    /** [zh-CN] 设备状态映射（key 为设备，value 为状态值）。 [en-US] Device status mapping (key=device, value=status). */
    readonly statusList: Readonly<Record<string, number>>;
    /** [zh-CN] 扩展描述字段。 [en-US] Extension field. */
    readonly ext: string;
    /** [zh-CN] 最新更新时间（毫秒时间戳）。 [en-US] Latest update time (Unix timestamp in milliseconds). */
    readonly latestTime: number;
    /** [zh-CN] 状态到期时间（毫秒时间戳）。 [en-US] Presence expiration time (Unix timestamp in milliseconds). */
    readonly expiryTime: number;
}
/**
 * [zh-CN] 订阅/查询在线状态响应。
 * [en-US] Response for subscribing to or querying presence status.
 *
 * @remarks
 * [zh-CN] 数组中的每一项对应一个用户的在线状态；服务端未返回或非法的条目会被 SDK 过滤。
 * [en-US] Each item represents a user's presence status; missing or malformed entries are automatically filtered by the SDK.
 */
export type SubscribePresenceResponse = ReadonlyArray<PresenceInfo>;
/**
 * [zh-CN] 已订阅在线状态用户列表响应。
 * [en-US] Response containing the list of subscribed user IDs.
 *
 * @remarks
 * [zh-CN] 仅包含用户 ID，不包含在线状态详情；如需详情请调用 `getPresenceStatus`。
 * [en-US] Contains user IDs only and does not include presence details; call `getPresenceStatus` to fetch details.
 */
export type SubscribedPresenceListResponse = ReadonlyArray<string>;
/**
 * [zh-CN] 订阅/查询在线状态原始响应（服务端返回）。
 * [en-US] Raw server response for subscribing to or querying presence status.
 */
export interface SubscribePresenceRawResponse {
    /** [zh-CN] 结果列表。 [en-US] List of response results.*/
    readonly result?: ReadonlyArray<{
        /** [zh-CN] 用户 ID。 [en-US] User ID. */
        readonly uid?: string;
        /** [zh-CN] 设备状态映射。 [en-US] Device status mapping. */
        readonly status?: Record<string, unknown>;
        /** [zh-CN] 扩展字段。 [en-US] Extension field. */
        readonly ext?: string;
        /** [zh-CN] 更新时间（毫秒时间戳）。 [en-US] Update time (Unix timestamp in milliseconds).  */
        readonly last_time?: number;
        /** [zh-CN] 到期时间（毫秒时间戳）。 [en-US] Expiration time (Unix timestamp in milliseconds). */
        readonly expiry?: number;
    }>;
}
/**
 * [zh-CN] 订阅列表原始响应（服务端返回）。
 * [en-US] Raw server response for the subscribed list.
 */
export interface SubscribedPresenceListRawResponse {
    /** [zh-CN] 结果对象。 [en-US] Response result object. */
    readonly result?: {
        /** [zh-CN] 订阅条目列表。 [en-US] List of subscribed entries. */
        readonly sublist?: ReadonlyArray<{
            /** [zh-CN] 用户 ID。 [en-US] User ID. */
            readonly uid?: string;
            /** [zh-CN] 到期时间（毫秒时间戳）。 [en-US] Expiration time (Unix timestamp in milliseconds).*/
            readonly expiry?: number;
        }>;
        /** [zh-CN] 总条目数。 [en-US] Total entry count.*/
        readonly totalnum?: number;
    };
}
