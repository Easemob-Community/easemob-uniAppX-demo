/**
 * [zh-CN] ChatRoomManager 公共类型定义。
 * [en-US] Public type definitions for ChatRoomManager.
 */
import type { CursorPageParams } from './group';
import type { UserInfo } from './user-info';
export declare const ChatRoomEventName: {
    readonly CHAT_ROOM_DESTROYED: "onChatRoomDestroyed";
    readonly MEMBERS_JOINED: "onMembersJoined";
    readonly MEMBERS_EXITED: "onMembersExited";
    readonly REMOVED_FROM_CHAT_ROOM: "onRemovedFromChatRoom";
    readonly MUTE_LIST_ADDED: "onMuteListAdded";
    readonly MUTE_LIST_REMOVED: "onMuteListRemoved";
    readonly ALLOW_LIST_ADDED: "onAllowListAdded";
    readonly ALLOW_LIST_REMOVED: "onAllowListRemoved";
    readonly ALL_MEMBER_MUTE_STATE_CHANGED: "onAllMemberMuteStateChanged";
    readonly ADMIN_ADDED: "onAdminAdded";
    readonly ADMIN_REMOVED: "onAdminRemoved";
    readonly OWNER_CHANGED: "onOwnerChanged";
    readonly ANNOUNCEMENT_CHANGED: "onAnnouncementChanged";
    readonly CHAT_ROOM_INFO_CHANGED: "onChatRoomInfoChanged";
    readonly ATTRIBUTES_UPDATE: "onAttributesUpdate";
    readonly ATTRIBUTES_REMOVED: "onAttributesRemoved";
};
/**
 * [zh-CN] 聊天室事件名称。
 * [en-US] Chat room event name.
 */
export type ChatRoomEventName = (typeof ChatRoomEventName)[keyof typeof ChatRoomEventName];
/**
 * [zh-CN] 当前用户在聊天室内的权限类型。
 * [en-US] Permission type of the current user in a chat room.
 */
export type ChatRoomPermissionType = 'owner' | 'admin' | 'member' | 'none';
/**
 * [zh-CN] 聊天室成员角色。
 * [en-US] Chat room member role.
 */
export type ChatRoomRole = 'owner' | 'admin' | 'member';
/**
 * [zh-CN] 聊天室列表中的摘要信息。
 * [en-US] Summary information for a chat room in the list.
 */
export interface ChatRoomSummary {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 聊天室名称。
     * [en-US] Chat room name.
     */
    readonly name: string;
    /**
     * [zh-CN] 聊天室所有者资料。SDK 会尽可能从缓存获取该信息，否则从用户资料接口获取。
     * [en-US] Profile of the chat room owner. The SDK retrieves this information from the cache when possible, otherwise from the user profile API.
     */
    readonly owner?: UserInfo;
    /**
     * [zh-CN] 当前成员数量。
     * [en-US] Current number of members.
     */
    readonly memberCount?: number;
    /**
     * [zh-CN] 聊天室是否已被禁用。
     * [en-US] Whether the chat room is disabled.
     */
    readonly disabled?: boolean;
}
/**
 * [zh-CN] 聊天室分页列表的返回结果。
 * [en-US] Paginated result of the chat room list.
 */
export interface ChatRoomListResult {
    /**
     * [zh-CN] 当前页的聊天室摘要列表。
     * [en-US] List of chat room summaries on the current page.
     */
    readonly items: ReadonlyArray<ChatRoomSummary>;
    /**
     * [zh-CN] 当前页码，从 1 开始；具体值以服务端返回为准。
     * [en-US] Current page number, starting from 1. The actual value is determined by the server response.
     */
    readonly pageNum?: number;
    /**
     * [zh-CN] 当前页大小。
     * [en-US] Page size of the current page.
     */
    readonly pageSize?: number;
    /**
     * [zh-CN] 服务端返回的总数量。
     * [en-US] Total number returned by the server.
     */
    readonly total?: number;
    /**
     * [zh-CN] 是否还有下一页数据。
     * [en-US] Whether more pages are available.
     */
    readonly hasMore?: boolean;
}
/**
 * [zh-CN] 聊天室详情。
 * [en-US] Details of the chat room.
 */
export interface ChatRoomDetail extends ChatRoomSummary {
    /**
     * [zh-CN] 聊天室描述。
     * [en-US] Chat room description.
     */
    readonly description?: string;
    /**
     * [zh-CN] 聊天室最大成员数。
     * [en-US] Maximum number of members allowed in the chat room.
     */
    readonly maxMembers?: number;
    /**
     * [zh-CN] 聊天室创建时间戳，具体单位以服务端返回为准。
     * [en-US] Creation timestamp of the chat room. The unit is determined by the server response.
     */
    readonly createdAt?: number;
    /**
     * [zh-CN] 聊天室扩展信息。
     * [en-US] Extension information of the chat room.
     */
    readonly ext?: string;
    /**
     * [zh-CN] 是否开启全员禁言。该字段映射服务端聊天室详情的 `mute`。
     * [en-US] Whether all-member mute is enabled. This field maps to `mute` in the server chat room detail.
     */
    readonly muteAllMembers?: boolean;
    /**
     * [zh-CN] 当前用户在聊天室中的权限类型。
     * [en-US] Permission type of the current user in the chat room.
     */
    readonly permissionType?: ChatRoomPermissionType;
}
/**
 * [zh-CN] 基于页码的分页参数。
 * [en-US] Parameters for page-number-based pagination.
 */
export interface ChatRoomPageParams {
    /**
     * [zh-CN] 当前页码，从 1 开始；未传时使用服务端默认值。
     * [en-US] The current page number, starting from 1. The server default is used when omitted.
     */
    readonly pageNum?: number;
    /**
     * [zh-CN] 每页返回的数据条数；未传时使用服务端默认值。
     * [en-US] The number of items returned per page. The server default is used when omitted.
     */
    readonly pageSize?: number;
}
/**
 * [zh-CN] 查询聊天室列表的分页参数。
 * [en-US] Pagination parameters for querying chat rooms.
 */
export type GetChatRoomListParams = ChatRoomPageParams;
/**
 * [zh-CN] 查询聊天室详情的参数。
 * [en-US] Parameters for querying chat room details.
 */
export interface GetChatRoomInfoParams {
    /**
     * [zh-CN] 聊天室 ID。该参数必传。
     * [en-US] Chat room ID. This parameter is required.
     */
    readonly chatRoomId: string;
}
/**
 * [zh-CN] 更新聊天室信息的输入字段。
 * [en-US] Input fields for updating chat room information.
 */
export interface ChatRoomUpdateInfoInput {
    /**
     * [zh-CN] 更新后的聊天室名称。未传则不修改。
     * [en-US] Updated chat room name. If omitted, the value is not changed.
     */
    readonly name?: string;
    /**
     * [zh-CN] 更新后的聊天室描述。未传则不修改。
     * [en-US] Updated chat room description. If omitted, the value is not changed.
     */
    readonly description?: string;
    /**
     * [zh-CN] 更新后的最大成员数。未传则不修改。
     * [en-US] Updated maximum member count. If omitted, the value is not changed.
     */
    readonly maxMembers?: number;
}
/**
 * [zh-CN] 更新聊天室信息的参数。
 * [en-US] Parameters for updating chat room information.
 */
export interface UpdateChatRoomInfoParams extends ChatRoomUpdateInfoInput {
    /**
     * [zh-CN] 聊天室 ID。该参数必传。
     * [en-US] Chat room ID. This parameter is required.
     */
    readonly chatRoomId: string;
}
/**
 * [zh-CN] 聊天室信息的更新结果。
 * [en-US] Result of updating chat room information.
 */
export interface ChatRoomUpdateResult {
    /**
     * [zh-CN] 名称是否更新成功。
     * [en-US] Whether the name was updated successfully.
     */
    readonly nameUpdated?: boolean;
    /**
     * [zh-CN] 描述是否更新成功。
     * [en-US] Whether the description was updated successfully.
     */
    readonly descriptionUpdated?: boolean;
    /**
     * [zh-CN] 最大成员数是否更新成功。
     * [en-US] Whether the maximum member count was updated successfully.
     */
    readonly maxMembersUpdated?: boolean;
}
/**
 * [zh-CN] 仅包含聊天室 ID 的通用操作目标。
 * [en-US] Common operation target that contains only the chat room ID.
 */
export interface ChatRoomMutationTarget {
    /**
     * [zh-CN] 聊天室 ID。该参数必传。
     * [en-US] Chat room ID. This parameter is required.
     */
    readonly chatRoomId: string;
}
/**
 * [zh-CN] 加入聊天室的参数。
 * [en-US] Parameters for joining a chat room.
 */
export interface JoinChatRoomParams extends ChatRoomMutationTarget {
    /**
     * [zh-CN] 加入聊天室时透传给服务端的扩展信息。
     * [en-US] Extension information passed to the server when joining the chat room.
     */
    readonly ext?: string;
    /**
     * [zh-CN] 是否离开当前账号已加入的其他聊天室；未传时由服务端默认策略决定。
     * [en-US] Whether to leave other chat rooms that the current account has joined. If omitted, the default server policy applies.
     */
    readonly leaveOtherRooms?: boolean;
}
/**
 * [zh-CN] 加入聊天室成功后由 ACK 附带的聊天室信息。服务端可能不返回部分或全部字段。
 * [en-US] Chat room information optionally attached to a successful join ACK. The server may omit some or all fields.
 */
export interface JoinChatRoomInfo {
    /**
     * [zh-CN] 聊天室是否已开启全员禁言。
     * [en-US] Whether all-member mute is enabled in the chat room.
     */
    readonly isAllMembersMuted?: boolean;
    /**
     * [zh-CN] 聊天室创建时间戳（毫秒）。
     * [en-US] Chat room creation timestamp in milliseconds.
     */
    readonly createTimestamp?: number;
    /**
     * [zh-CN] 当前用户是否在白名单中。
     * [en-US] Whether the current user is in the allow list.
     */
    readonly isInAllowlist?: boolean;
    /**
     * [zh-CN] 当前成员数量。
     * [en-US] Current number of members.
     */
    readonly memberCount?: number;
    /**
     * [zh-CN] 当前用户的禁言到期时间戳（毫秒）；`-1` 表示未禁言。
     * [en-US] Mute expiration timestamp in milliseconds for the current user; `-1` means not muted.
     */
    readonly muteExpireTimestamp?: number;
}
/**
 * [zh-CN] 批量用户操作的输入参数。
 * [en-US] Input parameters for batch user operations.
 */
export interface ChatRoomUserBatchInput {
    /**
     * [zh-CN] 用户 ID 列表。该参数必传，且至少包含一个有效的用户 ID。
     * [en-US] List of user IDs. This parameter is required and must contain at least one valid user ID.
     */
    readonly userIds: ReadonlyArray<string>;
}
/**
 * [zh-CN] 包含聊天室 ID 的批量用户操作参数。
 * [en-US] Batch user operation parameters that include the chat room ID.
 */
export interface ChatRoomUserBatchParams extends ChatRoomMutationTarget {
    /**
     * [zh-CN] 用户 ID 列表。该参数必传，且至少包含一个有效的用户 ID。
     * [en-US] List of user IDs. This parameter is required and must contain at least one valid user ID.
     */
    readonly userIds: ReadonlyArray<string>;
}
/**
 * [zh-CN] 单个管理员操作的输入参数。
 * [en-US] Input parameters for a single administrator operation.
 */
export interface ChatRoomAdminInput {
    /**
     * [zh-CN] 目标用户 ID。该参数必传。
     * [en-US] Target user ID. This parameter is required.
     */
    readonly userId: string;
}
/**
 * [zh-CN] 包含聊天室 ID 的管理员操作参数。
 * [en-US] Administrator operation parameters that include the chat room ID.
 */
export interface ChatRoomAdminParams extends ChatRoomMutationTarget {
    /**
     * [zh-CN] 目标用户 ID。该参数必传。
     * [en-US] Target user ID. This parameter is required.
     */
    readonly userId: string;
}
/**
 * [zh-CN] 聊天室成员条目。
 * [en-US] Chat room member entry.
 */
export interface ChatRoomMemberEntry {
    /**
     * [zh-CN] 成员的用户资料。
     * [en-US] Profile of the member.
     */
    readonly user: UserInfo;
    /**
     * [zh-CN] 成员角色。
     * [en-US] Member role.
     */
    readonly role?: ChatRoomRole;
    /**
     * [zh-CN] 成员加入聊天室的时间戳。
     * [en-US] Timestamp when the member joined the chat room.
     */
    readonly joinedAt?: number;
}
export type ChatRoomMemberListQuery = CursorPageParams;
/**
 * [zh-CN] 查询聊天室成员列表的参数。
 * [en-US] Parameters for querying the chat room member list.
 */
export interface ChatRoomMemberListParams extends ChatRoomMutationTarget, CursorPageParams {
}
/**
 * [zh-CN] 聊天室成员列表的返回结果。
 * [en-US] Result of the chat room member list.
 */
export interface ChatRoomMemberListResult {
    /**
     * [zh-CN] 成员条目列表。
     * [en-US] List of member entries.
     */
    readonly items: ReadonlyArray<ChatRoomMemberEntry>;
    /**
     * [zh-CN] 下一页游标。若为空，表示服务端未返回游标。
     * [en-US] Cursor for the next page. If empty, the server did not return a cursor.
     */
    readonly cursor?: string;
    /**
     * [zh-CN] 是否还有下一页数据。
     * [en-US] Whether more pages are available.
     */
    readonly hasMore?: boolean;
}
/**
 * [zh-CN] 单个成员操作的结果。
 * [en-US] Result of a single member operation.
 */
export interface ChatRoomMemberActionResult {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 目标用户资料。
     * [en-US] Profile of the target user.
     */
    readonly user: UserInfo;
    /**
     * [zh-CN] 操作名称。
     * [en-US] Operation name.
     */
    readonly action: string;
    /**
     * [zh-CN] 失败原因。该字段通常仅在操作失败时返回。
     * [en-US] Reason for the failure. This field is typically returned only when the operation fails.
     */
    readonly reason?: string;
}
/**
 * [zh-CN] 批量成员操作的结果。
 * [en-US] Result of batch member operations.
 */
export interface ChatRoomMemberActionListResult {
    /**
     * [zh-CN] 操作成功的目标用户结果列表。
     * [en-US] Results for target users whose operations succeeded.
     */
    readonly succeeded: ReadonlyArray<ChatRoomMemberActionResult>;
    /**
     * [zh-CN] 操作失败的目标用户结果列表。
     * [en-US] Results for target users whose operations failed.
     */
    readonly failed: ReadonlyArray<ChatRoomMemberActionResult>;
}
/**
 * [zh-CN] 禁言列表条目。
 * [en-US] Mute list entry.
 */
export interface ChatRoomMuteEntry {
    /**
     * [zh-CN] 被禁言用户的资料。
     * [en-US] Profile of the muted user.
     */
    readonly user: UserInfo;
    /**
     * [zh-CN] 禁言过期时间。
     * [en-US] Mute expiration time.
     */
    readonly muteExpire?: number;
    /**
     * [zh-CN] 禁言时长，单位通常为秒，具体以服务端返回为准。
     * [en-US] Mute duration, typically in seconds. The unit is determined by the server response.
     */
    readonly duration?: number;
}
/**
 * [zh-CN] 禁言成员时的输入参数。
 * [en-US] Input parameters for muting members.
 */
export interface ChatRoomMuteMembersInput {
    /**
     * [zh-CN] 待禁言的用户 ID 列表。该参数必传。
     * [en-US] List of user IDs to be muted. This parameter is required.
     */
    readonly userIds: ReadonlyArray<string>;
    /**
     * [zh-CN] 禁言时长，单位为秒。
     * [en-US] Mute duration, in seconds.
     */
    readonly duration: number;
}
/**
 * [zh-CN] 包含聊天室 ID 的禁言成员参数。
 * [en-US] Parameters for muting members that include the chat room ID.
 */
export interface ChatRoomMuteMembersParams extends ChatRoomMutationTarget {
    /**
     * [zh-CN] 待禁言的用户 ID 列表。该参数必传。
     * [en-US] List of user IDs to be muted. This parameter is required.
     */
    readonly userIds: ReadonlyArray<string>;
    /**
     * [zh-CN] 禁言时长，单位为秒。
     * [en-US] Mute duration, in seconds.
     */
    readonly duration: number;
}
/**
 * [zh-CN] 当前用户的禁言状态。
 * [en-US] Mute status of the current user.
 */
export interface ChatRoomMuteStatus {
    /**
     * [zh-CN] 当前用户是否处于禁言状态。
     * [en-US] Whether the current user is muted.
     */
    readonly muted: boolean;
    /**
     * [zh-CN] 禁言过期时间。
     * [en-US] Mute expiration time.
     */
    readonly muteExpireAt?: number;
}
/**
 * [zh-CN] 查询禁言列表的参数。
 * [en-US] Parameters for querying the mute list.
 */
export interface ChatRoomMuteListParams extends ChatRoomMutationTarget, ChatRoomPageParams {
}
/**
 * [zh-CN] allowlist 条目。
 * [en-US] Allow list entry.
 */
export interface ChatRoomAllowlistEntry {
    /**
     * [zh-CN] allowlist 用户资料。
     * [en-US] Profile of the user in the allow list.
     */
    readonly user: UserInfo;
}
/**
 * [zh-CN] 黑名单条目。
 * [en-US] Block list entry.
 */
export interface ChatRoomBlocklistEntry {
    /**
     * [zh-CN] 黑名单用户资料。
     * [en-US] Profile of the user in the block list.
     */
    readonly user: UserInfo;
}
/**
 * [zh-CN] 查询黑名单分页列表的参数。
 * [en-US] Parameters for querying the block list with pagination.
 */
export interface ChatRoomBlocklistParams extends ChatRoomMutationTarget, ChatRoomPageParams {
}
/**
 * [zh-CN] 聊天室公告。
 * [en-US] Chat room announcement.
 */
export interface ChatRoomAnnouncement {
    /**
     * [zh-CN] 公告内容。
     * [en-US] Announcement content.
     */
    readonly announcement: string;
}
/**
 * [zh-CN] 更新公告时的输入参数。
 * [en-US] Input parameters for updating the announcement.
 */
export interface ChatRoomAnnouncementUpdateInput {
    /**
     * [zh-CN] 更新后的公告内容。该参数必传。
     * [en-US] Updated announcement content. This parameter is required.
     */
    readonly announcement: string;
}
/**
 * [zh-CN] 包含聊天室 ID 的公告更新参数。
 * [en-US] Announcement update parameters that include the chat room ID.
 */
export interface ChatRoomAnnouncementUpdateParams extends ChatRoomMutationTarget, ChatRoomAnnouncementUpdateInput {
}
/**
 * [zh-CN] 聊天室共享文件条目。
 * [en-US] Chat room shared file entry.
 */
export interface ChatRoomSharedFile {
    /**
     * [zh-CN] 文件 ID。
     * [en-US] File ID.
     */
    readonly fileId: string;
    /**
     * [zh-CN] 文件名称。
     * [en-US] File name.
     */
    readonly fileName: string;
    /**
     * [zh-CN] 文件上传者资料。
     * [en-US] Profile of the user who uploaded the file.
     */
    readonly fileOwner?: UserInfo;
    /**
     * [zh-CN] 文件大小，单位为字节。
     * [en-US] File size, in bytes.
     */
    readonly fileSize?: number;
    /**
     * [zh-CN] 文件创建时间戳。
     * [en-US] Creation timestamp of the file.
     */
    readonly createdAt?: number;
}
export type ChatRoomSharedFileListQuery = ChatRoomPageParams;
/**
 * [zh-CN] 查询聊天室共享文件列表的参数。
 * [en-US] Parameters for querying the list of shared files in the chat room.
 */
export interface ChatRoomSharedFileListParams extends ChatRoomMutationTarget, ChatRoomPageParams {
}
/**
 * [zh-CN] 聊天室共享文件列表的返回结果。
 * [en-US] Result of the shared file list in the chat room.
 */
export interface ChatRoomSharedFileListResult {
    /**
     * [zh-CN] 当前页的共享文件列表。
     * [en-US] List of shared files on the current page.
     */
    readonly items: ReadonlyArray<ChatRoomSharedFile>;
    /**
     * [zh-CN] 当前页码。
     * [en-US] Current page number.
     */
    readonly pageNum?: number;
    /**
     * [zh-CN] 当前页大小。
     * [en-US] Current page size.
     */
    readonly pageSize?: number;
    /**
     * [zh-CN] 下一页游标。
     * [en-US] Cursor for the next page.
     */
    readonly cursor?: string;
    /**
     * [zh-CN] 是否还有下一页数据。
     * [en-US] Whether more pages are available.
     */
    readonly hasMore?: boolean;
}
/**
 * [zh-CN] 删除共享文件时的输入参数。
 * [en-US] Input parameters for deleting a shared file.
 */
export interface ChatRoomDeleteSharedFileInput {
    /**
     * [zh-CN] 文件 ID。该参数必传。
     * [en-US] File ID. This parameter is required.
     */
    readonly fileId: string;
}
/**
 * [zh-CN] 包含聊天室 ID 的删除共享文件参数。
 * [en-US] Deletion parameters for a shared file that include the chat room ID.
 */
export interface DeleteChatRoomSharedFileParams extends ChatRoomMutationTarget {
    /**
     * [zh-CN] 文件 ID。该参数必传。
     * [en-US] File ID. This parameter is required.
     */
    readonly fileId: string;
}
/**
 * [zh-CN] 查询聊天室属性时的输入参数。
 * [en-US] Input parameters for querying chat room attributes.
 */
export interface GetChatRoomAttributesInput {
    /**
     * [zh-CN] 指定要查询的属性 key 列表。未传时查询全部属性。
     * [en-US] List of attribute keys to query. If omitted, all attributes are queried.
     */
    readonly keys?: ReadonlyArray<string>;
}
/**
 * [zh-CN] 包含聊天室 ID 的属性查询参数。
 * [en-US] Attribute query parameters that include the chat room ID.
 */
export interface GetChatRoomAttributesParams extends ChatRoomMutationTarget {
    /**
     * [zh-CN] 指定要查询的属性 key 列表。未传时查询全部属性。
     * [en-US] List of attribute keys to query. If omitted, all attributes are queried.
     */
    readonly keys?: ReadonlyArray<string>;
}
/**
 * [zh-CN] 设置聊天室属性时的输入参数。
 * [en-US] Input parameters for setting chat room attributes.
 */
export interface SetChatRoomAttributesInput {
    /**
     * [zh-CN] 待设置的属性键值对。key 和 value 均必须为字符串。
     * [en-US] Attribute key-value pairs to set. Both the key and value must be strings.
     */
    readonly attributes: Readonly<Record<string, string>>;
    /**
     * [zh-CN] 成员退出聊天室时是否自动删除其设置的属性。默认值为 `true`。
     * [en-US] Whether to automatically delete attributes set by the member when the member leaves the chat room. The default value is `true`.
     */
    readonly autoDelete?: boolean;
    /**
     * [zh-CN] 是否允许覆盖其他成员设置的属性。默认值为 `false`。
     * [en-US] Whether to allow overwriting attributes set by other members. The default value is `false`.
     */
    readonly isForced?: boolean;
}
/**
 * [zh-CN] 聊天室属性设置参数（含聊天室 ID）。
 * [en-US] Parameters for setting chat room attributes (with room ID).
 */
export interface SetChatRoomAttributesParams extends ChatRoomMutationTarget {
    /**
     * [zh-CN] 待设置的属性键值对。key 和 value 均必须为字符串。
     * [en-US] Attribute key-value pairs to set. Both the key and value must be strings.
     */
    readonly attributes: Readonly<Record<string, string>>;
    /**
     * [zh-CN] 成员退出聊天室时是否自动删除其设置的属性。默认值为 `true`。
     * [en-US] Whether to automatically delete attributes set by the member when the member leaves the chat room. The default value is `true`.
     */
    readonly autoDelete?: boolean;
    /**
     * [zh-CN] 是否允许覆盖其他成员设置的属性。默认值为 `false`。
     * [en-US] Whether to allow overwriting attributes set by other members. The default value is `false`.
     */
    readonly isForced?: boolean;
}
/**
 * [zh-CN] 删除聊天室属性时的输入参数。
 * [en-US] Input parameters for removing chat room attributes.
 */
export interface RemoveChatRoomAttributesInput {
    /**
     * [zh-CN] 待删除的属性 key 列表。该参数必传。
     * [en-US] List of attribute keys to remove. This parameter is required.
     */
    readonly keys: ReadonlyArray<string>;
    /**
     * [zh-CN] 是否允许删除其他成员设置的属性。默认值为 `false`。
     * [en-US] Whether to allow removing attributes set by other members. The default value is `false`.
     */
    readonly isForced?: boolean;
}
/**
 * [zh-CN] 包含聊天室 ID 的属性删除参数。
 * [en-US] Attribute removal parameters that include the chat room ID.
 */
export interface RemoveChatRoomAttributesParams extends ChatRoomMutationTarget {
    /**
     * [zh-CN] 待删除的属性 key 列表。该参数必传。
     * [en-US] List of attribute keys to remove. This parameter is required.
     */
    readonly keys: ReadonlyArray<string>;
    /**
     * [zh-CN] 是否允许删除其他成员设置的属性。默认值为 `false`。
     * [en-US] Whether to allow removing attributes set by other members. The default value is `false`.
     */
    readonly isForced?: boolean;
}
/**
 * [zh-CN] 聊天室属性快照。
 * [en-US] Snapshot of chat room attributes.
 */
export interface ChatRoomAttributesSnapshot {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 当前属性键值对。
     * [en-US] Current attribute key-value pairs.
     */
    readonly attributes: Readonly<Record<string, string>>;
}
/**
 * [zh-CN] 聊天室属性批量变更的结果。
 * [en-US] Result of batch changes to chat room attributes.
 */
export interface ChatRoomAttributeMutationResult {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 已成功应用的属性 key 列表。
     * [en-US] List of attribute keys that were applied successfully.
     */
    readonly appliedKeys: ReadonlyArray<string>;
    /**
     * [zh-CN] 设置或删除失败的属性 key 与错误信息的映射。
     * [en-US] Mapping from attribute keys that failed to be set or removed to their error information.
     */
    readonly failedKeys: Readonly<Record<string, {
        readonly code: number;
        readonly message: string;
    }>>;
}
/**
 * [zh-CN] 聊天室被销毁事件的载荷。
 * [en-US] Payload carried by the event triggered when a chat room is destroyed.
 */
export interface ChatRoomDestroyedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 聊天室名称。
     * [en-US] Chat room name.
     */
    readonly chatRoomName?: string;
}
/**
 * [zh-CN] 用户加入聊天室事件的载荷。
 * [en-US] Payload of the event triggered when users join the chat room.
 */
export interface ChatRoomMembersJoinedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 聊天室名称。
     * [en-US] Chat room name.
     */
    readonly chatRoomName?: string;
    /**
     * [zh-CN] 加入聊天室的用户列表。
     * [en-US] List of users who joined the chat room.
     */
    readonly members: ReadonlyArray<UserInfo>;
    /**
     * [zh-CN] 用户加入聊天室时透传的扩展信息。
     * [en-US] Extension information passed to the server when the users joined the chat room.
     */
    readonly ext?: string;
}
/**
 * [zh-CN] 成员退出聊天室事件的载荷。
 * [en-US] Payload of the event triggered when members leave the chat room.
 */
export interface ChatRoomMembersExitedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 聊天室名称。
     * [en-US] Chat room name.
     */
    readonly chatRoomName?: string;
    /**
     * [zh-CN] 退出聊天室的成员列表。
     * [en-US] List of members who left the chat room.
     */
    readonly members: ReadonlyArray<UserInfo>;
}
/**
 * [zh-CN] 当前用户被移出聊天室事件的载荷。
 * [en-US] Payload of the event triggered when the current user is removed from the chat room.
 */
export interface ChatRoomRemovedFromChatRoomEventPayload {
    /**
     * [zh-CN] 被移出的原因码。
     * [en-US] Reason code for the removal.
     */
    readonly reason: number;
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 聊天室名称。
     * [en-US] Chat room name.
     */
    readonly chatRoomName?: string;
    /**
     * [zh-CN] 触发移除操作的参与者资料。参与者可能是聊天室所有者或聊天室管理员。
     * [en-US] Profile of the participant that initiated the removal. The participant can be a chat room owner or admin.
     */
    readonly participant?: UserInfo;
}
/**
 * [zh-CN] 聊天室禁言列表新增事件的载荷。
 * [en-US] Payload of the event triggered when users are added to the chat room mute list.
 */
export interface ChatRoomMuteListAddedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 新增的禁言条目列表。
     * [en-US] List of newly added mute entries.
     */
    readonly mutes: ReadonlyArray<ChatRoomMuteEntry>;
    /**
     * [zh-CN] 禁言过期时间。
     * [en-US] Mute expiration time.
     */
    readonly muteExpire?: number;
}
/**
 * [zh-CN] 聊天室禁言列表移除事件的载荷。
 * [en-US] Payload of the event triggered when users are removed from the chat room mute list.
 */
export interface ChatRoomMuteListRemovedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 解除禁言的用户资料列表。
     * [en-US] List of profiles of users removed from the mute list.
     */
    readonly mutes: ReadonlyArray<UserInfo>;
}
/**
 * [zh-CN] 聊天室白名单新增事件的载荷。
 * [en-US] Payload of the event triggered when users are added to the chat room allow list.
 */
export interface ChatRoomAllowListAddedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 新增到白名单中的用户资料列表。
     * [en-US] List of profiles of users added to the allow list.
     */
    readonly allowlist: ReadonlyArray<UserInfo>;
}
/**
 * [zh-CN] 聊天室白名单移除事件的载荷。
 * [en-US] Payload of the event triggered when users are removed from the chat room allow list.
 */
export interface ChatRoomAllowListRemovedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 从白名单中移除的用户资料列表。
     * [en-US] List of profiles of users removed from the allow list.
     */
    readonly allowlist: ReadonlyArray<UserInfo>;
}
/**
 * [zh-CN] 聊天室全员禁言状态变更事件的载荷。
 * [en-US] Payload of the event triggered when the all-member mute state of the chat room changes.
 */
export interface ChatRoomAllMemberMuteStateChangedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 当前是否已开启全员禁言。
     * [en-US] Whether all-member mute is currently enabled.
     */
    readonly isMuted: boolean;
}
/**
 * [zh-CN] 聊天室管理员新增事件的载荷。
 * [en-US] Payload of the event triggered when an administrator is added to the chat room.
 */
export interface ChatRoomAdminAddedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 新增管理员的资料。
     * [en-US] Profile of the newly added administrator.
     */
    readonly admin?: UserInfo;
}
/**
 * [zh-CN] 聊天室管理员移除事件的载荷。
 * [en-US] Payload of the event triggered when an administrator is removed from the chat room.
 */
export interface ChatRoomAdminRemovedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 被移除管理员的资料。
     * [en-US] Profile of the removed administrator.
     */
    readonly admin?: UserInfo;
}
/**
 * [zh-CN] 聊天室所有者变更事件的载荷。
 * [en-US] Payload of the event triggered when the chat room owner changes.
 */
export interface ChatRoomOwnerChangedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 新所有者资料。
     * [en-US] Profile of the new owner.
     */
    readonly newOwner?: UserInfo;
    /**
     * [zh-CN] 原所有者资料。
     * [en-US] Profile of the previous owner.
     */
    readonly oldOwner?: UserInfo;
}
/**
 * [zh-CN] 聊天室公告变更事件的载荷。
 * [en-US] Payload of the event triggered when the chat room announcement changes.
 */
export interface ChatRoomAnnouncementChangedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 最新公告内容。
     * [en-US] Latest announcement content.
     */
    readonly announcement: string;
}
/**
 * [zh-CN] 聊天室信息变更事件的载荷。
 * [en-US] Payload of the event triggered when chat room information changes.
 */
export interface ChatRoomInfoChangedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 最新的聊天室详情。
     * [en-US] Latest chat room details.
     */
    readonly chatRoomInfo: ChatRoomDetail;
}
/**
 * [zh-CN] 聊天室属性更新事件的载荷。
 * [en-US] Payload of the event triggered when chat room attributes are updated.
 */
export interface ChatRoomAttributesUpdateEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 更新后的属性键值对。
     * [en-US] Updated attribute key-value pairs.
     */
    readonly attributes: Readonly<Record<string, string>>;
    /**
     * [zh-CN] 执行更新操作的用户资料。
     * [en-US] Profile of the user who performed the update.
     */
    readonly from?: UserInfo;
}
/**
 * [zh-CN] 聊天室属性删除事件的载荷。
 * [en-US] Payload of the event triggered when chat room attributes are removed.
 */
export interface ChatRoomAttributesRemovedEventPayload {
    /**
     * [zh-CN] 聊天室 ID。
     * [en-US] Chat room ID.
     */
    readonly chatRoomId: string;
    /**
     * [zh-CN] 被删除的属性 key 列表。
     * [en-US] List of removed attribute keys.
     */
    readonly keyList: ReadonlyArray<string>;
    /**
     * [zh-CN]  执行删除操作的用户资料。
     * [en-US] Profile of the user who performed the removal.
     */
    readonly from?: UserInfo;
}
/**
 * [zh-CN] 聊天室事件名称与载荷类型之间的映射。
 * [en-US] Mapping between chat room event names and payload types.
 */
export interface ChatRoomEventPayloadMap {
    /**
     * [zh-CN] 聊天室被销毁事件的载荷。
     * [en-US] Payload of the event triggered when the chat room is destroyed.
     */
    readonly onChatRoomDestroyed: ChatRoomDestroyedEventPayload;
    /**
     * [zh-CN] 成员加入聊天室事件的载荷。
     * [en-US] Payload of the event triggered when members join the chat room.
     */
    readonly onMembersJoined: ChatRoomMembersJoinedEventPayload;
    /**
     * [zh-CN] 成员退出聊天室事件的载荷。
     * [en-US] Payload of the event triggered when members leave the chat room.
     */
    readonly onMembersExited: ChatRoomMembersExitedEventPayload;
    /**
     * [zh-CN] 当前用户被移出聊天室事件的载荷。
     * [en-US] Payload of the event triggered when the current user is removed from the chat room.
     */
    readonly onRemovedFromChatRoom: ChatRoomRemovedFromChatRoomEventPayload;
    /**
     * [zh-CN] 禁言列表新增事件的载荷。
     * [en-US] Payload of the event triggered when a user is added to the chat room mute list.
     */
    readonly onMuteListAdded: ChatRoomMuteListAddedEventPayload;
    /**
     * [zh-CN] 禁言列表移除事件的载荷。
     * [en-US] Payload of the event triggered when a user is removed from the chat room mute list.
     */
    readonly onMuteListRemoved: ChatRoomMuteListRemovedEventPayload;
    /**
     * [zh-CN] 白名单新增事件的载荷。
     * [en-US] Payload of the event triggered when a user is added to the chat room allow list.
     */
    readonly onAllowListAdded: ChatRoomAllowListAddedEventPayload;
    /**
     * [zh-CN] 白名单移除事件的载荷。
     * [en-US] Payload of the event triggered when a user is removed from the chat room allow list.
     */
    readonly onAllowListRemoved: ChatRoomAllowListRemovedEventPayload;
    /**
     * [zh-CN] 全员禁言状态变更事件的载荷。
     * [en-US] Payload of the event triggered when the all-member mute state of the chat room changes.
     */
    readonly onAllMemberMuteStateChanged: ChatRoomAllMemberMuteStateChangedEventPayload;
    /**
     * [zh-CN] 管理员新增事件的载荷。
     * [en-US] Payload of the event triggered when an administrator is added to the chat room.
     */
    readonly onAdminAdded: ChatRoomAdminAddedEventPayload;
    /**
     * [zh-CN] 管理员移除事件的载荷。
     * [en-US] Payload of the event triggered when an administrator is removed from the chat room.
     */
    readonly onAdminRemoved: ChatRoomAdminRemovedEventPayload;
    /**
     * [zh-CN] 所有者变更事件的载荷。
     * [en-US] Payload of the event triggered when the chat room owner changes.
     */
    readonly onOwnerChanged: ChatRoomOwnerChangedEventPayload;
    /**
     * [zh-CN] 公告变更事件的载荷。
     * [en-US] Payload of the event triggered when the chat room announcement changes.
     */
    readonly onAnnouncementChanged: ChatRoomAnnouncementChangedEventPayload;
    /**
     * [zh-CN] 聊天室信息变更事件的载荷。
     * [en-US] Payload of the event triggered when chat room information changes.
     */
    readonly onChatRoomInfoChanged: ChatRoomInfoChangedEventPayload;
    /**
     * [zh-CN] 属性更新事件的载荷。
     * [en-US] Payload of the event triggered when chat room attributes are updated.
     */
    readonly onAttributesUpdate: ChatRoomAttributesUpdateEventPayload;
    /**
     * [zh-CN] 属性删除事件的载荷。
     * [en-US] Payload of the event triggered when chat room attributes are removed.
     */
    readonly onAttributesRemoved: ChatRoomAttributesRemovedEventPayload;
}
/**
 * [zh-CN] 聊天室公开事件的处理器映射。
 * [en-US] Handler map for public chat room events.
 */
export type ChatRoomEventHandlerMap = Partial<{
    [K in keyof ChatRoomEventPayloadMap]: (payload: ChatRoomEventPayloadMap[K]) => void | Promise<void>;
}>;
/**
 * @internal
 * [zh-CN] 聊天室原始通知载荷。
 * [en-US] Raw chat room notification payload.
 */
export interface ChatRoomRawNotifyPayload {
    /** [zh-CN] 聊天室 ID。 [en-US] Chat room ID. */
    readonly chatRoomId: string;
    /** [zh-CN] 聊天室名称。 [en-US] Chat room name. */
    readonly chatRoomName?: string;
    /** [zh-CN] 原始原因文本。 [en-US] Raw reason text. */
    readonly reason?: string;
    /** [zh-CN] 原始原因码。 [en-US] Raw reason code. */
    readonly reasonCode?: number;
    /** [zh-CN] 参与者用户 ID。 [en-US] User ID of the participant. */
    readonly participantId?: string;
    /** [zh-CN] 成员用户 ID。 [en-US] User ID of the member. */
    readonly memberId?: string;
    /** [zh-CN] 成员用户 ID 列表。 [en-US] List of user IDs of members. */
    readonly memberIds?: ReadonlyArray<string>;
    /** [zh-CN] 用户 ID 列表。 [en-US] User ID list. */
    readonly userIds?: ReadonlyArray<string>;
    /** [zh-CN] 管理员用户 ID。 [en-US] User ID of the administrator. */
    readonly adminId?: string;
    /** [zh-CN] 原所有者用户 ID。 [en-US] User ID of the previous owner. */
    readonly oldOwnerId?: string;
    /** [zh-CN] 新所有者用户 ID。 [en-US] User ID of the new owner. */
    readonly newOwnerId?: string;
    /** [zh-CN] 公告内容。 [en-US] Announcement content. */
    readonly announcement?: string;
    /** [zh-CN] 禁言过期时间。 [en-US] Mute expiration timestamp. */
    readonly muteExpire?: number;
    /** [zh-CN] 用户 ID 到禁言过期时间的映射。 [en-US] Mapping from user ID to mute expiration timestamp. */
    readonly muteMembers?: Readonly<Record<string, number>>;
    /** [zh-CN] 是否已开启全员禁言。 [en-US] Whether all-member mute is enabled. */
    readonly isMuted?: boolean;
    /** [zh-CN] 扩展信息。 [en-US] Extension data. */
    readonly ext?: string;
    /** [zh-CN] 事件来源用户 ID。 [en-US] Source user ID of the event. */
    readonly from?: string;
    /** [zh-CN] 属性键值对。 [en-US] Attribute key-value map. */
    readonly attributes?: Readonly<Record<string, string>>;
    /** [zh-CN] 属性 key 列表。 [en-US] Attribute key list. */
    readonly keyList?: ReadonlyArray<string>;
    /** [zh-CN] 是否需要补拉聊天室详情。 [en-US] Whether chat room details should be fetched. */
    readonly shouldFetchChatRoomDetail?: boolean;
    /** [zh-CN] 原始通知中携带的聊天室详情补丁。 [en-US] Chat room detail patch carried by the raw notification. */
    readonly chatRoomPatch?: Partial<ChatRoomDetail>;
}
/**
 * @internal
 * [zh-CN] 聊天室原始通知信封。
 * [en-US] Raw chat room notification envelope.
 */
export interface ChatRoomRawNotifyEvent {
    /** [zh-CN] 聊天室事件名称。 [en-US] Chat room event name. */
    readonly eventName: ChatRoomEventName;
    /** [zh-CN] 原始通知载荷。 [en-US] Raw notification payload. */
    readonly payload: ChatRoomRawNotifyPayload;
}
