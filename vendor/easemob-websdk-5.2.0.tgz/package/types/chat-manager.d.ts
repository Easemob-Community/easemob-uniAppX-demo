import type { DownloadCombineMessageParams, Message, MessageBody, MessageReaction, MiniAppFile, VoiceMessageBody } from './index';
import type { ChatConversationType, MessageConversationLocator } from './message-conversation';
import type { GroupUserInfo } from './group';
import type { UserInfo } from './user-info';
export type { ChatConversationType } from './message-conversation';
/**
 * [zh-CN] 支持消息操作的会话类型，仅包含单聊和群聊。
 * [en-US] Conversation types supported by message operations, limited to one-to-one and group chats.
 */
export type MessageChatConversationType = Extract<ChatConversationType, 'singleChat' | 'groupChat'>;
/**
 * [zh-CN] 会话定位参数，包含会话 ID 与会话类型。
 * [en-US] Conversation locator that contains the conversation ID and type.
 */
export type ConversationLocator = MessageConversationLocator;
/**
 * [zh-CN] 清空单个会话未读数的参数。
 * [en-US] Parameters for clearing unread count of a single conversation.
 */
export interface ClearConversationUnreadMessageCountParams {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型，仅支持单聊和群聊。 [en-US] Conversation type, only singleChat and groupChat are supported. */
    readonly conversationType: MessageChatConversationType;
}
/**
 * [zh-CN] 批量发送消息已读回执的参数。
 *
 * [en-US] Parameters for sending message read receipts in batch.
 */
export interface SendMessageReadReceiptsParams {
    /** [zh-CN] 会话 ID，所有 `messageIds` 必须属于该会话。 [en-US] Conversation ID. All `messageIds` must belong to this conversation. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型，仅支持单聊和群聊。 [en-US] Conversation type. Only one-to-one chats and group chats are supported. */
    readonly conversationType: MessageChatConversationType;
    /** [zh-CN] 要发送已读回执的消息 ID 列表，必须非空、最多 50 条且属于同一会话。 [en-US] Message IDs to acknowledge. Must be non-empty, contain at most 50 items, and belong to the same conversation. */
    readonly messageIds: ReadonlyArray<string>;
}
/**
 * [zh-CN] 批量获取群消息已读回执详情的参数。
 * [en-US] Parameters for fetching group-message read receipt details in batch.
 */
export interface GetGroupMessageReadReceiptsParams {
    /** [zh-CN] 群组 ID。 [en-US] Group ID. */
    readonly groupId: string;
    /** [zh-CN] 非空目标消息 ID 列表；服务端当前最多接受 20 条，超限时 Promise reject。 [en-US] Non-empty target message IDs. The server currently accepts up to 20 items and rejects larger requests. */
    readonly messageIds: ReadonlyArray<string>;
}
/**
 * [zh-CN] 撤回消息的参数。
 * [en-US] Parameters for recalling a message.
 */
export interface RecallMessageParams extends ConversationLocator {
    /** [zh-CN] 待撤回的消息 ID。 [en-US] ID of the message to recall. */
    messageId: string;
    /** [zh-CN] 撤回操作附带的扩展字段。 [en-US] Extension payload for the recall operation. */
    ext?: Record<string, unknown>;
}
/**
 * [zh-CN] 编辑消息的参数。
 * [en-US] Parameters for editing a message.
 */
export interface UpdateMessageParams extends ConversationLocator {
    /** [zh-CN] 待编辑的消息 ID。 [en-US] ID of the message to edit. */
    messageId: string;
    /** [zh-CN] 编辑后的消息内容。文本消息可修改 `content` 和 `ext`；`body.targetLanguages` 非空时先翻译再编辑，译文写入 `body.translations`，翻译失败则抛出异常且不发送编辑。自定义消息可修改 `event`、`params` 和 `ext`；图片、语音、视频、文件、位置和合并消息仅可修改 `ext`。命令消息和复合消息不支持编辑。 [en-US] Updated message content. Text messages can change `content` and `ext`. Non-empty `body.targetLanguages` are translated before the edit and stored in `body.translations`; translation failure throws without sending the edit. Custom messages can change `event`, `params`, and `ext`. Image, voice, video, file, location, and combined messages can change `ext` only. Command and multi_body messages cannot be edited. */
    message: Pick<Message, 'type' | 'body' | 'ext'>;
}
/**
 * [zh-CN] 删除历史消息的参数。
 * [en-US] Parameters for removing historical messages.
 */
export interface RemoveHistoryMessagesParams extends ConversationLocator {
    /** [zh-CN] 指定要删除的消息 ID 列表。 [en-US] Message IDs to remove. */
    messageIds?: ReadonlyArray<string>;
    /** [zh-CN] 删除该时间戳之前的历史消息，单位为毫秒。 [en-US] Removes historical messages sent before this timestamp, in milliseconds. */
    beforeTimestamp?: number;
}
/**
 * [zh-CN] 获取历史消息的参数。
 * [en-US] Parameters for retrieving historical messages.
 */
export interface GetHistoryMessagesParams extends ConversationLocator {
    /** [zh-CN] 开始获取数据的游标位置。首次调用时传空字符串或 null，SDK 会按 `searchDirection` 参数的值拉取消息。服务器返回的数据中包含 cursor 字段，需保存在本地；后续调用该接口时，可传入最新的 cursor 作为下一次获取数据的起始位置。 [en-US] The cursor position from which to start fetching data. Pass an empty string or `null` on the first call, and the SDK will retrieve messages according to the value of the `searchDirection` parameter. The data returned by the server contains a cursor field, which needs be saved locally; on subsequent calls to this interface, you can pass the latest cursor as the starting position for the next data retrieval. */
    cursor?: string;
    /** [zh-CN] 每页返回的消息数量。 [en-US] Number of messages returned per page. */
    pageSize?: number;
    /** [zh-CN] 拉取方向。`up` 表示拉取更早的消息，`down` 表示拉取更新的消息。 [en-US] Retrieval direction. `up` retrieves earlier messages, and `down` retrieves more recent messages. */
    searchDirection?: 'up' | 'down';
    /** [zh-CN] 按发送者过滤，仅在群聊场景下生效。 [en-US] The user ID of the message sender. This field takes effect only in group chat. */
    senderIds?: ReadonlyArray<string>;
    /** [zh-CN] 按消息类型过滤。 [en-US] The message type. */
    messageTypes?: ReadonlyArray<Message['type']>;
    /** [zh-CN] 查询起始时间戳，单位为毫秒。 [en-US] Query start timestamp in milliseconds. */
    startTime?: number;
    /** [zh-CN] 查询结束时间戳，单位为毫秒。 [en-US] Query end timestamp in milliseconds. */
    endTime?: number;
}
/**
 * [zh-CN] 历史消息分页结果。
 * [en-US] Paginated result for historical messages.
 */
export interface MessageHistoryPage {
    /** [zh-CN] 当前页的消息列表。 [en-US] Message list in the current page. */
    items: ReadonlyArray<Message>;
    /** [zh-CN] 下一页游标。为空时表示没有后续数据。 [en-US] Cursor for the next page. An empty value indicates that no subsequent data is available. */
    cursor: string;
    /** [zh-CN] 是否还有更多历史消息。 [en-US] Whether more historical messages are available. */
    hasMore: boolean;
}
/**
 * [zh-CN] 下载消息附件的参数。
 * [en-US] Parameters for downloading a message attachment.
 */
export interface DownloadAttachmentParams {
    /** [zh-CN] 需要下载附件的消息，通常为图片、语音、视频、文件或复合消息。复合消息会下载其中全部图片、语音、视频和文件。 [en-US] Message whose attachment is to be downloaded, typically an image, voice, video, file, or multi_body message. A multi_body message downloads every image, voice, video, and file segment. */
    message: Message;
}
/**
 * [zh-CN] 消息附件下载结果。
 * [en-US] Result of downloading a message attachment.
 */
export interface MessageAttachmentDownloadResult {
    /** [zh-CN] 附件文件名。 [en-US] Attachment file name. */
    filename: string;
    /** [zh-CN] 附件的 MIME 类型。 [en-US] MIME type of the attachment. */
    mimeType: string;
    /** [zh-CN] 附件大小，单位为字节。 [en-US] Attachment size, in bytes. */
    size?: number;
    /** [zh-CN] 附件的二进制数据。 [en-US] Binary data of the attachment. */
    data: Uint8Array;
    /** [zh-CN] 实际下载地址。 [en-US] Actual download URL. */
    downloadUrl: string;
}
/**
 * [zh-CN] 使用完整合并消息对象下载并解析合并消息的参数。
 * [en-US] Parameters for downloading and parsing a combined message by using the complete combined message object.
 */
export interface DownloadCombineMessageByMessageInput {
    /** [zh-CN] 合并消息对象。SDK 会从 `message.body` 中读取下载地址和密钥。 [en-US] Combined message object. The SDK reads the download URL and secret from `message.body`. */
    message: Message;
    /** [zh-CN] 下载超时时间，单位为毫秒。未传时使用 SDK 默认值。 [en-US] Download timeout, in milliseconds. If omitted, the SDK default value is used. */
    timeoutMs?: number;
    /** [zh-CN] 单次允许解码的最大消息数量。未传时使用 SDK 默认值。 [en-US] Maximum number of messages that can be decoded in a single request. If omitted, the SDK default value is used. */
    maxItems?: number;
}
/**
 * [zh-CN] 下载并解析合并消息的参数。可传完整 `Message`，也可直接传合并消息体中的最小下载参数 `{ url, secret }`。
 * [en-US] Parameters for downloading and parsing a combine message. You can pass the full `Message`, or pass the minimal download parameters `{ url, secret }` from the combine message body directly.
 */
export type DownloadCombineMessageInput = DownloadCombineMessageByMessageInput | DownloadCombineMessageParams;
/**
 * [zh-CN] 查询群消息已读成员的参数。
 * [en-US] Parameters for querying members who have read a group message.
 */
export interface GroupMessageReadUsersParams {
    /** [zh-CN] 群组 ID。 [en-US] Group ID. */
    groupId: string;
    /** [zh-CN] 群消息 ID。 [en-US] Group message ID. */
    messageId: string;
    /** [zh-CN] 分页游标。 [en-US] Pagination cursor. */
    cursor?: string;
    /** [zh-CN] 每页返回的成员数量。 [en-US] Number of members returned per page. */
    pageSize?: number;
}
/**
 * [zh-CN] 群消息已读成员条目。
 * [en-US] Entry representing a member who has read a group message.
 */
export interface GroupMessageReadUser {
    /** [zh-CN] 用户 ID。 [en-US] User ID. */
    userId: string;
    /** [zh-CN] 用户资料摘要；启用用户资料同步时可能包含群名片。 [en-US] Summary of the user profile; may include the group name card when user-profile sync is enabled. */
    user: GroupUserInfo;
    /** [zh-CN] 服务端回执 ID。 [en-US] Server receipt ID. */
    ackId?: string;
    /** [zh-CN] 已读时间戳，单位毫秒。 [en-US] Read timestamp in milliseconds. */
    timestamp?: number;
    /** [zh-CN] 自定义回执内容。 [en-US] Custom receipt content. */
    ackContent?: string;
}
/**
 * @deprecated [zh-CN] 请改用 `GroupUserInfo`。 [en-US] Use `GroupUserInfo` instead.
 */
export type GroupMessageReadUserInfo = GroupUserInfo;
/**
 * [zh-CN] 群消息已读成员分页结果。
 * [en-US] Paginated result of members who have read a group message.
 */
export interface GroupMessageReadUsersResult {
    /** [zh-CN] 群组 ID。 [en-US] Group ID. */
    groupId: string;
    /** [zh-CN] 群消息 ID。 [en-US] Group message ID. */
    messageId: string;
    /** [zh-CN] 当前页的已读成员列表。 [en-US] List of members who have read the message in the current page. */
    users: ReadonlyArray<GroupMessageReadUser>;
    /** [zh-CN] 已读成员总数。 [en-US] Total number of members who have read the message. */
    count: number;
    /** [zh-CN] 下一页游标。 [en-US] Cursor for the next page. */
    cursor: string;
    /** [zh-CN] 是否还有更多成员。 [en-US] Whether more members are available. */
    hasMore: boolean;
}
/**
 * [zh-CN] 群消息已读回执详情条目。
 * [en-US] Group message read receipt detail item.
 */
export interface MessageReadReceiptDetail {
    /** [zh-CN] 消息 ID。 [en-US] Message ID. */
    readonly messageId: string;
    /** [zh-CN] 已读数量。 [en-US] Read receipt count. */
    readonly count: number;
}
/**
 * [zh-CN] 添加或删除消息 Reaction 的参数。
 * [en-US] Parameters for adding or removing a message Reaction.
 */
export interface ReactionOperationParams {
    /** [zh-CN] 消息 ID。 [en-US] Message ID. */
    messageId: string;
    /** [zh-CN] Reaction 内容，例如表情或业务标识。 [en-US] Reaction content, such as an emoji or a business-defined identifier. */
    reaction: string;
}
/**
 * [zh-CN] 获取消息 Reaction 列表的参数。
 * [en-US] Parameters for retrieving the Reaction list of a message.
 */
export interface GetReactionListParams {
    /** [zh-CN] 单个消息 ID 或消息 ID 列表。 [en-US] A single message ID or a list of message IDs. */
    messageId: string | ReadonlyArray<string>;
    /** [zh-CN] 会话类型；当前支持单聊和群聊。 [en-US] Conversation type. Currently, only one-to-one chat and group chat are supported. */
    conversationType: Extract<ChatConversationType, 'singleChat' | 'groupChat'>;
    /** [zh-CN] 群聊时必填的群组 ID。 [en-US] Group ID. This parameter is required only in group chat. */
    groupId?: string;
}
/**
 * [zh-CN] 单个 Reaction 的汇总信息。
 * [en-US] Summary information for a single Reaction.
 */
export interface MessageReactionSummary {
    /** [zh-CN] Reaction 内容。 [en-US] Reaction content. */
    reaction: string;
    /** [zh-CN] 添加该 Reaction 的用户数量。 [en-US] Number of users who added this Reaction. */
    count: number;
    /** [zh-CN] 当前登录用户是否已添加该 Reaction。 [en-US] Whether the current user has added this Reaction. */
    isAddedBySelf: boolean;
    /** [zh-CN] 添加该 Reaction 的用户 ID 列表。 [en-US] List of user IDs that added this Reaction. */
    userIds: ReadonlyArray<string>;
}
/**
 * [zh-CN] 单条消息的 Reaction 汇总信息。
 * [en-US] Reaction summary for a single message.
 */
export interface MessageReactionListItem {
    /** [zh-CN] 消息 ID。 [en-US] Message ID. */
    messageId: string;
    /** [zh-CN] 该消息上的 Reaction 汇总列表。 [en-US] List of Reaction summaries on the message. */
    reactions: ReadonlyArray<MessageReactionSummary>;
}
/**
 * [zh-CN] 获取 Reaction 详情的参数。
 * [en-US] Parameters for retrieving Reaction details.
 */
export interface GetReactionDetailParams extends ReactionOperationParams {
    /** [zh-CN] 分页游标。 [en-US] Pagination cursor. */
    cursor?: string;
    /** [zh-CN] 每页返回的用户数量。 [en-US] Number of users returned per page. */
    pageSize?: number;
}
/**
 * [zh-CN] Reaction 用户明细条目。
 * [en-US] Detailed user entry for a Reaction.
 */
export interface ReactionUser {
    /** [zh-CN] 用户 ID。 [en-US] User ID. */
    userId: string;
    /** [zh-CN] 用户资料摘要。 [en-US] Summary of the user profile. */
    user: UserInfo;
    /** [zh-CN] 添加 Reaction 的时间。 [en-US] Time when the Reaction was added. */
    createdAt?: string;
}
/**
 * [zh-CN] Reaction 详情分页结果。
 * [en-US] Paginated result of Reaction details.
 */
export interface MessageReactionDetailPage {
    /** [zh-CN] Reaction 内容。 [en-US] Reaction content. */
    reaction: string;
    /** [zh-CN] 添加该 Reaction 的用户数量。 [en-US] Number of users who added this Reaction. */
    count: number;
    /** [zh-CN] 当前用户是否已添加该 Reaction。 [en-US] Whether the current user has added this Reaction. */
    isAddedBySelf: boolean;
    /** [zh-CN] 添加该 Reaction 的用户明细列表。 [en-US] Detailed list of users who added this Reaction. */
    reactionUsers: ReadonlyArray<ReactionUser>;
    /** [zh-CN] 下一页游标。 [en-US] Cursor for the next page. */
    cursor: string;
    /** [zh-CN] 是否还有更多用户。 [en-US] Whether more users are available. */
    hasMore: boolean;
    /** [zh-CN] Reaction 创建时间。 [en-US] Time when the Reaction was created. */
    createdAt?: string;
}
/**
 * [zh-CN] 翻译服务支持的语言。
 * [en-US] Language supported by the translation service.
 */
export interface TranslationLanguage {
    /** [zh-CN] 语言代码。 [en-US] Language code. */
    code: string;
    /** [zh-CN] 语言英文名称，或服务端返回的语言名称。 [en-US] English name of the language, or the language name returned by the server. */
    name: string;
    /** [zh-CN] 语言的本地名称。 [en-US] Native name of the language. */
    nativeName: string;
}
/**
 * [zh-CN] 翻译消息的参数。
 * [en-US] Parameters for translating a message.
 */
export interface TranslateMessageParams {
    /** [zh-CN] 待翻译文本消息。 [en-US] Text message to translate. */
    message: Message;
    /** [zh-CN] 目标语言代码列表。 [en-US] List of target language codes. */
    targetLanguages: ReadonlyArray<string>;
}
/**
 * [zh-CN] 语音转文字的可选参数。
 * [en-US] Optional parameters for voice-to-text.
 */
export interface VoiceParams {
    /** [zh-CN] 语音格式，例如 `amr`、`mp3`、`pcm`。 [en-US] voice format, for example, `amr`, `mp3`, or `pcm`. */
    readonly format?: string;
    /** [zh-CN] 采样率。 [en-US] Sampling rate. */
    readonly sampleRate?: number;
    /** [zh-CN] 采样位深。 [en-US] Bit depth per sample. */
    readonly bitsPerSample?: number;
    /** [zh-CN] 声道数。 [en-US] Channel count. */
    readonly channels?: number;
}
/**
 * [zh-CN] 旧 SDK 兼容的语音消息体输入。
 * [en-US] Legacy-compatible voice message body input.
 */
export type VoiceMessageSource = VoiceMessageBody & {
    readonly type?: 'voice';
};
/**
 * [zh-CN] 语音文件输入，当前明确支持浏览器 `File` 与小程序 `MiniAppFile`。
 * [en-US] Voice file input. The current feature explicitly supports browser `File` and miniapp `MiniAppFile`.
 */
export type VoiceSourceFile = File | MiniAppFile;
/**
 * [zh-CN] 语音转文字的业务结果。
 * [en-US] Voice-to-text business result.
 */
export interface VoiceToTextResult {
    /** [zh-CN] 转写得到的文本内容。 [en-US] Transcribed text content. */
    readonly text: string;
}
/**
 * [zh-CN] 单条翻译结果。
 * [en-US] Result of a single translation.
 */
export interface MessageTranslation {
    /** [zh-CN] 翻译后的文本内容。 [en-US] Translated text content. */
    text: string;
    /** [zh-CN] 目标语言代码。 [en-US] Target language code. */
    to: string;
}
/**
 * [zh-CN] 消息翻译结果。
 * [en-US] Message translation result.
 */
export interface MessageTranslationResult {
    /** [zh-CN] 服务端识别出的源语言信息。 [en-US] Source language detected by the server. */
    detectedLanguage?: {
        /** [zh-CN] 源语言代码。 [en-US] Source language code. */
        language: string;
        /** [zh-CN] 识别置信度。 [en-US] Detection confidence score. */
        score: number;
    };
    /** [zh-CN] 翻译结果列表。 [en-US] List of translation results. */
    translations: ReadonlyArray<MessageTranslation>;
}
/**
 * [zh-CN] 消息送达回执事件载荷。
 *
 * 触发时机：接收方的 SDK 自动回传送达回执后，发送方会收到此事件。
 * 接收方：消息的原始发送方。
 * 前提：接收方初始化时已设置 `enableDeliveryReceipt: true`。
 *
 * [en-US] Payload of the message delivery receipt event.
 *
 * Triggered when: The recipient's SDK automatically sends a delivery receipt to the sender.
 * Received by: The original sender of the message.
 * Prerequisite: `enableDeliveryReceipt: true` is set when the recipient initializes the SDK.
 */
export interface MessageDeliveredEventPayload {
    /** [zh-CN] 已送达的原始消息 ID。 [en-US] ID of the original message that is delivered. */
    readonly messageId: string;
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型，固定为 `singleChat`。 [en-US] Conversation type, always `singleChat`. */
    readonly conversationType: 'singleChat';
}
interface MessageReceiptEventBase {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 本次回执包含的消息 ID 列表。 [en-US] Message IDs included in this receipt event. */
    readonly messageIds: ReadonlyArray<string>;
    /** [zh-CN] 回执时间戳。 [en-US] Receipt timestamp. */
    readonly timestamp: number;
}
/**
 * [zh-CN] 单聊消息已读回执事件载荷。
 *
 * 触发时机：对方发送单聊消息已读回执。接收方为消息的原始发送方。
 *
 * [en-US] Payload of a one-to-one message read receipt event.
 *
 * Triggered when: The peer user sends a one-to-one message read receipt. The original message sender receives this event.
 */
export interface SingleChatMessageReceiptEventPayload extends MessageReceiptEventBase {
    /** [zh-CN] 会话类型，固定为 `singleChat`。 [en-US] Conversation type, always `singleChat`. */
    readonly conversationType: 'singleChat';
}
/**
 * [zh-CN] 群聊消息已读回执事件载荷。
 *
 * 触发时机：群成员发送群消息已读回执。接收方为消息的原始发送方；每条详情中的 `count` 是该消息的累计已读人数。
 *
 * [en-US] Payload of a group message read receipt event.
 *
 * Triggered when: A group member sends a group message read receipt. The original message sender receives this event; `count` in each detail is the cumulative read count of that message.
 */
export interface GroupChatMessageReceiptEventPayload extends MessageReceiptEventBase {
    /** [zh-CN] 会话类型，固定为 `groupChat`。 [en-US] Conversation type, always `groupChat`. */
    readonly conversationType: 'groupChat';
    /** [zh-CN] 按消息 ID 返回的累计已读人数详情。 [en-US] Cumulative read-count details keyed by message ID. */
    readonly receiptDetails: ReadonlyArray<MessageReadReceiptDetail>;
}
/**
 * [zh-CN] 消息已读回执事件载荷；通过 `conversationType` 区分单聊与群聊结构。
 * [en-US] Message read receipt event payload discriminated by `conversationType`.
 */
export type MessageReceiptEventPayload = SingleChatMessageReceiptEventPayload | GroupChatMessageReceiptEventPayload;
/**
 * [zh-CN] 消息撤回事件载荷。
 *
 * 触发时机：发送方撤回消息，或群主/管理员撤回群内其他成员发送的消息。
 * 接收方：除当前操作设备外的会话成员，以及撤回者的其他已登录设备。
 *
 * [en-US] Payload of the message recall event.
 *
 * Triggered when: The sender recalls a message, or the group owner or admin recalls a message sent by another group member.
 * Received by: Conversation members and the recaller's other login devices, except the device performing the operation.
 */
export interface MessageRecalledEventPayload extends ConversationLocator {
    /** [zh-CN] 被撤回的消息 ID。 [en-US] ID of the recalled message. */
    messageId: string;
    /** [zh-CN] 撤回时间戳。 [en-US] Recall timestamp. */
    timestamp: number;
}
/**
 * [zh-CN] 消息编辑事件载荷。
 *
 * 触发时机：发送方编辑已发送的消息。
 * 接收方：除当前操作设备外的会话成员，以及编辑者的其他已登录设备。
 *
 * [en-US] Payload of the message edit event.
 *
 * Triggered when: The sender edits a successfully sent message.
 * Received by: Conversation members and the editor's other login devices, except the device performing the operation.
 */
export interface MessageUpdatedEventPayload extends ConversationLocator {
    /** [zh-CN] 被编辑的消息 ID。 [en-US] ID of the edited message. */
    messageId: string;
    /** [zh-CN] 编辑后的消息内容。 [en-US] Updated message content. */
    message: Pick<Message, 'type' | 'body' | 'ext' | 'modifiedInfo'>;
    /** [zh-CN] 编辑时间戳。 [en-US] Timestamp when the message was edited. */
    timestamp: number;
}
/**
 * [zh-CN] Reaction 变更事件载荷。
 *
 * 触发时机：会话中有成员对消息添加或移除 Reaction。
 * 接收方：会话内的所有成员。
 * 注意：当前仅支持单聊和群聊，不支持聊天室。
 *
 * [en-US] Payload of the Reaction change event.
 *
 * Triggered when: A member adds or removes a Reaction on a message in the conversation.
 * Received by: All members in the conversation.
 * Note: Currently, only one-to-one chat and group chat are supported. Chat rooms are not supported.
 */
export interface ReactionChangedEventPayload {
    /** [zh-CN] 消息 ID。 [en-US] Message ID. */
    messageId: string;
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    conversationId: string;
    /** [zh-CN] 会话类型（仅 singleChat 或 groupChat）。 [en-US] Conversation type. */
    conversationType: Extract<ChatConversationType, 'singleChat' | 'groupChat'>;
    /** [zh-CN] 消息发送者的用户 ID。 [en-US] User ID of the message sender. */
    from: string;
    /** [zh-CN] 消息接收方 ID。单聊场景下为对端用户 ID，群聊场景下为群组 ID。 [en-US] Recipient ID of the message. In one-to-one chat, this value is the peer user ID. In group chat, this value is the group ID. */
    to: string;
    /** [zh-CN] 当前消息上的完整 Reaction 列表。 [en-US] Complete list of current Reactions on the message. */
    reactions: ReadonlyArray<MessageReaction>;
    /** [zh-CN] Reaction 更新时间戳。 [en-US] Timestamp when the Reaction was last updated.  */
    timestamp: number;
}
/**
 * [zh-CN] 消息置顶变更事件载荷。
 *
 * 触发时机：会话中有成员置顶消息或取消置顶消息。
 * 接收方：除当前操作设备外的会话成员，以及当前用户的其他设备。
 *
 * [en-US] Payload of the message pinning status change event.
 *
 * Triggered when: A member pins or unpins a message in the conversation.
 * Received by: Conversation members and the current user's other devices, except the device performing the operation.
 */
export interface PinnedMessageChangedEventPayload extends ConversationLocator {
    /** [zh-CN] 消息 ID。 [en-US] Message ID. */
    messageId: string;
    /** [zh-CN] 操作类型。 [en-US] Operation type. */
    operation: 'pin' | 'unpin';
    /** [zh-CN] 置顶时间戳。 [en-US] Timestamp when the message was pinned. */
    pinTime?: number;
    /** [zh-CN] 操作者的用户 ID。 [en-US] User ID of the operator. */
    operatorId?: string;
}
/**
 * [zh-CN] 消息动作结果，适用于撤回等基于动作通道完成的操作。
 * [en-US] Result of a message action, applicable to operations such as recall that are completed through the action channel.
 */
export interface ChatActionResult {
    /** [zh-CN] 消息 ID。 [en-US] Message ID. */
    messageId: string;
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    conversationType: ChatConversationType;
    /** [zh-CN] 动作完成时间戳，单位毫秒。 [en-US] Timestamp when the action completed, in milliseconds. */
    timestamp: number;
}
/** @internal SDK 消息动作通道的内部载荷。 */
export interface ChatMessageAction {
    readonly kind: 'clearConversationUnreadMessageCount' | 'clearAllConversationUnreadMessageCount' | 'sendMessageReadReceipts' | 'recall' | 'update' | 'deliveryAck';
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType: ChatConversationType;
    /** [zh-CN] 消息 ID。 [en-US] Message ID. */
    readonly messageId?: string;
    readonly messageIds?: ReadonlyArray<string>;
    readonly sendToPeer?: boolean;
    readonly clearAllUnreadMessageCount?: boolean;
    readonly body?: MessageBody;
    readonly messageType?: Message['type'];
    readonly ext?: Record<string, unknown>;
}
/**
 * [zh-CN] 消息搜索关键词匹配模式。
 * [en-US] Keyword match type for message search.
 */
export type MessageSearchKeywordMatchType = 'or' | 'and';
/**
 * [zh-CN] 消息搜索范围。
 * [en-US] Message search scope.
 */
export type MessageSearchScope = 'none' | 'with' | 'only';
/**
 * [zh-CN] 消息搜索排序方向。
 * [en-US] Message search sort direction.
 */
export type MessageSearchDirection = 'up' | 'down';
/**
 * [zh-CN] 消息搜索支持的消息类型。
 * [en-US] Message types supported by server search.
 */
export type SearchableMessageType = 'txt' | 'img' | 'video' | 'file' | 'loc' | 'custom' | 'combine';
/**
 * [zh-CN] 消息搜索选项。
 * [en-US] Message search options.
 */
export interface MessageSearchOption {
    /** [zh-CN] 搜索关键词列表。该参数必传，最多支持 5 个关键词，且每个关键词最长为 150 个字符。 [en-US] List of search keywords. This parameter is required, supports up to 5 keywords, and each keyword can contain at most 150 characters. */
    keywordList: ReadonlyArray<string>;
    /** [zh-CN] 多关键词的匹配关系，默认值为 `or`。 [en-US] Matching rule for multiple keywords. The default value is `or`. */
    keywordListMatchType?: MessageSearchKeywordMatchType;
    /** [zh-CN] 会话内搜索时的会话 ID。 [en-US] Conversation ID used when searching within a specified conversation. */
    conversationId?: string;
    /** [zh-CN] 会话类型过滤，需与 conversationId 配合使用。 [en-US] Conversation type filter, must be used with conversationId. */
    conversationType?: ChatConversationType;
    /** [zh-CN] 消息体类型过滤条件。不支持 `audio` 和 `cmd` 类型。 [en-US] Filter condition for message body types. `audio` and `cmd` types are not supported. */
    msgTypes?: ReadonlyArray<SearchableMessageType>;
    /** [zh-CN] 查询开始时间戳，单位为毫秒；需与 `endTime` 同时传入。 [en-US] Query start timestamp, in milliseconds. This field must be provided together with `endTime`. */
    startTime?: number;
    /** [zh-CN] 查询结束时间戳，单位为毫秒；需与 `startTime` 同时传入。 [en-US] Query end timestamp, in milliseconds. This field must be provided together with `startTime`. */
    endTime?: number;
    /** [zh-CN] 搜索范围。`none` 表示仅搜索消息体，`with` 表示搜索消息体和扩展字段，`only` 表示仅搜索扩展字段。 [en-US] Search scope. `none` means searching only the message body, `with` means searching both the message body and extension fields, and `only` means searching only extension fields. */
    searchScope?: MessageSearchScope;
    /** [zh-CN] 搜索方向。`up` 表示从旧消息到新消息，`down` 表示从新消息到旧消息。 [en-US] Search direction. `up`: from older to newer messages; `down`: from newer to older messages. */
    direction?: MessageSearchDirection;
}
/**
 * [zh-CN] 服务端消息搜索参数。
 * [en-US] Parameters for server-side message search.
 */
export interface SearchMessagesParams {
    /** [zh-CN] 搜索选项。 [en-US] Search options. */
    option: MessageSearchOption;
    /** [zh-CN] 当前页码，从 1 开始。默认值为 1。 [en-US] Current page number, starting from 1. The default value is 1. */
    pageNum?: number;
    /** [zh-CN] 每页返回数量。取值范围为 [1, 100]，默认值为 20。 [en-US] Number of items returned per page. The value range is [1, 100], and the default value is 20. */
    pageSize?: number;
}
/**
 * [zh-CN] 搜索结果中的单条消息。
 * [en-US] Single message item in the search result.
 */
export interface SearchResultMessage extends Message {
    /** [zh-CN] 服务端返回的高亮片段列表。 [en-US] List of highlighted snippets returned by the server. */
    highlight?: ReadonlyArray<string>;
    /** [zh-CN] 服务端返回的摘要文本。 [en-US] Summary text returned by the server. */
    text?: string;
}
/**
 * [zh-CN] 服务端消息搜索结果。
 * [en-US] Result of server-side message search.
 */
export interface SearchMessagesResult {
    /** [zh-CN] 搜索结果消息列表。 [en-US] List of messages in the search result. */
    messages: ReadonlyArray<SearchResultMessage>;
    /** [zh-CN] 当前页码。 [en-US] Current page number. */
    pageNum: number;
    /** [zh-CN] 请求页大小。 [en-US] Requested page size. */
    pageSize: number;
    /** [zh-CN] 总页数。 [en-US] Total number of pages. */
    totalPages: number;
    /** [zh-CN] 是否为最后一页。 [en-US] Whether this is the last page. */
    isLast: boolean;
}
