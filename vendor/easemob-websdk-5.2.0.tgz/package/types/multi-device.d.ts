/**
 * [zh-CN] MultiDevice 公开类型定义。
 * [en-US] Public type definitions for ChatClient multi-device events.
 */
import type { ConversationType } from './conversation';
/**
 * [zh-CN] MultiDevice 事件分类。
 * [en-US] MultiDevice event categories.
 */
export declare const MultiDeviceEventCategory: {
    readonly CONTACT: "contact";
    readonly GROUP: "group";
    readonly THREAD: "thread";
    readonly CONVERSATION: "conversation";
    readonly MESSAGE_REMOVED: "messageRemoved";
};
/**
 * [zh-CN] 多设备事件分类。
 * [en-US] Multi-device event category.
 */
export type MultiDeviceEventCategory = (typeof MultiDeviceEventCategory)[keyof typeof MultiDeviceEventCategory];
/**
 * [zh-CN] 好友类多设备操作。
 * [en-US] Contact multi-device operations.
 */
export declare const MultiDeviceContactOperation: {
    readonly CONTACT_REMOVE: "CONTACT_REMOVE";
    readonly CONTACT_ACCEPT: "CONTACT_ACCEPT";
    readonly CONTACT_DECLINE: "CONTACT_DECLINE";
    readonly CONTACT_BAN: "CONTACT_BAN";
    readonly CONTACT_ALLOW: "CONTACT_ALLOW";
    readonly UNKNOWN: "UNKNOWN";
};
/**
 * [zh-CN] 联系人类多设备操作。
 * [en-US] Contact multi-device operation.
 */
export type MultiDeviceContactOperation = (typeof MultiDeviceContactOperation)[keyof typeof MultiDeviceContactOperation];
/**
 * [zh-CN] 群组类多设备操作。
 * [en-US] Group multi-device operations.
 */
export declare const MultiDeviceGroupOperation: {
    readonly GROUP_CREATE: "GROUP_CREATE";
    readonly GROUP_DESTROY: "GROUP_DESTROY";
    readonly GROUP_JOIN: "GROUP_JOIN";
    readonly GROUP_LEAVE: "GROUP_LEAVE";
    readonly GROUP_APPLY: "GROUP_APPLY";
    readonly GROUP_APPLY_ACCEPT: "GROUP_APPLY_ACCEPT";
    readonly GROUP_APPLY_DECLINE: "GROUP_APPLY_DECLINE";
    readonly GROUP_INVITE: "GROUP_INVITE";
    readonly GROUP_INVITE_ACCEPT: "GROUP_INVITE_ACCEPT";
    readonly GROUP_INVITE_DECLINE: "GROUP_INVITE_DECLINE";
    readonly GROUP_KICK: "GROUP_KICK";
    readonly GROUP_BAN: "GROUP_BAN";
    readonly GROUP_ALLOW: "GROUP_ALLOW";
    readonly GROUP_BLOCK: "GROUP_BLOCK";
    readonly GROUP_UNBLOCK: "GROUP_UNBLOCK";
    readonly GROUP_ASSIGN_OWNER: "GROUP_ASSIGN_OWNER";
    readonly GROUP_ADD_ADMIN: "GROUP_ADD_ADMIN";
    readonly GROUP_REMOVE_ADMIN: "GROUP_REMOVE_ADMIN";
    readonly GROUP_ADD_MUTE: "GROUP_ADD_MUTE";
    readonly GROUP_REMOVE_MUTE: "GROUP_REMOVE_MUTE";
    readonly GROUP_ADD_USER_WHITE_LIST: "GROUP_ADD_USER_WHITE_LIST";
    readonly GROUP_REMOVE_USER_WHITE_LIST: "GROUP_REMOVE_USER_WHITE_LIST";
    readonly GROUP_ALL_BAN: "GROUP_ALL_BAN";
    readonly GROUP_REMOVE_ALL_BAN: "GROUP_REMOVE_ALL_BAN";
    readonly GROUP_MEMBER_METADATA_CHANGED: "GROUP_MEMBER_METADATA_CHANGED";
    readonly GROUP_UPDATED: "GROUP_UPDATED";
    readonly UNKNOWN: "UNKNOWN";
};
/**
 * [zh-CN] 群组类多设备操作。
 * [en-US] Group multi-device operation.
 */
export type MultiDeviceGroupOperation = (typeof MultiDeviceGroupOperation)[keyof typeof MultiDeviceGroupOperation];
/**
 * [zh-CN] 消息话题类多设备操作。
 * [en-US] Message thread multi-device operations.
 */
export declare const MultiDeviceThreadOperation: {
    readonly THREAD_CREATE: "THREAD_CREATE";
    readonly THREAD_JOIN: "THREAD_JOIN";
    readonly THREAD_UPDATE: "THREAD_UPDATE";
    readonly THREAD_LEAVE: "THREAD_LEAVE";
    readonly THREAD_DESTROY: "THREAD_DESTROY";
    readonly THREAD_KICK: "THREAD_KICK";
    readonly UNKNOWN: "UNKNOWN";
};
/**
 * [zh-CN] 消息话题类多设备操作。
 * [en-US] Chat thread multi-device operation.
 */
export type MultiDeviceThreadOperation = (typeof MultiDeviceThreadOperation)[keyof typeof MultiDeviceThreadOperation];
/**
 * [zh-CN] 会话类多设备操作。
 * [en-US] Conversation multi-device operations.
 */
export declare const MultiDeviceConversationOperation: {
    readonly CONVERSATION_DELETED: "CONVERSATION_DELETED";
    readonly CONVERSATION_PINNED: "CONVERSATION_PINNED";
    readonly CONVERSATION_UNPINNED: "CONVERSATION_UNPINNED";
    readonly CONVERSATION_MARK: "CONVERSATION_MARK";
    readonly CONVERSATION_MUTE_INFO_CHANGED: "CONVERSATION_MUTE_INFO_CHANGED";
    readonly CONVERSATION_UNREAD_MESSAGE_COUNT_CLEARED: "CONVERSATION_UNREAD_MESSAGE_COUNT_CLEARED";
    readonly ALL_CONVERSATIONS_UNREAD_MESSAGE_COUNT_CLEARED: "ALL_CONVERSATIONS_UNREAD_MESSAGE_COUNT_CLEARED";
    readonly UNKNOWN: "UNKNOWN";
};
/**
 * [zh-CN] 会话类多设备操作。
 * [en-US] Conversation multi-device operation.
 */
export type MultiDeviceConversationOperation = (typeof MultiDeviceConversationOperation)[keyof typeof MultiDeviceConversationOperation];
/**
 * [zh-CN] 漫游消息删除类多设备操作。
 * [en-US] Roaming message deletion multi-device operations.
 */
export declare const MultiDeviceMessageRemovedOperation: {
    readonly MESSAGE_REMOVED: "MESSAGE_REMOVED";
    readonly UNKNOWN: "UNKNOWN";
};
/**
 * [zh-CN] 漫游消息删除类多设备操作。
 * [en-US] Roaming message removal multi-device operation.
 */
export type MultiDeviceMessageRemovedOperation = (typeof MultiDeviceMessageRemovedOperation)[keyof typeof MultiDeviceMessageRemovedOperation];
/**
 * [zh-CN] MultiDevice 公共载荷基类。
 * [en-US] Shared base payload for multi-device operations.
 */
export interface MultiDeviceEventBase {
    /** [zh-CN] 事件分类。 [en-US] Event category. */
    readonly category: MultiDeviceEventCategory;
    /** [zh-CN] 标准化操作名。 [en-US] Normalized operation name. */
    readonly operation: MultiDeviceContactOperation | MultiDeviceGroupOperation | MultiDeviceThreadOperation | MultiDeviceConversationOperation | MultiDeviceMessageRemovedOperation;
    /** [zh-CN] 来源设备 ID。 [en-US] Source device ID. */
    readonly deviceId?: string;
    /** [zh-CN] 事件时间戳。 [en-US] Event timestamp. */
    readonly timestamp?: number;
    /** [zh-CN] 原始调试数据。 [en-US] Raw debug data. */
    readonly raw?: Readonly<Record<string, unknown>>;
}
/**
 * [zh-CN] 联系人类多设备事件。
 * [en-US] Contact multi-device event.
 */
export interface MultiDeviceContactEvent extends MultiDeviceEventBase {
    /** [zh-CN] 固定为联系人事件分类。 [en-US] Always the contact event category. */
    readonly category: 'contact';
    /** [zh-CN] 联系人操作。 [en-US] Contact operation. */
    readonly operation: MultiDeviceContactOperation;
    /** [zh-CN] 目标用户 ID。 [en-US] Target user ID. */
    readonly targetUserId: string;
    /** [zh-CN] 联系人列表版本。 [en-US] Contact roster version. */
    readonly rosterVersion?: string;
    /** [zh-CN] 服务端扩展数据。 [en-US] Server extension data. */
    readonly ext?: string;
}
/**
 * [zh-CN] 群组类多设备事件。
 * [en-US] Group multi-device event.
 */
export interface MultiDeviceGroupEvent extends MultiDeviceEventBase {
    /** [zh-CN] 固定为群组事件分类。 [en-US] Always the group event category. */
    readonly category: 'group';
    /** [zh-CN] 群组操作。 [en-US] Group operation. */
    readonly operation: MultiDeviceGroupOperation;
    /** [zh-CN] 群组 ID。 [en-US] Group ID. */
    readonly groupId: string;
    /** [zh-CN] 相关用户 ID 列表。 [en-US] Related user IDs. */
    readonly userIds?: ReadonlyArray<string>;
    /** [zh-CN] 操作者用户 ID。 [en-US] Operator user ID. */
    readonly operatorId?: string;
    /** [zh-CN] 群组名称。 [en-US] Group name. */
    readonly groupName?: string;
}
/**
 * [zh-CN] 消息话题类多设备事件。
 * [en-US] Chat thread multi-device event.
 */
export interface MultiDeviceThreadEvent extends MultiDeviceEventBase {
    /** [zh-CN] 固定为消息话题事件分类。 [en-US] Always the chat thread event category. */
    readonly category: 'thread';
    /** [zh-CN] 消息话题操作。 [en-US] Chat thread operation. */
    readonly operation: MultiDeviceThreadOperation;
    /** [zh-CN] 消息话题 ID。 [en-US] Chat thread ID. */
    readonly threadId: string;
    /** [zh-CN] 父消息 ID。 [en-US] Parent message ID. */
    readonly parentId?: string;
    /** [zh-CN] 相关用户 ID 列表。 [en-US] Related user IDs. */
    readonly userIds?: ReadonlyArray<string>;
    /** [zh-CN] 操作者用户 ID。 [en-US] Operator user ID. */
    readonly operatorId?: string;
    /** [zh-CN] 消息话题名称。 [en-US] Chat thread name. */
    readonly threadName?: string;
}
interface MultiDeviceConversationEventBase extends MultiDeviceEventBase {
    /** [zh-CN] 固定为会话事件分类。 [en-US] Always the conversation event category. */
    readonly category: 'conversation';
    /** [zh-CN] 会话操作。 [en-US] Conversation operation. */
    readonly operation: MultiDeviceConversationOperation;
    /** [zh-CN] 会话标记槽位。 [en-US] Conversation mark slot. */
    readonly mark?: number;
    /** [zh-CN] 消息提醒类型。 [en-US] Message reminder type. */
    readonly remindType?: string;
    /** [zh-CN] 免打扰配置快照。 [en-US] Silent mode configuration snapshot. */
    readonly silentMode?: Readonly<Record<string, unknown>>;
    /** [zh-CN] 操作者用户 ID。 [en-US] Operator user ID. */
    readonly operatorId?: string;
}
/**
 * [zh-CN] 单个会话相关的多设备事件。
 * [en-US] Multi-device event scoped to one conversation.
 */
export interface MultiDeviceScopedConversationEvent extends MultiDeviceConversationEventBase {
    /** [zh-CN] 单会话操作。 [en-US] Single-conversation operation. */
    readonly operation: Exclude<MultiDeviceConversationOperation, 'ALL_CONVERSATIONS_UNREAD_MESSAGE_COUNT_CLEARED'>;
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType?: ConversationType;
}
/**
 * [zh-CN] 其他设备清空所有会话未读数事件。
 * [en-US] Event emitted when another device clears unread counts for all conversations.
 */
export interface MultiDeviceAllConversationsUnreadClearedEvent extends MultiDeviceConversationEventBase {
    /** [zh-CN] 固定为清空全部会话未读数操作。 [en-US] Always the clear-all-conversation-unread-counts operation. */
    readonly operation: 'ALL_CONVERSATIONS_UNREAD_MESSAGE_COUNT_CLEARED';
}
/**
 * [zh-CN] 会话类多设备事件；通过 `operation` 区分单会话动作与清空全部会话未读数。
 * [en-US] Conversation multi-device event discriminated by `operation`.
 */
export type MultiDeviceConversationEvent = MultiDeviceScopedConversationEvent | MultiDeviceAllConversationsUnreadClearedEvent;
/**
 * [zh-CN] 漫游消息删除类多设备事件。
 * [en-US] Roaming message removal multi-device event.
 */
export interface MultiDeviceMessageRemovedEvent extends MultiDeviceEventBase {
    /** [zh-CN] 固定为消息删除事件分类。 [en-US] Always the message removal event category. */
    readonly category: 'messageRemoved';
    /** [zh-CN] 消息删除操作。 [en-US] Message removal operation. */
    readonly operation: MultiDeviceMessageRemovedOperation;
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType?: ConversationType;
    /** [zh-CN] 被删除的消息 ID 列表。 [en-US] Removed message IDs. */
    readonly messageIds?: ReadonlyArray<string>;
    /** [zh-CN] 删除该时间戳之前的消息，单位毫秒。 [en-US] Removes messages before this timestamp, in milliseconds. */
    readonly beforeTimestamp?: number;
}
/**
 * [zh-CN] 所有公开多设备事件的联合类型。
 * [en-US] Union of all public multi-device events.
 */
export type MultiDeviceEvent = MultiDeviceContactEvent | MultiDeviceGroupEvent | MultiDeviceThreadEvent | MultiDeviceConversationEvent | MultiDeviceMessageRemovedEvent;
/**
 * [zh-CN] ChatClient 多设备监听器映射。
 * [en-US] ChatClient multi-device handler map.
 */
export interface MultiDeviceEventHandlerMap {
    /** [zh-CN] 联系人多设备事件。 [en-US] Contact multi-device event. */
    readonly onMultiDeviceContact?: (event: MultiDeviceContactEvent) => void | Promise<void>;
    /** [zh-CN] 群组多设备事件。 [en-US] Group multi-device event. */
    readonly onMultiDeviceGroup?: (event: MultiDeviceGroupEvent) => void | Promise<void>;
    /** [zh-CN] 消息话题多设备事件。 [en-US] Message thread multi-device event. */
    readonly onMultiDeviceThread?: (event: MultiDeviceThreadEvent) => void | Promise<void>;
    /** [zh-CN] 会话多设备事件。 [en-US] Conversation multi-device event. */
    readonly onMultiDeviceConversation?: (event: MultiDeviceConversationEvent) => void | Promise<void>;
    /** [zh-CN] 漫游消息删除多设备事件。 [en-US] Roaming message deletion multi-device event. */
    readonly onMultiDeviceMessageRemoved?: (event: MultiDeviceMessageRemovedEvent) => void | Promise<void>;
}
export {};
