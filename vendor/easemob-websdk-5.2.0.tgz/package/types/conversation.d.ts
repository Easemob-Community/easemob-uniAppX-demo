/**
 * [zh-CN] Conversation 公开类型定义。
 * [en-US] Public conversation type definitions.
 */
import type { Message } from './index';
export type { Sender } from './sender';
export declare const CONVERSATION_TYPE: {
    readonly SINGLE_CHAT: "singleChat";
    readonly GROUP_CHAT: "groupChat";
    readonly CHAT_ROOM: "chatRoom";
};
/**
 * [zh-CN] 会话类型。
 * [en-US] Conversation type.
 */
export type ConversationType = (typeof CONVERSATION_TYPE)[keyof typeof CONVERSATION_TYPE];
/**
 * [zh-CN] 会话标记槽位常量，实际业务含义由开发者维护。
 * [en-US] Conversation mark slot constants (value range: 0-19); the actual business meaning is defined and maintained by the application layer.
 */
export declare const CONVERSATION_MARK: {
    readonly MARK_0: 0;
    readonly MARK_1: 1;
    readonly MARK_2: 2;
    readonly MARK_3: 3;
    readonly MARK_4: 4;
    readonly MARK_5: 5;
    readonly MARK_6: 6;
    readonly MARK_7: 7;
    readonly MARK_8: 8;
    readonly MARK_9: 9;
    readonly MARK_10: 10;
    readonly MARK_11: 11;
    readonly MARK_12: 12;
    readonly MARK_13: 13;
    readonly MARK_14: 14;
    readonly MARK_15: 15;
    readonly MARK_16: 16;
    readonly MARK_17: 17;
    readonly MARK_18: 18;
    readonly MARK_19: 19;
};
/**
 * [zh-CN] 会话标记槽位，取值范围为 0 至 19。
 * [en-US] Conversation mark slot with a value from 0 to 19.
 */
export type ConversationMark = (typeof CONVERSATION_MARK)[keyof typeof CONVERSATION_MARK];
/**
 * [zh-CN] 会话唯一标识。
 * [en-US] Unique conversation identifier.
 */
export interface ConversationIdentifier {
    /** [zh-CN] 会话 ID：单聊时为对方用户 ID，群聊时为群组 ID，聊天室时为聊天室 ID。 [en-US] Conversation ID: User ID for one-to-one chats, group ID for group chats, or chat room ID for chat rooms. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType: ConversationType;
}
/**
 * [zh-CN] 设置或移除会话标记时的会话定位参数。
 * [en-US] Conversation locator used when setting or removing conversation marks.
 */
export type ConversationMarkTarget = ConversationIdentifier;
/**
 * [zh-CN] 会话列表查询过滤条件。
 * [en-US] Filter criteria for querying the conversation list.
 */
export interface ConversationFilter {
    /** [zh-CN] 若为 true，则仅返回已置顶的会话。 [en-US] If true, the SDK returns only pinned conversations. */
    readonly isPinned?: boolean;
    /** [zh-CN] 按会话标记槽位过滤，取值范围 0 至 19。 [en-US] Filters by conversation mark slot. The value range is 0-19. */
    readonly mark?: ConversationMark;
}
/**
 * [zh-CN] 删除会话的操作参数。
 * [en-US] Parameters for deleting a conversation.
 */
export interface DeleteConversationParams extends ConversationIdentifier {
    /** [zh-CN] 是否同时删除服务端存储的漫游消息。 [en-US] Whether to also delete the roaming messages stored on the server. */
    readonly deleteRoamingMessages?: boolean;
}
/**
 * [zh-CN] 设置会话置顶状态的操作参数。
 * [en-US] Parameters for setting the pinned status of a conversation.
 */
export interface SetConversationPinnedParams extends ConversationIdentifier {
    /** [zh-CN] `true` 表示置顶，`false` 表示取消置顶。 [en-US] `true`： pins the conversation, `false`： unpins the conversation. */
    readonly pinned: boolean;
}
/**
 * [zh-CN] 添加或移除会话标记的参数，支持单个会话或批量会话。
 * [en-US] Parameters for adding or removing conversation marks, supporting either a single conversation or batch conversations.
 */
export type ConversationMarkParams = {
    /** [zh-CN] 需要操作的会话列表。 [en-US] List of conversations to operate on. */
    readonly conversations: ReadonlyArray<ConversationMarkTarget>;
    /** [zh-CN] 会话标记槽位，取值范围 0 至 19。 [en-US] Conversation mark slot. The valid range is 0-19. */
    readonly mark: ConversationMark;
} | (ConversationIdentifier & {
    /** [zh-CN] 会话标记槽位，取值范围 0 至 19。 [en-US] Conversation mark slot. The valid range is 0-19. */
    readonly mark: ConversationMark;
});
/**
 * [zh-CN] 单个会话的标记变更结果。
 * [en-US] Result of a mark mutation operation for a single conversation.
 */
export interface ConversationMarkMutationItem extends ConversationIdentifier {
    /** [zh-CN] 操作失败原因；成功项不包含该字段。 [en-US] Failure reason; this field is omitted for successful operations. */
    readonly reason?: string;
}
/**
 * [zh-CN] 会话标记变更结果。
 * [en-US] Result of a batch conversation mark mutation operation.
 */
export interface ConversationMarkMutationResult {
    /** [zh-CN] 成功应用标记变更的会话。 [en-US] Conversations with mark change successfully applied. */
    readonly succeeded: ReadonlyArray<ConversationMarkMutationItem>;
    /** [zh-CN] 未能应用标记变更的会话。 [en-US] Conversations that failed to apply the mark change. */
    readonly failed: ReadonlyArray<ConversationMarkMutationItem>;
    /** [zh-CN] 本次操作涉及的标记槽位。 [en-US] The mark slot involved in this operation. */
    readonly mark: ConversationMark;
    /** [zh-CN] 标记操作类型：添加或移除。 [en-US] Mark operation type: add or remove. */
    readonly operation: 'addMark' | 'removeMark';
}
/**
 * [zh-CN] 置顶或取消置顶消息的参数。
 * [en-US] Parameters for pinning or unpinning a message.
 */
export interface PinMessageParams extends ConversationIdentifier {
    /** [zh-CN] 待操作的消息 ID。 [en-US] ID of the message to pin or unpin. */
    readonly messageId: string;
}
/**
 * [zh-CN] 获取会话内置顶消息列表的参数。该接口不分页，最多返回 20 条置顶消息。
 * [en-US] Parameters for retrieving the list of pinned messages in a conversation. This API does not support pagination and returns a maximum of 20 pinned messages.
 */
export type GetPinnedMessageListParams = ConversationIdentifier;
/**
 * [zh-CN] 会话变更结果。
 * [en-US] Conversation mutation result.
 */
export interface ConversationMutationResult {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType: ConversationType;
    /** [zh-CN] 操作类型：删除或置顶切换。 [en-US] Operation type: delete or toggle pin status. */
    readonly operation: 'delete' | 'setPinned';
    /** [zh-CN] 会话的置顶状态。 [en-US] Whether the conversation is pinned. */
    readonly isPinned?: boolean;
    /** [zh-CN] 置顶时间戳，单位毫秒。 [en-US] Timestamp when the item was pinned.*/
    readonly pinnedTime?: number;
}
/**
 * [zh-CN] 置顶或取消置顶消息的结果。
 * [en-US] Result of pinning or unpinning a message.
 */
export interface MessagePinMutationResult {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType: ConversationType;
    /** [zh-CN] 消息 ID。 [en-US] Message ID. */
    readonly messageId: string;
    /** [zh-CN] 操作类型：置顶或取消置顶。 [en-US] Operation type: pin or unpin. */
    readonly operation: 'pin' | 'unpin';
}
/**
 * [zh-CN] 置顶消息的摘要信息。
 * [en-US] Summary of a pinned message.
 */
export interface PinnedMessageSummary {
    /** [zh-CN] 消息 ID。 [en-US] Message ID. */
    readonly messageId: string;
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType: ConversationType;
    /** [zh-CN] 置顶操作者用户 ID。 [en-US] User ID of the operator who pinned message. */
    readonly operatorId?: string;
    /** [zh-CN] 置顶时间戳（毫秒）。 [en-US] Timestamp when the message was pinned, in milliseconds. */
    readonly pinnedAt: number;
    /** [zh-CN] 被置顶的完整消息。 [en-US] Full pinned message. */
    readonly message: Message;
}
/**
 * [zh-CN] 会话内置顶消息摘要列表，最多包含 20 条。
 * [en-US] Pinned message summaries in the conversation, up to 20 items.
 */
export interface PinnedMessageListResult {
    /** [zh-CN] 置顶消息摘要列表。 [en-US] Pinned message summaries. */
    readonly items: ReadonlyArray<PinnedMessageSummary>;
}
/**
 * [zh-CN] 主动刷新新会话列表时的参数。
 * [en-US] Parameters for manually refreshing the conversation list.
 */
export interface RefreshSessionListParams {
    /** [zh-CN] 是否需要返回空会话。（无消息的会话）。 [en-US] Whether to return empty conversations (conversations without any messages). */
    readonly includeEmpty?: boolean;
}
/**
 * [zh-CN] 会话列表专用的消息提醒类型。
 * [en-US] Notification reminder type specific to the conversation list.
 */
export type SessionListRemindType = 'DEFAULT' | 'ALL' | 'AT' | 'NONE';
/**
 * [zh-CN] 会话列表最后消息快照。
 * [en-US] Last-message snapshot used by the conversation list.
 *
 * @remarks
 * [zh-CN] 字段类型复用 Message，保留可获得的正文和元信息。历史摘要可能不完整，因此可选字段保持可选，body 保留对象类型以兼容旧缓存；新解析正文与 MessageBody 一致，不应将历史摘要强制转换为完整 Message。
 * [en-US] Field types are shared with Message and preserve available content and metadata. Legacy snippets can be incomplete, so optional fields remain optional and body keeps an object type for compatibility. Newly decoded content matches MessageBody; legacy snippets should not be cast to complete Message objects.
 * [zh-CN] 从旧版缓存升级时，最后消息可能缺少参与者和方向。若无法从同会话、同消息的记录恢复，`from`、`sender.userId` 及无法确定的单聊 `to` 为空字符串，`direct` 为 `undefined`。UI 应省略未知发送者资料和依赖方向的展示，不能默认认定对端发送。同步服务可用时重新同步会话列表，或等待新消息更新，可补齐能够获得的信息；保留旧消息正文，不通过清空缓存恢复身份。
 * [en-US] After upgrading from a legacy cache, the last message may lack participant and direction data. If it cannot be recovered from a record for the same conversation and message, `from`, `sender.userId`, and an undetermined one-to-one `to` are empty strings, while `direct` is `undefined`. The UI should omit unknown sender details and direction-dependent rendering instead of assuming an incoming message. Re-syncing the conversation list when the sync service is available, or receiving a new message, can populate available information. Legacy message content is retained; clearing the cache does not recover identities.
 */
export interface SessionMessageSnippet extends Readonly<Partial<Omit<Message, 'body'>>> {
    /** [zh-CN] 服务端消息 ID。 [en-US] Message ID on the server. */
    readonly msgServerId: Message['msgServerId'];
    /** [zh-CN] 消息发送者的用户 ID；无法恢复的旧缓存身份为空字符串。 [en-US] Sender user ID; empty when identity cannot be recovered from a legacy cache. */
    readonly from: Message['from'];
    /** [zh-CN] 实际接收方 ID：单聊为接收者用户 ID，群聊为群组 ID，聊天室为聊天室 ID；无法确定的旧缓存单聊接收者为空字符串。 [en-US] Actual recipient ID: recipient user ID for one-to-one chat, group ID for group chat, or chat room ID for chat room; empty when a legacy one-to-one recipient is undetermined. */
    readonly to: Message['to'];
    /** [zh-CN] 发送者信息；无法恢复的旧缓存中 userId 为空字符串。 [en-US] Sender information; userId is empty when legacy identity cannot be recovered. */
    readonly sender: Message['sender'];
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId?: Message['conversationId'];
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType?: Message['conversationType'];
    /** [zh-CN] 消息类型。 [en-US] Message type. */
    readonly type?: Message['type'];
    /** [zh-CN] 消息发送状态。 [en-US] Message sending status. */
    readonly sendStatus?: Message['sendStatus'];
    /** [zh-CN] 消息时间戳（毫秒）。 [en-US] Message timestamp, in milliseconds. */
    readonly timestamp: number;
    /** [zh-CN] 消息方向：发送或接收；仅在有可靠记录时提供，未知时为 undefined，不根据发送者推测。 [en-US] Message direction: outgoing or incoming; provided only from a reliable record, undefined when unknown, and never inferred from the sender. */
    readonly direct?: Message['direct'];
    /** [zh-CN] 消息修改信息；当最后一条消息被编辑后，此字段可能存在。 [en-US] Message modification information; present when the last message has been edited. */
    readonly modifiedInfo?: Message['modifiedInfo'];
    /** [zh-CN] 发送者用户资料的版本时间戳（秒），用于资料补全。 [en-US] User profile version timestamp (in seconds) of the message sender, used for profile hydration. */
    readonly userInfoUpdateTime?: number;
    /** [zh-CN] 群成员名片的版本时间戳（秒），仅群聊会话的最后一条消息可能存在此字段。 [en-US] The version timestamp (in seconds) of the Group member name card. This field may only exist for the last message in group chat conversations. */
    readonly namecardUpdateTime?: number;
    /** [zh-CN] 与 MessageBody 一致的消息正文。复合消息时这里直接是分段数组。 [en-US] Message content matching MessageBody. For a multi_body message, this is the segment array. */
    readonly body: Record<string, unknown> | ReadonlyArray<Record<string, unknown>>;
    /** [zh-CN] 消息扩展字段，与 onMessage 的 ext 一致；旧缓存可能缺失。 [en-US] Message extension fields, matching onMessage ext; may be absent in legacy caches. */
    readonly ext?: Message['ext'];
}
/**
 * [zh-CN] 公开的会话列表项，来自本地会话列表缓存的投影数据。
 * [en-US] Public conversation list item, projected from the local conversation list cache.
 */
export interface ConversationItem {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType: ConversationType;
    /** [zh-CN] 会话的未读消息数量。 [en-US] Unread message count for this conversation. */
    readonly unreadCount: number;
    /** [zh-CN] 最后一条消息摘要。 [en-US] Summary of the last message in the conversation. */
    readonly lastMessage: SessionMessageSnippet | null;
    /** [zh-CN] 最后一条消息的时间戳（毫秒）。 [en-US] Timestamp of the last message in milliseconds. */
    readonly lastMessageAt?: number;
    /** [zh-CN] 会话是否处于置顶状态。 [en-US] Whether the conversation is pinned. */
    readonly isPinned?: boolean;
    /** [zh-CN] 置顶时间戳（毫秒）。 [en-US] Timestamp when the conversation is pinned, in milliseconds. */
    readonly pinnedTimestamp?: number;
    /** [zh-CN] 会话已应用的标记列表。 [en-US] List of marks applied to the conversation. */
    readonly marks: ReadonlyArray<ConversationMark>;
    /** [zh-CN] 已读位置或已读时间戳。 [en-US] Read receipt position or read timestamp. */
    readonly readAt?: number;
    /** [zh-CN] 会话的提醒类型。 [en-US] Notification reminder type for the conversation. */
    readonly remindType: SessionListRemindType;
    /** [zh-CN] 会话的显示名称。 [en-US] Display name of the conversation. */
    readonly conversationName: string;
    /** [zh-CN] 会话的头像 URL 地址。 [en-US] Avatar URL of the conversation. */
    readonly conversationAvatar?: string;
}
