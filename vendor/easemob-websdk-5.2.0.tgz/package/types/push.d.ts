/**
 * [zh-CN] PushManager 对外类型定义，供推送 API 调用与文档生成使用。
 * [en-US] Public type definitions for PushManager, used by push APIs and documentation generation.
 */
/** [zh-CN] UTS 插件返回的原生推送通道编码。 [en-US] Native push channel code returned by the UTS plugin. */
export type NativePushTypeCode = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8;
/** [zh-CN] SDK 归一化后的原生推送通道。 [en-US] SDK-normalized native push channel. */
export type NativePushChannel = 'apns' | 'fcm' | 'huawei' | 'xiaomi' | 'meizu' | 'vivo' | 'oppo' | 'honor' | 'normal';
/**
 * [zh-CN] UTS 插件 Token 注册结果。`push_token` 是敏感信息，不应记录日志。
 * [en-US] Token registration result from the UTS plugin. `push_token` is sensitive and must not be logged.
 */
export interface NativePushTokenResult {
    /** [zh-CN] 厂商或 APNs Token。 [en-US] Vendor or APNs token. */
    readonly push_token: string;
    /** [zh-CN] 插件通道编码。 [en-US] Plugin channel code. */
    readonly push_type: NativePushTypeCode;
    /** [zh-CN] `200` 表示注册成功。 [en-US] `200` indicates successful registration. */
    readonly code: number;
    /** [zh-CN] 插件错误文本，仅供 SDK 内部判断。 [en-US] Plugin error text for internal SDK classification only. */
    readonly error: string;
}
/**
 * [zh-CN] SDK 所需的最小 UTS 原生推送插件接口。
 * [en-US] Minimal UTS native push plugin interface required by the SDK.
 */
export interface NativePushPlugin {
    /** [zh-CN] 注册并持续监听 Token。 [en-US] Registers and continuously observes token updates. */
    onRegister(callback: (result: NativePushTokenResult) => void): void;
    /** [zh-CN] 结束插件侧注册。 [en-US] Ends plugin-side registration. */
    unRegister(): void;
}
/**
 * [zh-CN] 各原生通道在环信控制台中的证书名称。
 * [en-US] Certificate names configured in the Easemob console for native channels.
 */
export interface NativePushCertificates {
    /** [zh-CN] Apple APNs 证书名称。 [en-US] Apple APNs certificate name. */
    readonly apns?: string;
    /** [zh-CN] Firebase Cloud Messaging 证书名称。 [en-US] Firebase Cloud Messaging certificate name. */
    readonly fcm?: string;
    /** [zh-CN] 华为推送证书名称。 [en-US] Huawei push certificate name. */
    readonly huawei?: string;
    /** [zh-CN] 小米推送证书名称。 [en-US] Xiaomi push certificate name. */
    readonly xiaomi?: string;
    /** [zh-CN] 魅族推送证书名称。 [en-US] Meizu push certificate name. */
    readonly meizu?: string;
    /** [zh-CN] vivo 推送证书名称。 [en-US] vivo push certificate name. */
    readonly vivo?: string;
    /** [zh-CN] OPPO 推送证书名称。 [en-US] OPPO push certificate name. */
    readonly oppo?: string;
    /** [zh-CN] 荣耀推送证书名称。 [en-US] Honor push certificate name. */
    readonly honor?: string;
}
/** [zh-CN] 配置原生推送所需参数。 [en-US] Options required to configure native push. */
export interface SetNativePushOptions {
    /** [zh-CN] 宿主从 UTS 导出函数组装的插件对象。 [en-US] Plugin object assembled from host-imported UTS functions. */
    readonly plugin: NativePushPlugin;
    /** [zh-CN] 通道到环信证书名称的映射，至少配置一项。 [en-US] Channel-to-certificate mapping with at least one entry. */
    readonly certificates: NativePushCertificates;
}
/** [zh-CN] 原生 Push Token 成功绑定事件。 [en-US] Native push token bound event. */
export interface PushTokenBoundEvent {
    /** [zh-CN] 实际绑定的原生推送通道。 [en-US] Native push channel that was bound. */
    readonly channel: Exclude<NativePushChannel, 'normal'>;
    /** [zh-CN] 实际使用的环信证书名称。 [en-US] Easemob certificate name used for binding. */
    readonly notifierName: string;
}
/** [zh-CN] 原生 Push Token 操作失败事件。 [en-US] Native push token operation failure event. */
export interface PushTokenOperationFailedEvent {
    /** [zh-CN] 失败发生的操作阶段。 [en-US] Operation stage where the failure occurred. */
    readonly stage: 'register' | 'bind' | 'remove';
    /** [zh-CN] 已解析出的推送通道。 [en-US] Resolved push channel, when available. */
    readonly channel?: NativePushChannel;
    /** [zh-CN] 已匹配的环信证书名称。 [en-US] Matched Easemob certificate name, when available. */
    readonly notifierName?: string;
    /** [zh-CN] SDK 统一错误码。 [en-US] Unified SDK error code. */
    readonly code?: number;
    /** [zh-CN] 相同操作是否适合重试。 [en-US] Whether retrying the same operation is appropriate. */
    readonly retryable: boolean;
}
/**
 * [zh-CN] 会话类型常量集合。
 * [en-US] Conversation type constants.
 */
export declare const PUSH_CONVERSATION_TYPE: {
    readonly SINGLE_CHAT: "singleChat";
    readonly GROUP_CHAT: "groupChat";
};
/**
 * [zh-CN] PushManager 支持的会话类型。
 * [en-US] Conversation types supported by PushManager.
 */
export type PushConversationType = (typeof PUSH_CONVERSATION_TYPE)[keyof typeof PUSH_CONVERSATION_TYPE];
/**
 * [zh-CN] 推送提醒类型常量集合。
 * [en-US] Push remind type constants.
 */
export declare const PUSH_REMIND_TYPE: {
    readonly ALL: "ALL";
    readonly AT: "AT";
    readonly NONE: "NONE";
    readonly DEFAULT: "DEFAULT";
};
/**
 * [zh-CN] 推送提醒类型。
 * [en-US] Push reminder type.
 */
export type PushRemindType = (typeof PUSH_REMIND_TYPE)[keyof typeof PUSH_REMIND_TYPE];
/**
 * [zh-CN] 可设置的推送提醒类型（不包含 DEFAULT）。
 * [en-US] Configurable push reminder types (excluding 'DEFAULT').
 */
export type PushRemindTypeWithoutDefault = Exclude<PushRemindType, 'DEFAULT'>;
/**
 * [zh-CN] 免打扰模式常量集合。
 * [en-US] Do Not Disturb (DND) mode constants.
 */
export declare const PUSH_SILENT_MODE: {
    readonly REMIND_TYPE: "REMIND_TYPE";
    readonly DURATION: "DURATION";
    readonly INTERVAL: "INTERVAL";
};
/**
 * [zh-CN] 免打扰模式类型。
 * [en-US] Do Not Disturb (DND) types.
 */
export type PushSilentMode = (typeof PUSH_SILENT_MODE)[keyof typeof PUSH_SILENT_MODE];
/**
 * [zh-CN] 时间点（24 小时制）。
 * [en-US] Time in 24-hour format.
 */
export interface PushTimePoint {
    /** [zh-CN] 小时，范围为 0 至 23。 [en-US] Hour, in the range [0, 23]. */
    readonly hours: number;
    /** [zh-CN] 分钟，范围为 0 至 59。 [en-US] Minute, in the range [0, 59]. */
    readonly minutes: number;
}
/**
 * [zh-CN] 推送提醒规则配置项（基于提醒类型）。
 * [en-US] Push reminder rule configuration (based on reminder type).
 */
export interface PushSilentModeRemindTypeRuleInput {
    /** [zh-CN] 取值必须为 `REMIND_TYPE`。 [en-US] Must be `REMIND_TYPE`. */
    readonly mode: 'REMIND_TYPE';
    /** [zh-CN] 提醒类型。可选值：`ALL`、`AT`、`NONE`。 [en-US] Reminder type. Valid values: `ALL`, `AT`, `NONE`. */
    readonly remindType: PushRemindTypeWithoutDefault;
}
/**
 * [zh-CN] 推送提醒规则配置项（基于持续时长）。
 * [en-US] Push reminder rule configuration (based on duration).
 */
export interface PushSilentModeDurationRuleInput {
    /** [zh-CN] 取值必须为 `DURATION`。 [en-US] Must be `DURATION`. */
    readonly mode: 'DURATION';
    /** [zh-CN] 持续时长（分钟），必须为正整数。SDK 会在 REST 请求中转换为毫秒。 [en-US] Duration in minutes, must be a positive integer. The SDK converts it to milliseconds for REST requests. */
    readonly duration: number;
}
/**
 * [zh-CN] 推送提醒规则配置项（基于时间区间）。
 * [en-US] Push reminder rule configuration (based on time interval).
 */
export interface PushSilentModeIntervalRuleInput {
    /** [zh-CN] 取值必须为 `INTERVAL`。 [en-US] Must be `INTERVAL`. */
    readonly mode: 'INTERVAL';
    /** [zh-CN] 开始时间点。 [en-US] Interval start time. */
    readonly startTime: PushTimePoint;
    /** [zh-CN] 结束时间点。 [en-US] Interval end time. */
    readonly endTime: PushTimePoint;
}
/**
 * [zh-CN] 免打扰规则配置项联合类型。
 * [en-US] Union type for DND mode rule configurations.
 */
export type PushSilentModeRuleInput = PushSilentModeRemindTypeRuleInput | PushSilentModeDurationRuleInput | PushSilentModeIntervalRuleInput;
/**
 * [zh-CN] 免打扰规则查询视图（各字段可并存）。
 * [en-US] DND mode rule view (fields can coexist).
 */
export interface PushSilentModeRuleView {
    /** [zh-CN] 当前提醒类型。 [en-US] Current reminder type. */
    readonly remindType?: PushRemindType;
    /** [zh-CN] 免打扰到期时间戳（毫秒）。该值直接映射服务端响应中的 `ignoreDuration`，SDK 不自行计算。 [en-US] DND expiration timestamp in milliseconds. This value maps directly from `ignoreDuration` in the server response and is not calculated by the SDK. */
    readonly expireTimestamp?: number;
    /** [zh-CN] 每日免打扰开始时间。 [en-US] Daily DND mode start time. */
    readonly silentModeStartTime?: PushTimePoint;
    /** [zh-CN] 每日免打扰结束时间。 [en-US] Daily DND mode end time. */
    readonly silentModeEndTime?: PushTimePoint;
}
/**
 * [zh-CN] 仅包含提醒类型的规则视图。
 * [en-US] Reminder-type-only rule view.
 */
export type PushSilentModeRemindTypeRuleView = Readonly<{
    /** [zh-CN] 当前提醒类型。 [en-US] Current reminder type. */
    remindType: PushRemindType;
}>;
/**
 * [zh-CN] 仅包含时长模式到期时间的规则视图。
 * [en-US] Expiration-only rule view for duration mode.
 */
export type PushSilentModeDurationRuleView = Readonly<{
    /** [zh-CN] 免打扰到期时间戳（毫秒），直接来自服务端响应。 [en-US] DND expiration timestamp in milliseconds, returned directly by the server. */
    expireTimestamp: number;
}>;
/**
 * [zh-CN] 仅包含时间区间的规则视图。
 * [en-US] Interval-only rule view.
 */
export type PushSilentModeIntervalRuleView = Readonly<{
    /** [zh-CN] 每日免打扰开始时间。 [en-US] Daily silent mode start time. */
    silentModeStartTime: PushTimePoint;
    /** [zh-CN] 每日免打扰结束时间。 [en-US] Daily silent mode end time. */
    silentModeEndTime: PushTimePoint;
}>;
/**
 * [zh-CN] 全局免打扰响应结果。
 * [en-US] Response for global DND mode.
 */
export interface GlobalSilentModeResponse {
    /** [zh-CN] 作用域，必须为 `global`。 [en-US] Scope, always `global`. */
    readonly scope: 'global';
    /** [zh-CN] 全局免打扰规则。 [en-US] Global DND mode rule. */
    readonly rule: PushSilentModeRuleView;
}
/**
 * [zh-CN] 会话免打扰配置响应。
 * [en-US] Response for DND configuration for a single conversation.
 */
export interface ConversationSilentModeResponse {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType: PushConversationType;
    /** [zh-CN] 会话免打扰规则。 [en-US] Conversation DND mode rule. */
    readonly rule: PushSilentModeRuleView;
}
/**
 * [zh-CN] 会话标识。
 * [en-US] Conversation identification.
 */
export interface ConversationIdentifier {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType: PushConversationType;
}
/**
 * [zh-CN] 批量会话免打扰响应。
 * [en-US] Response for DND settings of a batch of conversations.
 */
export interface BatchConversationSilentModeResponse {
    /** [zh-CN] 会话免打扰结果列表。 [en-US] List of conversation DND mode settings. */
    readonly conversations: ReadonlyArray<ConversationSilentModeResponse>;
}
/**
 * [zh-CN] 推送语言响应。
 * [en-US] Push language response.
 */
export interface PushLanguageResponse {
    /** [zh-CN] 当前生效的语言。 [en-US] Current push language. */
    readonly language: string;
}
/**
 * [zh-CN] 免打扰会话条目。
 * [en-US] Muted conversation item.
 */
export interface MutedConversationItem {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType: PushConversationType;
    /** [zh-CN] 推送提醒类型。可选值：`ALL`、`AT`、`NONE`。 [en-US] Reminder type. Valid values: `ALL`, `AT`, `NONE`. */
    readonly remindType: PushRemindTypeWithoutDefault;
}
/**s
 * [zh-CN] 免打扰会话分页响应结果。
 * [en-US] Paginated response for muted conversations.
 */
export interface MutedConversationPageResponse {
    /** [zh-CN] 当前页的免打扰会话列表。 [en-US] List of muted conversations for the current page. */
    readonly conversations: ReadonlyArray<MutedConversationItem>;
    /** [zh-CN] 下一页游标。若为空字符串，则表示没有更多数据。 [en-US] Next-page cursor. An empty string indicates no more data. */
    readonly cursor: string;
}
/**
 * [zh-CN] 上传推送 Token 的参数。
 * [en-US] Parameters for uploading the push token.
 */
export interface UploadPushTokenParams {
    /** [zh-CN] 设备唯一标识。 [en-US] Unique device ID. */
    readonly deviceId: string;
    /** [zh-CN] 设备推送 Token。 [en-US] Device push token. */
    readonly deviceToken: string;
    /** [zh-CN] 推送通道名称（例如：'FCM'）。 [en-US] Push channel name (e.g., 'FCM'). */
    readonly notifierName: string;
}
/**
 * [zh-CN] 设置全局免打扰的参数。
 * [en-US] Parameters for setting global Do Not Disturb (DND) mode.
 */
export interface SetGlobalSilentModeParams {
    /** [zh-CN] 推送提醒规则配置项。 [en-US] Push reminder rule configuration. */
    readonly rule: PushSilentModeRuleInput;
}
/**
 * [zh-CN] 查询全局免打扰设置的参数。
 * [en-US] Parameters for querying global DND settings.
 */
export type GetGlobalSilentModeParams = Record<string, never>;
/**
 * [zh-CN] 设置会话免打扰参数。
 * [en-US] Parameters for setting the conversation DND mode.
 */
export interface SetConversationSilentModeParams {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType: PushConversationType;
    /** [zh-CN] 会话免打扰规则。 [en-US] DND mode rule for the conversation. */
    readonly rule: PushSilentModeRuleInput;
}
/**
 * [zh-CN] 查询会话免打扰参数。
 * [en-US]Parameters for querying the conversation DND mode.
 */
export interface GetConversationSilentModeParams {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType: PushConversationType;
}
/**
 * [zh-CN] 清除会话推送提醒类型参数。
 * [en-US] Parameters for clearing the conversation push reminder type.
 */
export interface ClearConversationRemindTypeParams {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly conversationType: PushConversationType;
}
/**
 * [zh-CN] 批量查询会话免打扰设置的参数。
 * [en-US] Parameters for batch querying conversation DND mode.
 */
export interface GetConversationSilentModesParams {
    /** [zh-CN] 会话标识列表。单次最多支持 20 条。 [en-US] List of conversation IDs, up to 20 per request. */
    readonly conversationList: ReadonlyArray<ConversationIdentifier>;
}
/**
 * [zh-CN] 设置推送目标语言的参数。
 * [en-US] Parameters for setting the push notification language.
 */
export interface SetPushLanguageParams {
    /** [zh-CN] 语言标识符（例如：`zh-Hans`、`en`）。 [en-US] Language identifier (e.g., `zh-Hans`, `en`). */
    readonly language: string;
}
/**
 * [zh-CN] 查询推送目标语言的参数。
 * [en-US] Parameters for querying the push notification language.
 */
export type GetPushLanguageParams = Record<string, never>;
/**
 * [zh-CN] 分页查询会话提醒类型参数。
 * [en-US] Parameters for paginating conversations by reminder type.
 */
export interface GetConversationListByRemindTypeParams {
    /** [zh-CN] 分页大小，必须为正整数。 [en-US] Number of conversations per page. It must be a positive integer. */
    readonly pageSize: number;
    /** [zh-CN] 下一页游标。首次查询时无需传入。 [en-US] Cursor for the next page. Omit for the first request. */
    readonly cursor?: string;
}
