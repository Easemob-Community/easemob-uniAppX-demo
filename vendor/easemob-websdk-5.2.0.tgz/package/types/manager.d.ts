/**
 * Manager 类型定义
 */
import type { EventHandlerId, EventHandlerMap, EventName, EventPayloadMap } from './event-system';
/**
 * [zh-CN] 管理器可以声明的 SDK 能力。
 * [en-US] SDK capabilities that a manager can declare.
 */
export type ManagerCapability = 'rawNotify:group' | 'rawNotify:chatroom' | 'rawNotify:contact' | 'rawNotify:chatThread' | 'rawNotify:userInfo' | 'userInfo:read' | 'group:namecard';
/**
 * [zh-CN] 管理器可以处理的原始通知事件。
 * [en-US] Raw notification event that a manager can handle.
 */
export type RawNotifyEvent = {
    readonly type: 'group';
    readonly payload: unknown;
} | {
    readonly type: 'chatroom';
    readonly payload: unknown;
} | {
    readonly type: 'contact';
    readonly payload: unknown;
} | {
    readonly type: 'chatThread';
    readonly payload: unknown;
} | {
    readonly type: 'userInfo';
    readonly payload: unknown;
};
/**
 * [zh-CN] Manager 会话结束原因。
 * [en-US] Reason why a manager session is ending.
 */
export type ManagerSessionEndReason = 'logout' | 'terminal-disconnect';
/**
 * [zh-CN] Manager 可使用的当前登录会话标识；不包含鉴权 Token。
 * [en-US] Current login session identity available to managers; authentication tokens are excluded.
 */
export interface ManagerSessionContext {
    /** [zh-CN] 当前 SDK 实例内单调递增的会话代次。 [en-US] Monotonically increasing session generation within this SDK instance. */
    readonly generation: number;
    /** [zh-CN] 当前登录用户 ID。 [en-US] Current logged-in user ID. */
    readonly userId: string;
    /** [zh-CN] 当前连接的设备资源标识。 [en-US] Device resource identifier for the current connection. */
    readonly clientResource: string;
}
/**
 * [zh-CN] Manager 会话结束上下文。
 * [en-US] Context provided when a manager session is ending.
 */
export interface ManagerSessionEndContext extends ManagerSessionContext {
    /** [zh-CN] 会话结束原因。 [en-US] Session-ending reason. */
    readonly reason: ManagerSessionEndReason;
}
/**
 * [zh-CN] SDK 绑定管理器时提供的事件上下文。
 * [en-US] Event context provided when the SDK binds a manager.
 */
export interface ManagerEventContext<Handlers = EventHandlerMap> {
    /** [zh-CN] 注册事件处理器。 [en-US] Registers event handlers. */
    addEventHandler(id: EventHandlerId, handlers: Handlers): void;
    /** [zh-CN] 移除指定 ID 的事件处理器。 [en-US] Removes event handlers by ID. */
    removeEventHandler(id: EventHandlerId): void;
    /** [zh-CN] 派发 SDK 事件。 [en-US] Dispatches an SDK event. */
    dispatch?<TName extends EventName>(eventName: TName, payload: EventPayloadMap[TName]): void;
}
/**
 * [zh-CN] 可注册到 `ChatClient` 的管理器基础接口。
 * [en-US] Base interface for managers that can be registered with `ChatClient`.
 */
export interface ManagerBase<Client> {
    /** [zh-CN] 管理器声明的能力列表。 [en-US] Capabilities declared by the manager. */
    readonly capabilities?: ReadonlyArray<ManagerCapability>;
    /** [zh-CN] 将管理器绑定到客户端。 [en-US] Binds the manager to a client. */
    bind(client: Client, context?: ManagerEventContext): void;
    /** [zh-CN] 处理管理器订阅的原始通知。 [en-US] Handles raw notifications subscribed to by the manager. */
    handleRawNotify?(event: RawNotifyEvent): void | Promise<void>;
    /** [zh-CN] 登录上下文就绪后通知管理器；不得阻塞登录主链路。 [en-US] Notifies the manager after login context becomes ready; it must not block the login path. */
    onSessionReady?(context: ManagerSessionContext): void;
    /** [zh-CN] 鉴权上下文清理前通知管理器结束会话。 [en-US] Notifies the manager before authentication context is cleared. */
    onSessionEnding?(context: ManagerSessionEndContext): void | Promise<void>;
    /** [zh-CN] 清理当前会话运行时状态。 [en-US] Clears current session runtime state. */
    resetSessionRuntime?(): void;
}
/**
 * [zh-CN] 带静态注册键的管理器构造器。
 * [en-US] Manager constructor with a static registration key.
 */
export interface ManagerConstructor<Client, Manager extends ManagerBase<Client>, Key extends string> {
    /** [zh-CN] 创建管理器实例。 [en-US] Creates a manager instance. */
    new (): Manager;
    /** [zh-CN] 管理器在客户端上的注册键。 [en-US] Registration key of the manager on the client. */
    readonly key: Key;
}
/**
 * [zh-CN] 可注册的管理器实例；运行时通过 `constructor.key` 识别注册键。
 * [en-US] Registerable manager instance whose key is resolved from `constructor.key` at runtime.
 */
export type ManagerInstance<Client> = ManagerBase<Client> & {
    readonly constructor: {
        readonly key?: string;
        readonly name?: string;
    };
};
/**
 * [zh-CN] 从管理器实例推导出的注册键类型。
 * [en-US] Registration key type inferred from a manager instance.
 */
export type ManagerInstanceKey<Client, Manager extends ManagerInstance<Client>> = Manager['constructor'] extends {
    readonly key: infer Key;
} ? Key & string : string;
/**
 * [zh-CN] 管理器注册项，可以是构造器或实例。
 * [en-US] Manager registration represented by a constructor or an instance.
 */
export type ManagerRegistration<Client> = ManagerConstructor<Client, ManagerBase<Client>, string> | ManagerInstance<Client>;
/**
 * [zh-CN] 注册单个管理器后扩展出的客户端类型。
 * [en-US] Client type extended after registering one manager.
 */
export type WithManager<Client, Key extends string, Manager extends ManagerBase<Client>> = Client & {
    readonly [P in Key]: Manager;
};
/**
 * [zh-CN] 注册多个管理器后扩展出的客户端类型。
 * [en-US] Client type extended after registering multiple managers.
 */
export type WithManagers<Client, Items extends ReadonlyArray<ManagerRegistration<Client>>> = Client & {
    readonly [Item in Items[number] as Item extends ManagerConstructor<Client, ManagerBase<Client>, infer Key> ? Key : Item extends ManagerInstance<Client> ? ManagerInstanceKey<Client, Item> : never]: Item extends ManagerConstructor<Client, infer Instance, string> ? Instance : Item extends ManagerInstance<Client> ? Item : never;
};
