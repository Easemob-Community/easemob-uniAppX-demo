/**
 * [zh-CN] GroupManager 公共类型定义。
 * [en-US] Public type definitions for GroupManager.
 */
import type { UserInfo } from './user-info';
import type { SessionListRemindType } from './conversation';
import type { CompatibleFile, FileUploadProgress } from './index';
/**
 * [zh-CN] 用户在群组中的角色。
 * [en-US] User role in a group.
 */
export type GroupRole = 'owner' | 'admin' | 'member';
/**
 * [zh-CN] 群上下文中的用户资料，在全局用户资料基础上可包含该用户在目标群中的群名片。
 * [en-US] User profile in a group context, optionally including the user's name card in the target group.
 */
export interface GroupUserInfo extends UserInfo {
    /** [zh-CN] 用户在目标群中的群名片；未启用资料同步或本地无可用名片时不返回。 [en-US] The user's name card in the target group; omitted when profile sync is disabled or no local name card is available. */
    readonly nameCard?: string;
}
/**
 * [zh-CN] 群组摘要信息。
 * [en-US] Group summary.
 */
export interface GroupSummary {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 群组名称。 [en-US] The group name. */
    readonly name: string;
    /** [zh-CN] 群组描述。 [en-US] The group description. */
    readonly description?: string;
    /** [zh-CN] 当前群组成员数量。 [en-US] The current number of members in the group. */
    readonly memberCount?: number;
    /** [zh-CN] 群组是否为公开群。 [en-US] Whether the group is public. */
    readonly public?: boolean;
    /** [zh-CN] 用户加入群组时是否需要管理员审批。 [en-US] Whether admin approval is required when a user joins a group. */
    readonly joinApprovalRequired?: boolean;
    /** [zh-CN] 是否允许普通成员邀请其他用户加入群组。 [en-US] Whether regular members can invite other users to join the group. */
    readonly allowInvites?: boolean;
    /** [zh-CN] 群组最大成员数。 [en-US] The maximum number of members allowed in the group. */
    readonly maxMembers?: number;
    /** [zh-CN] 当前用户在群组中的角色。 [en-US] The current user's role in the group. */
    readonly role?: GroupRole;
    /** [zh-CN] 群组是否已被禁用。 [en-US] Whether the group is currently disabled. */
    readonly disabled?: boolean;
}
/**
 * [zh-CN] 群组分页列表结果。
 * [en-US] Paginated result for groups.
 */
export interface GroupListResult {
    /** [zh-CN] 当前页的群组摘要列表。 [en-US] The group summary list on the current page. */
    readonly items: ReadonlyArray<GroupSummary>;
    /** [zh-CN] 当前页码，从 1 开始。 [en-US] The current page number, starting from 1. */
    readonly pageNum?: number;
    /** [zh-CN] 当前页返回的数据条数。 [en-US] The number of items returned on the current page. */
    readonly pageSize?: number;
    /** [zh-CN] 下一页的分页游标。如果当前页为最后一页，返回结果中的 `cursor` 为空字符串。 [en-US] Cursor for the the next data retrieval. If the current page is the last page, the `cursor` in the result is an empty string.*/
    readonly cursor?: string;
    /** [zh-CN] 是否还有下一页数据。 [en-US] Whether there is data on the next page. */
    readonly hasMore?: boolean;
}
/**
 * [zh-CN] 群组详情。
 * [en-US] Detailed information about a group.
 */
export interface GroupDetail extends GroupSummary {
    /** [zh-CN] 群主的用户资料。 [en-US] The profile of the group owner. */
    readonly owner?: GroupUserInfo;
    /** [zh-CN] 受邀用户加入群组前是否需要确认邀请。 [en-US] Whether invited users must confirm the invitation before joining the group. */
    readonly inviteNeedConfirm?: boolean;
    /** [zh-CN] 群组是否开启全员禁言。 [en-US] Whether all members in the group are muted. */
    readonly muteAllMembers?: boolean;
    /** [zh-CN] 群组扩展信息。 [en-US] Group extension information. */
    readonly ext?: string;
    /** [zh-CN] 群组创建时间戳。 [en-US] The timestamp when the group was created. */
    readonly createdAt?: number;
    /** [zh-CN] 当前用户加入群组的时间戳。 [en-US] The timestamp when the current user joined the group. */
    readonly joinedAt?: number;
    /** [zh-CN] 群头像 URL。 [en-US] The URL of the group avatar. */
    readonly avatarUrl?: string;
    /** [zh-CN] 当前用户是否已屏蔽该群组消息。 [en-US] Whether the current user has blocked messages from this group. */
    readonly messageBlocked?: boolean;
}
/**
 * [zh-CN] 当前用户已加入群组的轻量同步摘要，不等同于完整群详情。
 * [en-US] A lightweight synchronization summary of groups that the current user has joined. This is not equivalent to the complete group details.
 */
export interface JoinedGroupSummary extends GroupSummary {
    /** [zh-CN] 群主用户 ID。 [en-US] The user ID of the group owner. */
    readonly ownerId?: string;
    /** [zh-CN] 群头像 URL。 [en-US] The URL of the group avatar. */
    readonly avatarUrl?: string;
    /** [zh-CN] 群组是否开启全员禁言。 [en-US] Whether all members in the group are muted. */
    readonly muteAllMembers?: boolean;
    /** [zh-CN] 当前用户的禁言到期时间戳，`0` 表示未被禁言。 [en-US] The timestamp when the current user's mute expires. A value of `0` means the user is not muted. */
    readonly muteExpiration?: number;
    /** [zh-CN] 该群会话的提醒类型。 [en-US] The reminder type of the group conversation. */
    readonly remindType?: SessionListRemindType;
    /** [zh-CN] 群组创建时间戳。 [en-US] The timestamp when the group was created. */
    readonly createdAt?: number;
    /** [zh-CN] 群组更新时间戳。 [en-US] The timestamp when the group was last updated. */
    readonly updatedAt?: number;
    /** [zh-CN] 当前用户加入群组的时间戳。 [en-US] The timestamp when the current user joined the group. */
    readonly joinedAt?: number;
}
/**
 * [zh-CN] 本地已加入群组快照完整性状态。
 * [en-US] Completeness status of the local joined group snapshot
 */
export type JoinedGroupSnapshotIntegrity = 'preview' | 'synced' | 'limited' | 'incomplete' | 'unknown';
/**
 * [zh-CN] 本地已加入群组快照来源。
 * [en-US] Source of a local joined-group snapshot.
 */
export type JoinedGroupSnapshotSource = 'localPreview' | 'sync';
/**
 * [zh-CN] 本地已加入群组快照元信息。
 * [en-US] Metadata of the local snapshot of joined groups.
 */
export interface JoinedGroupSnapshotMeta {
    /** [zh-CN] 当前快照的完整性状态。 [en-US] The completeness state of the current snapshot. */
    readonly integrity: JoinedGroupSnapshotIntegrity;
    /** [zh-CN] 当前结果是否受到服务端返回上限的影响。 [en-US] Whether the current result is affected by the server-side return limit. */
    readonly limited: boolean;
    /** [zh-CN] 本地预览数据的存储上限。 [en-US] The storage limit of the local preview data. */
    readonly storageLimit: number;
    /** [zh-CN] 服务端单次同步返回的数量上限。 [en-US] The maximum number of items returned in a single server synchronization. */
    readonly serverLimit: number;
    /** [zh-CN] 当前快照的来源。 [en-US] The source of the current snapshot. */
    readonly source: JoinedGroupSnapshotSource;
    /** [zh-CN] 服务端最后一批同步数据返回完成的时间。 [en-US] The time when the final batch of synchronized data from the server finished returning. */
    readonly lastSyncFinishedTs?: number;
    /** [zh-CN] 最近一次成功完成同步的本地时间。 [en-US] The local time when the most recent successful synchronization completed. */
    readonly lastSuccessfulAt?: number;
    /** [zh-CN] 当前快照状态的原因说明。 [en-US] The reason that explains the current snapshot state. */
    readonly reason?: string;
}
/**
 * [zh-CN] 本地已加入群组快照。
 * [en-US] The local snapshot of joined groups.
 */
export interface JoinedGroupSnapshot {
    /** [zh-CN] 群组轻量摘要列表。 [en-US] The list of lightweight group summaries. */
    readonly items: ReadonlyArray<JoinedGroupSummary>;
    /** [zh-CN] 快照元信息。 [en-US] The snapshot metadata. */
    readonly meta: JoinedGroupSnapshotMeta;
}
/**
 * [zh-CN] 更新群组信息时的输入参数。
 * [en-US] Input parameters for updating group information.
 */
export interface GroupUpdateInfoInput {
    /** [zh-CN] 更新后的群组名称。 [en-US] The updated group name. */
    readonly name?: string;
    /** [zh-CN] 更新后的群组描述。 [en-US] The updated group description. */
    readonly description?: string;
    /** [zh-CN] 更新后的群头像地址或标识。 [en-US] The updated group avatar URL or identifier. */
    readonly avatar?: string;
    /** [zh-CN] 更新后的群组扩展信息。 [en-US] The updated group extension information. */
    readonly ext?: string;
}
/**
 * [zh-CN] 更新群组配置时的输入参数。
 * [en-US] Input parameters for updating group configurations.
 */
export interface GroupUpdateConfigsInput {
    /** [zh-CN] 群组是否为公开群。 [en-US] Whether the group is public. */
    readonly public?: boolean;
    /** [zh-CN] 用户加入群组时是否需要管理员审批。 [en-US] Whether admin approval is required when a user joins a group. */
    readonly joinApprovalRequired?: boolean;
    /** [zh-CN] 是否允许普通成员邀请其他用户加入群组。 [en-US] Whether regular members can invite other users to join the group. */
    readonly allowInvites?: boolean;
    /** [zh-CN] 受邀用户加入群组前是否需要确认邀请。 [en-US] Whether invited users must confirm the invitation before joining the group. */
    readonly inviteNeedConfirm?: boolean;
    /** [zh-CN] 群组最大成员数。 [en-US] The maximum number of members allowed in the group. */
    readonly maxMembers?: number;
}
/**
 * [zh-CN] 变更群主时的输入参数。
 * [en-US] Input parameters for changing the group owner.
 */
export interface GroupOwnerChangeInput {
    /** [zh-CN] 新群主的用户 ID。 [en-US] The user ID of the new group owner. */
    readonly newOwner: string;
}
/**
 * [zh-CN] 群组成员条目。
 * [en-US] Information about a group member.
 */
export interface GroupMemberEntry {
    /** [zh-CN] 成员的用户资料。 [en-US] The profile of the member. */
    readonly user: GroupUserInfo;
    /** [zh-CN] 成员在群组中的角色。 [en-US] The member's role in the group. */
    readonly role?: GroupRole;
    /** [zh-CN] 成员加入群组的时间戳。 [en-US] The timestamp when the member joined the group. */
    readonly joinedAt?: number;
}
/**
 * [zh-CN] 群成员分页列表结果。
 * [en-US] Paginated result for group members.
 */
export interface GroupMemberListResult {
    /** [zh-CN] 当前页的成员列表。 [en-US] The member list on the current page. */
    readonly items: ReadonlyArray<GroupMemberEntry>;
    /** [zh-CN] 当前页码，从 1 开始。 [en-US] The current page number, starting from 1. */
    readonly pageNum?: number;
    /** [zh-CN] 当前页返回的成员数量。 [en-US] The number of members returned on the current page. */
    readonly pageSize?: number;
    /** [zh-CN] 下一页的分页游标。如果当前页为最后一页，返回结果中的 `cursor` 为空字符串。 [en-US] Cursor for the the next data retrieval. If the current page is the last page, the `cursor` in the result is an empty string.*/
    readonly cursor?: string;
    /** [zh-CN] 是否还有下一页数据。 [en-US] Whether there is data on the next page. */
    readonly hasMore?: boolean;
}
/**
 * [zh-CN] 群组禁言列表条目。
 * [en-US] Entry in the group mute list.
 */
export interface GroupMuteEntry {
    /** [zh-CN] 被禁言成员的用户资料。 [en-US] The profile of the muted member. */
    readonly user: GroupUserInfo;
    /** [zh-CN] 禁言到期时间戳。 [en-US] The timestamp when the mute expires. */
    readonly muteExpire?: number;
    /** [zh-CN] 禁言时长，单位为毫秒。 [en-US] The mute duration, in milliseconds. */
    readonly muteDuration?: number;
}
/**
 * [zh-CN] 群组白名单条目。
 * [en-US] Entry in the group allow list.
 */
export interface GroupAllowlistEntry {
    /** [zh-CN] 白名单成员的用户资料。 [en-US] The profile of the user in the allow list. */
    readonly user: GroupUserInfo;
}
/**
 * [zh-CN] 群组黑名单条目。
 * [en-US] Entry in the group block list.
 */
export interface GroupBlocklistEntry {
    /** [zh-CN] 黑名单成员的用户资料。 [en-US] The profile of the user in the block list. */
    readonly user: GroupUserInfo;
}
/**
 * [zh-CN] 群公告信息。
 * [en-US] The group announcement.
 */
export interface GroupAnnouncement {
    /** [zh-CN] 群公告内容。 [en-US] The content of the group announcement. */
    readonly announcement: string;
}
/**
 * [zh-CN] 群组共享文件条目。
 * [en-US] Information about a shared file in the group.
 */
export interface GroupSharedFile {
    /** [zh-CN] 共享文件 ID。 [en-US] The shared file ID. */
    readonly fileId: string;
    /** [zh-CN] 文件名称。 [en-US] The file name. */
    readonly fileName: string;
    /** [zh-CN] 上传该文件的用户资料。 [en-US] The profile of the user who uploaded the file. */
    readonly fileOwner?: GroupUserInfo;
    /** [zh-CN] 文件大小，单位为字节。 [en-US] The file size, in bytes. */
    readonly fileSize?: number;
    /** [zh-CN] 文件创建时间戳。 [en-US] The timestamp when the file was created. */
    readonly createdAt?: number;
}
/**
 * [zh-CN] 群组共享文件分页列表结果。
 * [en-US] Paginated result for shared files in a group.
 */
export interface GroupSharedFileListResult {
    /** [zh-CN] 当前页的共享文件列表。 [en-US] The shared file list on the current page. */
    readonly items: ReadonlyArray<GroupSharedFile>;
    /** [zh-CN] 当前页码，从 1 开始。 [en-US] The current page number, starting from 1. */
    readonly pageNum?: number;
    /** [zh-CN] 当前页返回的文件数量。 [en-US] The number of files returned on the current page. */
    readonly pageSize?: number;
    /** [zh-CN] 下一页的分页游标。如果当前页为最后一页，返回结果中的 `cursor` 为空字符串。 [en-US] Cursor for the the next data retrieval. If the current page is the last page, the `cursor` in the result is an empty string.*/
    readonly cursor?: string;
    /** [zh-CN] 是否还有下一页数据。 [en-US] Whether there is more data on the next page. */
    readonly hasMore?: boolean;
}
/**
 * [zh-CN] 基于游标的分页参数。
 * [en-US] Pagination parameters based on a cursor.
 */
export interface CursorPageParams {
    /** [zh-CN] 每页返回的数据条数。如果当前页为最后一页，实际返回的数据条数可能小于该值。 [en-US] The number of items returned per page. If the current page is the last page, the actual number of returned items may be smaller than this value. */
    readonly pageSize?: number;
    /** [zh-CN] 开始获取数据的游标位置。首次调用时传空字符串或 `null`；后续调用时传入上一次返回的 `cursor` 作为下一次获取数据的起始位置。如果当前页为最后一页，返回结果中的 `cursor` 为空字符串。 [en-US] The position from which to start retrieving data. For the first call, pass an empty string or `null`. In subsequent calls, you can pass the latest `cursor` as the starting position for the next data retrieval. If the current page is the last page, the `cursor` in the result is an empty string. */
    readonly cursor?: string;
}
/**
 * [zh-CN] 基于页码的分页参数。
 * [en-US] Pagination parameters based on page numbers.
 */
export interface NumberPageParams {
    /** [zh-CN] 当前页码，从 1 开始。 [en-US] The current page number, starting from 1. */
    readonly pageNum?: number;
    /** [zh-CN] 每页返回的数据条数。 [en-US] The number of items returned per page. */
    readonly pageSize?: number;
}
/**
 * [zh-CN] 批量用户操作的输入参数。
 * [en-US] Input parameters for batch operations on users.
 */
export interface GroupUserBatchInput {
    /** [zh-CN] 待操作的用户 ID 列表。 [en-US] The list of user IDs to operate on. */
    readonly userIds: ReadonlyArray<string>;
}
/**
 * [zh-CN] 查询群成员列表的分页参数。
 * [en-US] Pagination parameters for querying group members.
 */
export type GroupMemberListQuery = CursorPageParams;
/**
 * [zh-CN] 查询群禁言列表的分页参数。
 * [en-US] Pagination parameters for querying muted group members.
 */
export type GroupMuteListQuery = NumberPageParams;
export type GroupMuteListParams = GroupMutationTarget & NumberPageParams;
export type GroupBlocklistParams = GroupMutationTarget & NumberPageParams;
/**
 * [zh-CN] 批量禁言成员时的输入参数。
 * [en-US] Input parameters for muting members in batches.
 */
export interface GroupMuteMembersInput {
    /** [zh-CN] 待加入禁言列表的成员用户 ID 列表。 [en-US] The list of member user IDs to add to the mute list. */
    readonly userIds: ReadonlyArray<string>;
    /** [zh-CN] 禁言时长，单位为毫秒。 [en-US] The mute duration, in milliseconds. */
    readonly muteDuration: number;
}
/**
 * [zh-CN] 更新群公告时的输入参数。
 * [en-US] Input parameters for updating the group announcement.
 */
export interface GroupAnnouncementUpdateInput {
    /** [zh-CN] 更新后的群公告内容。 [en-US] The updated group announcement content. */
    readonly announcement: string;
}
/**
 * [zh-CN] 查询群共享文件列表的分页参数。
 * [en-US] Pagination parameters for querying group shared files.
 */
export type GroupSharedFileListQuery = NumberPageParams;
/**
 * [zh-CN] 获取当前用户已加入群组列表时的查询参数。
 * [en-US] Query parameters for retrieving the list of groups joined by the current user.
 */
export interface GetJoinedGroupListParams extends NumberPageParams {
    /** [zh-CN] 是否返回群组成员数量。 [en-US] Whether to return the member count of each group. */
    readonly needMemberCount?: boolean;
    /** [zh-CN] 是否返回当前用户在群组中的角色。 [en-US] Whether to return the current user's role in each group. */
    readonly needRole?: boolean;
}
/**
 * [zh-CN] 查询单个群组详情时的参数。
 * [en-US] Parameters for querying details of a single group.
 */
export interface GetGroupInfoParams {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
}
/**
 * [zh-CN] 批量查询群组详情时的参数。
 * [en-US] Parameters for querying details of multiple groups.
 */
export interface GetGroupInfoListParams {
    /** [zh-CN] 待查询的群组 ID 列表。 [en-US] The list of group IDs to query. */
    readonly groupIds: ReadonlyArray<string>;
}
/**
 * [zh-CN] 创建群组时的参数。
 * [en-US] Parameters for creating a group.
 */
export interface CreateGroupParams {
    /** [zh-CN] 群组名称。 [en-US] The group name. */
    readonly name: string;
    /** [zh-CN] 群组描述。 [en-US] The group description. */
    readonly description: string;
    /** [zh-CN] 初始成员用户 ID 列表。 [en-US] The list of user IDs of initial members. */
    readonly memberIds?: ReadonlyArray<string>;
    /** [zh-CN] 群组是否为公开群。 [en-US] Whether the group is public. */
    readonly public: boolean;
    /** [zh-CN] 用户加入群组时是否需要管理员审批。 [en-US] Whether admin approval is required when a user joins a group.*/
    readonly joinApprovalRequired: boolean;
    /** [zh-CN] 是否允许普通成员邀请其他用户加入群组。 [en-US] Whether regular members can invite other users to join the group. */
    readonly allowInvites: boolean;
    /** [zh-CN] 受邀用户加入群组前是否需要确认邀请。 [en-US] Whether invited users must confirm the invitation before joining the group. */
    readonly inviteNeedConfirm: boolean;
    /** [zh-CN] 群组最大成员数。 [en-US] The maximum number of members allowed in the group. */
    readonly maxMembers?: number;
    /** [zh-CN] 群组扩展信息。 [en-US] The group extension information. */
    readonly ext?: string;
    /** [zh-CN] 群头像地址或标识。 [en-US] The group avatar URL or identifier. */
    readonly avatar?: string;
}
/**
 * [zh-CN] 创建群组后的返回结果。
 * [en-US] Result returned after a group is created.
 */
export interface CreateGroupResult {
    /** [zh-CN] 创建成功后的群组 ID。 [en-US] The group ID returned after the group is created successfully. */
    readonly groupId: string;
}
/**
 * [zh-CN] 更新群组信息时的参数。
 * [en-US] Parameters for updating group information.
 */
export interface UpdateGroupInfoParams {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 更新后的群组名称。 [en-US] The updated group name. */
    readonly name?: string;
    /** [zh-CN] 更新后的群组描述。 [en-US] The updated group description. */
    readonly description?: string;
    /** [zh-CN] 更新后的群头像地址或标识。 [en-US] The updated group avatar URL or identifier. */
    readonly avatar?: string;
    /** [zh-CN] 群组是否为公开群。 [en-US] Whether the group is public. */
    readonly public?: boolean;
    /** [zh-CN] 用户加入群组时是否需要管理员审批。 [en-US] Whether admin approval is required when a user joins a group. */
    readonly joinApprovalRequired?: boolean;
    /** [zh-CN] 是否允许普通成员邀请其他用户加入群组。 [en-US] Whether regular members can invite other users to join the group. */
    readonly allowInvites?: boolean;
    /** [zh-CN] 受邀用户加入群组前是否需要确认邀请。 [en-US] Whether invited users must confirm the invitation before joining the group. */
    readonly inviteNeedConfirm?: boolean;
    /** [zh-CN] 群组最大成员数。 [en-US] The maximum number of members allowed in the group. */
    readonly maxMembers?: number;
    /** [zh-CN] 群组扩展信息。 [en-US] The updated group extension information. */
    readonly ext?: string;
}
/**
 * [zh-CN] 群组操作的目标参数，仅包含群组 ID。
 * [en-US] Target parameters for a group operation. Contains only the group ID.
 */
export interface GroupMutationTarget {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
}
/**
 * [zh-CN] 包含群组 ID 的批量用户操作参数。
 * [en-US] Batch user operation parameters that include the group ID.
 */
export interface GroupUserBatchParams extends GroupMutationTarget {
    /** [zh-CN] 待操作的用户 ID 列表。 [en-US] The list of user IDs to operate on. */
    readonly userIds: ReadonlyArray<string>;
}
/**
 * [zh-CN] 群组管理员相关操作的参数。
 * [en-US] Parameters for operations related to group admins.
 */
export interface GroupAdminMutationParams extends GroupMutationTarget {
    /** [zh-CN] 管理员用户 ID。 [en-US] The user ID of the admin. */
    readonly userId: string;
}
/**
 * [zh-CN] 变更群主时的参数。
 * [en-US] Parameters for changing the group owner.
 */
export interface GroupOwnerChangeParams extends GroupMutationTarget {
    /** [zh-CN] 新群主的用户 ID。 [en-US] The user ID of the new group owner. */
    readonly newOwner: string;
}
/**
 * [zh-CN] 申请加入群组时的参数。
 * [en-US] Parameters for applying to join a group.
 */
export interface GroupJoinParams extends GroupMutationTarget {
    /** [zh-CN] 入群申请附言。 [en-US] The message attached to the join request. */
    readonly message?: string;
}
/**
 * [zh-CN] 同意入群申请时的参数。
 * [en-US] Parameters for approving a request to join a group.
 */
export interface AcceptGroupJoinRequestParams extends GroupMutationTarget {
    /** [zh-CN] 申请加入群组的用户 ID。 [en-US] The user ID of the applicant who requested to join the group. */
    readonly userId: string;
}
/**
 * [zh-CN] 拒绝入群申请时的参数。
 * [en-US] Parameters for rejecting a request to join a group.
 */
export interface RejectGroupJoinRequestParams extends GroupMutationTarget {
    /** [zh-CN] 申请加入群组的用户 ID。 [en-US] The user ID of the applicant who requested to join the group. */
    readonly userId: string;
    /** [zh-CN] 拒绝入群申请的原因。 [en-US] The reason for declining the join request. */
    readonly reason: string;
}
/**
 * [zh-CN] 批量禁言成员时的参数。
 * [en-US] Parameters for muting members in batches.
 */
export interface GroupMuteMembersParams extends GroupMutationTarget {
    /** [zh-CN] 待加入禁言列表的成员用户 ID 列表。 [en-US] The list of user IDs of members to add to the mute list. */
    readonly userIds: ReadonlyArray<string>;
    /** [zh-CN] 禁言时长，单位为毫秒。 [en-US] The mute duration, in milliseconds. */
    readonly muteDuration: number;
}
/**
 * [zh-CN] 查询指定群成员列表的参数。
 * [en-US] Parameters for querying members of a specified group.
 */
export type GroupMemberListParams = GroupMutationTarget & CursorPageParams;
/**
 * [zh-CN] 更新群公告时的参数。
 * [en-US] Parameters for updating the group announcement.
 */
export interface GroupAnnouncementUpdateParams extends GroupMutationTarget {
    /** [zh-CN] 更新后的群公告内容。 [en-US] The updated group announcement content. */
    readonly announcement: string;
}
/**
 * [zh-CN] 查询指定群共享文件列表的参数。
 * [en-US] Parameters for querying shared files of a specified group.
 */
export type GroupSharedFileListParams = GroupMutationTarget & NumberPageParams;
/**
 * [zh-CN] 上传群组共享文件时的回调集合。
 * [en-US] Callback events used when uploading a shared file to a group.
 */
export interface UploadGroupSharedFileCallbacks {
    /** [zh-CN] 文件上传进度回调。 [en-US] Triggered when the file upload progress changes. */
    readonly onFileUploadProgress?: (event: FileUploadProgress) => void;
    /** [zh-CN] 文件上传完成回调。 [en-US] Triggered when the file upload completes. */
    readonly onFileUploadComplete?: (payload: unknown) => void;
    /** [zh-CN] 文件上传失败回调。 [en-US] Triggered when the file upload fails. */
    readonly onFileUploadError?: (payload: unknown) => void;
    /** [zh-CN] 文件上传取消回调。 [en-US] Triggered when the file upload is canceled. */
    readonly onFileUploadCanceled?: () => void;
}
/**
 * [zh-CN] 上传群组共享文件时的参数。
 * [en-US] Parameters for uploading a shared file to a group.
 */
export interface UploadGroupSharedFileParams extends GroupMutationTarget, UploadGroupSharedFileCallbacks {
    /** [zh-CN] 待上传的文件对象。 [en-US] The file object to upload. */
    readonly file: CompatibleFile | Blob | Record<string, unknown>;
}
/**
 * [zh-CN] 上传群组共享文件时的输入参数。
 * [en-US] Input parameters for uploading a shared file to a group.
 */
export interface GroupUploadSharedFileInput extends UploadGroupSharedFileCallbacks {
    /** [zh-CN] 待上传的文件对象。 [en-US] The file object to upload. */
    readonly file: CompatibleFile | Blob | Record<string, unknown>;
}
/**
 * [zh-CN] 删除群组共享文件时的参数。
 * [en-US] Parameters for deleting a shared file from a group.
 */
export interface DeleteGroupSharedFileParams extends GroupMutationTarget {
    /** [zh-CN] 待删除的共享文件 ID。 [en-US] The ID of the shared file to delete. */
    readonly fileId: string;
}
/**
 * [zh-CN] 删除群组共享文件时的输入参数。
 * [en-US] Input parameters for deleting a shared file from a group.
 */
export interface GroupDeleteSharedFileInput {
    /** [zh-CN] 待删除的共享文件 ID。 [en-US] The ID of the shared file to delete. */
    readonly fileId: string;
}
/**
 * [zh-CN] 下载群组共享文件时的回调集合。
 * [en-US] Callback events used when downloading a shared file from a group.
 */
export interface DownloadGroupSharedFileCallbacks {
    /** [zh-CN] 文件下载完成回调；支持 Blob 的运行时返回 Blob，否则返回 ArrayBuffer。 [en-US] Triggered when the file download completes; returns a Blob when supported, otherwise an ArrayBuffer. */
    readonly onFileDownloadComplete?: (data: Blob | ArrayBuffer) => void;
    /** [zh-CN] 文件下载失败回调。 [en-US] Triggered when the file download fails. */
    readonly onFileDownloadError?: (error: unknown) => void;
}
/**
 * [zh-CN] 下载群组共享文件时的参数。
 * [en-US] Parameters for downloading a shared file from a group.
 */
export interface DownloadGroupSharedFileParams extends GroupMutationTarget, DownloadGroupSharedFileCallbacks {
    /** [zh-CN] 待下载的共享文件 ID。 [en-US] The ID of the shared file to download. */
    readonly fileId: string;
    /** [zh-CN] 文件下载密钥。 [en-US] The file download secret. */
    readonly secret?: string;
}
/**
 * [zh-CN] 下载群组共享文件时的输入参数。
 * [en-US] Parameters for downloading a shared file from a group.
 */
export interface GroupDownloadSharedFileInput extends DownloadGroupSharedFileCallbacks {
    /** [zh-CN] 待下载的共享文件 ID。 [en-US] The ID of the shared file to download. */
    readonly fileId: string;
    /** [zh-CN] 文件下载密钥。 [en-US] The file download secret. */
    readonly secret?: string;
}
/**
 * [zh-CN] 设置群成员属性时的参数。
 * [en-US] Parameters for setting group member attributes.
 */
export interface SetGroupMemberAttributesParams extends GroupMutationTarget {
    /** [zh-CN] 成员用户 ID。 [en-US] The member user ID. */
    readonly userId: string;
    /** [zh-CN] 待设置的成员属性键值对。键和值均为字符串。 [en-US] The key-value pairs of member attributes to set. Both keys and values are strings. */
    readonly memberAttributes: Readonly<Record<string, string>>;
}
/**
 * [zh-CN] 设置群成员属性时的输入参数。
 * [en-US] Input parameters for setting group member attributes.
 */
export interface GroupSetMemberAttributesInput {
    /** [zh-CN] 成员用户 ID。 [en-US] The member user ID. */
    readonly userId: string;
    /** [zh-CN] 待设置的成员属性键值对。键和值均为字符串。 [en-US] The key-value pairs of member attributes to set. Both keys and values are strings. */
    readonly memberAttributes: Readonly<Record<string, string>>;
}
/**
 * [zh-CN] 查询群成员属性时的参数。
 * [en-US] Parameters for querying group member attributes.
 */
export interface GetGroupMembersAttributesParams extends GroupMutationTarget {
    /** [zh-CN] 待查询的成员用户 ID 列表。 [en-US] The list of member user IDs to query. */
    readonly userIds: ReadonlyArray<string>;
    /** [zh-CN] 待查询的属性 key 列表。不传时返回全部属性。 [en-US] The list of attribute keys to query. If omitted, all attributes are returned. */
    readonly keys?: ReadonlyArray<string>;
}
/**
 * [zh-CN] 查询群成员属性时的输入参数。
 * [en-US] Input parameters for querying group member attributes.
 */
export interface GroupGetMembersAttributesInput {
    /** [zh-CN] 待查询的成员用户 ID 列表。 [en-US] The list of member user IDs to query. */
    readonly userIds: ReadonlyArray<string>;
    /** [zh-CN] 待查询的属性 key 列表。不传时返回全部属性。 [en-US] The list of attribute keys to query. If omitted, all attributes are returned. */
    readonly keys?: ReadonlyArray<string>;
}
/**
 * [zh-CN] 群成员属性查询结果。
 * [en-US] Result of querying group member attributes.
 */
export interface GroupMembersAttributesResult {
    /** [zh-CN] 按成员用户 ID 映射的成员属性集合。 [en-US] The member attribute collections mapped by member user ID. */
    readonly items: Readonly<Record<string, Readonly<Record<string, string>>>>;
}
/**
 * [zh-CN] 收到群组邀请事件的载荷。
 * [en-US] Payload of the group invitation receipt event.
 */
export interface GroupInvitationReceivedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 群组名称。 [en-US] The group name. */
    readonly groupName?: string;
    /** [zh-CN] 发出该邀请的用户资料。 [en-US] The profile of the user who sent the invitation. */
    readonly inviter?: UserInfo;
    /** [zh-CN] 邀请附言。 [en-US] The message attached to the invitation. */
    readonly reason?: string;
}
/**
 * [zh-CN] 收到入群申请事件的载荷。
 * [en-US] Payload of the group join request receipt event.
 */
export interface GroupRequestToJoinReceivedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 群组名称。 [en-US] The group name. */
    readonly groupName?: string;
    /** [zh-CN] 发起入群申请的用户资料。 [en-US] The profile of the user who requested to join the group. */
    readonly applicant?: UserInfo;
    /** [zh-CN] 入群申请附言。 [en-US] The message attached to the join request. */
    readonly reason?: string;
}
/**
 * [zh-CN] 入群申请被同意事件的载荷。
 * [en-US] Payload of the event indicating that a group join request is accepted.
 */
export interface GroupRequestToJoinAcceptedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 群组名称。 [en-US] The group name. */
    readonly groupName?: string;
    /** [zh-CN] 同意该入群申请的用户资料。 [en-US] The profile of the user who accepted the join request. */
    readonly accepter?: UserInfo;
}
/**
 * [zh-CN] 入群申请被拒绝事件的载荷。
 * [en-US] Payload of the event indicating that a group join request is declined.
 */
export interface GroupRequestToJoinDeclinedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 群组名称。 [en-US] The group name. */
    readonly groupName?: string;
    /** [zh-CN] 拒绝该入群申请的用户资料。 [en-US] The profile of the user who declined the join request. */
    readonly decliner?: UserInfo;
    /** [zh-CN] 拒绝入群申请的原因。 [en-US] The reason for declining the join request. */
    readonly reason?: string;
    /** [zh-CN] 发起该入群申请的用户资料。 [en-US] The profile of the user who requested to join the group. */
    readonly applicant?: UserInfo;
}
/**
 * [zh-CN] 群组邀请被接受事件的载荷。
 * [en-US] Payload of the event indicating that a group invitation is accepted.
 */
export interface GroupInvitationAcceptedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 接受邀请的用户资料。 [en-US] The profile of the user who accepted the invitation. */
    readonly invitee?: UserInfo;
    /** [zh-CN] 接受邀请时附带的说明。 [en-US] The note provided when the invitation was accepted. */
    readonly reason?: string;
}
/**
 * [zh-CN] 群组邀请被拒绝事件的载荷。
 * [en-US] Payload of the event indicating that a group invitation is declined.
 */
export interface GroupInvitationDeclinedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 拒绝邀请的用户资料。 [en-US] The profile of the user who declined the invitation. */
    readonly invitee?: UserInfo;
    /** [zh-CN] 拒绝邀请的原因。 [en-US] The reason for declining the invitation. */
    readonly reason?: string;
}
/**
 * [zh-CN] 当前用户被移出群组事件的载荷。
 * [en-US] Payload of the event indicating that the current user is removed from the group.
 */
export interface GroupUserRemovedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 群组名称。 [en-US] The group name. */
    readonly groupName?: string;
}
/**
 * [zh-CN] 群组被解散事件的载荷。
 * [en-US] Payload of the event indicating that the group is disbanded.
 */
export interface GroupDestroyedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 群组名称。 [en-US] The group name. */
    readonly groupName?: string;
}
/**
 * [zh-CN] 群组邀请被自动接受事件的载荷。
 * [en-US] Payload of the event indicating that a group invitation is accepted automatically.
 */
export interface GroupAutoAcceptInvitationEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 发出邀请的用户资料。 [en-US] The profile of the user who sent the invitation. */
    readonly inviter?: UserInfo;
    /** [zh-CN] 自动接受邀请时附带的邀请附言。 [en-US] The invitation message attached when the invitation is accepted automatically. */
    readonly inviteMessage?: string;
}
/**
 * [zh-CN] 群组禁言列表新增事件的载荷。
 * [en-US] Payload of the event indicating that users is added to the group mute list.
 */
export interface GroupMuteListAddedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 被加入禁言列表的用户资料列表。 [en-US] The list of profiles for users added to the mute list. */
    readonly mutes: ReadonlyArray<UserInfo>;
    /** [zh-CN] 本次新增禁言的到期时间戳。 [en-US] The expiration timestamp of the newly added mute for this event. */
    readonly muteExpire?: number;
}
/**
 * [zh-CN] 群组禁言列表移除事件的载荷。
 * [en-US] Payload of the event indicating that users are removed from the group mute list.
 */
export interface GroupMuteListRemovedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 被移出禁言列表的用户资料列表。 [en-US] The list of profiles for users removed from the mute list. */
    readonly mutes: ReadonlyArray<UserInfo>;
}
/**
 * [zh-CN] 群组白名单新增事件的载荷。
 * [en-US] Payload of the event indicating that users are added to the group allow list.
 */
export interface GroupAllowListAddedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 被加入白名单的用户资料列表。 [en-US] The list of profiles for users added to the allow list. */
    readonly allowlist: ReadonlyArray<UserInfo>;
}
/**
 * [zh-CN] 群组白名单移除事件的载荷。
 * [en-US] Payload of the event indicating that users are removed from the group allow list.
 */
export interface GroupAllowListRemovedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 被移出白名单的用户资料列表。 [en-US] The list of profiles for users removed from the allow list. */
    readonly allowlist: ReadonlyArray<UserInfo>;
}
/**
 * [zh-CN] 群组全员禁言状态变更事件的载荷。
 * [en-US] Payload of the event indicating that the all-member mute state of a group is changed.
 */
export interface GroupAllMemberMuteStateChangedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 当前是否已开启全员禁言。 [en-US] Whether all members in the group are currently muted. */
    readonly isMuted: boolean;
}
/**
 * [zh-CN] 群组管理员新增事件的载荷。
 * [en-US] Payload of the event indicating that a group admin is added.
 */
export interface GroupAdminAddedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 被设为管理员的用户资料。 [en-US] The profile of the user who was granted admin privileges. */
    readonly administrator?: UserInfo;
}
/**
 * [zh-CN] 群组管理员移除事件的载荷。
 * [en-US] Payload of the event indicating that a group admin is removed.
 */
export interface GroupAdminRemovedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 被移除管理员权限的用户资料。 [en-US] The profile of the user whose admin privileges were removed. */
    readonly administrator?: UserInfo;
}
/**
 * [zh-CN] 群主变更事件的载荷。
 * [en-US] Payload of the event indicating that the group owner is changed.
 */
export interface GroupOwnerChangedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 新群主的用户资料。 [en-US] The profile of the new group owner. */
    readonly newOwner?: UserInfo;
    /** [zh-CN] 原群主的用户资料。 [en-US] The profile of the former group owner. */
    readonly oldOwner?: UserInfo;
}
/**
 * [zh-CN] 群成员加入事件的载荷。
 * [en-US] Payload of the event indicating that members have joined the group.
 */
export interface GroupMembersJoinedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 群组名称。群详情不可用且原始通知未携带名称时为 `undefined`。 [en-US] The group name. It is `undefined` when group details are unavailable and the raw notification does not include a name. */
    readonly groupName?: string;
    /** [zh-CN] 加入群组的成员用户资料列表。 [en-US] The list of profiles for members who joined the group. */
    readonly members: ReadonlyArray<UserInfo>;
}
/**
 * [zh-CN] 群成员退出事件的载荷。
 * [en-US] Payload of the event indicating that members have left the group.
 */
export interface GroupMembersExitedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 退出群组的成员用户资料列表。 [en-US] The list of profiles for members who left the group. */
    readonly members: ReadonlyArray<UserInfo>;
}
/**
 * [zh-CN] 群公告变更事件的载荷。
 * [en-US] Payload of the group announcement change event.
 */
export interface GroupAnnouncementChangedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 最新群公告内容。 [en-US] The latest group announcement content. */
    readonly announcement: string;
}
/**
 * [zh-CN] 群组共享文件新增事件的载荷。
 * [en-US] Payload of the event indicating that a shared file is added to the group.
 */
export interface GroupSharedFileAddedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 新增的群组共享文件信息。 [en-US] The information about the newly added shared file. */
    readonly sharedFile?: GroupSharedFile;
}
/**
 * [zh-CN] 群组共享文件删除事件的载荷。
 * [en-US] Payload of the event indicating that a shared file is deleted from the group.
 */
export interface GroupSharedFileDeletedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 被删除的共享文件 ID。 [en-US] The ID of the deleted shared file. */
    readonly fileId: string;
}
/**
 * [zh-CN] 群组信息变更事件的载荷。
 * [en-US] Payload of the group information change event.
 */
export interface GroupInfoChangedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 变更后的最新群组详情。 [en-US] The latest group details after the change. */
    readonly groupInfo: GroupDetail;
}
/**
 * [zh-CN] 群组禁用状态变更事件的载荷。
 * [en-US] Payload of the event indicating that the disabled state of a group has changed.
 */
export interface GroupDisabledChangedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 变更后的最新群组详情。 [en-US] The latest group details after the change. */
    readonly groupInfo: GroupDetail;
    /** [zh-CN] 群组当前是否已被禁用。 [en-US] Whether the group is currently disabled. */
    readonly disabled: boolean;
}
/**
 * [zh-CN] 群成员属性变更事件的载荷。
 * [en-US] Payload of the group member attribute change event.
 */
export interface GroupMemberAttributeChangedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 成员属性发生变更的用户资料。 [en-US] The profile of the user whose member attributes have changed. */
    readonly user?: UserInfo;
    /** [zh-CN] 变更后的成员属性键值对。 [en-US] The updated key-value pairs of the member attributes. */
    readonly attribute: Readonly<Record<string, string>>;
    /** [zh-CN] 发起本次成员属性变更的用户 ID。 [en-US] The user ID of the member who updated the attributes. */
    readonly from?: string;
    /** [zh-CN] 变更来源。`direct` 表示直接操作，`multiDevice` 表示多设备同步。 [en-US] The source of the change. `direct` indicates a direct operation, and `multiDevice` indicates multi-device synchronization. */
    readonly source?: 'direct' | 'multiDevice';
}
/**
 * [zh-CN] 群成员名片更新事件的载荷。
 * [en-US] Payload of the event indicating that a group member's name card is updated.
 */
export interface GroupUserGroupNamecardUpdatedEventPayload {
    /** [zh-CN] 群组 ID。 [en-US] The group ID. */
    readonly groupId: string;
    /** [zh-CN] 名片发生更新的用户 ID。 [en-US] The user ID of the member whose name card was updated. */
    readonly userId: string;
    /** [zh-CN] 更新后的群成员名片。 [en-US] The updated group member name card. */
    readonly namecard: string;
}
/**
 * [zh-CN] `GroupManager` 的事件监听器定义。
 * [en-US] Event listener definitions for `GroupManager`.
 */
export interface GroupManagerListener {
    /** [zh-CN] 群成员名片更新回调。 [en-US] Triggered when a group member's name card is updated. */
    readonly onUserGroupNamecardUpdated?: (groupId: string, userId: string, namecard: string) => void;
}
/** @internal 群事件原始通知载荷。 */
export interface GroupRawNotifyPayload {
    readonly groupId: string;
    readonly groupName?: string;
    readonly reason?: string;
    readonly inviterId?: string;
    readonly applicantId?: string;
    readonly accepterId?: string;
    readonly declinerId?: string;
    readonly inviteeId?: string;
    readonly administratorId?: string;
    readonly oldOwnerId?: string;
    readonly newOwnerId?: string;
    readonly memberIds?: ReadonlyArray<string>;
    readonly userId?: string;
    readonly userIds?: ReadonlyArray<string>;
    readonly announcement?: string;
    readonly sharedFile?: GroupSharedFile;
    readonly fileId?: string;
    readonly muteExpire?: number;
    readonly isMuted?: boolean;
    readonly attribute?: Readonly<Record<string, string>>;
    readonly from?: string;
    readonly source?: 'direct' | 'multiDevice';
    readonly shouldFetchGroupDetail?: boolean;
    readonly groupPatch?: Partial<GroupDetail>;
    readonly isDisabled?: boolean;
}
/** @internal 群事件原始通知信封。 */
export interface GroupRawNotifyEvent {
    readonly eventName: string;
    readonly payload: GroupRawNotifyPayload;
}
