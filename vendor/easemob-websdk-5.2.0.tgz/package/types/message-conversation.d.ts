/**
 * 消息会话定位类型与内部映射工具。
 */
export declare const CHAT_CONVERSATION_TYPES: readonly ["singleChat", "groupChat", "chatRoom"];
/**
 * [zh-CN] 消息所属的会话类型。
 * [en-US] Conversation type that a message belongs to.
 */
export type ChatConversationType = (typeof CHAT_CONVERSATION_TYPES)[number];
/**
 * [zh-CN] 消息所属会话的定位参数。
 * [en-US] Locator parameters for the conversation containing a message.
 */
export interface MessageConversationLocator {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    conversationType: ChatConversationType;
}
export declare const isChatConversationType: (value: string) => value is ChatConversationType;
export declare const toLegacyConversationType: (conversationType: ChatConversationType) => "single" | "group" | "room";
export declare const fromLegacyConversationType: (conversationType: "single" | "group" | "room") => ChatConversationType;
