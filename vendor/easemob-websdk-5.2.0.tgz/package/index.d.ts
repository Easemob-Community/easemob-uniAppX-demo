export { ChatClient } from './chat-client';
export { setConsoleLogEnabled, setLogLevel } from './log';
export type { LogEntry, LogLevel } from './types/log';
export { LogEventName, PushEventName } from './types/event-system';
export { AuthenticationError, ConnectionError, isSDKError, MessageReceiveError, MessageSendError, NetworkError, RestBusinessError, RestTransportError, SDKError, StorageError, UploadError, ValidationError, } from './utils/errors';
export type { ErrorContext, ErrorDetails } from './utils/errors';
export { createPlatformAdapter, detectRuntimePlatform } from './platform';
export { RUNTIME_PLATFORMS } from './platform';
export { ChatManager } from './managers/chat/index';
export { ChatThread } from './managers/chat-thread/index';
export { ChatThreadManager } from './managers/chat-thread/index';
export { ChatRoom } from './managers/chatroom/index';
export { ChatRoomManager } from './managers/chatroom/index';
export { ContactManager } from './managers/contact/index';
export { Group } from './managers/group/index';
export { GroupManager } from './managers/group/index';
export { PresenceManager } from './managers/presence/index';
export { PushManager } from './managers/push/index';
export { UserInfoManager } from './managers/user-info/index';
export { CacheManager } from './cache/index';
export type { InitConfig, // 初始化配置类型
AuthContext, // 认证上下文类型
RestContext, // REST 上下文类型
ConnectionState, // 连接状态类型
TokenRenewalResult, // token 续期结果类型
GetRTCTokenInfoParams, // RTC token 查询参数
RTCTokenInfo, // RTC token 信息
RTCUid, // RTC UID 类型
RTCUidUserIdMap, // RTC UID 到 userId 映射
DnsConfig, // DNS 配置类型
DnsHost, // DNS Host 类型
SelfIdsOnOtherPlatform, // 多端登录设备 ID 列表
ServerUrlsConfig, // 服务地址配置
ServiceConfig, // 服务配置
SyncConversationListConfig, } from './types/chat-client';
export type { SyncDataError, SyncDataErrorStage, SyncDataFinishedPayload, SyncDataStartPayload, SyncDataStatus, SyncDataType, } from './types/sync-data';
export type { AddContactParams, BlocklistAddResult, BlocklistMutationParams, BlocklistSnapshot, Contact, ContactInfoUpdatedEvent, ContactMutationTarget, ContactRosterEventPayload, ContactSnapshot, ContactSyncDecision, ContactSyncError, ContactSyncFinishPayload, ContactSyncSource, ContactSyncStage, SetContactRemarkParams, } from './types/contact';
export type { ManagerBase, // 管理器基础类型
ManagerCapability, ManagerConstructor, // 管理器构造器类型
ManagerEventContext, ManagerInstance, // 管理器实例类型
ManagerInstanceKey, ManagerRegistration, // 管理器注册类型
ManagerSessionContext, ManagerSessionEndContext, ManagerSessionEndReason, RawNotifyEvent, WithManager, // 单管理器扩展类型
WithManagers, } from './types/manager';
export type { ChatRoomAdminInput, ChatRoomAdminParams, ChatRoomAdminAddedEventPayload, ChatRoomAdminRemovedEventPayload, ChatRoomAllMemberMuteStateChangedEventPayload, ChatRoomAllowlistEntry, ChatRoomAnnouncement, ChatRoomAnnouncementChangedEventPayload, ChatRoomAnnouncementUpdateInput, ChatRoomAnnouncementUpdateParams, ChatRoomAttributeMutationResult, ChatRoomAttributesRemovedEventPayload, ChatRoomAttributesSnapshot, ChatRoomAllowListAddedEventPayload, ChatRoomAllowListRemovedEventPayload, ChatRoomBlocklistEntry, ChatRoomDestroyedEventPayload, ChatRoomDetail, ChatRoomEventHandlerMap, ChatRoomEventName, ChatRoomEventPayloadMap, ChatRoomListResult, ChatRoomAttributesUpdateEventPayload, ChatRoomMemberActionListResult, ChatRoomMemberActionResult, ChatRoomMemberEntry, ChatRoomMembersExitedEventPayload, ChatRoomMembersJoinedEventPayload, ChatRoomMemberListParams, ChatRoomMemberListResult, ChatRoomMuteEntry, ChatRoomMuteListAddedEventPayload, ChatRoomMuteListRemovedEventPayload, ChatRoomMuteMembersInput, ChatRoomMuteMembersParams, ChatRoomMuteStatus, ChatRoomMutationTarget, ChatRoomOwnerChangedEventPayload, ChatRoomPageParams, ChatRoomPermissionType, ChatRoomRole, ChatRoomInfoChangedEventPayload, ChatRoomSummary, ChatRoomUpdateInfoInput, ChatRoomUpdateResult, ChatRoomUserBatchInput, ChatRoomUserBatchParams, ChatRoomRemovedFromChatRoomEventPayload, DeleteChatRoomSharedFileParams, GetChatRoomAttributesInput, GetChatRoomAttributesParams, GetChatRoomInfoParams, GetChatRoomListParams, JoinChatRoomInfo, JoinChatRoomParams, RemoveChatRoomAttributesInput, RemoveChatRoomAttributesParams, SetChatRoomAttributesInput, SetChatRoomAttributesParams, UpdateChatRoomInfoParams, } from './types/chatroom';
export type { AcceptGroupJoinRequestParams, CreateGroupParams, CreateGroupResult, CursorPageParams, DeleteGroupSharedFileParams, DownloadGroupSharedFileParams, GetGroupInfoListParams, GetGroupInfoParams, GetGroupMembersAttributesParams, GroupAdminMutationParams, GroupAllowlistEntry, GroupAdminAddedEventPayload, GroupAdminRemovedEventPayload, GroupAnnouncement, GroupAnnouncementChangedEventPayload, GroupAnnouncementUpdateInput, GroupAnnouncementUpdateParams, GroupAutoAcceptInvitationEventPayload, GroupBlocklistEntry, GroupDeleteSharedFileInput, GroupDetail, GroupDownloadSharedFileInput, GroupDestroyedEventPayload, GroupInvitationAcceptedEventPayload, GroupInvitationDeclinedEventPayload, GroupInvitationReceivedEventPayload, GroupGetMembersAttributesInput, GroupListResult, GroupMemberAttributeChangedEventPayload, GroupMemberEntry, GroupMemberListQuery, GroupMuteListQuery, GroupMemberListParams, GroupMemberListResult, GroupMembersAttributesResult, GroupMembersExitedEventPayload, GroupMembersJoinedEventPayload, GroupMuteEntry, GroupMuteListAddedEventPayload, GroupMuteListRemovedEventPayload, GroupMuteMembersInput, GroupMutationTarget, NumberPageParams, GroupOwnerChangedEventPayload, GroupOwnerChangeInput, GroupOwnerChangeParams, GroupRequestToJoinAcceptedEventPayload, GroupRequestToJoinDeclinedEventPayload, GroupRequestToJoinReceivedEventPayload, GroupRole, GroupSetMemberAttributesInput, GroupSharedFile, GroupSharedFileListQuery, GroupSharedFileAddedEventPayload, GroupSharedFileDeletedEventPayload, GroupSharedFileListParams, GroupSharedFileListResult, GroupInfoChangedEventPayload, GroupDisabledChangedEventPayload, JoinedGroupSnapshot, JoinedGroupSnapshotIntegrity, JoinedGroupSnapshotMeta, JoinedGroupSnapshotSource, JoinedGroupSummary, GroupSummary, GroupUserInfo, GroupManagerListener, GroupUpdateConfigsInput, GroupUpdateInfoInput, GroupUploadSharedFileInput, GroupUserBatchInput, GroupUserBatchParams, GroupUserGroupNamecardUpdatedEventPayload, GroupUserRemovedEventPayload, GroupAllowListAddedEventPayload, GroupAllowListRemovedEventPayload, GroupAllMemberMuteStateChangedEventPayload, GroupJoinParams, GroupMuteMembersParams, RejectGroupJoinRequestParams, SetGroupMemberAttributesParams, UpdateGroupInfoParams, UploadGroupSharedFileParams, } from './types/group';
export type { ChatActionResult, ChatConversationType, ConversationLocator, DownloadCombineMessageInput, DownloadAttachmentParams, GetHistoryMessagesParams, GetGroupMessageReadReceiptsParams, GetReactionDetailParams, GetReactionListParams, GroupMessageReadUser, GroupMessageReadUserInfo, GroupMessageReadUsersParams, GroupMessageReadUsersResult, ClearConversationUnreadMessageCountParams, MessageAttachmentDownloadResult, MessageHistoryPage, MessageChatConversationType, MessageReadReceiptDetail, MessageReactionDetailPage, MessageReactionListItem, MessageReactionSummary, MessageTranslation, MessageTranslationResult, ReactionOperationParams, RecallMessageParams, RemoveHistoryMessagesParams, TranslateMessageParams, TranslationLanguage, UpdateMessageParams, MessageSearchOption, SearchableMessageType, SearchMessagesParams, SearchMessagesResult, SearchResultMessage, SendMessageReadReceiptsParams, VoiceParams, VoiceMessageSource, VoiceSourceFile, VoiceToTextResult, } from './types/chat-manager';
export type { CreateCmdMessageParams, // 命令消息入参类型
CreateCombineMessageParams, // 合并消息入参类型
CreateCustomMessageParams, // 自定义消息入参类型
CreateFileMessageParams, // 文件消息入参类型
CreateImageMessageParams, // 图片消息入参类型
CreateLocationMessageParams, // 位置消息入参类型
CreateMessageBaseParams, // 创建消息基础入参类型
CreateTextMessageParams, // 文本消息入参类型
CreateVideoMessageParams, // 视频消息入参类型
CreateVoiceMessageParams, // 语音消息入参类型
CreateMultiBodyMessageParams, CreateCustomMessageBodyParams, CreateFileMessageBodyParams, CreateImageMessageBodyParams, CreateLocationMessageBodyParams, CreateTextMessageBodyParams, CreateVideoMessageBodyParams, CreateVoiceMessageBodyParams, } from './types/message-create';
export type { CmdMessageBody, CombineMessage, CombineMessageBody, MultiBodySegment, MultiBody, CompatibleFile, CustomMessageBody, FileMessageBody, FileUploadProgress, FileUploadResult, ImageMessageBody, LocationMessageBody, Message, MessageBody, MessageDirect, MessagePriority, MessageReaction, MessageSendStatus, MessageType, MiniAppFile, ReactNativeFile, SendMessageOptions, StreamMessage, StreamMessageMeta, TextMessageBody, VideoMessageBody, VoiceMessageBody, } from './types/index';
export { ImageType, StreamMessageStatus } from './types/index';
export type { ChatEventHandlerMap, // Chat 事件处理器类型
ChatEventPayloadMap, ChatThreadEventName, ChatThreadEventHandlerMap, ChatThreadEventPayloadMap, ContactEventHandlerMap, // 联系人事件处理器类型
ContactEventPayloadMap, ConnectionEventHandlerMap, // 连接事件处理器类型
ConnectionEventPayloadMap, EventHandlerId, // 事件处理器标识
EventHandlerMap, // 通用事件处理器映射
EventName, // 事件名称
EventPayloadMap, // 事件载荷映射
MultiDeviceEventHandlerMap, MultiDeviceEventPayloadMap, GroupEventHandlerMap, // 群组事件处理器类型
GroupEventPayloadMap, LogEventHandlerMap, LogEventPayloadMap, PresenceEventHandlerMap, // 在线状态事件处理器类型
PresenceEventPayloadMap, PushEventHandlerMap, PushEventPayloadMap, UserInfoEventHandlerMap, // 用户资料事件处理器类型
UserInfoEventPayloadMap, } from './types/event-system';
export type { MultiDeviceContactOperation, MultiDeviceConversationOperation, MultiDeviceEvent, MultiDeviceEventCategory, MultiDeviceGroupOperation, MultiDeviceMessageRemovedOperation, MultiDeviceThreadOperation, } from './types/multi-device';
export type { ChatThreadBaseEventPayload, ChatThreadCreatedEventPayload, ChatThreadDetail, ChatThreadDestroyedEventPayload, ChatThreadLastMessageEntry, ChatThreadLastMessageListResult, ChatThreadListResult, ChatThreadMessageContext, ChatThreadMemberEntry, ChatThreadMemberListQuery, ChatThreadMemberListResult, ChatThreadMutationTarget, ChatThreadOverview, ChatThreadSummary, ChatThreadUpdatedEventPayload, ChatThreadUserRemovedEventPayload, CreateChatThreadParams, CreateChatThreadResult, GetChatThreadInfoParams, GetChatThreadLastMessageListParams, GetChatThreadListParams, GetChatThreadMemberListParams, GetJoinedChatThreadListParams, RemoveChatThreadMemberParams, UpdateChatThreadNameParams, } from './types/chat-thread';
export type { PresenceInfo, // 在线状态业务对象
PresenceState, // 在线状态事件类型
PresenceStatusDetails, // 在线状态详情类型
SubscribePresenceResponse, // 订阅在线状态响应
SubscribedPresenceListResponse, } from './types/presence';
export type { PublishPresenceParams } from './managers/presence-manager';
export type { BatchConversationSilentModeResponse, // 批量会话免打扰响应
ClearConversationRemindTypeParams, // 清除会话提醒参数
ConversationIdentifier, // 会话标识
ConversationSilentModeResponse, // 会话免打扰响应
GetConversationListByRemindTypeParams, // 分页查询参数
GetConversationSilentModeParams, // 查询会话免打扰参数
GetConversationSilentModesParams, // 批量查询会话免打扰参数
GetGlobalSilentModeParams, // 查询全局免打扰参数
GetPushLanguageParams, // 查询推送语言参数
GlobalSilentModeResponse, // 全局免打扰响应
MutedConversationItem, // 免打扰会话条目
MutedConversationPageResponse, // 免打扰会话分页响应
NativePushCertificates, NativePushChannel, NativePushPlugin, NativePushTokenResult, NativePushTypeCode, PushConversationType, // 会话类型
PushLanguageResponse, // 推送语言响应
PushTokenBoundEvent, PushTokenOperationFailedEvent, PushRemindType, // 提醒类型
PushRemindTypeWithoutDefault, // 提醒类型（不含默认）
PushSilentModeDurationRuleInput, // 时长规则输入
PushSilentModeDurationRuleView, // 时长规则输出
PushSilentModeIntervalRuleInput, // 时间区间规则输入
PushSilentModeIntervalRuleView, // 时间区间规则输出
PushSilentModeRemindTypeRuleInput, // 提醒规则输入
PushSilentModeRemindTypeRuleView, // 提醒规则输出
PushSilentModeRuleInput, // 免打扰规则输入
PushSilentModeRuleView, // 免打扰规则输出
PushTimePoint, // 时间点
SetConversationSilentModeParams, // 设置会话免打扰参数
SetNativePushOptions, SetGlobalSilentModeParams, // 设置全局免打扰参数
SetPushLanguageParams, // 设置推送语言参数
UploadPushTokenParams, } from './types/push';
export type { FetchUserInfoByAttributeParams, // 按属性查询参数
FetchUserInfoByUserIdParams, // 按用户 ID 查询参数
SubscribeUsersInfoParams, // 订阅资料变化参数
UnsubscribeUsersInfoParams, // 取消订阅资料变化参数
UpdateOwnInfoByAttributeParams, // 单属性更新参数模型
UpdateOwnInfoParams, // 当前用户资料更新参数
UserInfoAttribute, // 用户信息字段
UserInfoAttributeValue, // 用户信息字段值
UserInfoListener, // 用户资料监听器
UserInfo, } from './types/user-info';
export type { CacheConfig, // 缓存配置
CacheDump, // 缓存落盘结构
CacheMetadata, // 缓存元信息
ConversationSummary, // 会话摘要
ConversationListUpdatePayload, // 会话列表更新载荷
ConversationListUpdatePatch, // 会话列表更新补丁
ConversationListUpdateReason, // 会话列表更新原因
GroupNamecardCacheRecord, // 群名片缓存
MessageSnippet, // 消息摘要
UserInfoSummary, } from './cache/index';
export type { ConversationFilter, ConversationItem, ConversationMark, ConversationMarkMutationItem, ConversationMarkMutationResult, ConversationMarkParams, ConversationMutationResult, ConversationMarkTarget, ConversationType, DeleteConversationParams, GetPinnedMessageListParams, MessagePinMutationResult, PinMessageParams, PinnedMessageListResult, PinnedMessageSummary, RefreshSessionListParams, SessionListRemindType, SessionMessageSnippet, Sender, SetConversationPinnedParams, } from './types/conversation';
export { CONVERSATION_MARK } from './types/conversation';
export type { CreatePlatformAdapterOptions, // 平台适配器创建参数
GeneratedImageResult, HttpMethod, ImageGenerateOptions, ImageInfoResult, ImageProcessor, PlatformAdapter, // 平台适配器总接口
PlatformAdapterOverrides, // 平台适配器覆盖能力
PlatformAdapterOverridesResolver, PlatformAdapterError, // 平台错误
PlatformAdapterProfile, PlatformCapability, // 平台能力画像
PlatformErrorCode, PlatformErrorStage, PlatformFactoryResult, // 平台工厂结果
ProtoAdapter, RequestAdapter, RequestConfig, RequestResponse, RuntimeAdapter, RuntimePlatform, // 运行平台
SocketAdapter, SocketConnectConfig, SocketLike, SocketMessageData, SocketReadyState, SocketSendData, StorageAdapter, TransportAdapter, UploadAdapter, UploadConfig, UploadProgress, UploadResult, UploadSource, UploadSourceType, } from './platform';
