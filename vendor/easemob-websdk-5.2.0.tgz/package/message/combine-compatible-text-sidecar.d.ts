import type { Message } from '../types';
export declare const setCombineCompatibleTextSidecar: (message: Message, compatibleText: string | undefined) => void;
export declare const getCombineCompatibleTextSidecar: (message: Message) => string | undefined;
export declare const copyCombineCompatibleTextSidecar: (source: Message, target: Message) => void;
