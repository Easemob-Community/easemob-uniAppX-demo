/** 消息译文的公开映射与现有消息协议数组之间的转换。 */
export declare const toProtocolTranslations: (translations: Readonly<Record<string, string>> | undefined) => ReadonlyArray<{
    readonly code: string;
    readonly text: string;
}>;
/** 非法译文不影响原文解析；重复语言采用最后一个合法条目。 */
export declare const readTranslations: (metaPayload: unknown) => Record<string, string> | undefined;
