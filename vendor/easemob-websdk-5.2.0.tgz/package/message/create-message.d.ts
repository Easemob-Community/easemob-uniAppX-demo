/**
 * 消息创建方法
 */
import type { // 合并消息体
CompatibleFile, // 跨端文件类型
CreateCmdMessageParams, // 命令消息入参
CreateCombineMessageParams, // 合并消息入参
CreateCustomMessageParams, // 自定义消息入参
CreateFileMessageParams, // 文件消息入参
CreateImageMessageParams, // 图片消息入参
CreateLocationMessageParams, // 位置消息入参
CreateMessageBaseParams, // 创建消息基础入参
CreateTextMessageParams, // 文本消息入参
CreateVideoMessageParams, // 视频消息入参
CreateVoiceMessageParams, // 位置消息体
Message, // 消息类型
MessageBody, // 消息体联合类型
MessageType, // 消息类型联合
MultiBodySegment, Sender } from '../types';
export declare const ensureSender: (sender?: Sender) => Sender;
export declare const resolveMediaUrl: (url: string | undefined, data?: CompatibleFile) => string;
interface CreateImageMessageOptions {
    useCustomAttachmentUpload?: boolean;
}
export declare const buildMessage: (params: CreateMessageBaseParams, // 通用入参
sender: Sender, // 发送者信息
type: Exclude<MessageType, "multi_body">, // 消息类型
body: MessageBody, // 消息体
msgLocalId?: string) => Message;
export declare const buildMultiBodyMessage: (params: CreateMessageBaseParams, sender: Sender, bodies: ReadonlyArray<MultiBodySegment>, msgLocalId?: string) => Message;
/**
 * 创建文本消息
 */
export declare const createTextMessage: (params: CreateTextMessageParams, // 文本消息入参
sender?: Sender) => Message;
/**
 * 创建图片消息
 */
export declare const createImageMessage: (params: CreateImageMessageParams, // 图片消息入参
sender?: Sender, // 发送者信息
options?: CreateImageMessageOptions) => Message;
/**
 * 创建文件消息
 */
export declare const createFileMessage: (params: CreateFileMessageParams, // 文件消息入参
sender?: Sender) => Message;
/**
 * 创建语音消息
 */
export declare const createVoiceMessage: (params: CreateVoiceMessageParams, // 语音消息入参
sender?: Sender) => Message;
/**
 * 创建视频消息
 */
export declare const createVideoMessage: (params: CreateVideoMessageParams, // 视频消息入参
sender?: Sender) => Message;
/**
 * 创建位置消息
 */
export declare const createLocationMessage: (params: CreateLocationMessageParams, // 位置消息入参
sender?: Sender) => Message;
/**
 * 创建命令消息
 */
export declare const createCmdMessage: (params: CreateCmdMessageParams, // 命令消息入参
sender?: Sender) => Message;
/**
 * 创建自定义消息
 */
export declare const createCustomMessage: (params: CreateCustomMessageParams, // 自定义消息入参
sender?: Sender) => Message;
/**
 * 创建合并消息
 */
export declare const createCombineMessage: (params: CreateCombineMessageParams, sender?: Sender) => Message;
export {};
