import type { Message, MessageBody } from '../types';
import type { MessageProfileVersionSidecar } from '../core/message/profile-sync/profile-version-sidecar';
/** @internal Validated serializable fields shared by realtime projections and both cache formats. */
export declare const projectMessageMetadata: (value: unknown) => Omit<Partial<Message>, "body"> & MessageProfileVersionSidecar;
/** @internal Stable comparison for message snapshots; object key order has no business meaning. */
export declare const messageSnapshotSignature: (value: unknown) => string;
/** @internal A shallow serializable body projection without expanding combined-message details. */
export declare const projectMessageSegments: (bodies: ReadonlyArray<Record<string, unknown>>) => ReadonlyArray<Record<string, unknown>>;
export declare const projectMessageBody: (body: MessageBody | Record<string, unknown> | ReadonlyArray<Record<string, unknown>>) => Record<string, unknown> | ReadonlyArray<Record<string, unknown>>;
