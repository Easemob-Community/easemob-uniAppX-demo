import type { CompatibleFile, MultiBody, Message, MessageBody, MessageType } from '../types';
declare const MULTIBODY_SEGMENT_TYPES: readonly ["text", "image", "file", "voice", "video", "location", "custom"];
export type MultiBodySegmentType = (typeof MULTIBODY_SEGMENT_TYPES)[number];
export declare const isMultiBodySegmentType: (type: string) => type is MultiBodySegmentType;
/** 复合消息附件缓存 key。冒号必须保留，避免本地 id 和分段下标粘在一起。 */
export declare const attachmentStoreKey: (msgLocalId: string, bodyIndex: number) => string;
/** 本地文件挂在分段对象本身上。组装时按这个对象取走，复制分段会把文件丢掉。 */
export declare const holdAttachmentFile: (body: object, file: CompatibleFile) => void;
export declare const takeAttachmentFile: (body: object) => CompatibleFile | undefined;
export declare const mapRestSegmentType: (type: string | undefined) => MessageType | null;
/** REST 合并段经常写成 txt/text，并用 subType 0 或合并启发字段标识。 */
export declare const isCombineRestSegment: (segment: Record<string, unknown>) => boolean;
/** 多段无法合成复合消息时只留第一段，并说明原因。第一段本身解不出来则仍丢弃。 */
export declare const keepFirstBody: <T>(segments: ReadonlyArray<T>, reason: string) => ReadonlyArray<T>;
export declare const composeSegments: (segments: ReadonlyArray<{
    type: MessageType;
    body: MessageBody;
} | null>) => {
    type: MessageType;
    body: MessageBody;
} | null;
export declare const resolvePublicMessageContent: (contents: ReadonlyArray<unknown>, decodeContent: (content: Record<string, unknown>) => {
    type: MessageType;
    body: MessageBody;
} | null) => {
    type: MessageType;
    body: MessageBody;
} | null;
export declare const isDownloadableSegmentType: (type: string) => type is "image" | "voice" | "video" | "file";
export declare const attachMultiBodyUploadDetails: (error: unknown, msgLocalId: string) => void;
export declare const isMultiBodyMessage: (message: Pick<Message, "type" | "body">) => message is Message & {
    type: "multi_body";
    body: MultiBody;
};
export {};
