import type { Message } from '../types';
export declare const MAX_COMBINE_MESSAGE_COUNT = 300;
export declare const MAX_COMBINE_LEVEL = 10;
export declare const ensureCombineItemLimit: (count: number, max?: number) => void;
export declare const validateCombineMessageList: (messageList: ReadonlyArray<Message>) => void;
export declare const calculateCombineLevel: (messageList: ReadonlyArray<Message>) => number;
export declare const ensureCombineLevel: (combineLevel: number) => void;
