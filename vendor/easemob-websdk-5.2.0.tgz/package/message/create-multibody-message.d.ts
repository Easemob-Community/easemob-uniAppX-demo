import type { CreateMultiBodyMessageParams, CreateCustomMessageBodyParams, CreateFileMessageBodyParams, CreateImageMessageBodyParams, CreateLocationMessageBodyParams, CreateTextMessageBodyParams, CreateVideoMessageBodyParams, CreateVoiceMessageBodyParams, CustomMessageBody, FileMessageBody, ImageMessageBody, LocationMessageBody, Message, Sender, TextMessageBody, VideoMessageBody, VoiceMessageBody } from '../types';
interface CreateImageMessageBodyOptions {
    readonly useCustomAttachmentUpload?: boolean;
}
export declare const createTextMessageBody: (params: CreateTextMessageBodyParams) => {
    type: "text";
} & TextMessageBody;
export declare const createImageMessageBody: (params: CreateImageMessageBodyParams, options?: CreateImageMessageBodyOptions) => {
    type: "image";
} & ImageMessageBody;
export declare const createFileMessageBody: (params: CreateFileMessageBodyParams) => {
    type: "file";
} & FileMessageBody;
export declare const createVoiceMessageBody: (params: CreateVoiceMessageBodyParams) => {
    type: "voice";
} & VoiceMessageBody;
export declare const createVideoMessageBody: (params: CreateVideoMessageBodyParams) => {
    type: "video";
} & VideoMessageBody;
export declare const createLocationMessageBody: (params: CreateLocationMessageBodyParams) => {
    type: "location";
} & LocationMessageBody;
export declare const createCustomMessageBody: (params: CreateCustomMessageBodyParams) => {
    type: "custom";
} & CustomMessageBody;
/**
 * 组装复合消息。校验不通过时不取走本地文件。
 * 通过后把文件从分段对象挪到 `msgLocalId:bodyIndex`，发送时按这个 key 找文件。
 */
export declare const createMultiBodyMessage: (params: CreateMultiBodyMessageParams, sender?: Sender) => Message;
export {};
