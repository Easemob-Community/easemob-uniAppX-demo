import type { ChatConversationType, Message, MessageBody, MessageType, Sender } from '../types';
/** 合并消息解码后的子消息结构（内部类型） */
interface CombineMessageItem {
    msgServerId?: string;
    msgLocalId?: string;
    type: MessageType;
    sender: Sender;
    conversationId: string;
    conversationType: ChatConversationType;
    timestamp: number;
    body: MessageBody;
    ext?: Record<string, unknown>;
    combineLevel?: number;
}
type CombineMessageItemEncoder = (item: Message, index: number) => Uint8Array;
export declare const encodeCombineMessageList: (messageList: ReadonlyArray<Message>, encodeItem: CombineMessageItemEncoder) => Uint8Array;
export declare const decodeCombineMessageList: (payload: Uint8Array) => ReadonlyArray<CombineMessageItem>;
export {};
