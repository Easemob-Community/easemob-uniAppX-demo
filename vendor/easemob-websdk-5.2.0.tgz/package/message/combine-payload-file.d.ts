import { type RuntimeDetectionInput } from '../platform/env';
import type { CompatibleFile } from '../types';
export interface MaterializeCombinePayloadFileOptions {
    readonly payload: Uint8Array;
    readonly filename: string;
    readonly filetype: string;
    readonly fileId: string;
    readonly runtime?: RuntimeDetectionInput;
}
export declare const materializeCombinePayloadFile: (options: MaterializeCombinePayloadFileOptions) => Promise<CompatibleFile>;
export declare const removeCombinePayloadFile: (file: CompatibleFile | undefined, runtime?: RuntimeDetectionInput) => Promise<void>;
