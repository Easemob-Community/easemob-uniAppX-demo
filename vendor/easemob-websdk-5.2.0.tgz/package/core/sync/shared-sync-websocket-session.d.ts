import { type SocketAdapter, type SocketLike } from '../../platform/types';
export interface SharedSyncMessageResult<TResult> {
    readonly done: boolean;
    readonly result: TResult;
}
export interface SharedSyncDecodedFrame<TFrame> {
    readonly type: number;
    readonly requestId?: string;
    readonly frame: TFrame;
}
export interface SharedSyncRequestOptions<TFrame, TResult> {
    readonly dataType: 'conversation' | 'contact' | 'group';
    readonly label: string;
    readonly requestId: string;
    readonly encode: () => Uint8Array;
    readonly decode: (payload: Uint8Array) => SharedSyncDecodedFrame<TFrame>;
    readonly onFrame: (frame: TFrame, socket: SocketLike) => Promise<SharedSyncMessageResult<TResult> | void> | SharedSyncMessageResult<TResult> | void;
}
export interface SharedSyncWebSocketSessionOptions {
    readonly getUrls: () => Promise<ReadonlyArray<string>>;
    readonly socketAdapter?: SocketAdapter;
}
export declare class SharedSyncWebSocketSession {
    private readonly getUrls;
    private readonly socketAdapter?;
    private readonly pending;
    private socket;
    private state;
    private connectPromise;
    private activeUrl;
    private urlIndex;
    private attempt;
    private connectTimer;
    private idleTimer;
    private retryTimer;
    private completeCloseTimer;
    private cancelled;
    constructor(options: SharedSyncWebSocketSessionOptions);
    request<TFrame, TResult>(options: SharedSyncRequestOptions<TFrame, TResult>): Promise<TResult>;
    cancel(reason?: string): void;
    close(reason?: string): void;
    private ensureConnected;
    private connectWithRetry;
    private openSocket;
    private handleMessage;
    private routeFrame;
    private handleSocketFailure;
    private resendPendingRequests;
    private sendPendingRequest;
    private rejectPending;
    private rejectAll;
    private closeIfComplete;
    private resetIdleTimer;
    private clearTimers;
    private clearConnectTimer;
    private clearIdleTimer;
    private clearCompleteCloseTimer;
    private closeSocket;
    private buildConnectionError;
    private buildLogContext;
}
