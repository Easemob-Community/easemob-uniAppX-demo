import type { ConversationSummary } from '../../cache/cache-types';
import type { ConversationItem, ConversationMark } from '../../types/conversation';
import type { MutedConversationPageResponse } from '../../types/push';
export declare const toConversationItem: (item: ConversationItem) => ConversationItem;
export declare const toConversationSummary: (item: ConversationItem) => ConversationSummary;
export declare const queryConversationSummariesFromSessionList: (options: {
    readonly items: ReadonlyArray<ConversationItem>;
    readonly params?: {
        readonly pageSize?: number;
        readonly cursor?: string;
        readonly includeEmptyConversations?: boolean;
    };
    readonly defaultPageSize: number;
    readonly maxPageSize: number;
    readonly filter?: (item: ConversationItem) => boolean;
}) => {
    readonly items: ReadonlyArray<ConversationItem>;
    readonly cursor: string;
    readonly hasMore: boolean;
};
export declare const queryMutedConversationsFromSessionList: (options: {
    readonly items: ReadonlyArray<ConversationItem>;
    readonly pageSize: number;
    readonly cursor?: string;
}) => MutedConversationPageResponse;
export declare const hasSessionMark: (item: ConversationItem, mark: ConversationMark) => boolean;
