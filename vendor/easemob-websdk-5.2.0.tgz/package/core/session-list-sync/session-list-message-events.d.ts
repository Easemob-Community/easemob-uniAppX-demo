import type { ConversationItem, SessionMessageSnippet } from '../../types/conversation';
import type { ChatThreadRawNotifyPayload } from '../../types/chat-thread';
/** @internal Updates a parent message overview only when the notification identifies that message/thread. */
export declare const resolveThreadLastMessagePatch: (payload: ChatThreadRawNotifyPayload, items: ReadonlyArray<ConversationItem>, userId: string, useCustomAttachmentUpload?: boolean) => {
    readonly conversationId: string;
    readonly conversationType: "groupChat";
    readonly messageId: string;
    readonly patch: Partial<SessionMessageSnippet>;
} | null;
