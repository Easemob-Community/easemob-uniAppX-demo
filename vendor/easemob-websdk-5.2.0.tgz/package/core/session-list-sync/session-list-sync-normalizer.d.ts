import type { ConversationSummary } from '../../cache/cache-types';
import type { ChatClient } from '../../chat-client';
import type { ConversationItem } from '../../types/conversation';
export declare const buildFallbackConversationItemsFromConversations: (conversations: ReadonlyArray<ConversationSummary>, client: ChatClient) => Promise<ReadonlyArray<ConversationItem>>;
export declare const normalizeConversationSummaryToConversationItem: (conversation: ConversationSummary, client: ChatClient) => Promise<ConversationItem>;
export declare const normalizeConversationSummariesToConversationItems: (conversations: ReadonlyArray<ConversationSummary>, client: ChatClient) => Promise<ReadonlyArray<ConversationItem>>;
