import type { ChatClient } from '../../chat-client';
import type { SessionListCapabilityState } from '../../cache/cache-types';
import type { ConversationItem } from '../../types/conversation';
import type { SessionListRequestParams } from '../../protocol/session-list/types';
export declare class SessionListSyncController {
    private readonly client;
    private running;
    private currentSession;
    private activeFinish;
    private cancelled;
    private capabilityState;
    constructor(client: ChatClient);
    getCapabilityState(): SessionListCapabilityState;
    cancel(): void;
    /** @internal */
    cancelForTeardown(): (() => void) | null;
    refresh(params: SessionListRequestParams): Promise<ReadonlyArray<ConversationItem>>;
    private runRefresh;
    private tryDirectFallback;
    private createRetrySession;
    private buildFallbackSessionList;
}
