import type { ChatClient } from '../../chat-client';
import type { ConversationItem } from '../../types/conversation';
import type { SessionListRequestParams } from '../../protocol/session-list/types';
import type { SessionListSyncSession } from './session-list-sync-session';
export declare const toSessionListRequestLastSyncTime: (lastSyncTime: number) => number;
export declare const runSessionListSync: (options: {
    readonly client: ChatClient;
    readonly session: SessionListSyncSession;
    readonly params: SessionListRequestParams;
}) => Promise<{
    readonly items: ReadonlyArray<ConversationItem>;
    readonly lastSyncFinishedTs: number;
}>;
