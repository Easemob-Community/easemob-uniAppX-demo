import type { SessionListSyncBatchEnvelope, SessionListSyncSnapshot, SessionListSyncStatus } from './session-list-sync-types';
export declare class SessionListSyncSession {
    private readonly requestId;
    private readonly startedAt;
    private status;
    private readonly seenBatchKeys;
    private readonly itemsByConversation;
    private batchCount;
    private finishedAt?;
    constructor(requestId?: string);
    getRequestId(): string;
    getStartedAt(): number;
    start(): void;
    markSyncing(): void;
    pushBatch(batch: SessionListSyncBatchEnvelope): {
        readonly accepted: boolean;
        readonly done: boolean;
    };
    fail(): void;
    cancel(): void;
    getItems(): ReadonlyArray<SessionListSyncBatchEnvelope['sessions'][number]>;
    getBatchCount(): number;
    getStatus(): SessionListSyncStatus;
    buildSnapshot(): SessionListSyncSnapshot;
    private isTerminal;
}
