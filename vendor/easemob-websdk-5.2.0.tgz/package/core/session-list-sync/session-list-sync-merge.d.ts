import type { SessionListCacheRecord } from '../../cache/cache-types';
import type { Message } from '../../types';
export declare const sortSessionListRecords: (items: ReadonlyArray<SessionListCacheRecord>) => ReadonlyArray<SessionListCacheRecord>;
export declare const mergeSessionListSnapshot: (options: {
    readonly snapshot: ReadonlyArray<SessionListCacheRecord>;
    readonly existing: ReadonlyArray<SessionListCacheRecord>;
    readonly syncStartedAt?: number;
}) => ReadonlyArray<SessionListCacheRecord>;
export declare const applySessionListMessagePatch: (options: {
    readonly existing: ReadonlyArray<SessionListCacheRecord>;
    readonly nextRecord: SessionListCacheRecord;
    readonly message: Message;
}) => ReadonlyArray<SessionListCacheRecord>;
export declare const mergeSessionListIncrementalWithPinnedOverride: (options: {
    readonly existing: ReadonlyArray<SessionListCacheRecord>;
    readonly incoming: ReadonlyArray<SessionListCacheRecord>;
}) => ReadonlyArray<SessionListCacheRecord>;
