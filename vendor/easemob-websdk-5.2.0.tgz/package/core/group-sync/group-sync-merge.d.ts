import type { JoinedGroupSnapshot } from '../../types/group';
import type { GroupSyncMergeInput } from './group-sync-types';
export declare const mergeJoinedGroupSnapshot: (input: GroupSyncMergeInput) => JoinedGroupSnapshot;
