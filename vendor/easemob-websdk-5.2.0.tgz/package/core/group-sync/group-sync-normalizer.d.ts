import type { JoinedGroupProtocolItem } from '../../protocol/joined-groups/types';
import type { JoinedGroupSummary } from '../../types/group';
export declare const normalizeJoinedGroupItem: (item: JoinedGroupProtocolItem) => JoinedGroupSummary | null;
export declare const normalizeJoinedGroupItems: (items: ReadonlyArray<JoinedGroupProtocolItem>) => ReadonlyArray<JoinedGroupSummary>;
