import type { GroupSyncControllerDependencies } from './group-sync-types';
export declare class GroupSyncController {
    private readonly dependencies;
    private running;
    constructor(dependencies: GroupSyncControllerDependencies);
    sync(): Promise<void>;
    cancel(): void;
    private runSync;
    private hasSameMembership;
    private buildRequest;
}
