import type { JoinedGroupsResponse } from '../../protocol/joined-groups/types';
export declare class GroupSyncSession {
    private readonly requestId;
    private readonly batches;
    private latestCursor;
    private done;
    private lastSyncFinishedTs;
    constructor(requestId: string);
    getResumeCursor(): string | undefined;
    push(response: JoinedGroupsResponse): {
        readonly done: boolean;
    };
    buildResult(): {
        readonly batches: ReadonlyArray<JoinedGroupsResponse>;
        readonly lastSyncFinishedTs?: number;
    };
}
