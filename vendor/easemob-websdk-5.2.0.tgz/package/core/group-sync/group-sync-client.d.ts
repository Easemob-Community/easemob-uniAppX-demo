import { SDKError } from '../../utils/errors';
import type { SharedSyncWebSocketSession } from '../sync/shared-sync-websocket-session';
import type { JoinedGroupsErrorDetail, JoinedGroupsRequest, JoinedGroupsResponse } from '../../protocol/joined-groups/types';
export declare const mapJoinedGroupsApiError: (detail: JoinedGroupsErrorDetail) => SDKError;
export declare class GroupSyncClient {
    private readonly codec;
    private readonly sharedSession;
    constructor(sharedSession: SharedSyncWebSocketSession);
    sync(options: {
        readonly urls: ReadonlyArray<string>;
        readonly request: JoinedGroupsRequest;
    }): Promise<{
        readonly batches: ReadonlyArray<JoinedGroupsResponse>;
        readonly lastSyncFinishedTs?: number;
    }>;
    cancel(): void;
    private syncWithSharedSession;
    private buildAttemptRequest;
}
