import { ConnectionError } from '../../utils/errors';
export type LoginDeadlineStatus = 'active' | 'provision-received' | 'expired' | 'disposed';
/** 单次首次登录共享的端到端时间预算。 */
export declare class LoginDeadline {
    readonly attemptId: number;
    readonly timeoutMs: number;
    private readonly now;
    private readonly expiresAt;
    private readonly timeoutPromise;
    private timeoutId;
    private status;
    constructor(attemptId: number, timeoutMs: number, now?: () => number);
    getStatus(): LoginDeadlineStatus;
    remainingMs(): number;
    clamp(stageTimeoutMs: number): number;
    race<T>(operation: Promise<T>): Promise<T>;
    markProvisionReceived(): boolean;
    expire(): void;
    dispose(): void;
    createTimeoutError(): ConnectionError;
    private clearTimer;
}
