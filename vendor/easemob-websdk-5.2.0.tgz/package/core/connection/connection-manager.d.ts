/**
 * 连接管理器
 *
 * 负责 WebSocket 连接管理、状态管理、事件处理
 * 参考：engineCore/connection.ts
 */
import { EventHub } from '../events/event-hub';
import { ConnectionStatus } from '../../types';
import type { TokenRenewalResult } from '../../types';
import { type SocketAdapter, type SocketLike } from '../../platform';
import type { LoginDeadline } from './login-deadline';
import { MsyncCodec } from '../../protocol/msync/codec';
import type { MessageReceiver } from '../message/message-receiver';
/**
 * 连接配置
 */
export interface ConnectionConfig {
    serverUrl: string;
    serverUrls?: ReadonlyArray<string>;
    userId: string;
    token: string;
    appKey: string;
    useCustomAttachmentUpload?: boolean;
    heartBeatWait?: number;
    autoReconnectNumMax?: number;
    connectTimeout?: number;
    useReplacedMessageContents?: boolean;
    useFixedDeviceId?: boolean;
    deviceId?: string;
    customDeviceName?: string;
    customOSPlatform?: number;
    uiKitVersion?: string;
    loginExtensionInfo?: string;
    serviceId?: string;
    socketAdapter?: SocketAdapter;
}
/**
 * 连接管理器
 */
export declare class ConnectionManager {
    private config;
    private serverUrls;
    private serverUrlIndex;
    private websocket;
    private connection;
    private provisionTimeoutId;
    private reconnectAttempts;
    private eventHub;
    private messageReceiver;
    private msyncCodec;
    private provisionPromise;
    private provisionResolve;
    private provisionReject;
    private queues;
    private currentQueueId;
    private currentQueue;
    private nextKey;
    private offlineMessageSyncing;
    private offlineMessageSyncLifecycleDispatched;
    private offlineMessageSyncLifecycleActive;
    private offlineMessageQueueNames;
    private offlineMessageReport;
    private readonly offlineMessageQueueReports;
    private readonly offlineMessageQueueCounts;
    private offlineMessageTotalCount;
    private readonly connectionRetry;
    private reconnectTimerId;
    private reconnectDelayReject;
    private reconnectTask;
    private pendingReconnectReason;
    private reconnectInProgress;
    private reconnectPaused;
    private terminalDisconnectError;
    private offlineRecoverPending;
    private isLoginPhase;
    private isLoggedIn;
    private hasEverConnected;
    private isOnline;
    private readonly heartbeatManager;
    private readonly internalHandlerId;
    private suppressNextCloseEvent;
    private readonly connectionEventNormalizer;
    private readonly socketAdapter;
    private socketDisposers;
    private inboundMessageQueue;
    private socketGeneration;
    private connectionAttemptGeneration;
    private activeConnectionAttemptCancel;
    private activeLoginDeadline;
    private tokenLifecycle;
    private tokenWillExpireTimerId;
    private tokenExpiredTimerId;
    constructor(config: ConnectionConfig, eventHub: EventHub);
    /**
     * 获取连接状态
     */
    getConnectionStatus(): ConnectionStatus;
    /**
     * 获取 WebSocket 实例（用于消息发送）
     */
    getWebSocket(): SocketLike | null;
    /**
     * 获取 MSync 编解码器（供消息模块复用）
     */
    getMsyncCodec(): MsyncCodec;
    /**
     * 获取客户端资源标识
     */
    getClientResource(): string;
    /**
     * 绑定消息接收器（用于处理下行消息）
     */
    setMessageReceiver(receiver: MessageReceiver): void;
    /**
     * 更新当前连接使用的 IM token。
     * Updates the IM token used by the current connection.
     */
    renewToken(token: string, expireAt: number): TokenRenewalResult;
    /**
     * 处理在线事件
     */
    handleOnline(): void;
    /**
     * 处理离线事件
     */
    handleOffline(): void;
    /**
     * 处理前台恢复事件
     */
    handleForeground(): Promise<void>;
    private resumeReconnect;
    private handleSendTimeout;
    private resetReconnectState;
    private getReconnectDiagnostic;
    private normalizeServerUrls;
    private pickNextServerUrl;
    private resolveEffectiveMaxAttempts;
    private isNonRetryableError;
    private isServerNormalClosePayload;
    private clearReconnectTimer;
    private resolveLoginStageTimeout;
    private isLoginDeadlineExpired;
    private requireLoginTimeoutError;
    private waitForReconnectDelay;
    private buildConnectionEventPayload;
    private dispatchConnectionEvent;
    private updateStatus;
    private clampTimerDelay;
    private clearTokenTimers;
    private setupTokenLifecycle;
    private setupTokenLifecycleFromProvision;
    private emitTokenWillExpire;
    private emitTokenExpired;
    private isTokenExpiredConnectionError;
    private handleTokenExpiredDisconnect;
    private startHeartbeat;
    private stopHeartbeat;
    private checkHeartbeatOnce;
    private sendHeartbeatPing;
    /**
     * 建立连接
     */
    connect(loginDeadline?: LoginDeadline): Promise<void>;
    private connectWithRetry;
    private connectOnce;
    private prepareForConnectAttempt;
    private handleConnectSuccess;
    private sendPostProvisionInitialSync;
    private triggerReconnect;
    /**
     * 为发送动作恢复当前连接。不可恢复状态会直接完成，由调用方继续按未连接处理。
     */
    recoverConnectionForSend(): Promise<void>;
    private startPendingReconnectIfNeeded;
    private handleDisconnection;
    private closeWebSocket;
    /**
     * 创建 WebSocket 连接
     */
    private createWebSocketConnection;
    private cancelActiveConnectionAttempt;
    /**
     * 处理 WebSocket 关闭
     */
    private handleWebSocketClose;
    private rejectProvisionAfterQueuedMessages;
    /**
     * 处理连接错误
     */
    private handleConnectionError;
    private handleTerminalConnectionError;
    /**
     * 处理 WebSocket 下行消息
     */
    private handleWebSocketMessage;
    /**
     * 发送 provision 并等待回包
     */
    private startProvision;
    /**
     * 处理 provision 回包
     */
    private handleProvisionMessage;
    private handleNoticeMessage;
    /**
     * 处理 UNREAD：对每个队列发起拉取
     */
    private handleUnreadMessage;
    private handleSyncMessage;
    /**
     * 根据 nextKey/isLast 续拉队列消息
     */
    private handleSyncQueueState;
    private resolveSyncQueueState;
    private handleLogoutMessage;
    private resolveStatisticDisconnectError;
    private resetProvisionHandlers;
    private rejectPendingProvision;
    /**
     * 断开连接
     */
    disconnect(): Promise<void>;
    /**
     * 销毁连接管理器
     */
    destroy(): void;
    private resolveSocketAdapter;
    private attachSocketListeners;
    private clearSocketListeners;
    private sendMsyncPayload;
    private sendBackqueue;
    private sendLastSession;
    private sendNextQueue;
    private removeQueueEntry;
    private startOfflineMessageSync;
    private finishOfflineMessageQueue;
    private isQueueInList;
    private isSelfQueue;
    private getQueueName;
    private getQueueResource;
    private getQueueId;
    private getQueueField;
    private isSameQueue;
    private resetSyncState;
}
