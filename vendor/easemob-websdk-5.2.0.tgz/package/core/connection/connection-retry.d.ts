/**
 * 连接重试逻辑
 *
 * 实现指数退避策略，最大 60 秒间隔
 */
/**
 * 重试配置
 */
export interface RetryConfig {
    maxAttempts?: number;
    initialDelay?: number;
    maxDelay?: number;
    backoffMultiplier?: number;
    randomSource?: () => number;
}
/**
 * 连接重试管理器
 */
export declare class ConnectionRetry {
    private config;
    private attemptCount;
    constructor(config?: RetryConfig);
    /**
     * 计算重试延迟（指数退避 + equal jitter）
     */
    getRetryDelay(): number;
    /**
     * 记录重试尝试
     */
    recordAttempt(): void;
    /**
     * 重置重试计数
     */
    reset(): void;
    /**
     * 检查是否应该重试
     */
    shouldRetry(): boolean;
    /**
     * 获取当前尝试次数
     */
    getAttemptCount(): number;
    /**
     * 等待重试延迟
     */
    waitForRetry(): Promise<void>;
}
