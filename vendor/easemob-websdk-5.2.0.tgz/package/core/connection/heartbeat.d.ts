/**
 * 心跳机制
 *
 * 实现 ping/pong 机制，超时处理
 * 参考：HEARTBEAT_INTERVAL = 30000ms
 */
import { type SocketLike } from '../../platform';
/**
 * 心跳配置
 */
export interface HeartbeatConfig {
    interval?: number;
    timeout?: number;
}
/**
 * 心跳管理器
 */
export declare class HeartbeatManager {
    private config;
    private websocket;
    private heartbeatTimer;
    private timeoutTimer;
    private lastPongTime;
    private onTimeoutCallback;
    private sendPing;
    private probeResolvers;
    private messageDisposer;
    private readonly handlePong;
    constructor(config?: HeartbeatConfig);
    /**
     * 启动心跳
     */
    start(websocket: SocketLike, onTimeout?: () => void, sendPing?: () => void): void;
    /**
     * 停止心跳
     */
    stop(): void;
    /**
     * 发送 ping
     */
    private sendPingInternal;
    /**
     * 处理 pong 消息
     */
    private extractMessageText;
    private parseJson;
    private static isRecord;
    private static readString;
    /**
     * 重置超时定时器
     */
    private resetTimeout;
    /**
     * 标记心跳成功
     */
    markAlive(): void;
    /**
     * 获取最后 pong 时间
     */
    getLastPongTime(): number;
    /**
     * 单次心跳探测
     */
    probeOnce(websocket: SocketLike, timeoutMs?: number): Promise<boolean>;
    private attachWebSocket;
    private resolveProbe;
    private removeProbeResolver;
}
