/**
 * 统一事件系统 EventHub
 */
import type { EventHandlerId, EventHandlerMap, EventName, EventPayloadMap } from '../../types/event-system';
export declare class EventHub {
    private handlers;
    addEventHandler(id: EventHandlerId, handlers: EventHandlerMap): void;
    removeEventHandler(id: EventHandlerId): void;
    dispatch<K extends EventName>(event: K, payload: EventPayloadMap[K]): void;
    private dispatchToHandlers;
    private invokeHandler;
    private reportHandlerError;
    private isPromiseLike;
}
