/**
 * 消息重试逻辑
 *
 * 存储失败消息、重连后重试、最多 3 次尝试
 */
import { Message } from '../../types';
/**
 * 失败消息存储
 */
export declare class MessageRetryManager {
    private failedMessages;
    private maxRetries;
    /**
     * 记录失败消息
     */
    recordFailedMessage(message: Message): void;
    /**
     * 获取所有失败消息
     */
    getFailedMessages(): Message[];
    /**
     * 重试失败消息
     */
    retryFailedMessages(sendMessageFn: (message: Message) => Promise<Message>): Promise<void>;
    /**
     * 清除失败消息
     */
    clearFailedMessages(): void;
    /**
     * 移除特定消息
     */
    removeFailedMessage(msgLocalId: string): void;
}
