import { type StreamMessage } from '../../types';
import { EventHub } from '../events/event-hub';
import { StreamMessageCache } from './stream-message-cache';
/**
 * 流式消息处理器：负责乱序缓存、顺序回调、兜底完成与错误终止。
 */
export declare class StreamMessageHandler {
    private readonly eventHub;
    private readonly cache;
    private readonly completedIds;
    constructor(eventHub: EventHub, cache?: StreamMessageCache);
    handle(message: StreamMessage): void;
    destroy(): void;
    private dispatchSequentialChunks;
    private handleFullChunk;
    private dispatchServerError;
    private buildDispatchMessage;
    private resolveMessageId;
    private resolveFullText;
    private resolveDeltaText;
    private markCompleted;
}
