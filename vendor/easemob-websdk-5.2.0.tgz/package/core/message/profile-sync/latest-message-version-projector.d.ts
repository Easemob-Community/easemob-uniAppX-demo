import type { MessageSnippet } from '../../../cache/cache-types';
import type { Message } from '../../../types';
export declare const projectLatestMessageVersions: (message: Message) => Pick<MessageSnippet, "userInfoUpdateTime" | "namecardUpdateTime">;
