import type { Message } from '../../../types';
export interface MessageProfileVersionSidecar {
    readonly userInfoUpdateTime?: number;
    readonly namecardUpdateTime?: number;
}
export declare const setMessageProfileVersionSidecar: (message: Message, sidecar: MessageProfileVersionSidecar) => void;
export declare const getMessageProfileVersionSidecar: (message: Message) => MessageProfileVersionSidecar | null;
export declare const clearMessageProfileVersionSidecar: (message: Message) => void;
export declare const copyMessageProfileVersionSidecar: (source: Message, target: Message) => void;
