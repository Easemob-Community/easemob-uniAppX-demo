export interface UserInfoHydrationTarget {
    readonly userId: string;
    readonly userInfoUpdateTime?: number;
}
export interface UserInfoHydrationQueueOptions {
    readonly windowMs: number;
    readonly batchSize: number;
    readonly maxConcurrency: number;
    readonly maxRetries: number;
    readonly onFlush: (targets: ReadonlyArray<UserInfoHydrationTarget>) => Promise<void> | void;
}
export declare class UserInfoHydrationQueue {
    private readonly options;
    private readonly pendingTargets;
    private readonly readyBatches;
    private timer;
    private activeCount;
    private generation;
    constructor(options: UserInfoHydrationQueueOptions);
    enqueue(userId: string, userInfoUpdateTime?: number): void;
    destroy(): void;
    getOptions(): Omit<UserInfoHydrationQueueOptions, 'onFlush'>;
    private schedule;
    private flush;
    private runReadyBatches;
    private mergeWaitingTarget;
    private mergeTarget;
    private resolveMaxVersion;
}
