export interface GroupNamecardHydratorOptions {
    readonly maxConcurrency: number;
}
export declare class GroupNamecardHydrator {
    private readonly options;
    constructor(options: GroupNamecardHydratorOptions);
    getOptions(): GroupNamecardHydratorOptions;
}
