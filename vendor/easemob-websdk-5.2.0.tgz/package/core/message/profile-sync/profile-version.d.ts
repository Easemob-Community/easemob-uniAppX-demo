export declare const MAX_PROFILE_VERSION_SECONDS = 2147483647;
export declare const normalizeProfileVersionSeconds: (value: unknown) => number | undefined;
export declare const normalizeProfileVersionFromTimestamp: (value: number | undefined) => number | undefined;
