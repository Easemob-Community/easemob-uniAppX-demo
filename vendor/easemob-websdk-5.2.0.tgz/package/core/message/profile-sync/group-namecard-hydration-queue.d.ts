export interface GroupNamecardHydrationTarget {
    readonly userId: string;
    readonly namecardUpdateTime?: number;
}
export interface GroupNamecardHydrationBatch {
    readonly groupId: string;
    readonly targets: ReadonlyArray<GroupNamecardHydrationTarget>;
}
export interface GroupNamecardHydrationQueueOptions {
    readonly windowMs: number;
    readonly minWindowMs: number;
    readonly maxBatchSize: number;
    readonly maxConcurrency: number;
    readonly onFlushGroup: (batch: GroupNamecardHydrationBatch) => Promise<void> | void;
}
export declare class GroupNamecardHydrationQueue {
    private readonly options;
    private readonly pendingGroups;
    private readonly readyGroups;
    private readonly pendingOrder;
    private readonly activeGroups;
    private timer;
    private activeGroupCount;
    constructor(options: GroupNamecardHydrationQueueOptions);
    enqueue(groupId: string, userId: string, namecardUpdateTime?: number): void;
    destroy(): void;
    getOptions(): Omit<GroupNamecardHydrationQueueOptions, 'onFlushGroup'>;
    private schedule;
    private flushWindow;
    private runReadyGroups;
    private resolveWindowDelay;
    private resolveMaxVersion;
}
