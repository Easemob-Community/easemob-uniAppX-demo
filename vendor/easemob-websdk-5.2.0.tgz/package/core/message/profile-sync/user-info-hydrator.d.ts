export interface UserInfoHydratorOptions {
    readonly batchSize: number;
}
export declare class UserInfoHydrator {
    private readonly options;
    constructor(options: UserInfoHydratorOptions);
    getOptions(): UserInfoHydratorOptions;
}
