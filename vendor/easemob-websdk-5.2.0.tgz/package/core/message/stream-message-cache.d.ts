import { type StreamMessage } from '../../types';
export interface StreamSession {
    msgId: string;
    startSeq: number | null;
    lastDispatchedSeq: number;
    fullText: string;
    completed: boolean;
    completedReason?: 'normal' | 'fallback_full' | 'timeout_error';
    chunksBySeq: Map<number, StreamMessage>;
    lastActivityTs: number;
}
export interface StreamMessageCacheOptions {
    readonly ttlMs?: number;
    readonly maxSessions?: number;
}
/**
 * 流式消息缓存：按 msgId 聚合分片，负责顺序扫描和状态推进。
 * 内置 TTL 和上限清理，防止未完成 session 内存泄漏。
 */
export declare class StreamMessageCache {
    private sessions;
    private readonly ttlMs;
    private readonly maxSessions;
    constructor(options?: StreamMessageCacheOptions);
    getOrCreate(msgId: string): StreamSession;
    get(msgId: string): StreamSession | undefined;
    addChunk(msgId: string, message: StreamMessage): {
        duplicate: boolean;
        session: StreamSession;
    };
    getSequentialChunks(msgId: string): ReadonlyArray<StreamMessage>;
    markDispatched(msgId: string, message: StreamMessage, fullText: string): void;
    markCompleted(msgId: string, reason: 'normal' | 'fallback_full' | 'timeout_error', fullText: string): void;
    clear(msgId: string): void;
    clearAll(): void;
    private evictStale;
    private evictOldest;
}
