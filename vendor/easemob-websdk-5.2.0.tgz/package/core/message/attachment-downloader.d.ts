import { type RequestAdapter } from '../../platform';
import type { Message, MessageAttachmentDownloadResult } from '../../types';
export declare class AttachmentDownloader {
    private readonly requestAdapter;
    constructor(requestAdapter?: RequestAdapter);
    private resolveMultiBodyTargets;
    private assertHasDownloadUrl;
    download(message: Message, timeoutMs?: number): Promise<MessageAttachmentDownloadResult | ReadonlyArray<MessageAttachmentDownloadResult>>;
    private downloadSingle;
}
