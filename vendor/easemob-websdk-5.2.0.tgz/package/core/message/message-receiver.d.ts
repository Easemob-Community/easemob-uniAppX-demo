/**
 * 消息接收器
 *
 * 负责处理下行 SYNC 消息：解析 ACK 与聊天消息，并派发事件。
 */
import { EventHub } from '../events/event-hub';
import type { Message } from '../../types';
import type { MsyncCodec, SyncDecodeResult } from '../../protocol/msync/codec';
import type { MessageSender } from './message-sender';
/**
 * 消息接收器
 */
export declare class MessageReceiver {
    private eventHub;
    private messageSender;
    private msyncCodec;
    private streamMessageHandler;
    private readonly messageContexts;
    private readonly recentMessageIds;
    private enableDeliveryReceipt;
    constructor(msyncCodec: MsyncCodec, messageSender: MessageSender, eventHub: EventHub);
    setDeliveryAckEnabled(enabled: boolean): void;
    rememberSentMessageContext(message: Message): void;
    /**
     * 处理 SYNC payload，分离 ACK 与聊天消息
     */
    handleSyncPayload(payload: Uint8Array): SyncDecodeResult | null;
    /**
     * 处理 ACK 回包
     */
    private handleAck;
    /**
     * 派发消息事件
     */
    private dispatchMessage;
    private sendDeliveryAckIfNeeded;
    private handleNotifies;
    private handleUserInfoNotify;
    private handleContactNotify;
    private handlePresenceNotify;
    private handleGroupNotify;
    private handleChatRoomNotify;
    private handleReactionNotify;
    private handleConversationNotify;
    private handleMultiDeviceNotify;
    private toMessageReceiptPayload;
    private handleMessageDeliveredNotify;
    private handleMessageRecalledNotify;
    private handleMessageUpdatedNotify;
    private normalizeUpdatedMessageBody;
    private handleChatThreadNotify;
    private normalizePresenceStatus;
    /**
     * 销毁接收器
     */
    destroy(): void;
    private rememberMessageContext;
    private resolveMessageReceiptContext;
    private resolveMessageContextId;
    private resolveMessageConversationContext;
    private resolveReactionConversationContext;
    private normalizeReactionList;
    private normalizeReactionOperations;
    private normalizeTimestamp;
}
