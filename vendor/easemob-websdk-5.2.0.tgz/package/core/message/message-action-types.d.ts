import type { ChatConversationType } from '../../types/chat-manager';
import type { JoinChatRoomInfo } from '../../types/chatroom';
import type { Message, MessageBody } from '../../types';
export interface MessageActionRequest {
    readonly kind: 'clearConversationUnreadMessageCount' | 'clearAllConversationUnreadMessageCount' | 'sendMessageReadReceipts' | 'recall' | 'update' | 'deliveryAck';
    readonly conversationId: string;
    readonly conversationType: ChatConversationType;
    readonly messageId?: string;
    readonly messageIds?: ReadonlyArray<string>;
    readonly sendToPeer?: boolean;
    readonly clearAllUnreadMessageCount?: boolean;
    readonly body?: MessageBody;
    readonly messageType?: Message['type'];
    readonly ext?: Record<string, unknown>;
}
export interface ActionAckResult {
    readonly protocolId: string;
    readonly serverId: string;
    readonly statusCode: number;
    readonly reason?: string;
    readonly chatRoomInfo?: JoinChatRoomInfo;
}
