import type { Message } from '../../types';
import type { MessageTranslationResult } from '../../types/chat-manager';
/** 仅为本次发送准备消息快照，不回填调用方持有的消息对象。 */
export declare const prepareTextTranslation: (message: Message, translate: (params: {
    readonly text: string;
    readonly targetLanguages: ReadonlyArray<string>;
}) => Promise<MessageTranslationResult>) => Promise<Message>;
