/** 普通消息最近 ID 的有界去重器。 */
export declare class RecentMessageIdDeduper {
    private readonly limit;
    private readonly seenIds;
    private readonly orderedIds;
    constructor(limit?: number);
    /** 返回 true 表示 ID 已在当前窗口内出现。 */
    checkAndRecord(messageId: string): boolean;
    clear(): void;
    size(): number;
}
