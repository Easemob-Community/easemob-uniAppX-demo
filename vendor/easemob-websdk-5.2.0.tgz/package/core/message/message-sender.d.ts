/**
 * 消息发送器
 *
 * 接收 Message 对象，发送消息、等待 ACK、错误处理
 * 参考：engineCore/mSync.ts
 */
import type { Message, SendMessageOptions } from '../../types';
import { MsyncCodec } from '../../protocol/msync/codec';
import { EventHub } from '../events/event-hub';
import { AttachmentUploader } from '../../upload/attachment-uploader';
import { type SocketLike } from '../../platform';
import type { ActionAckResult, MessageActionRequest } from './message-action-types';
import type { ChatRoomOperationRequest } from './chatroom-operation-types';
import type { JoinChatRoomInfo } from '../../types/chatroom';
/**
 * 消息发送器
 */
export declare class MessageSender {
    private websocket;
    private pendingMessages;
    private ackTimeout;
    private eventHub;
    private msyncCodec;
    private attachmentUploader;
    private messageReportCount;
    private chatRoomReportCount;
    private messageReportSaturated;
    private chatRoomReportSaturated;
    constructor(msyncCodec: MsyncCodec, websocket: SocketLike | null, eventHub: EventHub, attachmentUploader?: AttachmentUploader);
    updateAuthToken(token: string): void;
    /**
     * 发送一条消息。调用方看到的是这一个方法，实际分成准备和等待回执两段。
     *
     * 1. 流式消息，或 WebSocket 未连接：直接失败，不上传。
     * 2. 合并消息先打成一个文件。其他类型跳过。
     * 3. `prepareMessage` 上传本地附件，并把远端地址写回消息体。复合消息在这里按段串行上传。
     * 4. 调用 `onSending`。这时消息还没写到网上。
     * 5. `doSendMessage` 编码并写出，然后停在 Promise 上，直到下面三者之一：
     *    - `handleAck`：服务端接受，补上 `msgServerId`，清本地文件，再 `onSuccess`。
     *    - `handleSendError`：服务端拒绝或连接中断。
     *    - 超时：一直没有回执。
     * 6. 第 3 步之后的失败也进下面的 catch。`onFailed` 拿到的是上传后的消息，
     *    已成功的附件带远端地址，再次发送时会跳过。
     */
    sendMessage(message: Message, options?: SendMessageOptions): Promise<Message>;
    sendAction(action: MessageActionRequest, createAckError?: (statusCode: number, reason?: string) => Error): Promise<ActionAckResult>;
    sendChatRoomOperation(request: ChatRoomOperationRequest, createAckError?: (statusCode: number, reason?: string) => Error): Promise<ActionAckResult>;
    /**
     * 把准备好的消息写到 WebSocket，并等待服务端回执。
     * 这里先登记待确认消息，再发送。回执到达时用 protocolId 找回这条登记，
     * 由 `handleAck` 或 `handleSendError` 结束这个 Promise。
     */
    private doSendMessage;
    private sendProtocolPayload;
    private prepareCombineMessage;
    /**
     * 服务端接受了这条消息。用 protocolId 找到 `doSendMessage` 登记的待确认消息，
     * 写入服务端 id，清掉本地附件，再 resolve，发送 Promise 才返回。
     */
    handleAck(protocolId: string, msgServerId?: string, replacedMessage?: Message, chatRoomInfo?: JoinChatRoomInfo): void;
    private resolveReplacedMessage;
    /**
     * 消息已经写出，但服务端拒绝或连接中断。
     * reject 之后回到 `sendMessage` 的 catch，由那里回调 `onFailed`。
     */
    handleSendError(protocolId: string, error: Error): void;
    handleAckFailure(protocolId: string, statusCode: number, reason: string | undefined, error: Error): void;
    /**
     * 更新 WebSocket 实例
     */
    setWebSocket(websocket: SocketLike | null): void;
    /**
     * 销毁消息发送器
     */
    destroy(): void;
    private createPendingDataReport;
    private finishPendingDataReport;
}
