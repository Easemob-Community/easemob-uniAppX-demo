import type { RequestAdapter } from '../../platform';
import type { DownloadCombineMessageParams, Message } from '../../types';
export declare class CombineMessageDownloader {
    private readonly requestAdapter;
    constructor(requestAdapter?: RequestAdapter);
    downloadAndParse(options: DownloadCombineMessageParams): Promise<ReadonlyArray<Message>>;
}
