import type { GroupNamecardCacheRecord, UserInfoSummary } from '../../cache/cache-types';
import type { GroupUserInfo } from '../../types/group';
import type { UserInfo } from '../../types/user-info';
interface GroupUserInfoCache {
    getRuntimeUserInfo?(userId: string, updateAccess: boolean): UserInfo | null;
    getUserInfoSummaries?(userIds: ReadonlyArray<string>, updateAccess: boolean): ReadonlyArray<UserInfoSummary>;
    getGroupNamecard?(groupId: string, userId: string, updateAccess: boolean): GroupNamecardCacheRecord | null;
}
export interface GroupUserInfoContext {
    readonly groupId: string;
    readonly user: UserInfo;
}
export interface GroupUserInfoFetchParams {
    readonly userIds: ReadonlyArray<string>;
}
export interface ResolveGroupUserInfoContextsOptions {
    readonly contexts: ReadonlyArray<GroupUserInfoContext>;
    readonly includeNameCard: boolean;
    readonly cacheManager: GroupUserInfoCache | null;
    readonly fetchUserInfos?: (params: GroupUserInfoFetchParams) => Promise<ReadonlyArray<UserInfo>>;
    readonly hydrateGroupNamecards?: (groupId: string, userIds: ReadonlyArray<string>) => Promise<void>;
}
export interface GroupUserInfoContextsResolution {
    readonly usersByContextKey: ReadonlyMap<string, GroupUserInfo>;
    readonly fetchedUserInfos: ReadonlyArray<UserInfo>;
    readonly missingUserIds: ReadonlyArray<string>;
}
export interface ResolveGroupUserInfoMapOptions extends Omit<ResolveGroupUserInfoContextsOptions, 'contexts'> {
    readonly groupId: string;
    readonly users: ReadonlyArray<UserInfo>;
}
export interface GroupUserInfoMapResolution {
    readonly usersById: ReadonlyMap<string, GroupUserInfo>;
    readonly fetchedUserInfos: ReadonlyArray<UserInfo>;
    readonly missingUserIds: ReadonlyArray<string>;
}
export declare const getGroupUserInfoContextKey: (groupId: string, userId: string) => string;
export declare const resolveGroupUserInfoContexts: (options: ResolveGroupUserInfoContextsOptions) => Promise<GroupUserInfoContextsResolution>;
export declare const resolveGroupUserInfoMap: (options: ResolveGroupUserInfoMapOptions) => Promise<GroupUserInfoMapResolution>;
export {};
