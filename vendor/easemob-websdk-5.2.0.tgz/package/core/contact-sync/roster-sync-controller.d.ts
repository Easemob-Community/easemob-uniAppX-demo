/**
 * 联系人同步控制器
 */
import type { ContactSyncContextState, ContactSyncDependencies, ContactSyncDecisionResult } from './roster-sync-types';
export declare const decideContactSync: (options: {
    metadata?: {
        readonly version: string;
        readonly requiresSync: boolean;
    };
    metadataFailed?: boolean;
    state: ContactSyncContextState;
}) => ContactSyncDecisionResult;
export declare class RosterSyncController {
    private readonly dependencies;
    private running;
    constructor(dependencies: ContactSyncDependencies);
    sync(): Promise<void>;
    cancel(): void;
    private runSync;
}
