/**
 * 联系人同步 websocket 客户端
 */
import type { SharedSyncWebSocketSession } from '../sync/shared-sync-websocket-session';
import type { RosterRequest } from '../../protocol/roster/types';
export declare class RosterSyncClient {
    private readonly codec;
    private readonly sharedSession;
    constructor(sharedSession: SharedSyncWebSocketSession);
    sync(options: {
        urls: ReadonlyArray<string>;
        request: RosterRequest;
    }): Promise<{
        readonly mode: 'full' | 'incremental';
        readonly version: string;
        readonly pages: ReadonlyArray<import('../../protocol/roster/types').RosterResponse>;
    }>;
    cancel(): void;
    private syncWithSharedSession;
    private buildAttemptRequest;
}
