import type { ContactRosterEventPayload } from '../../types/contact';
export declare const setContactRosterVersionSidecar: (payload: ContactRosterEventPayload, rosterVersion: string | undefined) => void;
export declare const getContactRosterVersionSidecar: (payload: ContactRosterEventPayload) => string | undefined;
