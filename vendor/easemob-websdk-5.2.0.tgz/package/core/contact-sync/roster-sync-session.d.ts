/**
 * 联系人同步分页会话
 */
import type { RosterResponse } from '../../protocol/roster/types';
export declare class RosterSyncSession {
    private readonly requestId;
    private readonly pages;
    private responseType;
    private version;
    private nextCursor;
    private pageCount;
    private completed;
    constructor(requestId: string);
    push(page: RosterResponse): {
        readonly done: boolean;
        readonly nextCursor: number;
        readonly pageCount: number;
    };
    getNextCursor(): number;
    getPageCount(): number;
    hasPages(): boolean;
    isCompleted(): boolean;
    buildResult(): {
        readonly mode: 'full' | 'incremental';
        readonly version: string;
        readonly pages: ReadonlyArray<RosterResponse>;
    };
}
