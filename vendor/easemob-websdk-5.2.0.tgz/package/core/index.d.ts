/**
 * 核心模块集成
 *
 * 集成连接和消息组件
 */
import type { LoginDeadline } from './connection/login-deadline';
import { EventHub } from './events/event-hub';
import type { ConnectionStatus, Message, DownloadCombineMessageParams, MessageAttachmentDownloadResult, SendMessageOptions, TokenRenewalResult } from '../types';
import type { PlatformFactoryResult, SocketAdapter } from '../platform';
import type { MessageActionRequest, ActionAckResult } from './message/message-action-types';
import type { ChatRoomOperationRequest } from './message/chatroom-operation-types';
/**
 * 核心 SDK 类
 */
export declare class CoreSDK {
    private eventHub;
    private connectionManager;
    private messageSender;
    private messageReceiver;
    private combineMessageDownloader;
    private attachmentDownloader;
    private readonly platformAdapter;
    private runtimeEventBridge;
    private readonly handleOnline;
    private readonly handleOffline;
    private readonly handleForegroundChange;
    constructor(config: {
        serverUrl: string;
        serverUrls?: ReadonlyArray<string>;
        userId: string;
        token: string;
        appKey: string;
        restBaseUrl?: string;
        useCustomAttachmentUpload?: boolean;
        enableMd5Check?: boolean;
        enableMultipartUpload?: boolean;
        heartBeatWait?: number;
        autoReconnectNumMax?: number;
        useReplacedMessageContents?: boolean;
        useFixedDeviceId?: boolean;
        deviceId?: string;
        customDeviceName?: string;
        customOSPlatform?: number;
        uiKitVersion?: string;
        loginExtensionInfo?: string;
        serviceId?: string;
        platformAdapter?: PlatformFactoryResult;
        socketAdapter?: SocketAdapter;
        enableDeliveryReceipt?: boolean;
    }, eventHub: EventHub);
    /**
     * 设置事件处理器
     */
    private setupEventHandlers;
    private registerNetworkListeners;
    private unregisterNetworkListeners;
    private resolveRuntimeAdapter;
    private createBrowserRuntimeAdapter;
    /**
     * 连接
     */
    connect(loginDeadline?: LoginDeadline): Promise<void>;
    /**
     * 断开连接
     */
    disconnect(): Promise<void>;
    /**
     * 获取连接状态
     */
    getConnectionStatus(): ConnectionStatus;
    /**
     * @internal
     * [zh-CN] 为发送动作创建或复用连接恢复任务。
     * [en-US] Creates or reuses a connection recovery task for message sending.
     */
    recoverConnectionForSend(): Promise<void>;
    /**
     * 获取客户端资源标识
     */
    getClientResource(): string;
    /**
     * 更新当前连接与发送链路使用的 IM token。
     * Updates the IM token used by connection and send pipeline.
     */
    renewToken(token: string, expireAt: number): TokenRenewalResult;
    /**
     * 发送消息
     */
    sendMessage(message: Message, options?: SendMessageOptions): Promise<Message>;
    sendMessageAction(action: MessageActionRequest, createAckError?: (statusCode: number, reason?: string) => Error): Promise<ActionAckResult>;
    sendChatRoomOperation(request: ChatRoomOperationRequest, createAckError?: (statusCode: number, reason?: string) => Error): Promise<ActionAckResult>;
    /**
     * 下载并解析合并消息详情
     */
    downloadAndParseCombineMessage(options: DownloadCombineMessageParams): Promise<ReadonlyArray<Message>>;
    downloadAttachment(message: Message, timeoutMs?: number): Promise<MessageAttachmentDownloadResult | ReadonlyArray<MessageAttachmentDownloadResult>>;
    decodeServerMessageMeta(metaPayload: Uint8Array): Message | null;
    /**
     * 销毁
     */
    destroy(): void;
}
