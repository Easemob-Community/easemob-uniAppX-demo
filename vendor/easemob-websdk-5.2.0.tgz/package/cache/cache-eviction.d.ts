/**
 * 缓存淘汰工具
 */
export interface EvictionResult<T> {
    readonly kept: ReadonlyArray<T>;
    readonly removed: ReadonlyArray<T>;
}
export declare const removeExpired: <T extends {
    lastUpdate: number;
}>(items: ReadonlyArray<T>, // 待处理列表
ttlMs: number, // TTL 毫秒
now: number) => EvictionResult<T>;
export declare const evictByLru: <T extends {
    lastAccess: number;
}>(items: ReadonlyArray<T>, // 待处理列表
removeCount: number) => EvictionResult<T>;
