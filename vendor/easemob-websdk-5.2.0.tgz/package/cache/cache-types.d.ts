/**
 * 缓存模块类型定义
 */
import type { ConversationIdentifier, ConversationItem, ConversationMark, ConversationType } from '../types/conversation';
import type { Message, MessageDirect, MessageModifiedInfo } from '../types';
import type { Sender } from '../types/sender';
import type { JoinedGroupSnapshotMeta, JoinedGroupSummary } from '../types/group';
/**
 * [zh-CN] 缓存中的消息摘要。
 * [en-US] Message snippet stored in the cache.
 */
export interface MessageSnippet extends Readonly<Partial<Omit<Message, 'type' | 'body'>>> {
    /** [zh-CN] 真实发送者 ID；旧缓存可能缺失。 [en-US] Actual sender ID; may be absent in legacy caches. */
    readonly from?: string;
    /** [zh-CN] 真实接收者 ID；旧缓存可能缺失。 [en-US] Actual recipient ID; may be absent in legacy caches. */
    readonly to?: string;
    /** [zh-CN] 真实发送者资料。 [en-US] Actual sender information. */
    readonly sender?: Sender;
    /** [zh-CN] 消息收发方向。 [en-US] Message direction. */
    readonly direct?: MessageDirect;
    /** [zh-CN] 消息 ID。 [en-US] Message ID. */
    readonly msgId: string;
    /** [zh-CN] 消息类型。 [en-US] Message type. */
    readonly type: string;
    /** [zh-CN] 消息体摘要。复合消息时这里直接是分段数组。 [en-US] Message body snippet. For a multi_body message, this is the segment array. */
    readonly body: Record<string, unknown> | ReadonlyArray<Record<string, unknown>>;
    /** [zh-CN] 消息扩展字段，与 onMessage 的 ext 一致；旧缓存可能缺失。 [en-US] Message extension fields, matching onMessage ext; may be absent in legacy caches. */
    readonly ext?: Record<string, unknown>;
    /** [zh-CN] 消息时间戳，单位毫秒。 [en-US] Message timestamp in milliseconds. */
    readonly timestamp: number;
    /** [zh-CN] 用户资料版本，单位秒。 [en-US] User profile version in seconds. */
    readonly userInfoUpdateTime?: number;
    /** [zh-CN] 群名片版本，单位秒。 [en-US] Group name card version in seconds. */
    readonly namecardUpdateTime?: number;
    /** [zh-CN] 消息修改信息。 [en-US] Message modification information. */
    readonly modifiedInfo?: MessageModifiedInfo;
}
/**
 * [zh-CN] 缓存中的会话摘要。
 * [en-US] Conversation summary stored in the cache.
 */
export interface ConversationSummary {
    /** [zh-CN] 会话 ID。 [en-US] Conversation ID. */
    readonly conversationId: string;
    /** [zh-CN] 会话类型。 [en-US] Conversation type. */
    readonly type: ConversationType;
    /** [zh-CN] 最后一条消息摘要。 [en-US] Last message snippet. */
    readonly lastMessage: MessageSnippet | null;
    /** [zh-CN] 未读消息数。 [en-US] Unread message count. */
    readonly unreadCount: number;
    /** [zh-CN] 是否置顶。 [en-US] Whether the conversation is pinned. */
    readonly isPinned?: boolean;
    /** [zh-CN] 置顶时间戳，单位毫秒。 [en-US] Pin timestamp in milliseconds. */
    readonly pinnedTime?: number;
    /** [zh-CN] 会话标记。 [en-US] Conversation marks. */
    readonly marks: ReadonlyArray<ConversationMark>;
    /** [zh-CN] 最近访问时间戳，单位毫秒。 [en-US] Last access timestamp in milliseconds. */
    readonly lastAccess: number;
    /** [zh-CN] 最近更新时间戳，单位毫秒。 [en-US] Last update timestamp in milliseconds. */
    readonly lastUpdate: number;
}
/**
 * [zh-CN] 缓存中的用户资料摘要。
 * [en-US] User profile summary stored in the cache.
 */
export interface UserInfoSummary {
    /** [zh-CN] 用户 ID。 [en-US] User ID. */
    readonly userId: string;
    /** [zh-CN] 用户昵称。 [en-US] User nickname. */
    readonly nickname?: string;
    /** [zh-CN] 用户头像 URL。 [en-US] User avatar URL. */
    readonly avatarUrl?: string;
    /** [zh-CN] 用户签名。 [en-US] User signature. */
    readonly sign?: string;
    /** [zh-CN] 用户扩展信息。 [en-US] User extension data. */
    readonly ext?: string;
    /** [zh-CN] 用户资料版本，单位秒。 [en-US] User profile version in seconds. */
    readonly userInfoUpdateTime?: number;
    /** [zh-CN] 最近同步时间戳，单位毫秒。 [en-US] Last synchronization timestamp in milliseconds. */
    readonly lastSyncAt?: number;
    /** [zh-CN] 最近访问时间戳，单位毫秒。 [en-US] Last access timestamp in milliseconds. */
    readonly lastAccess: number;
    /** [zh-CN] 最近更新时间戳，单位毫秒。 [en-US] Last update timestamp in milliseconds. */
    readonly lastUpdate: number;
}
/**
 * [zh-CN] 缓存中的群名片记录。
 * [en-US] Group name card record stored in the cache.
 */
export interface GroupNamecardCacheRecord {
    /** [zh-CN] 群组 ID。 [en-US] Group ID. */
    readonly groupId: string;
    /** [zh-CN] 用户 ID。 [en-US] User ID. */
    readonly userId: string;
    /** [zh-CN] 群名片。 [en-US] Group name card. */
    readonly namecard: string;
    /** [zh-CN] 群名片版本，单位秒。 [en-US] Group name card version in seconds. */
    readonly namecardUpdateTime?: number;
    /** [zh-CN] 最近同步时间戳，单位毫秒。 [en-US] Last synchronization timestamp in milliseconds. */
    readonly lastSyncAt?: number;
    /** [zh-CN] 最近访问时间戳，单位毫秒。 [en-US] Last access timestamp in milliseconds. */
    readonly lastAccess: number;
    /** [zh-CN] 最近更新时间戳，单位毫秒。 [en-US] Last update timestamp in milliseconds. */
    readonly lastUpdate: number;
}
export type ContactCacheIntegrity = 'complete' | 'incomplete';
export type ContactCacheIncompleteReason = 'quota_exceeded' | 'user_info_missing' | 'corrupted' | 'first_sync_pending' | 'manual_reset';
export type ContactVersionSource = 'metadata' | 'sync_page' | 'roster_notice';
export type ContactSyncMode = 'full' | 'incremental' | 'skipped';
export interface ContactRelationRecord {
    readonly userId: string;
    readonly remark: string;
    readonly sign: string;
    readonly addTs: number;
    readonly updatedAt: number;
    readonly metadataUpdatedAt: number;
}
export interface ContactVersionState {
    readonly version: string;
    readonly lastVersionCheckAt: number;
    readonly lastVersionSource: ContactVersionSource;
}
export interface ContactCacheMeta {
    readonly cacheIntegrity: ContactCacheIntegrity;
    readonly reason?: ContactCacheIncompleteReason;
    readonly lastSyncTs: number;
    readonly lastSuccessfulVersion: string;
    readonly lastSyncMode: ContactSyncMode;
}
/**
 * [zh-CN] 缓存元信息。
 * [en-US] Cache metadata.
 */
export interface CacheMetadata {
    /** [zh-CN] 缓存结构版本号。 [en-US] Cache schema version. */
    readonly schemaVersion: number;
    /** [zh-CN] 最近一次落盘时间戳，单位毫秒。 [en-US] Last flush timestamp in milliseconds. */
    readonly lastFlush: number;
}
/**
 * [zh-CN] 本地缓存配置。
 * [en-US] Local cache configuration.
 */
export interface CacheConfig {
    /** [zh-CN] 缓存结构版本号。 [en-US] Cache schema version. */
    readonly schemaVersion: number;
    /** [zh-CN] 缓存有效期，单位秒。 [en-US] Cache time to live in seconds. */
    readonly ttlSeconds: number;
    /** [zh-CN] 批量落盘间隔，单位毫秒。 [en-US] Batched flush interval in milliseconds. */
    readonly flushIntervalMs: number;
    /** [zh-CN] 用户资料缓存最大条数。 [en-US] Maximum number of cached user profiles. */
    readonly maxUserInfoCount: number;
    /** [zh-CN] 群名片缓存最大条数。 [en-US] Maximum number of cached group name cards. */
    readonly maxGroupNamecardCount?: number;
    /** [zh-CN] 会话缓存最大条数。 [en-US] Maximum number of cached conversations. */
    readonly maxConversations?: number;
}
/**
 * [zh-CN] 会话列表更新原因。
 * - `conversation`：会话列表同步或会话缓存基线变化；
 * - `profile`：好友或用户资料补全导致会话展示信息（例如，昵称或头像）变化；
 * - `message`：收发消息导致最后一条消息、未读数或会话排序发生变化；
 * - `local`：触发了本地会话操作，如置顶、标记、删除会话等。
 * [en-US] The reason for a conversation list update.
 * - `conversation`: Indicates a conversation list synchronization or changes to the baseline cache.
 * - `profile`: Indicates that friend or user profile completion has updated the displayed information (e.g., nicknames or avatars) of the conversation.
 * - `message`: Indicates that sending or receiving messages has updated the last message, unread count, or conversation sorting.
 * - `local`: Indicates local conversation actions, such as pinning, marking, or deleting a conversation.
 */
export type ConversationListUpdateReason = 'conversation' | 'profile' | 'message' | 'local';
/**
 * [zh-CN] 会话列表更新补丁。简单的 UI 渲染可以直接使用 `ConversationListUpdatePayload.items`；只有在需要保留业务层自定义本地字段，或进行精细化数据合并时，才需要读取该补丁。
 * [en-US] The patch for a conversation list update. Simple UIs can directly use `ConversationListUpdatePayload.items` for rendering; read this patch only when you need to preserve custom local fields or perform fine-grained data merging.
 */
export interface ConversationListUpdatePatch {
    /**
     * [zh-CN] 是否为一次整体基线重置。为 `true` 时，表示 SDK 重新建立或替换了会话列表基线（例如登录后加载缓存、服务端全量同步、回退到全量刷新等）。业务层若自行维护带本地自定义字段的列表，此时应将 `items` 视为唯一的权威快照，并按会话 Key 重新挂载本地字段；简单 UI 直接使用 `items` 渲染即可。
     * [en-US] Whether this update is a full baseline reset. When `true`, it indicates that the SDK has rebuilt or replaced the conversation list baseline (e.g., loading cache upon login, full server synchronization, or falling back to a full refresh). If your app maintains a local list with custom fields, you should treat `items` as the current authoritative snapshot and re-bind your local fields by conversation key; simple UIs can directly use `items` for rendering.
     */
    readonly reset: boolean;
    /** [zh-CN] 本次新增或 SDK 字段发生变化的会话。 [en-US] Conversations inserted or changed in SDK-owned fields during this update. */
    readonly upserted: ReadonlyArray<ConversationItem>;
    /** [zh-CN] 本次移除的会话标识。 [en-US] Conversation identifiers removed in this update. */
    readonly removed: ReadonlyArray<ConversationIdentifier>;
    /** [zh-CN] 本次受影响的会话 key，格式为 `${conversationType}:${conversationId}`。 [en-US] Affected conversation keys in `${conversationType}:${conversationId}` format. */
    readonly affectedKeys: ReadonlyArray<string>;
    /**
     * [zh-CN] 本次是否改变了会话列表顺序。可能只有排序变化而没有 `upserted` 内容变化，例如置顶、最后消息时间或服务端排序基线变化。按补丁合并的业务在该值为 `true` 时，应按 `items` 中的顺序重排本地列表；直接使用 `items` 的业务无需额外处理。
     * [en-US] Whether the conversation-list order changed. The order may change even when `upserted` is empty, for example due to pinning, last-message time, or server ordering baseline changes. Patch-merging consumers should reorder their local list according to `items` when this is `true`; consumers using `items` directly need no extra handling.
     */
    readonly orderChanged: boolean;
}
/**
 * [zh-CN] `onConversationListUpdate` 事件载荷。`items` 始终是 SDK 当前完整且已排序的 `ConversationItem` 快照；`patch` 用于业务按增量合并并保留自定义本地字段。
 * [en-US] Payload of `onConversationListUpdate`. `items` is always the SDK's current full, ordered `ConversationItem` snapshot; `patch` helps apps merge incrementally while preserving custom local fields.
 */
export interface ConversationListUpdatePayload {
    /** [zh-CN] 会话列表快照版本号，每次有效派发递增，可用于忽略旧事件。 [en-US] Conversation list snapshot version, incremented for each effective dispatch and useful for ignoring stale events. */
    readonly version: number;
    /** [zh-CN] 当前完整且已排序的会话列表快照。简单 UI 推荐直接用该字段刷新列表。 [en-US] Current full and ordered conversation list snapshot. Simple UIs are recommended to render this field directly. */
    readonly items: ReadonlyArray<ConversationItem>;
    /** [zh-CN] 本次列表更新原因。 [en-US] Reason for this list update. */
    readonly reason: ConversationListUpdateReason;
    /** [zh-CN] 本次变化补丁，便于业务保留本地字段。 [en-US] Patch for this update, useful for preserving app-local fields. */
    readonly patch: ConversationListUpdatePatch;
}
/**
 * [zh-CN] 通用缓存落盘结构。
 * [en-US] Generic persisted cache structure.
 */
export interface CacheDump<T> {
    /** [zh-CN] 缓存项列表。 [en-US] Cached items. */
    readonly items: ReadonlyArray<T>;
}
export interface SessionListCacheRecord extends ConversationItem {
    readonly updatedAt: number;
}
export interface SessionListCheckpoint {
    readonly lastSyncTime: number;
    readonly lastSyncFinishedTs: number;
    readonly sessionsLastSyncTs: number;
    readonly lastSuccessfulAt: number;
}
export interface SessionListStorageRecord {
    readonly items: ReadonlyArray<SessionListCacheRecord>;
    readonly checkpoint?: SessionListCheckpoint;
}
export interface JoinedGroupPreviewStorageRecord {
    readonly items: ReadonlyArray<JoinedGroupSummary>;
    readonly meta: JoinedGroupSnapshotMeta;
}
export interface SessionListCapabilityState {
    readonly status: 'unknown' | 'available' | 'unsupported' | 'unconfigured';
    readonly determinedAt?: number;
    readonly reason?: string;
}
