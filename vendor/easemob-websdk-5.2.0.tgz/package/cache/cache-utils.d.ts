/**
 * 缓存工具方法
 */
export { isStorageQuotaExceededError as isQuotaExceededError } from '../utils/storage-error';
export declare const isRecord: (value: unknown) => value is Record<string, unknown>;
export declare const safeJsonParse: <T>(raw: string | null, fallback: T) => T;
export declare const safeJsonStringify: (value: unknown) => string | null;
