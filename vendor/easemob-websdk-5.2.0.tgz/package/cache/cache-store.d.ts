/**
 * 跨平台键值存储访问封装
 */
import type { StorageAdapter } from '../platform';
import type { CacheCryptoAdapter } from './cache-crypto';
export declare class CacheStore {
    private readonly storage;
    private readonly cryptoAdapter;
    constructor(cryptoAdapter?: CacheCryptoAdapter, storageAdapter?: StorageAdapter);
    private static createLocalStorageAdapter;
    static checkAvailable(): boolean;
    readAsync<T>(key: string, fallback: T): Promise<T>;
    writeAsync(key: string, value: unknown): Promise<void>;
    /**
     * Writes a cache record and propagates serialization/storage failures to the caller.
     * 写入缓存记录，并将序列化或存储失败抛给调用方。
     */
    writeStrictAsync(key: string, value: unknown): Promise<void>;
    private writeInternal;
    remove(key: string): Promise<void>;
}
