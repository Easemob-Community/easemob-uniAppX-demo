/**
 * 联系人关系缓存
 */
import type { ContactCacheIncompleteReason, ContactCacheMeta, ContactRelationRecord, ContactSyncMode, ContactVersionState, UserInfoSummary } from './cache-types';
import type { ContactSnapshot, ContactSyncSource } from '../types/contact';
export declare class ContactCache {
    private readonly items;
    private versionState;
    private meta;
    load(rawItems: ReadonlyArray<ContactRelationRecord>, versionState?: ContactVersionState | null, meta?: ContactCacheMeta | null): void;
    getAll(): ReadonlyArray<ContactRelationRecord>;
    getVersionState(): ContactVersionState;
    getMeta(): ContactCacheMeta;
    getUserIds(): ReadonlyArray<string>;
    replaceAll(items: ReadonlyArray<ContactRelationRecord>): void;
    upsert(items: ReadonlyArray<ContactRelationRecord>): void;
    addByNotice(userId: string, updatedAt: number): boolean;
    remove(userId: string): boolean;
    updateRemark(userId: string, remark: string, updatedAt: number): boolean;
    setVersionState(state: ContactVersionState): void;
    updateVersionFromNotice(version: string, updatedAt: number): boolean;
    setMeta(meta: ContactCacheMeta): void;
    updateMeta(options: {
        cacheIntegrity: 'complete' | 'incomplete';
        reason?: ContactCacheIncompleteReason;
        lastSyncTs?: number;
        lastSuccessfulVersion?: string;
        lastSyncMode?: ContactSyncMode;
    }): void;
    computeIntegrity(userInfos: ReadonlyArray<UserInfoSummary>): ContactCacheMeta;
    buildSnapshot(userInfos: ReadonlyArray<UserInfoSummary>, source: ContactSyncSource): ContactSnapshot;
    private normalizeRecord;
    private normalizeVersionState;
    private normalizeMeta;
}
