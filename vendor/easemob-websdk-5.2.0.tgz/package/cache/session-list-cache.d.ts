import type { ConversationItem } from '../types/conversation';
import type { SessionListCacheRecord } from './cache-types';
export declare class SessionListCache {
    private items;
    load(rawItems: ReadonlyArray<SessionListCacheRecord>, now: number): void;
    getAll(): ReadonlyArray<SessionListCacheRecord>;
    setAll(items: ReadonlyArray<SessionListCacheRecord>): void;
    exportItems(): ReadonlyArray<ConversationItem>;
    private normalizeItem;
}
