/**
 * 群名片缓存
 */
import type { GroupNamecardCacheRecord } from './cache-types';
export declare class GroupNamecardCache {
    private readonly items;
    load(rawItems: ReadonlyArray<GroupNamecardCacheRecord>, now: number): void;
    getAll(): ReadonlyArray<GroupNamecardCacheRecord>;
    get(groupId: string, userId: string, now: number, updateAccess: boolean): GroupNamecardCacheRecord | null;
    getByGroupId(groupId: string, now: number, updateAccess: boolean): ReadonlyArray<GroupNamecardCacheRecord>;
    setAll(items: ReadonlyArray<GroupNamecardCacheRecord>, now: number): void;
    remove(targets: ReadonlyArray<{
        groupId: string;
        userId: string;
    }>): void;
    removeExpired(ttlMs: number, now: number, protectedUserIds?: ReadonlySet<string>): boolean;
    evictByLru(removeCount: number, protectedUserIds?: ReadonlySet<string>): boolean;
    trimMax(maxCount: number, protectedUserIds?: ReadonlySet<string>): boolean;
    private normalizeItem;
}
