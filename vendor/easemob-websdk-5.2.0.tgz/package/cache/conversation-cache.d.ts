/**
 * 会话摘要缓存
 */
import type { ConversationSummary } from './cache-types';
import type { ConversationType } from '../types/conversation';
export declare class ConversationCache {
    private items;
    load(rawItems: ReadonlyArray<ConversationSummary>, now: number): void;
    getAll(): ReadonlyArray<ConversationSummary>;
    setAll(items: ReadonlyArray<ConversationSummary>): void;
    updateLastAccess(conversationIds: ReadonlyArray<{
        conversationId: string;
        type: ConversationType;
    }>, now: number): boolean;
    removeExpired(ttlMs: number, now: number): boolean;
    evictByLru(removeCount: number): boolean;
    trimMax(maxCount?: number): boolean;
    private findIndex;
    private normalizeItem;
    private normalizeMessage;
}
