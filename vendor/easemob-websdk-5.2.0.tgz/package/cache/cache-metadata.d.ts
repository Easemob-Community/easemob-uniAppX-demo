/**
 * 缓存元信息管理
 */
import type { CacheMetadata } from './cache-types';
import { CacheStore } from './cache-store';
export declare class CacheMetadataStore {
    private readonly store;
    private readonly key;
    private readonly schemaVersion;
    constructor(store: CacheStore, key: string, schemaVersion: number);
    load(): Promise<CacheMetadata>;
    save(metadata: CacheMetadata): Promise<void>;
    touchLastFlush(): Promise<CacheMetadata>;
}
