/**
 * 缓存加密工具
 */
export interface CacheCryptoPayload {
    readonly __enc: true;
    readonly v: 1;
    readonly alg: 'AES-GCM';
    readonly kdf: 'SHA-256';
    readonly iv: string;
    readonly ct: string;
}
export interface CacheCryptoAdapter {
    readonly isEnabled: () => boolean;
    readonly encrypt: (plaintext: string) => Promise<string>;
    readonly decrypt: (payload: string) => Promise<string | null>;
}
export declare class CacheCrypto implements CacheCryptoAdapter {
    private readonly enabled;
    private readonly keyPromise;
    private getCrypto;
    constructor(appKey: string, userId: string);
    isEnabled(): boolean;
    encrypt(plaintext: string): Promise<string>;
    decrypt(payload: string): Promise<string | null>;
    private deriveKey;
}
