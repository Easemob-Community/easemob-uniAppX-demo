import type { ContactSnapshot } from '../types/contact';
import type { UserInfo, UserInfoNotifyPatch } from '../types/user-info';
import type { JoinedGroupSnapshot } from '../types/group';
import type { StorageAdapter } from '../platform';
import type { CacheConfig, ContactCacheMeta, ContactRelationRecord, ContactVersionState, ConversationSummary, GroupNamecardCacheRecord, SessionListCheckpoint, UserInfoSummary } from './cache-types';
import type { ConversationMark, ConversationType, ConversationItem, SessionListRemindType } from '../types/conversation';
import type { Message } from '../types';
import { type UserInfoRuntimeMergeResult, type UserInfoRuntimeUpsertRecord } from '../managers/user-info/user-info-runtime-store';
export interface CacheManagerOptions {
    readonly appKey: string;
    readonly userId: string;
    readonly cacheEncryptionMode?: 'auto' | 'off';
    /** [zh-CN] 跨平台存储适配器；缺失或不可用时允许降级。 [en-US] Cross-platform storage adapter; persistence may gracefully degrade when unavailable. */
    readonly storageAdapter?: StorageAdapter;
    readonly config?: Partial<CacheConfig>;
}
export interface ConversationMergeResult {
    readonly items: ReadonlyArray<ConversationSummary>;
    readonly changed: boolean;
}
export interface ConversationMessagePatchResult {
    readonly items: ReadonlyArray<ConversationSummary>;
    readonly changed: boolean;
}
/** @internal A targeted last-message update; batches preserve notification order. */
export interface ConversationLastMessagePatch {
    readonly conversationId: string;
    readonly conversationType: ConversationType;
    readonly messageId: string;
    readonly patch: Partial<NonNullable<ConversationItem['lastMessage']>>;
}
export interface SessionListPatchResult {
    readonly items: ReadonlyArray<ConversationItem>;
    readonly changed: boolean;
}
export interface ConversationUnreadClearResult extends SessionListPatchResult {
    /** [zh-CN] 本地 conversation 或 session-list 缓存中是否存在目标会话。 [en-US] Whether the target conversation exists in the local conversation or session-list cache. */
    readonly matched: boolean;
}
export interface SessionListDisplayRefreshTarget {
    readonly userId: string;
    readonly lastModified?: number;
}
export interface SessionListGroupDisplayRefreshTarget {
    readonly groupId: string;
    readonly name?: string;
    readonly avatarUrl?: string;
    readonly remindType?: SessionListRemindType;
}
export interface SessionListGroupDisplayRefreshOptions {
    readonly onlyWhenNameMissing?: boolean;
}
export interface SessionListBatchApplyResult {
    readonly items: ReadonlyArray<ConversationItem>;
    readonly checkpoint: SessionListCheckpoint;
}
export interface ContactSyncApplyResult {
    readonly snapshot: ContactSnapshot;
    readonly changed: boolean;
}
export interface ContactLocalPatchResult {
    readonly snapshot: ContactSnapshot;
    readonly changed: boolean;
}
export declare class CacheManager {
    private readonly config;
    private readonly userId;
    private readonly store;
    private readonly metadataStore;
    private readonly conversationCache;
    private readonly userInfoCache;
    private readonly groupNamecardCache;
    private readonly sessionListCache;
    private readonly joinedGroupPreviewCache;
    private readonly contactCache;
    private readonly userInfoRuntimeStore;
    private readonly conversationDeletionTimestamps;
    private currentConversation;
    private readonly conversationKey;
    private readonly userInfoKey;
    private readonly groupNamecardKey;
    private readonly sessionListKey;
    private readonly sessionListCheckpointKey;
    private readonly joinedGroupPreviewKey;
    private readonly contactRelationKey;
    private readonly contactVersionKey;
    private readonly contactMetaKey;
    private readonly metadataKey;
    private sessionListCheckpoint;
    private flushTimer;
    private flushIdleHandle;
    private activeFlushPromise;
    private sessionListCommitInProgress;
    private mutationRevision;
    private readonly domainRevisions;
    private pendingDirtyRevisions;
    private readonly loadPromise;
    constructor(options: CacheManagerOptions);
    getConfig(): CacheConfig;
    prepare(): Promise<void>;
    loadConversationSummaries(): ReadonlyArray<ConversationSummary>;
    loadSessionList(): ReadonlyArray<ConversationItem>;
    loadJoinedGroupPreviewSnapshot(): JoinedGroupSnapshot;
    applyJoinedGroupPreviewSnapshot(snapshot: JoinedGroupSnapshot): void;
    /** @internal 在群组全量同步完成后严格提交权威预览，写入失败时不替换内存预览。 */
    commitJoinedGroupPreviewSnapshot(snapshot: JoinedGroupSnapshot): Promise<JoinedGroupSnapshot>;
    /** @internal 删除当前缓存用户的一个已加入群预览，并在返回前刷新持久化记录。 */
    removeJoinedGroupPreview(groupId: string): Promise<JoinedGroupSnapshot>;
    loadSessionListCheckpoint(): SessionListCheckpoint;
    /**
     * @internal
     * [zh-CN] 正常会话结束前持久化待处理缓存域。
     * [en-US] Flushes pending cache domains before a normal session shutdown.
     */
    flushPending(): Promise<void>;
    resetSessionListCheckpoint(): void;
    loadUserInfoSummaries(): ReadonlyArray<UserInfoSummary>;
    loadGroupNamecards(groupId?: string): ReadonlyArray<GroupNamecardCacheRecord>;
    loadContactSnapshot(source?: 'cache' | 'sync'): ContactSnapshot;
    loadContactRelationRecords(): ReadonlyArray<ContactRelationRecord>;
    loadContactVersionState(): ContactVersionState;
    loadContactCacheMeta(): ContactCacheMeta;
    markConversationAccess(targets: ReadonlyArray<{
        conversationId: string;
        type: ConversationType;
    }>): void;
    setCurrentConversation(params: {
        readonly conversationId: string;
        readonly type: ConversationType;
    }): void;
    resetCurrentConversation(): void;
    getCurrentConversation(): {
        readonly conversationId: string;
        readonly type: ConversationType;
    } | null;
    clearConversationUnreadMessageCount(params: {
        readonly conversationId: string;
        readonly type: ConversationType;
        readonly readAt?: number;
    }): ConversationUnreadClearResult;
    clearAllConversationUnreadMessageCount(params?: {
        readonly readAt?: number;
    }): SessionListPatchResult;
    applyConversationPinnedMutation(params: {
        readonly conversationId: string;
        readonly type: ConversationType;
        readonly isPinned: boolean;
        readonly pinnedTime?: number;
    }): SessionListPatchResult;
    deleteConversation(params: {
        readonly conversationId: string;
        readonly type: ConversationType;
        readonly deletedAt?: number;
    }): SessionListPatchResult;
    clearConversations(): SessionListPatchResult;
    applyConversationMarkMutation(params: {
        readonly conversations: ReadonlyArray<{
            readonly conversationId: string;
            readonly conversationType: ConversationType;
            readonly applied: boolean;
        }>;
        readonly mark: ConversationMark;
        readonly operation: 'addMark' | 'removeMark';
    }): SessionListPatchResult;
    replaceSessionList(items: ReadonlyArray<ConversationItem>, checkpoint?: Partial<SessionListCheckpoint>, options?: {
        readonly syncStartedAt?: number;
    }): void;
    mergeSessionListIncremental(items: ReadonlyArray<ConversationItem>, checkpoint?: Partial<SessionListCheckpoint>): void;
    commitSessionListSync(options: {
        readonly items: ReadonlyArray<ConversationItem>;
        readonly mode: 'full' | 'incremental';
        readonly checkpoint: SessionListCheckpoint;
        readonly syncStartedAt?: number;
    }): Promise<SessionListBatchApplyResult>;
    setUserInfoSummaries(items: ReadonlyArray<UserInfoSummary>): void;
    upsertRuntimeUserInfos(items: ReadonlyArray<UserInfoRuntimeUpsertRecord>): void;
    getRuntimeUserInfo(userId: string, updateAccess?: boolean): UserInfo | null;
    applyUserInfoNotifyPatch(patch: UserInfoNotifyPatch): UserInfoRuntimeMergeResult;
    updateUserInfoSummaryFromRuntime(userId: string): void;
    getUserInfoSummaries(userIds: ReadonlyArray<string>, updateAccess: boolean): ReadonlyArray<UserInfoSummary>;
    removeUserInfo(userIds: ReadonlyArray<string>): void;
    getGroupNamecard(groupId: string, userId: string, updateAccess: boolean): GroupNamecardCacheRecord | null;
    setGroupNamecards(items: ReadonlyArray<GroupNamecardCacheRecord>): void;
    removeGroupNamecards(targets: ReadonlyArray<{
        groupId: string;
        userId: string;
    }>): void;
    setContactVersionState(state: ContactVersionState): void;
    markContactCacheIncomplete(reason: ContactCacheMeta['reason']): void;
    applyContactSync(options: {
        mode: 'full' | 'incremental';
        relations: ReadonlyArray<ContactRelationRecord>;
        userInfos: ReadonlyArray<Pick<UserInfoSummary, 'userId' | 'nickname' | 'avatarUrl' | 'sign' | 'ext'>>;
        version: string;
        lastSyncTs: number;
    }): ContactSyncApplyResult;
    refreshSessionListDisplayFromUserInfos(targets: ReadonlyArray<SessionListDisplayRefreshTarget>): SessionListPatchResult;
    refreshSessionListDisplayFromJoinedGroups(groups: ReadonlyArray<SessionListGroupDisplayRefreshTarget>, options?: SessionListGroupDisplayRefreshOptions): SessionListPatchResult;
    removeContact(userId: string): ContactLocalPatchResult;
    updateContactRemark(userId: string, remark: string): ContactLocalPatchResult;
    applyContactRosterNotice(options: {
        readonly action: 'add' | 'remove';
        readonly userId: string;
        readonly rosterVersion?: string;
    }): ContactLocalPatchResult;
    updateConversationsFromServer(items: ReadonlyArray<ConversationSummary>, options?: {
        readonly syncStartedAt?: number;
    }): ConversationMergeResult;
    applyIncomingMessageToConversations(message: Message): ConversationMessagePatchResult;
    /** @internal [zh-CN] 只更新同会话同消息的最后消息，不改变未读数或排序时间。 [en-US] Patches the matching last message without changing unread counts or ordering timestamps. */
    patchConversationLastMessage(options: ConversationLastMessagePatch): SessionListPatchResult;
    /** @internal [zh-CN] 批量匹配最后消息，仅比较命中的快照。 [en-US] Matches a batch and compares only affected last-message snapshots. */
    patchConversationLastMessages(updates: ReadonlyArray<ConversationLastMessagePatch>): boolean;
    applyIncomingMessageToSessionList(message: Message): SessionListPatchResult;
    private loadFromStorage;
    private readDump;
    private readValue;
    private normalizeSessionListCheckpoint;
    private scheduleFlush;
    private markDirty;
    private getDomainRevision;
    private ensureFlushScheduled;
    private takePendingDirtyBatch;
    private restoreDirtyBatch;
    private addQuotaCleanupDomains;
    private flushNow;
    private flushDirtyBatch;
    private writeDirtyDomains;
    private writeDomain;
    private writeSessionListStorageRecord;
    private buildIncrementalSessionListRecords;
    private buildSessionListSyncCandidate;
    private filterItemsAgainstConversationDeletions;
    private getConversationLatestUpdate;
    private handleQuotaExceeded;
    private evictByPolicy;
    private calculateEvictCount;
    private mergeConversationLists;
    private isConversationListEqual;
    private buildConversationSignature;
    private buildConversationKey;
    private areConversationMarksEqual;
    private buildConversationFromMessage;
    private resolveConversationFromMessage;
    private buildMessageSnippet;
    private normalizeMessageBody;
    private buildSessionListRecordFromConversation;
    private resolveSessionListUnreadCount;
    private shouldIncreaseUnreadForMessage;
    private buildSingleSessionDisplayFields;
    private shouldSkipSessionUserDisplayRefresh;
    private hydrateSessionListRecordsFromLocalProfiles;
    private resolveSessionDisplayUserInfo;
    private buildSessionMessageSender;
    private buildSingleChatPeerMessageSender;
    private isSenderEqual;
    private buildGroupSessionDisplayFields;
    private mapJoinedGroupRemindTypeToSession;
    private buildChatRoomSessionDisplayFields;
    private isSessionListEqual;
    private buildSessionListSignature;
    private refreshContactCacheIntegrity;
    private buildContactSnapshotSignature;
    private applyContactLocalPatch;
}
