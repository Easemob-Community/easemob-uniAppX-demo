/**
 * 缓存 key 生成工具
 */
export declare const CACHE_KEY_PREFIX = "IMSDK";
export declare const CacheKeyName: {
    readonly CONVERSATIONS: "conversationMap";
    readonly USER_INFO: "userInfoMap";
    readonly GROUP_NAMECARD: "groupNamecardMap";
    readonly CONTACT_RELATIONS: "contactRelationMap";
    readonly CONTACT_VERSION: "contactVersion";
    readonly CONTACT_META: "contactMeta";
    readonly SESSION_LIST: "sessionListMap";
    readonly SESSION_LIST_CHECKPOINT: "sessionListCheckpoint";
    readonly JOINED_GROUP_PREVIEW: "joinedGroupPreview";
    readonly METADATA: "metadata";
};
export type CacheKeyName = (typeof CacheKeyName)[keyof typeof CacheKeyName];
export interface CacheKeyContext {
    readonly appKey: string;
    readonly userId: string;
    readonly schemaVersion: number;
}
export declare const buildCacheKey: (context: CacheKeyContext, name: CacheKeyName) => string;
