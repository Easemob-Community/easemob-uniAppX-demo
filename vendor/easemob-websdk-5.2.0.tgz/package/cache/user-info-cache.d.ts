/**
 * 用户信息缓存
 */
import type { UserInfoSummary } from './cache-types';
export declare class UserInfoCache {
    private readonly items;
    load(rawItems: ReadonlyArray<UserInfoSummary>, now: number): void;
    getAll(): ReadonlyArray<UserInfoSummary>;
    getByIds(userIds: ReadonlyArray<string>, now: number, updateAccess: boolean): ReadonlyArray<UserInfoSummary>;
    setAll(items: ReadonlyArray<UserInfoSummary>, now: number): void;
    remove(userIds: ReadonlyArray<string>): void;
    removeExpired(ttlMs: number, now: number, protectedUserIds?: ReadonlySet<string>): boolean;
    evictByLru(removeCount: number, protectedUserIds?: ReadonlySet<string>): boolean;
    trimMax(maxCount: number, protectedUserIds?: ReadonlySet<string>): boolean;
    private normalizeItem;
}
