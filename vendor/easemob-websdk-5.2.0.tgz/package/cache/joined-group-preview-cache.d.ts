import type { JoinedGroupSnapshot } from '../types/group';
import type { JoinedGroupPreviewStorageRecord } from './cache-types';
export declare const JOINED_GROUP_PREVIEW_STORAGE_LIMIT = 100;
export declare const JOINED_GROUP_SERVER_LIMIT = 3000;
export declare class JoinedGroupPreviewCache {
    private items;
    private meta;
    load(record: JoinedGroupPreviewStorageRecord | null | undefined): void;
    setSnapshot(snapshot: JoinedGroupSnapshot): void;
    getSnapshot(): JoinedGroupSnapshot;
    exportRecord(): JoinedGroupPreviewStorageRecord;
}
