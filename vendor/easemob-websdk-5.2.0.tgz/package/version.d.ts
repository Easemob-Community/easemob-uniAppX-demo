/** [zh-CN] SDK 对外发布版本。 [en-US] Public SDK release version. */
export declare const SDK_VERSION: string;
