export interface RuntimeApiErrorEntry {
    readonly code: number;
    readonly runtimeMessage?: string;
    readonly retryable?: boolean;
    readonly httpStatus?: number;
    readonly provisional?: boolean;
    readonly canonicalCode?: number;
    readonly aliases?: readonly string[];
    readonly matchField?: string;
    readonly matchValue?: string | number;
    readonly matchPattern?: string;
}
export type RuntimeErrorMatchedBy = 'key' | 'field' | 'code' | 'alias' | 'common';
export interface ResolvedApiBusinessError {
    readonly reasonKey: string;
    readonly entry: RuntimeApiErrorEntry;
    readonly matchedBy: RuntimeErrorMatchedBy;
}
export interface RuntimeApiErrorDefinition {
    readonly range?: string;
    readonly localErrors?: Readonly<Record<string, Readonly<Record<string, RuntimeApiErrorEntry>>>>;
    readonly errors: Readonly<Record<string, RuntimeApiErrorEntry>>;
}
export interface RuntimeCommonErrorDefinition {
    readonly range?: string;
    readonly errors: Readonly<Record<string, RuntimeApiErrorEntry>>;
}
export interface RuntimeErrorMap {
    readonly common: Readonly<Record<string, RuntimeCommonErrorDefinition>>;
    readonly apis: Readonly<Record<string, RuntimeApiErrorDefinition>>;
}
export declare const mergeRuntimeErrorMaps: (...maps: ReadonlyArray<RuntimeErrorMap>) => RuntimeErrorMap;
