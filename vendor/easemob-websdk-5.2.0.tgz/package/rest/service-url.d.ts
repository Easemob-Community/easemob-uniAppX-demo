/**
 * 将 REST 服务地址转换为统一数据同步 WebSocket 地址。
 *
 * @internal
 */
export declare const deriveSyncWebSocketUrl: (restApiUrl: string) => string;
