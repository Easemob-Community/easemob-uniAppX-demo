/**
 * dnsconfig 请求与解析
 */
import { ConnectionError } from '../utils/errors';
import type { DnsConfig } from '../types/chat-client';
import type { RequestAdapter } from '../platform/types';
export declare const DEFAULT_DNS_CONFIG_URLS: string[];
export interface DnsConfigResult {
    appKey: string;
    websocketUrl: string;
    websocketUrls: string[];
    baseUrl: string;
    restBaseUrl: string;
    dnsConfig: DnsConfig;
}
type DnsConfigIdentity = {
    readonly appKey: string;
    readonly appId?: never;
} | {
    readonly appId: string;
    readonly appKey?: never;
};
interface DnsLoginDeadline {
    remainingMs(): number;
    createTimeoutError(): ConnectionError;
}
export declare function resolveDnsConfig(options: DnsConfigIdentity & {
    baseUrls?: string[];
    pageProtocol?: 'http' | 'https';
    requestAdapter?: RequestAdapter;
    loginDeadline?: DnsLoginDeadline;
}): Promise<DnsConfigResult>;
export {};
