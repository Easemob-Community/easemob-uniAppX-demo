import type { RestContext } from '../types/chat-client';
export declare const MAX_USER_INFO_SUBSCRIPTION_COUNT = 100;
export declare const buildSubscribeUserInfoChangesRequest: (userIds: ReadonlyArray<string>) => {
    readonly usernames: ReadonlyArray<string>;
};
export declare const buildUnsubscribeUserInfoChangesUserIds: (userIds: ReadonlyArray<string>) => ReadonlyArray<string>;
export declare const buildSubscribeUserInfoChangesEndpoint: (context: RestContext) => string;
export declare const buildUnsubscribeUserInfoChangesEndpoint: (context: RestContext, userIds: ReadonlyArray<string>) => string;
export declare const buildGetSubscribedUserInfoListEndpoint: (context: RestContext) => string;
export declare const readSubscribedUserIdsFromEnvelope: (response: unknown) => ReadonlyArray<string>;
