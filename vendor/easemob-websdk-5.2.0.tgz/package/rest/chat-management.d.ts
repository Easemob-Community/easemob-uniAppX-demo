import type { RestClient } from './client';
import type { RestContext } from '../types/chat-client';
import type { GetGroupMessageReadReceiptsParams, GetHistoryMessagesParams, GetReactionDetailParams, GetReactionListParams, GroupMessageReadUsersResult, GroupMessageReadUsersParams, MessageReadReceiptDetail, MessageHistoryPage, MessageReactionDetailPage, MessageReactionListItem, RemoveHistoryMessagesParams, TranslationLanguage, MessageTranslationResult, SearchMessagesParams, SearchMessagesResult } from '../types/chat-manager';
import type { Message } from '../types';
type DecodeMetaMessage = (metaPayload: Uint8Array) => Message | null;
export declare const requestGetHistoryMessages: (client: RestClient, context: RestContext, params: GetHistoryMessagesParams, decodeMetaMessage: DecodeMetaMessage) => Promise<MessageHistoryPage>;
export declare const requestRemoveHistoryMessages: (client: RestClient, context: RestContext, params: RemoveHistoryMessagesParams) => Promise<void>;
export declare const requestGetGroupMessageReadUsers: (client: RestClient, context: RestContext, params: GroupMessageReadUsersParams) => Promise<GroupMessageReadUsersResult>;
export declare const requestGetGroupMessageReadReceipts: (client: RestClient, context: RestContext, params: GetGroupMessageReadReceiptsParams) => Promise<ReadonlyArray<MessageReadReceiptDetail>>;
export declare const requestAddReaction: (client: RestClient, context: RestContext, params: {
    messageId: string;
    reaction: string;
}) => Promise<void>;
export declare const requestRemoveReaction: (client: RestClient, context: RestContext, params: {
    messageId: string;
    reaction: string;
}) => Promise<void>;
export declare const requestGetReactionList: (client: RestClient, context: RestContext, params: GetReactionListParams) => Promise<ReadonlyArray<MessageReactionListItem>>;
export declare const requestGetReactionDetail: (client: RestClient, context: RestContext, params: GetReactionDetailParams) => Promise<MessageReactionDetailPage>;
export declare const requestGetSupportedTranslationLanguages: (client: RestClient, context: RestContext) => Promise<ReadonlyArray<TranslationLanguage>>;
export declare const requestTranslateMessage: (client: RestClient, context: RestContext, params: {
    text: string;
    targetLanguages: ReadonlyArray<string>;
}) => Promise<MessageTranslationResult>;
export declare const requestSearchMessages: (client: RestClient, context: RestContext, params: SearchMessagesParams) => Promise<SearchMessagesResult>;
export {};
