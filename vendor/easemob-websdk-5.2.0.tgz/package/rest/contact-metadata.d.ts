/**
 * 联系人版本元数据查询
 */
import type { RestContext } from '../types/chat-client';
import type { RequestAdapter } from '../platform/types';
export interface ContactMetadataVersionResponse {
    readonly version: string;
    readonly requiresSync: boolean;
    readonly checkedAt: number;
}
export declare const fetchContactMetadataVersion: (context: RestContext, currentVersion: string, requestAdapter?: RequestAdapter) => Promise<ContactMetadataVersionResponse>;
