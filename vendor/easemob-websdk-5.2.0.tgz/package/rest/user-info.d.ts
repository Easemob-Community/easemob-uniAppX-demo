import type { RestContext } from '../types/chat-client';
import type { UpdateOwnInfoParams, UpdateOwnInfoByAttributeParams, UserInfo, UserInfoAttribute } from '../types/user-info';
export declare const USER_INFO_ATTRIBUTE_TO_REST_FIELD: {
    readonly nickname: "nickname";
    readonly avatarUrl: "avatarurl";
    readonly mail: "mail";
    readonly phone: "phone";
    readonly gender: "gender";
    readonly sign: "sign";
    readonly birth: "birth";
    readonly ext: "ext";
};
export type RestUserInfoAttribute = (typeof USER_INFO_ATTRIBUTE_TO_REST_FIELD)[keyof typeof USER_INFO_ATTRIBUTE_TO_REST_FIELD];
export interface NormalizedUserInfoFetchRecord {
    readonly profile: UserInfo;
    readonly lastModified?: number;
}
export declare const DEFAULT_USER_INFO_ATTRIBUTES: ReadonlyArray<UserInfoAttribute>;
export declare const mapUserInfoAttributeToRestField: (attribute: UserInfoAttribute, path?: string) => RestUserInfoAttribute;
export declare const normalizeUserInfoTargetIds: (userIds: ReadonlyArray<string>, path?: string) => ReadonlyArray<string>;
export declare const normalizeUserInfoAttributes: (attributes: ReadonlyArray<UserInfoAttribute>, path?: string) => ReadonlyArray<UserInfoAttribute>;
export declare const buildUserInfoFetchEndpoint: (context: RestContext) => string;
export declare const buildUserInfoUpdateEndpoint: (context: RestContext) => string;
export declare const buildFetchUserInfoByUserIdRequest: (userIds: ReadonlyArray<string>) => {
    readonly targets: ReadonlyArray<string>;
};
export declare const buildFetchUserInfoByAttributeRequest: (userIds: ReadonlyArray<string>, attributes: ReadonlyArray<UserInfoAttribute>) => {
    readonly targets: ReadonlyArray<string>;
    readonly properties: ReadonlyArray<RestUserInfoAttribute>;
};
export declare const normalizeUserInfoFetchRecords: (response: unknown, requestedUserIds: ReadonlyArray<string>) => ReadonlyArray<NormalizedUserInfoFetchRecord>;
export declare const normalizeFetchedUserInfos: (response: unknown, requestedUserIds: ReadonlyArray<string>) => ReadonlyArray<UserInfo>;
export declare const buildUpdateOwnInfoFormBody: (params: UpdateOwnInfoParams) => string;
export declare const buildUpdateOwnInfoByAttributeFormBody: (attribute: UpdateOwnInfoByAttributeParams["attribute"], value: UpdateOwnInfoByAttributeParams["value"]) => string;
