export declare const CHAT_ERROR_MAP: {
    readonly common: {};
    readonly apis: {
        readonly sendMessage: {
            readonly range: "1,4,100,108,110,202,210,213-215,219-222,300-301,303,305,402,405-406,500-501,505-510,602-603,606-607,1200,1299";
            readonly localErrors: {
                readonly sendMessage: {
                    readonly operation_cancelled: {
                        readonly code: 1;
                        readonly retryable: false;
                    };
                    readonly upload_invalid_appkey: {
                        readonly code: 100;
                        readonly retryable: false;
                    };
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                    readonly not_connected: {
                        readonly code: 300;
                        readonly retryable: true;
                    };
                    readonly request_timeout: {
                        readonly code: 301;
                        readonly retryable: true;
                    };
                    readonly send_failed: {
                        readonly code: 303;
                        readonly retryable: false;
                    };
                    readonly upload_failed: {
                        readonly code: 402;
                        readonly retryable: true;
                    };
                    readonly file_too_large: {
                        readonly code: 405;
                        readonly retryable: false;
                    };
                    readonly file_content_improper: {
                        readonly code: 406;
                        readonly retryable: false;
                    };
                    readonly encode_failed: {
                        readonly code: 500;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly SERVICE_LIMIT_EXCEEDED: {
                    readonly code: 4;
                    readonly retryable: false;
                };
                readonly TOKEN_EXPIRED: {
                    readonly code: 108;
                    readonly retryable: false;
                };
                readonly AUTH_FAILED: {
                    readonly code: 202;
                    readonly retryable: false;
                };
                readonly PERMISSION_DENIED: {
                    readonly code: 210;
                    readonly retryable: false;
                };
                readonly BIND_ANOTHER_DEVICE: {
                    readonly code: 213;
                    readonly retryable: false;
                };
                readonly TOO_MANY_DEVICES: {
                    readonly code: 214;
                    readonly retryable: false;
                };
                readonly USER_MUTED: {
                    readonly code: 215;
                    readonly retryable: false;
                };
                readonly USER_MUTED_BY_ADMIN: {
                    readonly code: 219;
                    readonly retryable: false;
                };
                readonly USER_DEVICE_CHANGED: {
                    readonly code: 220;
                    readonly retryable: false;
                };
                readonly USER_NOT_ON_ROSTER: {
                    readonly code: 221;
                    readonly retryable: false;
                };
                readonly BLOCKED_BY_RECIPIENT: {
                    readonly code: 222;
                    readonly retryable: false;
                    readonly aliases: readonly ["blocked"];
                };
                readonly SERVER_SERVING_DISABLED: {
                    readonly code: 305;
                    readonly retryable: false;
                };
                readonly MESSAGE_INCLUDE_ILLEGAL_CONTENT: {
                    readonly code: 501;
                    readonly retryable: false;
                };
                readonly SERVICE_NOT_ENABLED: {
                    readonly code: 505;
                    readonly retryable: false;
                };
                readonly MESSAGE_EXPIRED: {
                    readonly code: 506;
                    readonly retryable: false;
                };
                readonly MESSAGE_ILLEGAL_WHITELIST: {
                    readonly code: 507;
                    readonly retryable: false;
                };
                readonly MESSAGE_EXTERNAL_LOGIC_BLOCKED: {
                    readonly code: 508;
                    readonly retryable: false;
                };
                readonly MESSAGE_CURRENT_LIMITING: {
                    readonly code: 509;
                    readonly retryable: true;
                };
                readonly MESSAGE_SIZE_LIMIT: {
                    readonly code: 510;
                    readonly retryable: false;
                };
                readonly GROUP_NOT_JOINED: {
                    readonly code: 602;
                    readonly retryable: false;
                };
                readonly GROUP_PERMISSION_DENIED: {
                    readonly code: 603;
                    readonly retryable: false;
                };
                readonly GROUP_NOT_EXIST: {
                    readonly code: 606;
                    readonly retryable: false;
                };
                readonly GROUP_DISABLED: {
                    readonly code: 607;
                    readonly retryable: false;
                };
                readonly MESSAGE_BLOCKED: {
                    readonly code: 1200;
                    readonly retryable: false;
                };
                readonly THIRD_DEFAULT_FAILED: {
                    readonly code: 1299;
                    readonly retryable: false;
                };
            };
        };
        readonly getHistoryMessages: {
            readonly range: "4,110,202,505";
            readonly localErrors: {
                readonly getHistoryMessages: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly retryable: false;
                };
                readonly page_size_exceeded: {
                    readonly code: 110;
                    readonly aliases: readonly ["pull number cannot be greater", "limit is to large"];
                    readonly retryable: false;
                };
            };
        };
        readonly removeHistoryMessages: {
            readonly range: "110,112,202,505";
            readonly localErrors: {
                readonly removeHistoryMessages: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly retryable: false;
                };
                readonly query_param_reaches_limit: {
                    readonly code: 112;
                    readonly aliases: readonly ["delete msg list limit"];
                    readonly retryable: false;
                };
            };
        };
        readonly getGroupMessageReadUsers: {
            readonly range: "4,110,500";
            readonly localErrors: {
                readonly getGroupMessageReadUsers: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly message_not_found: {
                    readonly code: 500;
                    readonly retryable: false;
                };
            };
        };
        readonly recallMessage: {
            readonly range: "110,201,300,504,505";
            readonly localErrors: {
                readonly recallMessage: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly message_invalid: {
                    readonly code: 110;
                    readonly retryable: false;
                };
                readonly not_login: {
                    readonly code: 201;
                    readonly retryable: true;
                };
                readonly not_connected: {
                    readonly code: 300;
                    readonly retryable: true;
                };
                readonly recall_time_limit: {
                    readonly code: 504;
                    readonly retryable: false;
                };
                readonly recall_disabled: {
                    readonly code: 505;
                    readonly retryable: false;
                };
            };
        };
        readonly updateMessage: {
            readonly range: "110,111,201,210,300,511";
            readonly localErrors: {
                readonly modifyMessage: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                    readonly unsupported_type: {
                        readonly code: 111;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly message_invalid: {
                    readonly code: 110;
                    readonly retryable: false;
                };
                readonly unsupported_type: {
                    readonly code: 111;
                    readonly retryable: false;
                };
                readonly not_login: {
                    readonly code: 201;
                    readonly retryable: true;
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly retryable: false;
                };
                readonly not_connected: {
                    readonly code: 300;
                    readonly retryable: true;
                };
                readonly edit_failed: {
                    readonly code: 511;
                    readonly retryable: true;
                };
            };
        };
        readonly downloadMessageAttachment: {
            readonly range: "400,401,403,407";
            readonly localErrors: {
                readonly downloadAttachment: {
                    readonly validation_invalid: {
                        readonly code: 401;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_found: {
                    readonly code: 400;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly invalid: {
                    readonly code: 401;
                    readonly retryable: false;
                };
                readonly download_failed: {
                    readonly code: 403;
                    readonly retryable: true;
                };
                readonly expired: {
                    readonly code: 407;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly downloadAndParseCombineMessage: {
            readonly range: "110,401,403,500";
            readonly localErrors: {
                readonly downloadAndParseCombineMessage: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly invalid_param: {
                    readonly code: 110;
                    readonly retryable: false;
                };
                readonly invalid_type: {
                    readonly code: 500;
                    readonly retryable: false;
                };
                readonly parse_failed: {
                    readonly code: 401;
                    readonly retryable: true;
                };
                readonly download_failed: {
                    readonly code: 403;
                    readonly retryable: true;
                };
            };
        };
        readonly addReaction: {
            readonly range: "110,302,505,600,602,1300-1302";
            readonly localErrors: {
                readonly addReaction: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly reaction_already_operated: {
                    readonly code: 1301;
                    readonly retryable: false;
                };
                readonly reaction_reach_limit: {
                    readonly code: 1300;
                    readonly retryable: false;
                };
                readonly group_not_joined: {
                    readonly code: 602;
                    readonly retryable: false;
                };
                readonly reaction_operation_illegal: {
                    readonly code: 1302;
                    readonly retryable: false;
                };
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly retryable: false;
                };
                readonly server_busy: {
                    readonly code: 302;
                    readonly retryable: true;
                };
            };
        };
        readonly removeReaction: {
            readonly range: "110,505,1301,1302";
            readonly localErrors: {
                readonly removeReaction: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly retryable: false;
                };
                readonly reaction_operation_illegal: {
                    readonly code: 1302;
                    readonly retryable: false;
                };
            };
        };
        readonly getReactionList: {
            readonly range: "110,505,600";
            readonly localErrors: {
                readonly getReactionList: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly retryable: false;
                };
                readonly group_invalid_id: {
                    readonly code: 600;
                    readonly retryable: false;
                };
            };
        };
        readonly getReactionDetail: {
            readonly range: "110,505,1302";
            readonly localErrors: {
                readonly getReactionDetail: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly retryable: false;
                };
                readonly reaction_operation_illegal: {
                    readonly code: 1302;
                    readonly retryable: false;
                };
            };
        };
        readonly pinMessage: {
            readonly range: "4,110";
            readonly errors: {
                readonly pin_msg_id_illegal: {
                    readonly code: 110;
                    readonly retryable: false;
                };
                readonly pin_message_limit: {
                    readonly code: 4;
                    readonly aliases: readonly ["91101"];
                    readonly retryable: false;
                };
                readonly pin_message_not_found: {
                    readonly code: 110;
                    readonly aliases: readonly ["91102"];
                    readonly retryable: false;
                };
            };
        };
        readonly unpinMessage: {
            readonly range: "110";
            readonly errors: {
                readonly pin_msg_id_illegal: {
                    readonly code: 110;
                    readonly retryable: false;
                };
                readonly pin_message_not_found: {
                    readonly code: 110;
                    readonly aliases: readonly ["91102", "user session pin message not exist"];
                    readonly retryable: false;
                };
            };
        };
        readonly getPinnedMessageList: {
            readonly range: "110,111";
            readonly errors: {
                readonly operation_unsupported: {
                    readonly code: 111;
                    readonly aliases: readonly ["15002"];
                    readonly retryable: false;
                };
                readonly pin_message_not_found: {
                    readonly code: 110;
                    readonly aliases: readonly ["91102", "user session pin message not exist"];
                    readonly retryable: false;
                };
            };
        };
        readonly getSupportedTranslationLanguages: {
            readonly range: "505";
            readonly errors: {
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly aliases: readonly ["service not open!"];
                    readonly retryable: false;
                };
            };
        };
        readonly translateMessage: {
            readonly range: "505,1110-1113";
            readonly localErrors: {
                readonly translateMessage: {
                    readonly validation_invalid: {
                        readonly code: 1110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly translate_text_too_long: {
                    readonly code: 1110;
                    readonly runtimeMessage: "Translation text is too long";
                    readonly retryable: false;
                };
                readonly translate_param_invalid: {
                    readonly code: 1110;
                    readonly runtimeMessage: "Invalid target language";
                    readonly retryable: false;
                };
                readonly service_not_enabled: {
                    readonly code: 1111;
                    readonly runtimeMessage: "Translation service is not enabled";
                    readonly aliases: readonly ["service not open!"];
                    readonly retryable: false;
                };
                readonly translate_usage_limit: {
                    readonly code: 1112;
                    readonly runtimeMessage: "Translation quota has been reached";
                    readonly aliases: readonly ["The request has reached the maximum limit"];
                    readonly retryable: false;
                };
                readonly translate_failed: {
                    readonly code: 1113;
                    readonly runtimeMessage: "Translation service error";
                    readonly aliases: readonly ["The request failed, please try again later."];
                    readonly retryable: false;
                };
            };
        };
        readonly voiceMessageToText: {
            readonly range: "4,110,202,407-411,505";
            readonly localErrors: {
                readonly voiceMessageToText: {
                    readonly validation_invalid: {
                        readonly code: 407;
                        readonly retryable: false;
                    };
                    readonly file_not_found: {
                        readonly code: 410;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly unauthorized: {
                    readonly code: 202;
                    readonly retryable: true;
                };
                readonly file_not_found: {
                    readonly code: 410;
                    readonly retryable: false;
                    readonly aliases: readonly ["4041001"];
                };
                readonly file_invalid: {
                    readonly code: 407;
                    readonly retryable: false;
                    readonly aliases: readonly ["4001002"];
                };
                readonly duration_too_long: {
                    readonly code: 408;
                    readonly retryable: false;
                    readonly aliases: readonly ["4001003"];
                };
                readonly file_too_large: {
                    readonly code: 411;
                    readonly retryable: false;
                    readonly aliases: readonly ["4001001"];
                };
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly retryable: false;
                    readonly aliases: readonly ["4031001"];
                };
                readonly service_limit_exceeded: {
                    readonly code: 4;
                    readonly retryable: true;
                    readonly aliases: readonly ["4031002"];
                };
                readonly voice_to_text_failed: {
                    readonly code: 409;
                    readonly retryable: true;
                    readonly aliases: readonly ["5021003", "5001003"];
                };
            };
        };
        readonly voiceFileToText: {
            readonly range: "4,110,202,402,407-411,505";
            readonly localErrors: {
                readonly voiceFileToText: {
                    readonly validation_invalid: {
                        readonly code: 407;
                        readonly retryable: false;
                    };
                    readonly upload_required: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly unauthorized: {
                    readonly code: 202;
                    readonly retryable: true;
                };
                readonly upload_failed: {
                    readonly code: 402;
                    readonly retryable: true;
                    readonly aliases: readonly ["5021001"];
                };
                readonly file_invalid: {
                    readonly code: 407;
                    readonly retryable: false;
                    readonly aliases: readonly ["4001002"];
                };
                readonly duration_too_long: {
                    readonly code: 408;
                    readonly retryable: false;
                    readonly aliases: readonly ["4001003"];
                };
                readonly file_too_large: {
                    readonly code: 411;
                    readonly retryable: false;
                    readonly aliases: readonly ["4001001"];
                };
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly retryable: false;
                    readonly aliases: readonly ["4031001"];
                };
                readonly service_limit_exceeded: {
                    readonly code: 4;
                    readonly retryable: true;
                    readonly aliases: readonly ["4031002"];
                };
                readonly voice_to_text_failed: {
                    readonly code: 409;
                    readonly retryable: true;
                    readonly aliases: readonly ["5021003", "5001003"];
                };
            };
        };
        readonly getConversationList: {
            readonly range: "110";
            readonly localErrors: {
                readonly getConversationList: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {};
        };
        readonly getPinnedConversationList: {
            readonly range: "110";
            readonly localErrors: {
                readonly getPinnedConversationList: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {};
        };
        readonly getConversationListByMark: {
            readonly range: "110";
            readonly localErrors: {
                readonly getConversationListByMark: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {};
        };
        readonly deleteConversation: {
            readonly range: "110";
            readonly localErrors: {
                readonly deleteConversation: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {};
        };
        readonly clearConversationUnreadMessageCount: {
            readonly range: "110,201,300,500";
            readonly localErrors: {
                readonly clearConversationUnreadMessageCount: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly retryable: true;
                };
                readonly not_connected: {
                    readonly code: 300;
                    readonly retryable: true;
                };
                readonly message_invalid: {
                    readonly code: 500;
                    readonly retryable: false;
                };
            };
        };
        readonly clearAllConversationUnreadMessageCount: {
            readonly range: "201,300,500";
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly retryable: true;
                };
                readonly not_connected: {
                    readonly code: 300;
                    readonly retryable: true;
                };
                readonly message_invalid: {
                    readonly code: 500;
                    readonly retryable: false;
                };
            };
        };
        readonly sendMessageReadReceipts: {
            readonly range: "110,300";
            readonly localErrors: {
                readonly sendMessageReadReceipts: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly invalid_direction: {
                    readonly code: 110;
                    readonly retryable: false;
                };
                readonly not_connected: {
                    readonly code: 300;
                    readonly retryable: true;
                };
            };
        };
        readonly getGroupMessageReadReceipts: {
            readonly range: "110,202,210,303";
            readonly localErrors: {
                readonly getGroupMessageReadReceipts: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly illegal_argument: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly auth_bad_access_token: {
                    readonly code: 202;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly forbidden_op: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
                readonly unknown_exception_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                };
            };
        };
        readonly setConversationPinned: {
            readonly range: "110";
            readonly localErrors: {
                readonly setConversationPinned: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {};
        };
        readonly addConversationMark: {
            readonly range: "110";
            readonly localErrors: {
                readonly addConversationMark: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {};
        };
        readonly removeConversationMark: {
            readonly range: "110";
            readonly localErrors: {
                readonly removeConversationMark: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {};
        };
        readonly clearAllMessagesAndConversations: {
            readonly range: "";
            readonly errors: {};
        };
        readonly searchMessages: {
            readonly range: "110,202,303,505";
            readonly localErrors: {
                readonly searchMessages: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly parameter_error: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly aliases: readonly ["4000005", "4000006"];
                };
                readonly token_invalid: {
                    readonly code: 202;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly aliases: readonly ["4010101"];
                };
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["4030204"];
                };
                readonly app_not_found: {
                    readonly code: 110;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["4040302"];
                };
                readonly server_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                    readonly aliases: readonly ["5000701", "5020801"];
                };
            };
        };
    };
};
