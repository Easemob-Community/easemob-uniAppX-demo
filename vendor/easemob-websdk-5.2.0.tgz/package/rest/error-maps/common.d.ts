export declare const COMMON_ERROR_MAP: {
    readonly common: {
        readonly validation: {
            readonly range: "100-110";
            readonly errors: {
                readonly MISSING_REQUIRED: {
                    readonly code: 110;
                };
                readonly INVALID_FORMAT: {
                    readonly code: 110;
                };
                readonly UNKNOWN: {
                    readonly code: 110;
                };
            };
        };
        readonly auth: {
            readonly range: "108,200-215";
            readonly errors: {
                readonly ALREADY_LOGIN: {
                    readonly code: 200;
                };
                readonly NOT_LOGIN: {
                    readonly code: 201;
                };
                readonly UNAUTHORIZED: {
                    readonly code: 202;
                };
                readonly FORBIDDEN: {
                    readonly code: 210;
                };
                readonly TOKEN_EXPIRED: {
                    readonly code: 108;
                };
                readonly BIND_ANOTHER_DEVICE: {
                    readonly code: 213;
                };
                readonly LOGIN_TOO_MANY_DEVICES: {
                    readonly code: 214;
                };
                readonly USER_MUTED: {
                    readonly code: 215;
                };
            };
        };
        readonly connection: {
            readonly range: "1,100,202,300-304";
            readonly errors: {
                readonly TIMEOUT: {
                    readonly code: 301;
                };
                readonly LOGIN_TIMEOUT: {
                    readonly code: 301;
                };
                readonly WEBSOCKET_ERROR: {
                    readonly code: 300;
                };
                readonly NOT_CREATED: {
                    readonly code: 1;
                };
                readonly CLOSED_BEFORE_READY: {
                    readonly code: 300;
                };
                readonly CANCELLED: {
                    readonly code: 1;
                };
                readonly PROVISION_TIMEOUT: {
                    readonly code: 301;
                };
                readonly PROVISION_REJECTED: {
                    readonly code: 202;
                };
                readonly PROVISION_CLOSED: {
                    readonly code: 300;
                };
                readonly DNSLIST_FAILED: {
                    readonly code: 304;
                };
                readonly SERVER_BUSY: {
                    readonly code: 302;
                };
            };
        };
        readonly storage: {
            readonly range: "3";
            readonly errors: {
                readonly OPERATION_FAILED: {
                    readonly code: 3;
                };
            };
        };
        readonly message: {
            readonly range: "1,300-511";
            readonly errors: {
                readonly NOT_CONNECTED: {
                    readonly code: 300;
                };
                readonly ACK_TIMEOUT: {
                    readonly code: 301;
                };
                readonly SEND_FAILED: {
                    readonly code: 303;
                };
                readonly SENDER_DESTROYED: {
                    readonly code: 1;
                };
                readonly ENCODE_FAILED: {
                    readonly code: 500;
                };
                readonly DECODE_FAILED: {
                    readonly code: 500;
                };
                readonly ACK_MISSING: {
                    readonly code: 301;
                };
            };
        };
        readonly transport: {
            readonly range: "2,301,303";
            readonly errors: {
                readonly NETWORK_ERROR: {
                    readonly code: 2;
                };
                readonly TIMEOUT: {
                    readonly code: 301;
                };
                readonly HTTP_ERROR: {
                    readonly code: 303;
                };
                readonly BUSINESS_UNKNOWN: {
                    readonly code: 303;
                };
            };
        };
        readonly upload: {
            readonly range: "1,100,110,301,402,405";
            readonly errors: {
                readonly REQUIRED_FIELD_MISSING: {
                    readonly code: 110;
                };
                readonly INVALID_APPKEY: {
                    readonly code: 100;
                };
                readonly SIZE_EXCEEDED: {
                    readonly code: 405;
                };
                readonly REQUEST_FAILED: {
                    readonly code: 402;
                };
                readonly TIMEOUT: {
                    readonly code: 301;
                };
                readonly ABORTED: {
                    readonly code: 1;
                };
            };
        };
        readonly unknown: {
            readonly range: "1,4";
            readonly errors: {
                readonly UNKNOWN: {
                    readonly code: 1;
                };
                readonly SERVICE_LIMIT_EXCEEDED: {
                    readonly code: 4;
                };
            };
        };
        readonly push: {
            readonly range: "1500,1501,1502";
            readonly errors: {
                readonly TOKEN_UPLOAD_FAILED: {
                    readonly code: 1500;
                };
                readonly SILENT_MODE_OPERATION_FAILED: {
                    readonly code: 1501;
                };
                readonly PUSH_LANGUAGE_OPERATION_FAILED: {
                    readonly code: 1502;
                };
            };
        };
        readonly chatroom: {
            readonly range: "700-707";
            readonly errors: {
                readonly CHATROOM_INVALID_ID: {
                    readonly code: 700;
                };
                readonly CHATROOM_NOT_JOINED: {
                    readonly code: 702;
                };
                readonly CHATROOM_PERMISSION_DENIED: {
                    readonly code: 703;
                };
                readonly CHATROOM_MEMBERS_FULL: {
                    readonly code: 704;
                };
                readonly CHATROOM_NOT_EXIST: {
                    readonly code: 705;
                };
                readonly CHATROOM_OWNER_NOT_ALLOW_LEAVE: {
                    readonly code: 706;
                };
                readonly CHATROOM_USER_IN_BLOCKLIST: {
                    readonly code: 707;
                };
            };
        };
    };
    readonly apis: {};
};
