export declare const PRESENCE_ERROR_MAP: {
    readonly common: {};
    readonly apis: {
        readonly publishPresence: {
            readonly range: "1100";
            readonly errors: {
                readonly PRESENCE_PARAM_EXCEED: {
                    readonly code: 1100;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
            };
        };
        readonly subscribePresences: {
            readonly range: "1100,1101";
            readonly errors: {
                readonly cannot_subscribe_yourself: {
                    readonly code: 1101;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "result";
                    readonly matchPattern: "you can't sub yourself";
                };
                readonly param_length_exceed: {
                    readonly code: 1100;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
            };
        };
        readonly unsubscribePresence: {
            readonly range: "1100";
            readonly errors: {
                readonly param_length_exceed: {
                    readonly code: 1100;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
            };
        };
        readonly getSubscribedPresenceList: {
            readonly range: "1100";
            readonly errors: {
                readonly param_length_exceed: {
                    readonly code: 1100;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
            };
        };
        readonly getPresenceStatus: {
            readonly range: "1100";
            readonly errors: {
                readonly param_length_exceed: {
                    readonly code: 1100;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
            };
        };
    };
};
