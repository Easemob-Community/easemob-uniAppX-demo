export declare const CORE_ERROR_MAP: {
    readonly common: {};
    readonly apis: {
        readonly getSelfIdsOnOtherPlatform: {
            readonly range: "202,300-303";
            readonly errors: {};
        };
        readonly getTokenExpireTimestamp: {
            readonly range: "";
            readonly errors: {};
        };
        readonly getRtcTokenInfo: {
            readonly range: "";
            readonly errors: {};
        };
        readonly getUserIdsWithRtcUids: {
            readonly range: "";
            readonly errors: {};
        };
    };
};
