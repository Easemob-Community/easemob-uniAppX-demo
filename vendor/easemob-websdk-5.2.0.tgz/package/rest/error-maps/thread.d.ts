export declare const THREAD_ERROR_MAP: {
    readonly common: {};
    readonly apis: {
        readonly createChatThread: {
            readonly range: "4,110,201,210,301,303,606";
            readonly localErrors: {
                readonly createChatThread: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly aliases: readonly ["unauthorized"];
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["group_authorization", "forbidden"];
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "GROUP_NOT_FOUND"];
                };
                readonly service_limit_exceeded: {
                    readonly code: 4;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly aliases: readonly ["limit_exceeded"];
                };
                readonly request_timeout: {
                    readonly code: 301;
                    readonly httpStatus: 504;
                    readonly retryable: true;
                    readonly aliases: readonly ["timeout"];
                };
                readonly service_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                    readonly aliases: readonly ["server_unknown_error"];
                };
            };
        };
        readonly getChatThreadList: {
            readonly range: "110,201,210,301,303,606";
            readonly localErrors: {
                readonly getChatThreadList: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly aliases: readonly ["unauthorized"];
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["group_authorization", "forbidden"];
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "GROUP_NOT_FOUND"];
                };
                readonly request_timeout: {
                    readonly code: 301;
                    readonly httpStatus: 504;
                    readonly retryable: true;
                    readonly aliases: readonly ["timeout"];
                };
                readonly service_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                    readonly aliases: readonly ["server_unknown_error"];
                };
            };
        };
        readonly getJoinedChatThreadList: {
            readonly range: "110,201,210,301,303,606";
            readonly localErrors: {
                readonly getJoinedChatThreadList: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly aliases: readonly ["unauthorized"];
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["group_authorization", "forbidden"];
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "GROUP_NOT_FOUND"];
                };
                readonly request_timeout: {
                    readonly code: 301;
                    readonly httpStatus: 504;
                    readonly retryable: true;
                    readonly aliases: readonly ["timeout"];
                };
                readonly service_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                    readonly aliases: readonly ["server_unknown_error"];
                };
            };
        };
        readonly getChatThreadInfo: {
            readonly range: "110,201,210,301,303,606";
            readonly localErrors: {
                readonly getChatThreadInfo: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly getInfo: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly refresh: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly aliases: readonly ["unauthorized"];
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["group_authorization", "forbidden"];
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "THREAD_NOT_FOUND"];
                };
                readonly request_timeout: {
                    readonly code: 301;
                    readonly httpStatus: 504;
                    readonly retryable: true;
                    readonly aliases: readonly ["timeout"];
                };
                readonly service_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                    readonly aliases: readonly ["server_unknown_error"];
                };
            };
        };
        readonly joinChatThread: {
            readonly range: "4,110,201,210,301,303,606";
            readonly localErrors: {
                readonly joinChatThread: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly join: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly aliases: readonly ["unauthorized"];
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["group_authorization", "forbidden"];
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "THREAD_NOT_FOUND"];
                };
                readonly service_limit_exceeded: {
                    readonly code: 4;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly aliases: readonly ["limit_exceeded"];
                };
                readonly request_timeout: {
                    readonly code: 301;
                    readonly httpStatus: 504;
                    readonly retryable: true;
                    readonly aliases: readonly ["timeout"];
                };
                readonly service_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                    readonly aliases: readonly ["server_unknown_error"];
                };
            };
        };
        readonly leaveChatThread: {
            readonly range: "110,201,210,301,303,606";
            readonly localErrors: {
                readonly leaveChatThread: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly leave: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly aliases: readonly ["unauthorized"];
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["group_authorization", "forbidden"];
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "THREAD_NOT_FOUND"];
                };
                readonly request_timeout: {
                    readonly code: 301;
                    readonly httpStatus: 504;
                    readonly retryable: true;
                    readonly aliases: readonly ["timeout"];
                };
                readonly service_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                    readonly aliases: readonly ["server_unknown_error"];
                };
            };
        };
        readonly destroyChatThread: {
            readonly range: "110,201,210,301,303,606";
            readonly localErrors: {
                readonly destroyChatThread: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly destroy: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly aliases: readonly ["unauthorized"];
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["group_authorization", "forbidden"];
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "THREAD_NOT_FOUND"];
                };
                readonly request_timeout: {
                    readonly code: 301;
                    readonly httpStatus: 504;
                    readonly retryable: true;
                    readonly aliases: readonly ["timeout"];
                };
                readonly service_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                    readonly aliases: readonly ["server_unknown_error"];
                };
            };
        };
        readonly updateChatThreadName: {
            readonly range: "110,201,210,301,303,606";
            readonly localErrors: {
                readonly updateChatThreadName: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly updateName: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly aliases: readonly ["unauthorized"];
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["group_authorization", "forbidden"];
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "THREAD_NOT_FOUND"];
                };
                readonly request_timeout: {
                    readonly code: 301;
                    readonly httpStatus: 504;
                    readonly retryable: true;
                    readonly aliases: readonly ["timeout"];
                };
                readonly service_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                    readonly aliases: readonly ["server_unknown_error"];
                };
            };
        };
        readonly getChatThreadMemberList: {
            readonly range: "110,201,210,301,303,606";
            readonly localErrors: {
                readonly getChatThreadMemberList: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly getMemberList: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly aliases: readonly ["unauthorized"];
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["group_authorization", "forbidden"];
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "THREAD_NOT_FOUND"];
                };
                readonly request_timeout: {
                    readonly code: 301;
                    readonly httpStatus: 504;
                    readonly retryable: true;
                    readonly aliases: readonly ["timeout"];
                };
                readonly service_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                    readonly aliases: readonly ["server_unknown_error"];
                };
            };
        };
        readonly removeChatThreadMember: {
            readonly range: "110,201,210,301,303,606";
            readonly localErrors: {
                readonly removeChatThreadMember: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly removeMember: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly aliases: readonly ["unauthorized"];
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["group_authorization", "forbidden"];
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "THREAD_NOT_FOUND"];
                };
                readonly request_timeout: {
                    readonly code: 301;
                    readonly httpStatus: 504;
                    readonly retryable: true;
                    readonly aliases: readonly ["timeout"];
                };
                readonly service_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                    readonly aliases: readonly ["server_unknown_error"];
                };
            };
        };
        readonly getChatThreadLastMessageList: {
            readonly range: "110,201,210,301,303,606";
            readonly localErrors: {
                readonly getChatThreadLastMessageList: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly not_login: {
                    readonly code: 201;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly aliases: readonly ["unauthorized"];
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["group_authorization", "forbidden"];
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "THREAD_NOT_FOUND"];
                };
                readonly request_timeout: {
                    readonly code: 301;
                    readonly httpStatus: 504;
                    readonly retryable: true;
                    readonly aliases: readonly ["timeout"];
                };
                readonly service_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                    readonly aliases: readonly ["server_unknown_error"];
                };
            };
        };
    };
};
