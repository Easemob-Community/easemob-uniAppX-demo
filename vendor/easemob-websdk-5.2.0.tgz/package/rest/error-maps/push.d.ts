export declare const PUSH_ERROR_MAP: {
    readonly common: {};
    readonly apis: {
        readonly setGlobalSilentMode: {
            readonly range: "110,1501";
            readonly localErrors: {
                readonly setGlobalSilentMode: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly SILENT_MODE_OPERATION_FAILED: {
                    readonly code: 1501;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
            };
        };
        readonly setConversationSilentMode: {
            readonly range: "110,1501";
            readonly localErrors: {
                readonly setConversationSilentMode: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly SILENT_MODE_OPERATION_FAILED: {
                    readonly code: 1501;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
            };
        };
        readonly setPushLanguage: {
            readonly range: "110,1502";
            readonly localErrors: {
                readonly setPushLanguage: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly PUSH_LANGUAGE_OPERATION_FAILED: {
                    readonly code: 1502;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
            };
        };
        readonly uploadPushToken: {
            readonly range: "110,201,1500";
            readonly localErrors: {
                readonly uploadPushToken: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly setNativePush: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly removePushToken: {
                    readonly auth_not_login: {
                        readonly code: 201;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly TOKEN_UPLOAD_FAILED: {
                    readonly code: 1500;
                    readonly httpStatus: 400;
                    readonly retryable: true;
                };
            };
        };
        readonly getGlobalSilentMode: {
            readonly range: "1501";
            readonly errors: {
                readonly SILENT_MODE_OPERATION_FAILED: {
                    readonly code: 1501;
                    readonly retryable: false;
                };
            };
        };
        readonly getConversationSilentMode: {
            readonly range: "110,1501";
            readonly localErrors: {
                readonly getConversationSilentMode: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly SILENT_MODE_OPERATION_FAILED: {
                    readonly code: 1501;
                    readonly retryable: false;
                };
            };
        };
        readonly clearConversationRemindType: {
            readonly range: "110,1501";
            readonly localErrors: {
                readonly clearConversationRemindType: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly SILENT_MODE_OPERATION_FAILED: {
                    readonly code: 1501;
                    readonly retryable: false;
                };
            };
        };
        readonly getConversationSilentModes: {
            readonly range: "110,1501";
            readonly localErrors: {
                readonly getConversationSilentModes: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly SILENT_MODE_OPERATION_FAILED: {
                    readonly code: 1501;
                    readonly retryable: false;
                };
            };
        };
        readonly getConversationListByRemindType: {
            readonly range: "110";
            readonly localErrors: {
                readonly getConversationListByRemindType: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {};
        };
        readonly getPushLanguage: {
            readonly range: "1502";
            readonly errors: {
                readonly PUSH_LANGUAGE_OPERATION_FAILED: {
                    readonly code: 1502;
                    readonly retryable: false;
                };
            };
        };
    };
};
