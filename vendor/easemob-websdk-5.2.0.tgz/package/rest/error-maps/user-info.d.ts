export declare const USER_INFO_ERROR_MAP: {
    readonly common: {};
    readonly apis: {
        readonly updateOwnUserInfo: {
            readonly range: "4,110,204,303,505,901";
            readonly localErrors: {
                readonly updateOwnInfo: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly updateOwnInfoByAttribute: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "desc";
                    readonly matchPattern: "user metadata service not allow";
                };
                readonly data_length_exceed: {
                    readonly code: 901;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "desc";
                    readonly matchPattern: "exceeds";
                };
                readonly concurrent_update_conflict: {
                    readonly code: 303;
                    readonly httpStatus: 409;
                    readonly retryable: true;
                    readonly matchField: "desc";
                    readonly matchPattern: "Concurrent";
                };
                readonly resource_not_found: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly rate_limit: {
                    readonly code: 4;
                    readonly httpStatus: 429;
                    readonly retryable: true;
                };
            };
        };
        readonly updateOwnInfo: {
            readonly range: "4,110,204,303,505,901";
            readonly localErrors: {
                readonly updateOwnInfo: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly updateOwnInfoByAttribute: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "desc";
                    readonly matchPattern: "user metadata service not allow";
                };
                readonly data_length_exceed: {
                    readonly code: 901;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "desc";
                    readonly matchPattern: "exceeds";
                };
                readonly concurrent_update_conflict: {
                    readonly code: 303;
                    readonly httpStatus: 409;
                    readonly retryable: true;
                    readonly matchField: "desc";
                    readonly matchPattern: "Concurrent";
                };
                readonly resource_not_found: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly rate_limit: {
                    readonly code: 4;
                    readonly httpStatus: 429;
                    readonly retryable: true;
                };
            };
        };
        readonly updateOwnInfoByAttribute: {
            readonly range: "4,110,204,303,505,901";
            readonly localErrors: {
                readonly updateOwnInfo: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
                readonly updateOwnInfoByAttribute: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly service_not_enabled: {
                    readonly code: 505;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "desc";
                    readonly matchPattern: "user metadata service not allow";
                };
                readonly data_length_exceed: {
                    readonly code: 901;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "desc";
                    readonly matchPattern: "exceeds";
                };
                readonly concurrent_update_conflict: {
                    readonly code: 303;
                    readonly httpStatus: 409;
                    readonly retryable: true;
                    readonly matchField: "desc";
                    readonly matchPattern: "Concurrent";
                };
                readonly resource_not_found: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly rate_limit: {
                    readonly code: 4;
                    readonly httpStatus: 429;
                    readonly retryable: true;
                };
            };
        };
        readonly getUserInfoByUserId: {
            readonly range: "4,110,204,900";
            readonly localErrors: {
                readonly getUserInfoByUserId: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly usercount_exceed: {
                    readonly code: 900;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly rate_limit: {
                    readonly code: 4;
                    readonly httpStatus: 429;
                    readonly retryable: true;
                };
            };
        };
        readonly getUserInfoByAttribute: {
            readonly range: "4,110,204,900";
            readonly localErrors: {
                readonly getUserInfoByAttribute: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly usercount_exceed: {
                    readonly code: 900;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly rate_limit: {
                    readonly code: 4;
                    readonly httpStatus: 429;
                    readonly retryable: true;
                };
            };
        };
        readonly subscribeUsersInfo: {
            readonly range: "4,202,210,303,1600,1601";
            readonly errors: {
                readonly unauthorized: {
                    readonly code: 202;
                    readonly httpStatus: 401;
                    readonly retryable: true;
                };
                readonly forbidden: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly aliases: readonly ["operation forbidden"];
                    readonly matchField: "error_description";
                    readonly matchPattern: "metadata subscription not allow";
                    readonly retryable: false;
                };
                readonly subscriber_limit_exceeded: {
                    readonly code: 1600;
                    readonly httpStatus: 400;
                    readonly matchField: "error_description";
                    readonly matchPattern: "metadata subscription count exceeds limit";
                    readonly retryable: false;
                };
                readonly target_limit_exceeded: {
                    readonly code: 1601;
                    readonly httpStatus: 400;
                    readonly matchField: "error_description";
                    readonly matchPattern: "metadata subscribed count exceeds limit";
                    readonly retryable: false;
                };
                readonly rate_limit: {
                    readonly code: 4;
                    readonly httpStatus: 429;
                    readonly retryable: true;
                };
                readonly server_unknown_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                };
            };
        };
        readonly unsubscribeUsersInfo: {
            readonly range: "4,202,210,303,1600,1601";
            readonly errors: {
                readonly unauthorized: {
                    readonly code: 202;
                    readonly httpStatus: 401;
                    readonly retryable: true;
                };
                readonly forbidden: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly aliases: readonly ["operation forbidden"];
                    readonly matchField: "error_description";
                    readonly matchPattern: "metadata subscription not allow";
                    readonly retryable: false;
                };
                readonly subscriber_limit_exceeded: {
                    readonly code: 1600;
                    readonly httpStatus: 400;
                    readonly matchField: "error_description";
                    readonly matchPattern: "metadata subscription count exceeds limit";
                    readonly retryable: false;
                };
                readonly target_limit_exceeded: {
                    readonly code: 1601;
                    readonly httpStatus: 400;
                    readonly matchField: "error_description";
                    readonly matchPattern: "metadata subscribed count exceeds limit";
                    readonly retryable: false;
                };
                readonly rate_limit: {
                    readonly code: 4;
                    readonly httpStatus: 429;
                    readonly retryable: true;
                };
                readonly server_unknown_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                };
            };
        };
        readonly getSubscribedUsers: {
            readonly range: "4,202,210,303,1600,1601";
            readonly errors: {
                readonly unauthorized: {
                    readonly code: 202;
                    readonly httpStatus: 401;
                    readonly retryable: true;
                };
                readonly forbidden: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly aliases: readonly ["operation forbidden"];
                    readonly matchField: "error_description";
                    readonly matchPattern: "metadata subscription not allow";
                    readonly retryable: false;
                };
                readonly subscriber_limit_exceeded: {
                    readonly code: 1600;
                    readonly httpStatus: 400;
                    readonly matchField: "error_description";
                    readonly matchPattern: "metadata subscription count exceeds limit";
                    readonly retryable: false;
                };
                readonly target_limit_exceeded: {
                    readonly code: 1601;
                    readonly httpStatus: 400;
                    readonly matchField: "error_description";
                    readonly matchPattern: "metadata subscribed count exceeds limit";
                    readonly retryable: false;
                };
                readonly rate_limit: {
                    readonly code: 4;
                    readonly httpStatus: 429;
                    readonly retryable: true;
                };
                readonly server_unknown_error: {
                    readonly code: 303;
                    readonly httpStatus: 500;
                    readonly retryable: true;
                };
            };
        };
    };
};
