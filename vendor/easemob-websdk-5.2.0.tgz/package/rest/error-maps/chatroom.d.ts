export declare const CHATROOM_ERROR_MAP: {
    readonly common: {};
    readonly apis: {
        readonly getChatRoomList: {
            readonly range: "";
            readonly errors: {};
        };
        readonly getChatRoomInfo: {
            readonly range: "705";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly runtimeMessage: "Chat room does not exist";
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found"];
                };
            };
        };
        readonly updateChatRoomInfo: {
            readonly range: "110,210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly forbidden_op: {
                    readonly code: 110;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
                readonly illegal_argument: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly destroyChatRoom: {
            readonly range: "210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly joinChatRoom: {
            readonly range: "4,705,704,707";
            readonly errors: {
                readonly exceed_limit: {
                    readonly code: 4;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
                readonly members_full: {
                    readonly code: 704;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "error_description";
                    readonly matchPattern: "member list is full";
                };
                readonly user_in_blocklist: {
                    readonly code: 707;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "error_description";
                    readonly matchPattern: "is in the blacklist";
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly leaveChatRoom: {
            readonly range: "705";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly getChatRoomMemberList: {
            readonly range: "705";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly runtimeMessage: "Chat room does not exist";
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found"];
                };
            };
        };
        readonly addChatRoomMembers: {
            readonly range: "110,204,210,705";
            readonly errors: {
                readonly illegal_argument: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly service_resource_not_found: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly removeChatRoomMembers: {
            readonly range: "210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly getChatRoomAdminList: {
            readonly range: "705";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly setChatRoomAdmin: {
            readonly range: "204,210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly service_resource_not_found: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly removeChatRoomAdmin: {
            readonly range: "210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly getChatRoomMuteList: {
            readonly range: "705";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly muteChatRoomMembers: {
            readonly range: "110,210,705";
            readonly errors: {
                readonly illegal_argument: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly unmuteChatRoomMembers: {
            readonly range: "210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly muteAllChatRoomMembers: {
            readonly range: "210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly unmuteAllChatRoomMembers: {
            readonly range: "210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly isCurrentUserMutedInChatRoom: {
            readonly range: "705";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly runtimeMessage: "Chat room does not exist";
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["30005"];
                };
            };
        };
        readonly getChatRoomBlocklist: {
            readonly range: "705";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly blockChatRoomMembers: {
            readonly range: "204,210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly service_resource_not_found: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly unblockChatRoomMembers: {
            readonly range: "210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly getChatRoomAllowlist: {
            readonly range: "705";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly addUsersToChatRoomAllowlist: {
            readonly range: "204,210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly service_resource_not_found: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly removeUsersFromChatRoomAllowlist: {
            readonly range: "210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly checkIfInChatRoomAllowList: {
            readonly range: "705";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly getChatRoomAnnouncement: {
            readonly range: "705";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly updateChatRoomAnnouncement: {
            readonly range: "110,210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly forbidden_op: {
                    readonly code: 110;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly getChatRoomSharedFileList: {
            readonly range: "705";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly deleteChatRoomSharedFile: {
            readonly range: "210,705";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly getChatRoomAttributes: {
            readonly range: "110,705";
            readonly errors: {
                readonly illegal_argument: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 705;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly setChatRoomAttributes: {
            readonly range: "110,210,702,703,4";
            readonly errors: {
                readonly illegal_argument: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly chatroom_not_joined: {
                    readonly code: 702;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60011;
                };
                readonly chatroom_permission_denied: {
                    readonly code: 703;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60010;
                };
                readonly exceed_limit: {
                    readonly code: 4;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60012;
                };
                readonly MetadataException: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
            };
        };
        readonly setChatRoomAttribute: {
            readonly range: "110,210,702,703,4";
            readonly errors: {
                readonly illegal_argument: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly chatroom_not_joined: {
                    readonly code: 702;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60011;
                };
                readonly chatroom_permission_denied: {
                    readonly code: 703;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60010;
                };
                readonly exceed_limit: {
                    readonly code: 4;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60012;
                };
                readonly MetadataException: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
            };
        };
        readonly removeChatRoomAttributes: {
            readonly range: "110,210,702,703,4";
            readonly errors: {
                readonly illegal_argument: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly chatroom_not_joined: {
                    readonly code: 702;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60011;
                };
                readonly chatroom_permission_denied: {
                    readonly code: 703;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60010;
                };
                readonly exceed_limit: {
                    readonly code: 4;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60012;
                };
                readonly MetadataException: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
            };
        };
        readonly removeChatRoomAttribute: {
            readonly range: "110,210,702,703,4";
            readonly errors: {
                readonly illegal_argument: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly chatroom_not_joined: {
                    readonly code: 702;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60011;
                };
                readonly chatroom_permission_denied: {
                    readonly code: 703;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60010;
                };
                readonly exceed_limit: {
                    readonly code: 4;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60012;
                };
                readonly MetadataException: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                };
            };
        };
    };
};
