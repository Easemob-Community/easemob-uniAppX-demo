export declare const CONTACT_ERROR_MAP: {
    readonly common: {};
    readonly apis: {
        readonly getContactList: {
            readonly range: "";
            readonly errors: {};
        };
        readonly addContact: {
            readonly range: "110,204,210,1000,1001,1002";
            readonly localErrors: {
                readonly addContact: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                    readonly cannot_add_self: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly USER_NOT_FOUND: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly ALREADY_FRIEND: {
                    readonly code: 1000;
                    readonly retryable: false;
                };
                readonly BLOCKED_BY_USER: {
                    readonly code: 210;
                    readonly retryable: false;
                };
                readonly CONTACT_REACH_LIMIT: {
                    readonly code: 1001;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "error_description";
                    readonly matchPattern: "Inviter's contact max count";
                };
                readonly CONTACT_REACH_LIMIT_PEER: {
                    readonly code: 1002;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "error_description";
                    readonly matchPattern: "Invitee's contact max count";
                };
            };
        };
        readonly deleteContact: {
            readonly range: "110,204";
            readonly localErrors: {
                readonly deleteContact: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly USER_NOT_FOUND: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found"];
                };
            };
        };
        readonly acceptContactInvite: {
            readonly range: "110,204,1001,1002";
            readonly localErrors: {
                readonly acceptContactInvite: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly USER_NOT_FOUND: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly CONTACT_REACH_LIMIT: {
                    readonly code: 1001;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "error_description";
                    readonly matchPattern: "Inviter's contact max count";
                };
                readonly CONTACT_REACH_LIMIT_PEER: {
                    readonly code: 1002;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "error_description";
                    readonly matchPattern: "Invitee's contact max count";
                };
            };
        };
        readonly declineContactInvite: {
            readonly range: "110,204";
            readonly localErrors: {
                readonly declineContactInvite: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly USER_NOT_FOUND: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly setContactRemark: {
            readonly range: "4,110,221";
            readonly localErrors: {
                readonly setContactRemark: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly USER_NOT_ON_ROSTER: {
                    readonly code: 221;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_description";
                    readonly matchPattern: "please add as a friend first";
                };
                readonly remark_length_exceeded: {
                    readonly code: 4;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_description";
                    readonly matchPattern: "remark length must less than";
                };
            };
        };
        readonly getBlocklist: {
            readonly range: "";
            readonly errors: {};
        };
        readonly addUsersToBlocklist: {
            readonly range: "4,110,204";
            readonly localErrors: {
                readonly addUsersToBlocklist: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {
                readonly service_resource_not_found: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly blocklist_limit_exceeded: {
                    readonly code: 4;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_description";
                    readonly matchPattern: "almost reached or been greater than the upper range";
                };
            };
        };
        readonly removeUserFromBlocklist: {
            readonly range: "110";
            readonly localErrors: {
                readonly removeUserFromBlocklist: {
                    readonly validation_invalid: {
                        readonly code: 110;
                        readonly retryable: false;
                    };
                };
            };
            readonly errors: {};
        };
    };
};
