export declare const GROUP_ERROR_MAP: {
    readonly common: {};
    readonly apis: {
        readonly createGroup: {
            readonly range: "4,110,204,608";
            readonly errors: {
                readonly invalid_parameter: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly illegal_argument: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly exceed_limit: {
                    readonly code: 4;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
                readonly group_name_violation: {
                    readonly code: 608;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["INVALID_GROUP_NAME"];
                };
                readonly resource_not_found: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "username_not_found"];
                };
            };
        };
        readonly getJoinedGroupList: {
            readonly range: "";
            readonly errors: {};
        };
        readonly getGroupInfo: {
            readonly range: "606";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly getGroupInfoList: {
            readonly range: "606";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly updateGroupInfo: {
            readonly range: "110,603,606,607,608";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 603;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
                readonly forbidden_op: {
                    readonly code: 603;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
                readonly illegal_argument: {
                    readonly code: 110;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly exceed_limit: {
                    readonly code: 110;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
                readonly group_name_violation: {
                    readonly code: 608;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly group_disabled: {
                    readonly code: 607;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
            };
        };
        readonly changeGroupOwner: {
            readonly range: "603,606";
            readonly errors: {
                readonly forbidden_op: {
                    readonly code: 603;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly destroyGroup: {
            readonly range: "603,606,607";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 603;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
                readonly group_disabled: {
                    readonly code: 607;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                };
            };
        };
        readonly leaveGroup: {
            readonly range: "602,603,606";
            readonly errors: {
                readonly not_joined: {
                    readonly code: 602;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_NOT_JOINED", "group_not_joined"];
                };
                readonly owner_cannot_leave: {
                    readonly code: 603;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "error_description";
                    readonly matchPattern: "owner can not quit group";
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly joinGroup: {
            readonly range: "600-607,613";
            readonly errors: {
                readonly group_invalid_id: {
                    readonly code: 600;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_INVALID_ID"];
                };
                readonly already_joined: {
                    readonly code: 601;
                    readonly retryable: false;
                    readonly aliases: readonly ["ALREADY_JOINED", "GROUP_ALREADY_JOINED", "group_already_joined"];
                };
                readonly not_joined: {
                    readonly code: 602;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_NOT_JOINED", "group_not_joined"];
                };
                readonly group_authorization: {
                    readonly code: 603;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["NEED_APPROVAL", "GROUP_PERMISSION_DENIED"];
                };
                readonly group_full: {
                    readonly code: 604;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_FULL", "GROUP_MEMBERS_FULL"];
                    readonly matchField: "error_description";
                    readonly matchPattern: "member list is full";
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_NOT_FOUND", "service_resource_not_found"];
                };
                readonly group_disabled: {
                    readonly code: 607;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_DISABLED"];
                };
                readonly group_user_in_blocklist: {
                    readonly code: 613;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_USER_IN_BLOCKLIST"];
                    readonly matchField: "error_description";
                    readonly matchPattern: "is in the blacklist";
                };
            };
        };
        readonly inviteUsersToGroup: {
            readonly range: "204,603,606,607";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 603;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                };
                readonly resource_not_found: {
                    readonly code: 204;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found", "username_not_found"];
                };
                readonly group_not_found: {
                    readonly code: 606;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_NOT_FOUND"];
                };
                readonly group_disabled: {
                    readonly code: 607;
                    readonly retryable: false;
                };
            };
        };
        readonly acceptGroupJoinRequest: {
            readonly range: "";
            readonly errors: {};
        };
        readonly rejectGroupJoinRequest: {
            readonly range: "";
            readonly errors: {};
        };
        readonly acceptInvitation: {
            readonly range: "";
            readonly errors: {};
        };
        readonly rejectInvitation: {
            readonly range: "";
            readonly errors: {};
        };
        readonly removeGroupMembers: {
            readonly range: "";
            readonly errors: {};
        };
        readonly addGroupAdmin: {
            readonly range: "";
            readonly errors: {};
        };
        readonly removeGroupAdmin: {
            readonly range: "";
            readonly errors: {};
        };
        readonly muteGroupMembers: {
            readonly range: "";
            readonly errors: {};
        };
        readonly unmuteGroupMembers: {
            readonly range: "";
            readonly errors: {};
        };
        readonly muteAllGroupMembers: {
            readonly range: "";
            readonly errors: {};
        };
        readonly unmuteAllGroupMembers: {
            readonly range: "";
            readonly errors: {};
        };
        readonly blockGroupMembers: {
            readonly range: "";
            readonly errors: {};
        };
        readonly unblockGroupMembers: {
            readonly range: "";
            readonly errors: {};
        };
        readonly addUsersToGroupAllowlist: {
            readonly range: "";
            readonly errors: {};
        };
        readonly removeUsersFromGroupAllowlist: {
            readonly range: "";
            readonly errors: {};
        };
        readonly checkIfInGroupAllowList: {
            readonly range: "";
            readonly errors: {};
        };
        readonly getGroupMemberList: {
            readonly range: "606";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["service_resource_not_found"];
                };
            };
        };
        readonly getGroupAdminList: {
            readonly range: "606";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly getGroupMuteList: {
            readonly range: "606";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly checkIfInGroupMuteList: {
            readonly range: "606";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly getGroupBlocklist: {
            readonly range: "606";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly getGroupAllowlist: {
            readonly range: "606";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly getGroupAnnouncement: {
            readonly range: "606";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                };
            };
        };
        readonly updateGroupAnnouncement: {
            readonly range: "110";
            readonly errors: {
                readonly announcement_length_exceeded: {
                    readonly code: 110;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "error_description";
                    readonly matchPattern: "announce into length exceeds limit";
                };
                readonly announcement_info_length_exceeded: {
                    readonly code: 110;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "error_description";
                    readonly matchPattern: "announce info length exceeds limit";
                };
            };
        };
        readonly getGroupSharedFileList: {
            readonly range: "606";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly aliases: readonly ["RestGroupFeignException"];
                };
            };
        };
        readonly deleteGroupSharedFile: {
            readonly range: "603,605,606";
            readonly errors: {
                readonly group_authorization: {
                    readonly code: 603;
                    readonly retryable: false;
                };
                readonly file_not_found: {
                    readonly code: 605;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_SHARED_FILE_INVALID_ID"];
                };
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly retryable: false;
                };
            };
        };
        readonly setGroupMemberAttributes: {
            readonly range: "4,210,302,305,602,609-612";
            readonly errors: {
                readonly attributes_reach_limit: {
                    readonly code: 609;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_MEMBER_ATTRIBUTES_REACH_LIMIT"];
                    readonly matchField: "error_code";
                    readonly matchValue: 60006;
                };
                readonly attributes_update_failed: {
                    readonly code: 610;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_MEMBER_ATTRIBUTES_UPDATE_FAILED"];
                    readonly matchField: "error_code";
                    readonly matchValue: 60005;
                };
                readonly attributes_key_reach_limit: {
                    readonly code: 611;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_MEMBER_ATTRIBUTES_KEY_REACH_LIMIT"];
                    readonly matchField: "error_code";
                    readonly matchValue: 60009;
                };
                readonly attributes_value_reach_limit: {
                    readonly code: 612;
                    readonly retryable: false;
                    readonly aliases: readonly ["GROUP_MEMBER_ATTRIBUTES_VALUE_REACH_LIMIT"];
                    readonly matchField: "error_code";
                    readonly matchValue: 600010;
                };
                readonly not_joined: {
                    readonly code: 602;
                    readonly httpStatus: 404;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60003;
                };
                readonly permission_denied: {
                    readonly code: 210;
                    readonly httpStatus: 401;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60001;
                };
                readonly permission_denied_403: {
                    readonly code: 210;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60002;
                };
                readonly exceed_service_limit: {
                    readonly code: 4;
                    readonly httpStatus: 400;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60007;
                };
                readonly service_disabled: {
                    readonly code: 305;
                    readonly httpStatus: 403;
                    readonly retryable: false;
                    readonly matchField: "error_code";
                    readonly matchValue: 60004;
                };
            };
        };
        readonly getGroupMembersAttributes: {
            readonly range: "606";
            readonly errors: {
                readonly resource_not_found: {
                    readonly code: 606;
                    readonly retryable: false;
                };
            };
        };
        readonly getGroupNamecards: {
            readonly range: "";
            readonly errors: {};
        };
    };
};
