import type { RestClient } from './client';
import type { RestContext } from '../types/chat-client';
import type { VoiceMessageBody, VoiceParams, VoiceSourceFile, VoiceToTextResult } from '../types';
import { normalizeUploadSource } from '../platform/upload/upload-source';
import { SDKError } from '../utils/errors';
interface UploadLike {
    upload(config: {
        readonly url: string;
        readonly headers?: Record<string, string>;
        readonly source: ReturnType<typeof normalizeUploadSource>['source'];
        readonly fields?: Record<string, string>;
        readonly timeoutMs?: number;
    }): Promise<{
        readonly status: number;
        readonly body: string;
    }>;
}
export declare const extractFileIdFromUrl: (url?: string) => string | undefined;
export declare const mapVoiceToTextError: (error: unknown) => SDKError;
export declare const validateVoiceMessageSource: (voiceMessageBody: unknown, voiceParams?: VoiceParams) => VoiceMessageBody;
export declare const validateVoiceSourceFile: (file: unknown, voiceParams?: VoiceParams) => VoiceSourceFile;
export declare const requestVoiceMessageToText: (client: RestClient, context: RestContext, voiceMessageBody: VoiceMessageBody, voiceParams?: VoiceParams) => Promise<VoiceToTextResult>;
export declare const requestVoiceFileToText: (uploadAdapter: UploadLike, context: RestContext, file: VoiceSourceFile, voiceParams?: VoiceParams) => Promise<VoiceToTextResult>;
export {};
