import type { RestClient } from './client';
import type { AddContactParams, BlocklistAddResult, BlocklistMutationParams, Contact, ContactMutationTarget, SetContactRemarkParams } from '../types/contact';
import type { RestContext } from '../types/chat-client';
import type { UserInfo } from '../types/user-info';
interface GetContactListParams {
    readonly pageSize?: number;
    readonly cursor?: string;
}
interface ContactListPage {
    readonly cursor: string;
    readonly contacts: ReadonlyArray<Contact>;
}
export declare const ADD_CONTACT_SELF_ERROR_MESSAGE = "User ID is invalid: cannot add yourself as a contact";
export declare const dedupeUserIds: (userIds: ReadonlyArray<string>) => ReadonlyArray<string>;
export declare const normalizeBlocklistEntries: (payload: unknown) => ReadonlyArray<UserInfo>;
export declare const normalizeBlocklistAddResult: (payload: unknown) => BlocklistAddResult;
export declare const normalizeContactListPage: (payload: unknown, existingContacts: ReadonlyMap<string, Contact>) => ContactListPage;
export declare const assertNormalizedUserIds: (params: BlocklistMutationParams, path: string) => ReadonlyArray<string>;
export declare const requestAddContact: (client: RestClient, context: RestContext, params: AddContactParams) => Promise<void>;
export declare const requestDeleteContact: (client: RestClient, context: RestContext, params: ContactMutationTarget) => Promise<void>;
export declare const requestAcceptContactInvite: (client: RestClient, context: RestContext, params: ContactMutationTarget) => Promise<void>;
export declare const requestDeclineContactInvite: (client: RestClient, context: RestContext, params: ContactMutationTarget) => Promise<void>;
export declare const requestSetContactRemark: (client: RestClient, context: RestContext, params: SetContactRemarkParams) => Promise<void>;
export declare const requestGetBlocklist: (client: RestClient, context: RestContext) => Promise<ReadonlyArray<UserInfo>>;
export declare const requestGetContactList: (client: RestClient, context: RestContext, params: GetContactListParams, existingContacts: ReadonlyMap<string, Contact>) => Promise<ContactListPage>;
export declare const requestAddUsersToBlocklist: (client: RestClient, context: RestContext, userIds: ReadonlyArray<string>) => Promise<BlocklistAddResult>;
export declare const requestRemoveUsersFromBlocklist: (client: RestClient, context: RestContext, userIds: ReadonlyArray<string>) => Promise<void>;
export {};
