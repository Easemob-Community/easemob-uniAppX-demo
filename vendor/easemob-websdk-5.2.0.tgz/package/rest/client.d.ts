/**
 * REST 客户端基础类
 *
 * 统一 Promise 返回，不使用回调
 */
import type { RuntimeErrorMap } from './error-map-types';
import type { RequestAdapter } from '../platform/types';
/**
 * HTTP 方法
 */
export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
/**
 * 请求配置
 */
export interface RequestConfig {
    method?: HttpMethod;
    headers?: Record<string, string>;
    body?: unknown;
    timeout?: number;
    operation?: string;
}
export interface RestClientOptions {
    timeout?: number;
    headers?: Record<string, string>;
    errorMap?: RuntimeErrorMap;
    requestAdapter?: RequestAdapter;
    /** 为 true 时在请求头注入 X-Request-Id（Manager REST 使用） */
    includeRequestId?: boolean;
}
/**
 * REST 客户端
 */
export declare class RestClient {
    private baseUrl;
    private defaultHeaders;
    private timeout;
    private errorMap;
    private requestAdapter;
    private includeRequestId;
    constructor(baseUrl: string, options?: RestClientOptions);
    /**
     * 脱敏 URL（屏蔽 query 参数值）
     */
    private sanitizeUrl;
    /**
     * 设置认证 token
     */
    setAuthToken(token: string): void;
    /**
     * 移除认证 token
     */
    removeAuthToken(): void;
    /**
     * 基于 HTTP 状态码的通用错误兜底
     */
    private buildHttpStatusFallbackError;
    /**
     * 发送请求
     */
    request<T>(endpoint: string, config?: RequestConfig): Promise<T>;
    private handleErrorPayload;
    /**
     * GET 请求
     */
    get<T>(endpoint: string, config?: Omit<RequestConfig, 'method' | 'body'>): Promise<T>;
    /**
     * POST 请求
     */
    post<T>(endpoint: string, body?: unknown, config?: Omit<RequestConfig, 'method'>): Promise<T>;
    /**
     * PUT 请求
     */
    put<T>(endpoint: string, body?: unknown, config?: Omit<RequestConfig, 'method'>): Promise<T>;
    /**
     * DELETE 请求
     */
    delete<T>(endpoint: string, config?: Omit<RequestConfig, 'method' | 'body'>): Promise<T>;
    /**
     * PATCH 请求
     */
    patch<T>(endpoint: string, body?: unknown, config?: Omit<RequestConfig, 'method'>): Promise<T>;
}
