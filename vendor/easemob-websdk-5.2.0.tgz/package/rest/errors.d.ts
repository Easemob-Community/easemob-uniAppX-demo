import { RestBusinessError } from '../utils/errors';
import type { ResolvedApiBusinessError, RuntimeApiErrorEntry, RuntimeErrorMap, RuntimeErrorMatchedBy } from './error-map-types';
/**
 * 创建 API 错误
 */
export declare function resolveApiBusinessError(errorMap: RuntimeErrorMap | undefined, apiName: string | undefined, payload: unknown): ResolvedApiBusinessError | undefined;
export declare function resolveRestBusinessErrorMessage(options: {
    apiName?: string;
    entry?: RuntimeApiErrorEntry;
    mapped?: boolean;
    reasonKey?: string;
}): string;
export declare function createRestBusinessError(options: {
    apiName: string;
    message?: string;
    entry?: RuntimeApiErrorEntry;
    serverCode?: number | string;
    serverMessage?: string;
    httpStatus?: number;
    mapped?: boolean;
    reasonKey?: string;
    matchedBy?: RuntimeErrorMatchedBy;
}): RestBusinessError;
