/**
 * 缓存模块配置常量
 */
export declare const CACHE_SCHEMA_VERSION = 1;
export declare const CACHE_TTL_SECONDS: number;
export declare const CACHE_FLUSH_INTERVAL_MS = 1000;
export declare const CACHE_MAX_USER_INFO_COUNT = 1000;
export declare const CACHE_MAX_GROUP_NAMECARD_COUNT = 1000;
export declare const CACHE_EVICTION_USER_INFO_RATIO = 0.2;
export declare const CACHE_EVICTION_GROUP_NAMECARD_RATIO = 0.2;
export declare const CACHE_EVICTION_CONVERSATION_RATIO = 0.05;
export declare const CACHE_EVICTION_MIN_BATCH = 1;
