/**
 * @deprecated 浏览器兼容上传入口。实际网络实现位于平台层。
 */
export { simpleUpload } from '../platform/upload/legacy-simple-upload';
