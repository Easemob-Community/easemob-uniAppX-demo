import type { Message, SendMessageOptions } from '../types';
import type { UploadConfig } from './types';
type AttachmentUploaderConfig = UploadConfig;
export declare class AttachmentUploader {
    private config;
    constructor(config?: AttachmentUploaderConfig);
    updateConfig(config: AttachmentUploaderConfig): void;
    updateAuthToken(token: string): void;
    /**
     * 发送前统一准备附件消息。
     * 这里会串起 029 的主流程：解析本地文件、决定图片发送语义、按门槛做预检、命中则复用远端资源，未命中再进入实际上传。
     */
    prepareMessage(message: Message, options?: SendMessageOptions): Promise<Message>;
    /**
     * 按段串行准备复合消息的附件。文本、位置、自定义段跳过。
     * 附件段的 msgLocalId 改成 `msgLocalId:bodyIndex`，才能取到组装时放入的文件。
     * 任一段失败就整条不发送，已经传完的段不会单独提交。
     */
    private prepareMultiBodyMessage;
    /** 失败回调补上复合消息的 msgLocalId。进度、完成和取消都不带分段序号。 */
    private withSegmentCallbacks;
    private resolveUploadUrl;
    private hasUploadedRemoteResource;
    private prepareAttachmentUpload;
    private resolveImageCandidate;
    private maybePrecheck;
    private computeMd5;
    private resolveImageProcessor;
    private requestPrecheck;
    private requestJson;
    private requestByAdapter;
    private buildPrecheckedUploadResult;
    private uploadAttachment;
    private uploadByAdapter;
    private buildPreparedMessage;
    private resolveThumbnailWidth;
    private resolveThumbnailHeight;
    private resolveUploadMetadata;
}
export {};
