import { type NormalizedUploadSource } from '../platform/upload/upload-source';
import type { CompatibleFile, ImageMessageBody, ImageType } from '../types';
import type { AttachmentMessageBody, AttachmentMessageType, AttachmentPrecheckDecision, AttachmentPrecheckResult, AttachmentPrecheckThresholdType, ImageSendPolicy, UploadResponsePayload } from './types';
export type ProtocolImageType = 1 | 2;
export declare const IMAGE_TYPE_ORIGINAL: ImageType;
export declare const IMAGE_TYPE_LARGE: ImageType;
export declare const PROTOCOL_IMAGE_TYPE_ORIGINAL: ProtocolImageType;
export declare const PROTOCOL_IMAGE_TYPE_LARGE: ProtocolImageType;
export declare const IMAGE_PRECHECK_ORIGINAL_THRESHOLD: number;
export declare const ATTACHMENT_PRECHECK_THRESHOLD: number;
export declare const isRemoteUrl: (url: string) => boolean;
export declare const isLocalUrl: (url: string) => boolean;
export declare const shouldUploadByUrl: (url: string | undefined, hasData: boolean) => boolean;
export declare const parseAppKey: (appKey: string) => {
    orgName: string;
    appName: string;
};
export declare const toUploadChatType: (conversationType: string) => string;
export declare const appendUrlQueryParams: (url: string, params: Record<string, string | number | undefined>) => string;
export declare const appendAttachUrlParams: (url: string, secret?: string) => string;
export declare const resolveImageSendPolicy: (body: ImageMessageBody) => ImageSendPolicy;
export declare const resolvePrecheckThresholdType: (messageType: AttachmentMessageType, imageType?: ImageType) => AttachmentPrecheckThresholdType;
export declare const resolvePrecheckThresholdBytes: (thresholdType: AttachmentPrecheckThresholdType) => number;
export declare const buildAttachmentPrecheckDecision: (options: {
    messageType: AttachmentMessageType;
    fileSize: number;
    imageType?: ImageType;
}) => AttachmentPrecheckDecision;
export declare const isAttachmentPrecheckHit: (result: {
    exists: boolean;
    uuid?: string;
    shareSecret?: string;
}) => boolean;
export declare const parseAttachmentPrecheckResult: (payload: UploadResponsePayload) => AttachmentPrecheckResult;
export declare const deriveImageUrls: (remotePath: string, options?: {
    deriveVariants?: boolean;
}) => {
    originalImageUrl?: string;
    bigImageUrl?: string;
    thumbnailUrl?: string;
};
export declare const toUploadImageType: (imageType: ImageType | undefined) => "origin" | "large";
export declare const toProtocolImageType: (imageType: ImageType | undefined) => ProtocolImageType;
export declare const fromProtocolImageType: (imageType: unknown) => ImageType;
export declare const buildUploadResult: (options: {
    response: UploadResponsePayload;
    restBaseUrl: string;
    orgName: string;
    appName: string;
    fileType: string;
    fileName: string;
    fallbackSize: number;
    messageType: AttachmentMessageType;
    imageType?: ImageType;
    width?: number;
    height?: number;
    useCustomAttachmentUpload?: boolean;
}) => {
    url?: string;
    isOriginalImage?: boolean;
    originalImageUrl?: string;
    bigImageUrl?: string;
    secret?: string;
    fileLength?: number;
    filetype?: string;
    filename?: string;
    thumbnailUrl?: string;
    width?: number;
    height?: number;
};
export declare const normalizeAttachmentFile: (file: CompatibleFile | undefined, body: AttachmentMessageBody) => NormalizedUploadSource;
