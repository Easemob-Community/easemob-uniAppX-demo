/**
 * @deprecated 浏览器兼容分片上传入口。实际网络实现位于平台层。
 */
export { multipartAbort, multipartUpload, } from '../platform/upload/legacy-multipart-upload';
