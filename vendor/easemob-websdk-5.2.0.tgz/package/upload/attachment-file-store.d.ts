import type { CompatibleFile } from '../types';
declare class AttachmentFileStore {
    private readonly store;
    set(msgLocalId: string, file: CompatibleFile): void;
    get(msgLocalId: string): CompatibleFile | undefined;
    consume(msgLocalId: string): CompatibleFile | undefined;
    delete(msgLocalId: string): void;
    clear(): void;
}
export declare const attachmentFileStore: AttachmentFileStore;
export type { AttachmentFileStore };
