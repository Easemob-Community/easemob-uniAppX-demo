export declare const MULTIPART_THRESHOLD: number;
export declare const DEFAULT_PART_SIZE: number;
export declare const MAX_POOL = 4;
export declare const FILE_CONVERSATION_TYPES: {
    readonly single: "CHAT";
    readonly group: "GROUP";
    readonly room: "ROOM";
};
