/**
 * Web 平台 WebSocket 适配器
 */
import { type SocketAdapter } from '../types';
export interface WebSocketAdapterOptions {
    readonly webSocketCtor?: typeof WebSocket;
}
export declare const createWebSocketAdapter: (options?: WebSocketAdapterOptions) => SocketAdapter | undefined;
