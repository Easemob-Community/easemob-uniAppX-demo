import { type SocketAdapter } from '../types';
/**
 * [zh-CN] 解析显式 SocketAdapter；仅为旧的独立内部构造入口保留浏览器默认兼容能力。
 * [en-US] Resolves an explicit SocketAdapter while retaining browser-default compatibility for legacy standalone internal construction.
 */
export declare const resolveSocketAdapter: (socketAdapter?: SocketAdapter) => SocketAdapter;
