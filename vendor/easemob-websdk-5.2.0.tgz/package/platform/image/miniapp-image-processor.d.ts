import { type ImageProcessor } from '../types';
interface MiniAppReadFileSuccessResult {
    readonly data: string | ArrayBuffer;
}
interface MiniAppGetFileInfoSuccessResult {
    readonly size: number;
    readonly digest?: string;
}
interface MiniAppGetFileInfoOptions {
    readonly filePath: string;
    readonly digestAlgorithm?: 'md5';
    readonly success: (result: MiniAppGetFileInfoSuccessResult) => void;
    readonly fail?: (error: unknown) => void;
}
interface MiniAppFileSystemManagerLike {
    readFile?(options: {
        readonly filePath: string;
        readonly success: (result: MiniAppReadFileSuccessResult) => void;
        readonly fail?: (error: unknown) => void;
    }): void;
    getFileInfo?(options: MiniAppGetFileInfoOptions): void;
}
interface MiniAppImageInfoResponse {
    readonly width: number;
    readonly height: number;
    readonly type?: string;
    readonly path?: string;
}
export interface MiniAppImageRuntimeLike {
    getImageInfo(options: {
        readonly src: string;
        readonly success: (result: MiniAppImageInfoResponse) => void;
        readonly fail?: (error: unknown) => void;
    }): void;
    compressImage?(options: {
        readonly src: string;
        readonly quality?: number;
        readonly compressedWidth?: number;
        readonly compressedHeight?: number;
        readonly success?: (result: {
            readonly tempFilePath: string;
        }) => void;
        readonly fail?: (error: unknown) => void;
    }): void;
    getFileSystemManager?(): MiniAppFileSystemManagerLike;
    getFileInfo?(options: MiniAppGetFileInfoOptions): void;
}
export declare const createMiniAppImageProcessor: (runtime: MiniAppImageRuntimeLike) => ImageProcessor;
export {};
