import { type ImageProcessor } from '../types';
export declare const createWebImageProcessor: () => ImageProcessor;
