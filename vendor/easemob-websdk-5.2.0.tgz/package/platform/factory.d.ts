/**
 * 跨平台适配器工厂
 */
import { type CreatePlatformAdapterOptions, type PlatformFactoryResult, type RuntimePlatform } from './types';
import { type RuntimeDetectionInput } from './env';
export declare const detectRuntimePlatform: (prefer?: RuntimePlatform, runtimeInput?: RuntimeDetectionInput) => RuntimePlatform;
export declare const createPlatformAdapter: (options?: CreatePlatformAdapterOptions) => PlatformFactoryResult;
