import { type RequestAdapter } from '../types';
/**
 * [zh-CN] 创建一次性捕获全局 fetch 的浏览器兼容请求适配器。
 * [en-US] Creates a browser-compatibility request adapter that captures global fetch once.
 */
export declare const createDefaultWebRequestAdapter: () => RequestAdapter;
export declare const resolveRequestAdapter: (requestAdapter?: RequestAdapter) => RequestAdapter;
