/**
 * Web 平台请求适配器
 */
import { type RequestAdapter } from '../types';
export interface WebRequestAdapterOptions {
    readonly fetchImpl?: typeof fetch;
    readonly timeoutMs?: number;
}
export declare const createWebRequestAdapter: (options?: WebRequestAdapterOptions) => RequestAdapter | undefined;
