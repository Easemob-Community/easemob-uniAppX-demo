/**
 * 平台能力校验器
 */
import { type PlatformCapability } from './types';
export declare const DEFAULT_REQUIRED_CAPABILITIES: ReadonlyArray<keyof PlatformCapability>;
export declare const resolveMissingCapabilities: (capability: PlatformCapability, requiredCapabilities?: ReadonlyArray<keyof PlatformCapability>) => string[];
export declare const validatePlatformCapabilities: (capability: PlatformCapability, requiredCapabilities?: ReadonlyArray<keyof PlatformCapability>) => void;
