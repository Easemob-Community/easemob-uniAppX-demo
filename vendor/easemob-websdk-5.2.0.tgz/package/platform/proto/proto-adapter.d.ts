/**
 * ProtoAdapter 抽象与编解码注册器
 */
import { Type } from 'protobufjs/light';
import { type ProtoAdapter as PlatformProtoAdapter } from '../types';
export type ProtoAdapter = PlatformProtoAdapter;
export interface ProtoTypeCodec {
    encode(payload: unknown): Uint8Array;
    decode(payload: Uint8Array): unknown;
}
export declare class ProtoCodecRegistry {
    private readonly codecMap;
    register(typeName: string, codec: ProtoTypeCodec): void;
    registerType(typeName: string, protoType: Type): void;
    get(typeName: string): ProtoTypeCodec | undefined;
    getOrThrow(typeName: string): ProtoTypeCodec;
}
