/**
 * 静态 protobuf 适配器
 */
import { Namespace, Root } from 'protobufjs/light';
import { type ProtoAdapter } from './proto-adapter';
export declare const ensureStaticProtoRootInstalled: (namespace: Namespace) => void;
export declare const getStaticProtoRoot: () => Root;
export declare const createStaticProtoAdapter: () => ProtoAdapter;
