import { Namespace, Reader, Type, Writer, type IConversionOptions } from 'protobufjs/light';
export declare const encodeWithReflection: (type: Type, payload: Record<string, unknown>, writer?: Writer) => Writer;
export declare const decodeWithReflection: (type: Type, payload: Uint8Array | Reader, length?: number) => Record<string, unknown>;
export declare const toObjectWithReflection: (type: Type, message: Record<string, unknown>, options?: IConversionOptions) => Record<string, unknown>;
export declare const installReflectionCodec: (type: Type) => void;
export declare const installReflectionCodecRecursive: (type: Type) => void;
export declare const installReflectionCodecInNamespace: (namespace: Namespace) => void;
export declare const installReflectionRuntime: () => void;
