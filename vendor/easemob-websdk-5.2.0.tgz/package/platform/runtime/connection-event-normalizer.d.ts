/**
 * 连接事件归一化与去重
 */
import { type ConnectionEventName as ConnectionEventNameType, type ConnectionEventPayload, type ConnectionStatus as ConnectionStatusType } from '../../types';
interface NormalizedConnectionEvent {
    readonly eventName: ConnectionEventNameType;
    readonly payload: ConnectionEventPayload;
}
export declare class ConnectionEventNormalizer {
    private lastEventKey;
    normalize(status: ConnectionStatusType, payload: ConnectionEventPayload): NormalizedConnectionEvent | null;
    reset(): void;
}
export {};
