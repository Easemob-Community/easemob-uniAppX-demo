/**
 * 运行时事件桥接器
 */
import type { RuntimeAdapter } from '../types';
export interface RuntimeEventBridgeHandlers {
    readonly onOnline: () => void;
    readonly onOffline: () => void;
    readonly onForeground: () => void;
    readonly onBackground: () => void;
}
export declare class RuntimeEventBridge {
    private readonly runtime;
    private readonly handlers;
    private unsubscribeNetwork;
    private unsubscribeVisibility;
    private lastOnline;
    private lastForeground;
    constructor(runtime: RuntimeAdapter, handlers: RuntimeEventBridgeHandlers);
    start(): void;
    stop(): void;
    private handleNetworkChange;
    private handleVisibilityChange;
}
