/**
 * Web 平台运行时适配器
 */
import type { RuntimeAdapter, RuntimePlatform } from '../types';
interface EventBridgeLike {
    addEventListener(type: string, listener: () => void): void;
    removeEventListener(type: string, listener: () => void): void;
}
interface DocumentLike extends EventBridgeLike {
    readonly visibilityState?: string;
}
interface NavigatorLike {
    readonly onLine?: boolean;
    readonly connection?: {
        readonly type?: string;
        readonly effectiveType?: string;
    };
}
export interface WebRuntimeAdapterOptions {
    readonly platform: RuntimePlatform;
    readonly windowRef?: EventBridgeLike;
    readonly documentRef?: DocumentLike;
    readonly navigatorRef?: NavigatorLike;
}
export declare const createWebRuntimeAdapter: (options: WebRuntimeAdapterOptions) => RuntimeAdapter;
export {};
