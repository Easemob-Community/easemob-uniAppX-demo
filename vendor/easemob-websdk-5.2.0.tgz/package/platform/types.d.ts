/**
 * 跨平台适配层类型定义
 */
/**
 * [zh-CN] SDK 可识别的运行平台常量。
 * [en-US] Runtime platform constants recognized by the SDK.
 */
export declare const RUNTIME_PLATFORMS: {
    readonly WEB: "web";
    readonly WECHAT_MINIAPP: "wechat-miniapp";
    readonly QQ_MINIAPP: "qq-miniapp";
    readonly TOUTIAO_MINIAPP: "toutiao-miniapp";
    readonly BAIDU_MINIAPP: "baidu-miniapp";
    readonly ALIPAY_MINIAPP: "alipay-miniapp";
    readonly DINGTALK_MINIAPP: "dingtalk-miniapp";
    readonly LARK_MINIAPP: "lark-miniapp";
    readonly KUAISHOU_MINIAPP: "kuaishou-miniapp";
    readonly JD_MINIAPP: "jd-miniapp";
    readonly MINIAPP_360: "360-miniapp";
    readonly HARMONY_MINIAPP: "harmony-miniapp";
    readonly QUICKAPP: "quickapp";
    readonly UNIAPP: "uniapp";
    readonly REACT_NATIVE: "react-native";
    readonly ELECTRON_RENDERER: "electron-renderer";
    readonly ELECTRON_MAIN: "electron-main";
    readonly UNKNOWN: "unknown";
};
/**
 * [zh-CN] SDK 可识别的运行平台。
 * [en-US] Runtime platform recognized by the SDK.
 */
export type RuntimePlatform = (typeof RUNTIME_PLATFORMS)[keyof typeof RUNTIME_PLATFORMS];
/**
 * [zh-CN] 平台适配错误发生阶段常量。
 * [en-US] Platform adapter error stage constants.
 */
export declare const PLATFORM_ERROR_STAGE: {
    readonly INIT: "init";
    readonly REQUEST: "request";
    readonly UPLOAD: "upload";
    readonly SOCKET: "socket";
    readonly PROTO: "proto";
    readonly RUNTIME: "runtime";
    readonly STORAGE: "storage";
};
/**
 * [zh-CN] 平台适配错误发生阶段。
 * [en-US] Stage where a platform adapter error occurred.
 */
export type PlatformErrorStage = (typeof PLATFORM_ERROR_STAGE)[keyof typeof PLATFORM_ERROR_STAGE];
/**
 * [zh-CN] 平台适配错误码常量。
 * [en-US] Platform adapter error code constants.
 */
export declare const PLATFORM_ERROR_CODE: {
    readonly INIT_FAILED: "PLATFORM_INIT_FAILED";
    readonly MISSING_CAPABILITY: "PLATFORM_MISSING_CAPABILITY";
    readonly REQUEST_FAILED: "PLATFORM_REQUEST_FAILED";
    readonly UPLOAD_FAILED: "PLATFORM_UPLOAD_FAILED";
    readonly SOCKET_FAILED: "PLATFORM_SOCKET_FAILED";
    readonly PROTO_FAILED: "PLATFORM_PROTO_FAILED";
};
/**
 * [zh-CN] 平台适配错误码。
 * [en-US] Platform adapter error code.
 */
export type PlatformErrorCode = (typeof PLATFORM_ERROR_CODE)[keyof typeof PLATFORM_ERROR_CODE];
/**
 * [zh-CN] 平台适配层抛出的结构化错误。
 * [en-US] Structured error thrown by the platform adapter layer.
 */
export interface PlatformAdapterError extends Error {
    /** [zh-CN] 平台错误码。 [en-US] Platform error code. */
    readonly code: PlatformErrorCode;
    /** [zh-CN] 错误发生阶段。 [en-US] Stage where the error occurred. */
    readonly stage: PlatformErrorStage;
    /** [zh-CN] 是否可以安全重试。 [en-US] Whether the operation can be safely retried. */
    readonly retryable: boolean;
    /** [zh-CN] 用于诊断的附加详情。 [en-US] Additional diagnostic details. */
    readonly details?: Record<string, unknown>;
}
/**
 * [zh-CN] 创建平台适配错误的选项。
 * [en-US] Options for creating a platform adapter error.
 */
export interface PlatformErrorOptions {
    /** [zh-CN] 平台错误码。 [en-US] Platform error code. */
    readonly code: PlatformErrorCode;
    /** [zh-CN] 错误发生阶段。 [en-US] Stage where the error occurred. */
    readonly stage: PlatformErrorStage;
    /** [zh-CN] 是否可以安全重试。 [en-US] Whether the operation can be safely retried. */
    readonly retryable: boolean;
    /** [zh-CN] 用于诊断的附加详情。 [en-US] Additional diagnostic details. */
    readonly details?: Record<string, unknown>;
}
export declare const createPlatformError: (message: string, options: PlatformErrorOptions) => PlatformAdapterError;
/**
 * [zh-CN] 请求适配器支持的 HTTP 方法。
 * [en-US] HTTP methods supported by the request adapter.
 */
export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
/**
 * [zh-CN] 平台请求适配器的请求配置。
 * [en-US] Request configuration for a platform request adapter.
 */
export interface RequestConfig {
    /** [zh-CN] 请求 URL。 [en-US] Request URL. */
    readonly url: string;
    /** [zh-CN] HTTP 方法，默认由调用方决定。 [en-US] HTTP method; the caller determines the default. */
    readonly method?: HttpMethod;
    /** [zh-CN] 请求头。 [en-US] Request headers. */
    readonly headers?: Record<string, string>;
    /** [zh-CN] 请求体。 [en-US] Request body. */
    readonly body?: string | Record<string, unknown> | Uint8Array;
    /** [zh-CN] 期望的响应数据类型。 [en-US] Expected response data type. */
    readonly responseType?: 'json' | 'text' | 'arraybuffer';
    /** [zh-CN] 请求超时时间，单位毫秒。 [en-US] Request timeout in milliseconds. */
    readonly timeoutMs?: number;
    /** [zh-CN] 请求取消信号。 [en-US] Request cancellation signal. */
    readonly signal?: AbortSignal;
}
/**
 * [zh-CN] 平台请求适配器返回的响应。
 * [en-US] Response returned by a platform request adapter.
 */
export interface RequestResponse<TData> {
    /** [zh-CN] HTTP 状态码。 [en-US] HTTP status code. */
    readonly status: number;
    /** [zh-CN] HTTP 状态文本；宿主无法提供时可省略。 [en-US] HTTP status text; may be omitted when unavailable from the host. */
    readonly statusText?: string;
    /** [zh-CN] 响应头。 [en-US] Response headers. */
    readonly headers: Record<string, string>;
    /** [zh-CN] 响应数据；空正文或无法解析的 JSON 必须作为响应保留，不得改报网络错误。 [en-US] Response data; an empty body or malformed JSON must remain a response instead of being reclassified as a network failure. */
    readonly data: TData;
}
/**
 * [zh-CN] 跨平台 HTTP 请求适配器。
 * [en-US] Cross-platform HTTP request adapter.
 */
export interface RequestAdapter {
    /** [zh-CN] 发起 HTTP 请求。 [en-US] Sends an HTTP request. */
    request<TData>(config: RequestConfig): Promise<RequestResponse<TData>>;
}
/**
 * [zh-CN] 上传源类型。
 * [en-US] Upload source type.
 */
export type UploadSourceType = 'web-file' | 'miniapp-path' | 'rn-uri';
/**
 * [zh-CN] 跨平台上传源描述。
 * [en-US] Cross-platform upload source descriptor.
 */
export interface UploadSource {
    /** [zh-CN] 上传源类型。 [en-US] Upload source type. */
    readonly sourceType: UploadSourceType;
    /** [zh-CN] Web 文件或二进制对象。 [en-US] Web file or binary object. */
    readonly file?: File | Blob;
    /** [zh-CN] 小程序本地文件路径。 [en-US] Mini Program local file path. */
    readonly path?: string;
    /** [zh-CN] React Native 文件 URI。 [en-US] React Native file URI. */
    readonly uri?: string;
    /** [zh-CN] 文件名称。 [en-US] File name. */
    readonly name?: string;
    /** [zh-CN] 文件 MIME 类型。 [en-US] File MIME type. */
    readonly mimeType?: string;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    readonly size?: number;
}
/**
 * [zh-CN] 图片基础信息。
 * [en-US] Basic image information.
 */
export interface ImageInfoResult {
    /** [zh-CN] 图片宽度，单位像素。 [en-US] Image width in pixels. */
    readonly width: number;
    /** [zh-CN] 图片高度，单位像素。 [en-US] Image height in pixels. */
    readonly height: number;
    /** [zh-CN] 图片 MIME 类型。 [en-US] Image MIME type. */
    readonly mimeType?: string;
    /** [zh-CN] 文件大小，单位字节。 [en-US] File size in bytes. */
    readonly fileSize?: number;
    /** [zh-CN] 是否为 GIF 图片。 [en-US] Whether the image is a GIF. */
    readonly isGif?: boolean;
}
/**
 * [zh-CN] 生成大图的选项。
 * [en-US] Options for generating a large image.
 */
export interface ImageGenerateOptions {
    /** [zh-CN] 短边最大像素数。 [en-US] Maximum pixel count of the short edge. */
    readonly maxShortEdge: number;
    /** [zh-CN] 图片质量。 [en-US] Image quality. */
    readonly quality: number;
}
/**
 * [zh-CN] 图片处理后的生成结果。
 * [en-US] Result produced by image processing.
 */
export interface GeneratedImageResult {
    /** [zh-CN] 生成后的上传源。 [en-US] Generated upload source. */
    readonly source: UploadSource;
    /** [zh-CN] 图片宽度，单位像素。 [en-US] Image width in pixels. */
    readonly width: number;
    /** [zh-CN] 图片高度，单位像素。 [en-US] Image height in pixels. */
    readonly height: number;
    /** [zh-CN] 生成文件名称。 [en-US] Generated file name. */
    readonly fileName?: string;
    /** [zh-CN] 生成文件 MIME 类型。 [en-US] Generated file MIME type. */
    readonly fileType?: string;
    /** [zh-CN] 生成文件大小，单位字节。 [en-US] Generated file size in bytes. */
    readonly fileSize?: number;
    /** [zh-CN] Web 环境生成的二进制对象。 [en-US] Binary object generated in Web runtimes. */
    readonly webFile?: Blob;
}
/**
 * [zh-CN] 跨平台图片处理适配器。
 * [en-US] Cross-platform image processing adapter.
 */
export interface ImageProcessor {
    /** [zh-CN] 读取图片信息。 [en-US] Reads image information. */
    getImageInfo(source: UploadSource): Promise<ImageInfoResult>;
    /** [zh-CN] 生成大图资源。 [en-US] Generates a large-image resource. */
    generateBigImage(source: UploadSource, options: ImageGenerateOptions): Promise<GeneratedImageResult>;
    /** [zh-CN] 计算上传源的 MD5。 [en-US] Computes the MD5 of an upload source. */
    computeMd5(source: UploadSource): Promise<string>;
}
/**
 * [zh-CN] 平台上传进度。
 * [en-US] Platform upload progress.
 */
export interface UploadProgress {
    /** [zh-CN] 已上传字节数。 [en-US] Number of uploaded bytes. */
    readonly loaded: number;
    /** [zh-CN] 文件总字节数。 [en-US] Total number of bytes. */
    readonly total?: number;
    /** [zh-CN] 上传百分比。 [en-US] Upload percentage. */
    readonly percent?: number;
}
/**
 * [zh-CN] 平台上传适配器的上传配置。
 * [en-US] Upload configuration for a platform upload adapter.
 */
export interface UploadConfig {
    /** [zh-CN] 上传 URL。 [en-US] Upload URL. */
    readonly url: string;
    /** [zh-CN] HTTP 方法，默认 POST。 [en-US] HTTP method; defaults to POST. */
    readonly method?: HttpMethod;
    /** [zh-CN] 上传请求头。 [en-US] Upload request headers. */
    readonly headers?: Record<string, string>;
    /** [zh-CN] 待上传资源。 [en-US] Resource to upload. */
    readonly source: UploadSource;
    /** [zh-CN] 附加表单字段。 [en-US] Additional form fields. */
    readonly fields?: Record<string, string>;
    /** [zh-CN] 文件表单字段名，默认 file。 [en-US] File form field name; defaults to file. */
    readonly fileFieldName?: string;
    /** [zh-CN] 上传超时时间，单位毫秒。 [en-US] Upload timeout in milliseconds. */
    readonly timeoutMs?: number;
    /** [zh-CN] 上传取消信号。 [en-US] Upload cancellation signal. */
    readonly signal?: AbortSignal;
    /** [zh-CN] 上传进度回调。 [en-US] Upload progress callback. */
    readonly onProgress?: (progress: UploadProgress) => void;
}
/**
 * [zh-CN] 平台上传适配器返回的结果。
 * [en-US] Result returned by a platform upload adapter.
 */
export interface UploadResult {
    /** [zh-CN] HTTP 状态码。 [en-US] HTTP status code. */
    readonly status: number;
    /** [zh-CN] 原始响应正文。 [en-US] Raw response body. */
    readonly body: string;
}
/**
 * [zh-CN] 跨平台文件上传适配器。
 * [en-US] Cross-platform file upload adapter.
 */
export interface UploadAdapter {
    /** [zh-CN] 按 method、fileFieldName、取消、超时和进度契约上传文件或分片。 [en-US] Uploads a file or chunk while honoring method, fileFieldName, cancellation, timeout, and progress semantics. */
    upload(config: UploadConfig): Promise<UploadResult>;
}
/**
 * [zh-CN] Socket 可发送的数据类型。
 * [en-US] Data types that a socket can send.
 */
export type SocketSendData = string | ArrayBuffer | Uint8Array;
/**
 * [zh-CN] Socket 可接收的数据类型。
 * [en-US] Data types that a socket can receive.
 */
export type SocketMessageData = string | ArrayBuffer | Blob;
/**
 * [zh-CN] Socket 就绪状态常量。
 * [en-US] Socket ready-state constants.
 */
export declare const SOCKET_READY_STATE: {
    readonly CONNECTING: 0;
    readonly OPEN: 1;
    readonly CLOSING: 2;
    readonly CLOSED: 3;
};
/**
 * [zh-CN] Socket 就绪状态。
 * [en-US] Socket ready state.
 */
export type SocketReadyState = (typeof SOCKET_READY_STATE)[keyof typeof SOCKET_READY_STATE];
/**
 * [zh-CN] Socket 建连配置。
 * [en-US] Socket connection configuration.
 */
export interface SocketConnectConfig {
    /** [zh-CN] Socket 服务地址。 [en-US] Socket server URL. */
    readonly url: string;
    /** [zh-CN] WebSocket 子协议。 [en-US] WebSocket subprotocols. */
    readonly protocols?: string | string[];
    /** [zh-CN] 建连超时时间（毫秒）；超时后适配器必须关闭底层连接任务。 [en-US] Connection timeout in milliseconds; the adapter must close the underlying task after timeout. */
    readonly timeoutMs?: number;
}
/**
 * [zh-CN] SDK 使用的跨平台 Socket 实例接口。
 * [en-US] Cross-platform socket instance used by the SDK.
 */
export interface SocketLike {
    /** [zh-CN] 当前 Socket 就绪状态。 [en-US] Current socket ready state. */
    readonly readyState: number;
    /** [zh-CN] 发送数据。 [en-US] Sends data. */
    send(data: SocketSendData): Promise<void>;
    /** [zh-CN] 关闭连接。 [en-US] Closes the connection. */
    close(code?: number, reason?: string): void;
    /** [zh-CN] 注册连接打开监听器并返回取消函数。 [en-US] Registers an open listener and returns an unsubscribe function. */
    onOpen(handler: () => void): () => void;
    /** [zh-CN] 注册消息监听器并返回取消函数。 [en-US] Registers a message listener and returns an unsubscribe function. */
    onMessage(handler: (data: SocketMessageData) => void): () => void;
    /** [zh-CN] 注册错误监听器并返回取消函数。 [en-US] Registers an error listener and returns an unsubscribe function. */
    onError(handler: (error: unknown) => void): () => void;
    /** [zh-CN] 注册关闭监听器并返回取消函数。 [en-US] Registers a close listener and returns an unsubscribe function. */
    onClose(handler: (event: {
        code?: number;
        reason?: string;
    }) => void): () => void;
}
/**
 * [zh-CN] Socket 建连适配器。
 * [en-US] Socket connection adapter.
 */
export interface SocketAdapter {
    /** [zh-CN] 建立 Socket 连接。 [en-US] Establishes a socket connection. */
    connect(config: SocketConnectConfig): Promise<SocketLike>;
}
/**
 * [zh-CN] SDK 使用的原子网络传输适配器；三个能力必须完整提供，缺失时初始化失败且不会回退到全局网络对象。
 * [en-US] Atomic network transport adapter used by the SDK; all three capabilities are required, and a missing capability fails initialization without falling back to network globals.
 */
export interface TransportAdapter {
    /** [zh-CN] HTTP 请求适配器。 [en-US] HTTP request adapter. */
    readonly request: RequestAdapter;
    /** [zh-CN] 文件上传适配器。 [en-US] File upload adapter. */
    readonly upload: UploadAdapter;
    /** [zh-CN] Socket 适配器。 [en-US] Socket adapter. */
    readonly socket: SocketAdapter;
}
/**
 * [zh-CN] 宿主运行时能力适配器。
 * [en-US] Host runtime capability adapter.
 */
export interface RuntimeAdapter {
    /** [zh-CN] 获取当前运行平台。 [en-US] Gets the current runtime platform. */
    getPlatform(): RuntimePlatform;
    /** [zh-CN] 获取当前网络类型；无法获取时可以省略该能力。 [en-US] Gets the current network type; this capability may be omitted when unavailable. */
    getNetworkType?(): Promise<string | number>;
    /** [zh-CN] 监听网络状态并返回取消函数。 [en-US] Observes network status and returns an unsubscribe function. */
    onNetworkChange(listener: (online: boolean) => void): () => void;
    /** [zh-CN] 监听应用前后台状态并返回取消函数。 [en-US] Observes app visibility and returns an unsubscribe function. */
    onAppVisibilityChange(listener: (foreground: boolean) => void): () => void;
}
/**
 * [zh-CN] 异步键值存储适配器。
 * [en-US] Asynchronous key-value storage adapter.
 */
export interface StorageAdapter {
    /** [zh-CN] 读取指定键。 [en-US] Reads a value by key. */
    getItem(key: string): Promise<string | null>;
    /** [zh-CN] 写入指定键。 [en-US] Writes a value by key. */
    setItem(key: string, value: string): Promise<void>;
    /** [zh-CN] 删除指定键。 [en-US] Removes a value by key. */
    removeItem(key: string): Promise<void>;
}
/**
 * [zh-CN] Protobuf 编解码适配器。
 * [en-US] Protobuf encoding and decoding adapter.
 */
export interface ProtoAdapter {
    /** [zh-CN] 将对象编码为二进制数据。 [en-US] Encodes an object into binary data. */
    encode<TInput>(type: string, payload: TInput): Uint8Array;
    /** [zh-CN] 将二进制数据解码为对象。 [en-US] Decodes binary data into an object. */
    decode<TOutput>(type: string, payload: Uint8Array): TOutput;
}
/**
 * [zh-CN] SDK 的完整跨平台适配器。
 * [en-US] Complete cross-platform adapter used by the SDK.
 */
export interface PlatformAdapter {
    /** [zh-CN] 当前运行平台。 [en-US] Current runtime platform. */
    readonly platform: RuntimePlatform;
    /** [zh-CN] HTTP 请求适配器。 [en-US] HTTP request adapter. */
    readonly request: RequestAdapter;
    /** [zh-CN] 文件上传适配器。 [en-US] File upload adapter. */
    readonly upload: UploadAdapter;
    /** [zh-CN] Socket 适配器。 [en-US] Socket adapter. */
    readonly socket: SocketAdapter;
    /** [zh-CN] 宿主运行时适配器。 [en-US] Host runtime adapter. */
    readonly runtime: RuntimeAdapter;
    /** [zh-CN] Protobuf 编解码适配器。 [en-US] Protobuf codec adapter. */
    readonly proto: ProtoAdapter;
    /** [zh-CN] 键值存储适配器。 [en-US] Key-value storage adapter. */
    readonly storage: StorageAdapter;
    /** [zh-CN] 可选图片处理适配器。 [en-US] Optional image processing adapter. */
    readonly imageProcessor?: ImageProcessor;
}
/**
 * [zh-CN] 平台适配器能力画像。
 * [en-US] Platform adapter capability profile.
 */
export interface PlatformCapability {
    /** [zh-CN] 是否支持 HTTP 请求。 [en-US] Whether HTTP requests are supported. */
    readonly request: boolean;
    /** [zh-CN] 是否支持文件上传。 [en-US] Whether file upload is supported. */
    readonly upload: boolean;
    /** [zh-CN] 是否支持 Socket。 [en-US] Whether sockets are supported. */
    readonly socket: boolean;
    /** [zh-CN] 是否支持宿主运行时监听。 [en-US] Whether host runtime observation is supported. */
    readonly runtime: boolean;
    /** [zh-CN] 是否支持 Protobuf 编解码。 [en-US] Whether Protobuf codecs are supported. */
    readonly proto: boolean;
    /** [zh-CN] 是否支持键值存储。 [en-US] Whether key-value storage is supported. */
    readonly storage: boolean;
    /** [zh-CN] 是否支持图片处理。 [en-US] Whether image processing is supported. */
    readonly imageProcessor: boolean;
}
/**
 * [zh-CN] 包含平台标识和能力画像的完整适配器。
 * [en-US] Complete adapter with a platform identifier and capability profile.
 */
export interface PlatformAdapterProfile extends PlatformAdapter {
    /** [zh-CN] 解析后的平台标识。 [en-US] Resolved platform identifier. */
    readonly platformId: RuntimePlatform;
    /** [zh-CN] 平台能力画像。 [en-US] Platform capability profile. */
    readonly capability: PlatformCapability;
}
/**
 * [zh-CN] 用于替换 SDK 默认实现的平台适配器集合。
 * [en-US] Platform adapters that override SDK defaults.
 */
export interface PlatformAdapterOverrides {
    /** [zh-CN] HTTP 请求适配器覆盖。 [en-US] HTTP request adapter override. */
    readonly request?: RequestAdapter;
    /** [zh-CN] 文件上传适配器覆盖。 [en-US] File upload adapter override. */
    readonly upload?: UploadAdapter;
    /** [zh-CN] Socket 适配器覆盖。 [en-US] Socket adapter override. */
    readonly socket?: SocketAdapter;
    /** [zh-CN] 宿主运行时适配器覆盖。 [en-US] Host runtime adapter override. */
    readonly runtime?: RuntimeAdapter;
    /** [zh-CN] Protobuf 编解码适配器覆盖。 [en-US] Protobuf codec adapter override. */
    readonly proto?: ProtoAdapter;
    /** [zh-CN] 键值存储适配器覆盖。 [en-US] Key-value storage adapter override. */
    readonly storage?: StorageAdapter;
    /** [zh-CN] 图片处理适配器覆盖。 [en-US] Image processing adapter override. */
    readonly imageProcessor?: ImageProcessor;
}
/**
 * [zh-CN] 根据默认适配器动态返回覆盖项的函数。
 * [en-US] Function that resolves adapter overrides from SDK defaults.
 */
export type PlatformAdapterOverridesResolver = (defaults: Readonly<PlatformAdapterOverrides>) => PlatformAdapterOverrides;
/**
 * [zh-CN] 创建平台适配器的选项。
 * [en-US] Options for creating a platform adapter.
 */
export interface CreatePlatformAdapterOptions {
    /** [zh-CN] 优先使用的平台；缺省时由 SDK 自动识别。 [en-US] Preferred platform; SDK auto-detects it when omitted. */
    readonly prefer?: RuntimePlatform;
    /** [zh-CN] 显式运行时对象，用于非标准打包器或宿主；缺省时 SDK 自动收集全局能力。 [en-US] Explicit runtime object for non-standard bundlers or hosts; SDK collects global capabilities when omitted. */
    readonly runtimeInput?: object;
    /** [zh-CN] 原子网络传输适配器；提供后 request、upload、socket 必须完整且全部来自该实例，否则初始化失败。 [en-US] Atomic network transport adapter; when provided, request, upload, and socket must all be complete and come from this instance, otherwise initialization fails. */
    readonly transportAdapter?: TransportAdapter;
    /** [zh-CN] 可选适配器覆盖；未提供的能力继续使用 SDK 默认实现。 [en-US] Optional adapter overrides; omitted capabilities continue to use SDK defaults. */
    readonly overrides?: PlatformAdapterOverrides | PlatformAdapterOverridesResolver;
}
/**
 * [zh-CN] 平台适配器工厂返回结果。
 * [en-US] Result returned by the platform adapter factory.
 */
export type PlatformFactoryResult = PlatformAdapterProfile;
