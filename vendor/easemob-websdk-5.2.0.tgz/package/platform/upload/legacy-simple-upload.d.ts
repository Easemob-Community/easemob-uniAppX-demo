import type { UploadRequest } from '../../upload/types';
import { buildUploadResult } from '../../upload/utils';
export declare const simpleUpload: (request: UploadRequest) => Promise<ReturnType<typeof buildUploadResult>>;
