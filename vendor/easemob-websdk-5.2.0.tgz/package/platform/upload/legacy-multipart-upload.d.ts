import type { UploadRequest } from '../../upload/types';
import { buildUploadResult } from '../../upload/utils';
import type { RequestAdapter } from '../types';
import type { DataReportOperationHandle } from '../../data-report/types';
export declare const multipartUpload: (request: UploadRequest) => Promise<ReturnType<typeof buildUploadResult>>;
export declare const multipartAbort: (options: {
    restBaseUrl: string;
    orgName: string;
    appName: string;
    token: string;
    uuid: string;
    requestAdapter?: RequestAdapter;
    dataReportOperation?: DataReportOperationHandle;
}) => Promise<void>;
