import { type UploadAdapter } from '../types';
interface ReactNativeFormDataLike {
    append(name: string, value: unknown): void;
}
interface ReactNativeFormDataConstructor {
    new (): ReactNativeFormDataLike;
}
export interface ReactNativeUploadAdapterOptions {
    readonly fetchImpl?: typeof fetch;
    readonly formDataCtor?: ReactNativeFormDataConstructor;
    readonly timeoutMs?: number;
}
export declare const createReactNativeUploadAdapter: (options?: ReactNativeUploadAdapterOptions) => UploadAdapter | undefined;
export {};
