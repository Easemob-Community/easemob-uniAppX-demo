/**
 * 上传源规范化
 */
import type { CompatibleFile } from '../../types';
import type { UploadSource } from '../types';
interface NormalizeUploadSourceOptions {
    readonly file: CompatibleFile;
    readonly fallbackName?: string;
    readonly fallbackMimeType?: string;
    readonly fallbackSize?: number;
}
export interface NormalizedUploadSource {
    readonly source: UploadSource;
    readonly fileName: string;
    readonly fileType: string;
    readonly fileSize: number;
    readonly webFile?: Blob;
}
export declare const normalizeUploadSource: (options: NormalizeUploadSourceOptions) => NormalizedUploadSource;
export {};
