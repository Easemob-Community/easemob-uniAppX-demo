/**
 * 上传错误映射
 */
import { UploadError } from '../../utils/errors';
import { type PlatformAdapterError } from '../types';
export declare const mapUploadAdapterError: (error: unknown) => UploadError;
export declare const isPlatformUploadError: (error: unknown) => error is PlatformAdapterError;
