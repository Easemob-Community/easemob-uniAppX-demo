/**
 * Web 平台上传适配器
 */
import { type UploadAdapter } from '../types';
export interface WebUploadAdapterOptions {
    readonly xhrFactory?: () => XMLHttpRequest;
    readonly fetchImpl?: typeof fetch;
    readonly timeoutMs?: number;
}
export declare const createWebUploadAdapter: (options?: WebUploadAdapterOptions) => UploadAdapter | undefined;
