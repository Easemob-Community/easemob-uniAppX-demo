import { type RuntimePlatform } from './types';
export interface MiniProgramRuntimeLike {
    readonly miniGlobal?: MiniProgramRuntimeLike;
    readonly request?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly connectSocket?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly uploadFile?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly getImageInfo?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly compressImage?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly getFileSystemManager?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly canIUse?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly getSystemInfo?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly getSystemInfoSync?: (...args: ReadonlyArray<unknown>) => Record<string, unknown>;
    readonly onNetworkStatusChange?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly offNetworkStatusChange?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly onAppShow?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly offAppShow?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly onAppHide?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly offAppHide?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly getNetworkType?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly getStorageSync?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly setStorageSync?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly removeStorageSync?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly getStorage?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly setStorage?: (...args: ReadonlyArray<unknown>) => unknown;
    readonly removeStorage?: (...args: ReadonlyArray<unknown>) => unknown;
}
export interface RuntimeDetectionInput {
    readonly wx?: MiniProgramRuntimeLike;
    readonly qq?: MiniProgramRuntimeLike;
    readonly tt?: MiniProgramRuntimeLike;
    readonly swan?: MiniProgramRuntimeLike;
    readonly my?: MiniProgramRuntimeLike;
    readonly dd?: MiniProgramRuntimeLike;
    readonly jd?: MiniProgramRuntimeLike;
    readonly ks?: MiniProgramRuntimeLike;
    readonly uni?: MiniProgramRuntimeLike;
    readonly __uniConfig?: unknown;
    readonly skipWaiting?: () => Promise<void>;
    readonly registration?: unknown;
    readonly navigator?: {
        readonly product?: string;
        readonly onLine?: boolean;
    };
    readonly process?: {
        readonly versions?: {
            readonly electron?: string;
        };
    };
    readonly window?: Window;
    readonly document?: Document;
    readonly localStorage?: Storage;
    readonly fetch?: typeof fetch;
    readonly WebSocket?: typeof WebSocket;
    readonly XMLHttpRequest?: typeof XMLHttpRequest;
    readonly FormData?: typeof FormData;
    readonly TextEncoder?: typeof TextEncoder;
    readonly TextDecoder?: typeof TextDecoder;
}
export interface RuntimeEnvInfo {
    readonly platform: RuntimePlatform;
    readonly hostPlatform: RuntimePlatform;
    readonly framework: 'native' | 'uniapp' | 'web' | 'worker' | 'react-native' | 'electron';
    readonly global: RuntimeDetectionInput | MiniProgramRuntimeLike;
}
export declare const isMiniProgramRuntime: (value: unknown) => value is MiniProgramRuntimeLike;
export declare const isWebRuntime: (runtime: RuntimeDetectionInput) => boolean;
export declare const hasNativeMiniProgramHost: (runtime: RuntimeDetectionInput) => boolean;
export declare const resolveRuntimeEnv: (runtimeInput?: RuntimeDetectionInput, prefer?: RuntimePlatform) => RuntimeEnvInfo;
export declare const isMiniProgramPlatform: (platform: RuntimePlatform) => boolean;
