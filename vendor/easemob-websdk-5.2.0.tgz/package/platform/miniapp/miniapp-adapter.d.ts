import { type PlatformAdapterOverrides, type RuntimePlatform } from '../types';
import type { MiniProgramRuntimeLike } from '../env';
export declare const createMiniProgramAdapterOverrides: (runtimeInput: MiniProgramRuntimeLike, platform?: RuntimePlatform, hostPlatform?: RuntimePlatform) => PlatformAdapterOverrides;
