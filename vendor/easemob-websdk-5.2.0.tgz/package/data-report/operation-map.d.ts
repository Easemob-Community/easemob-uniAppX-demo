import type { DataReportOperationType } from './types';
type OperationDescriptor = Readonly<{
    operationName: string;
    operationType: DataReportOperationType;
}>;
export declare const resolveDataReportOperation: (operation: string) => OperationDescriptor;
export declare const resolveDataReportResultCount: (value: unknown) => number | undefined;
export {};
