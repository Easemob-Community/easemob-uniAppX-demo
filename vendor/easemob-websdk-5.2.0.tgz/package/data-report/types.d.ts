import type { RequestAdapter } from '../platform/types';
export type DataReportState = 'unknown' | 'enabled' | 'disabled';
export type DataReportOperationType = 'REST' | 'MESSAGE' | 'ROSTER' | 'USER' | 'GROUP' | 'CHATROOM' | 'MANUALLOGIN' | 'SENDMESSAGE' | 'OPERATION';
export type ReportBodyValue = string | number | boolean | undefined;
export type ReportEventBody = Readonly<Record<string, ReportBodyValue>>;
export type WireReportEvent = Readonly<{
    eventId: 9674 | 9675;
    body: ReportEventBody;
}>;
export type QueuedReportEvent = Readonly<{
    appKey: string;
    wire: WireReportEvent;
}>;
export type DataReportDropReason = 'capacity' | 'rate-limit';
export type DataReportSessionOptions = Readonly<{
    appKey: string;
    sdkVersion: string;
    platform: string;
    deviceId?: string;
    did?: string;
    os?: string | number;
    uikitVersion?: string;
    uid?: string;
    accessChannel?: string;
}>;
export type StartOperationOptions = Readonly<{
    operationName: string;
    operationType: DataReportOperationType;
    uid?: string;
    msgId?: string | number;
    messageType?: string | number;
}>;
export type StartRequestOptions = Readonly<{
    requestName?: string;
    method?: string;
    url?: string;
}>;
export type FinishRequestOptions = Readonly<{
    code: string | number;
    success: boolean;
    description?: string;
    resultCount?: number;
}>;
export type FinishOperationOptions = FinishRequestOptions;
export interface DataReportRequestHandle {
    retry(): DataReportRequestHandle;
    finish(options: FinishRequestOptions): void;
}
export interface DataReportOperationHandle {
    startRequest(options?: StartRequestOptions): DataReportRequestHandle;
    finish(options: FinishOperationOptions): void;
    discard(): void;
}
export type DataReporterOptions = Readonly<{
    requestAdapter?: RequestAdapter;
    debug?: boolean;
    now?: () => number;
    randomId?: () => string;
    send?: (appKey: string, events: ReadonlyArray<WireReportEvent>) => Promise<void>;
    onDiagnostic?: (message: string, details?: Readonly<Record<string, unknown>>) => void;
}>;
