export declare const DATA_REPORT_EVENT_IDS: {
    readonly INIT: 9674;
    readonly API: 9675;
};
export declare const DATA_REPORT_BIZ = "im";
export declare const DATA_REPORT_TOKEN = "32f24ab2ddb74f508aa9286c356cec84";
export declare const DATA_REPORT_PRODUCTION_URL = "https://data-reporting.rtnsvc.com/report";
export declare const DATA_REPORT_DEBUG_URL = "https://data-reporting.realtimemesh.com/report";
export declare const DATA_REPORT_BATCH_SIZE = 10;
export declare const DATA_REPORT_EVENT_CAPACITY = 1000;
export declare const DATA_REPORT_RATE_LIMIT = 1000;
export declare const DATA_REPORT_RATE_WINDOW_MS = 60000;
export declare const DATA_REPORT_FLUSH_INTERVAL_MS = 1000;
export declare const DATA_REPORT_CORRELATION_LIMIT = 1000;
export declare const DATA_REPORT_DEFAULT_ACCESS_CHANNEL = "direct";
export declare const DATA_REPORT_UNKNOWN_NETWORK = -1;
export declare const DATA_REPORT_OPERATION_TYPES: {
    readonly REST: "REST";
    readonly MESSAGE: "MESSAGE";
    readonly ROSTER: "ROSTER";
    readonly USER: "USER";
    readonly GROUP: "GROUP";
    readonly CHATROOM: "CHATROOM";
    readonly OPERATION: "OPERATION";
};
