export declare const normalizeDataReportNetworkType: (value: unknown) => number | string;
