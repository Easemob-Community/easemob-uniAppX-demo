import type { DataReportDropReason, QueuedReportEvent, WireReportEvent } from './types';
type EventQueueOptions = Readonly<{
    send: (appKey: string, events: ReadonlyArray<WireReportEvent>) => Promise<void>;
    capacity?: number;
    batchSize?: number;
    rateLimit?: number;
    flushIntervalMs?: number;
    now?: () => number;
    onDrop?: (reason: DataReportDropReason) => void;
}>;
export declare class DataReportEventQueue {
    private readonly sendBatch;
    private readonly capacity;
    private readonly batchSize;
    private readonly rateLimit;
    private readonly flushIntervalMs;
    private readonly now;
    private readonly onDrop;
    private readonly events;
    private enabled;
    private timer;
    private windowStartedAt;
    private acceptedInWindow;
    private capacityDiagnosticEmitted;
    private rateDiagnosticEmitted;
    constructor(options: EventQueueOptions);
    get size(): number;
    enqueue(event: QueuedReportEvent): boolean;
    enable(): void;
    updateAppKey(previousAppKey: string, nextAppKey: string): void;
    pause(): void;
    clear(): void;
    private refreshRateWindow;
    private schedule;
    private consume;
    private clearTimer;
}
export {};
