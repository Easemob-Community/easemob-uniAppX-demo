export { applyDataReportDnsSwitch, getDataReporterForTest, getDataReportServiceId, installDataReporter, resetDataReporter, startDataReportOperation, startDataReportSession, updateDataReportSession, updateDataReportNetworkType, } from './bridge';
export { DataReporter } from './data-reporter';
export type { DataReportOperationHandle, DataReportRequestHandle, DataReportSessionOptions, DataReportState, WireReportEvent, } from './types';
