import type { DataReportOperationHandle, DataReportSessionOptions, DataReporterOptions, DataReportState, StartOperationOptions } from './types';
export declare class DataReporter {
    private readonly now;
    private readonly randomId;
    private readonly queue;
    private currentState;
    private session;
    private networkType;
    constructor(options: DataReporterOptions);
    get state(): DataReportState;
    get queuedEventCount(): number;
    get serviceId(): string | undefined;
    startSession(options: DataReportSessionOptions): string;
    updateSession(options: Partial<DataReportSessionOptions>): void;
    updateNetworkType(value: unknown): void;
    applyDnsSwitch(value: unknown): void;
    startOperation(options: StartOperationOptions): DataReportOperationHandle;
    reset(): void;
    private enqueue;
    private createNoopOperation;
}
