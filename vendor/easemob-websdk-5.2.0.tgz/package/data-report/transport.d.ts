import type { RequestAdapter } from '../platform/types';
import type { WireReportEvent } from './types';
type DataReportTransportOptions = Readonly<{
    requestAdapter?: RequestAdapter;
    debug?: boolean;
    now?: () => number;
    onFailure?: (details: Readonly<Record<string, unknown>>) => void;
}>;
export declare class DataReportTransport {
    private readonly requestAdapter;
    private readonly debug;
    private readonly now;
    private readonly onFailure;
    constructor(options: DataReportTransportOptions);
    send(appKey: string, events: ReadonlyArray<WireReportEvent>): Promise<void>;
}
export {};
