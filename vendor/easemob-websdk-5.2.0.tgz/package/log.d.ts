import type { LogLevel } from './types/log';
/**
 * [zh-CN] 设置控制台、onLog 事件和日志上报共同使用的最低日志级别。
 * [en-US] Sets the minimum log level shared by console output, onLog events, and log reporting.
 *
 * @param level - [zh-CN] 最低日志级别。 [en-US] The minimum log level.
 * @returns {void} [zh-CN] 无返回值。 [en-US] No return value.
 *
 * @example
 * ```ts
 * setLogLevel('WARN');
 * ```
 */
export declare function setLogLevel(level: LogLevel): void;
/**
 * [zh-CN] 设置 SDK 日志是否输出到运行环境控制台。该开关不影响 onLog 事件或日志上报。
 * [en-US] Enables or disables SDK log output to the runtime console. This does not affect onLog events or log reporting.
 *
 * @param enabled - [zh-CN] 是否启用控制台输出。 [en-US] Whether console output is enabled.
 * @returns {void} [zh-CN] 无返回值；不抛出业务错误。 [en-US] No return value; throws no business errors.
 *
 * @example
 * ```ts
 * setConsoleLogEnabled(false);
 * ```
 */
export declare function setConsoleLogEnabled(enabled: boolean): void;
