/**
 * 重试工具
 *
 * 支持指数退避策略
 */
export interface RetryOptions {
    maxAttempts?: number;
    initialDelay?: number;
    maxDelay?: number;
    backoffMultiplier?: number;
    jitter?: boolean;
}
/**
 * 重试函数
 *
 * @param fn 要重试的函数
 * @param options 重试选项
 * @returns Promise，成功时返回函数结果，失败时抛出最后一个错误
 */
export declare function retry<T>(fn: () => Promise<T>, options?: RetryOptions): Promise<T>;
/**
 * 重试函数（带条件判断）
 *
 * 只有满足条件的错误才会重试
 */
export declare function retryWithCondition<T>(fn: () => Promise<T>, shouldRetry: (error: unknown) => boolean, options?: RetryOptions): Promise<T>;
