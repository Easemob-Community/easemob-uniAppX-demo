/**
 * 日志工具
 *
 * 支持结构化日志，多级别日志控制
 */
import { type LogReporterContext, type LogReportState } from './log-reporter';
import type { LogEntry, LogLevel } from '../types/log';
export interface Logger {
    debug(message: string, ...args: unknown[]): void;
    warn(message: string, ...args: unknown[]): void;
    error(message: string, ...args: unknown[]): void;
}
type LogEntrySink = (entry: LogEntry) => void;
/**
 * [zh-CN] 设置控制台、onLog 事件和日志上报共同使用的最低日志级别。
 * [en-US] Sets the minimum log level shared by console output, onLog events, and log reporting.
 *
 * @param level - [zh-CN] 最低日志级别。 [en-US] The minimum log level.
 * @returns [zh-CN] 无返回值。 [en-US] No return value.
 *
 * @example
 * ```ts
 * setLogLevel('WARN');
 * ```
 */
export declare function setLogLevel(level: LogLevel): void;
/**
 * [zh-CN] 设置 SDK 日志是否输出到运行环境控制台。该开关不影响 onLog 事件或日志上报。
 * [en-US] Enables or disables SDK log output to the runtime console. This does not affect onLog events or log reporting.
 *
 * @param enabled - [zh-CN] 是否启用控制台输出。 [en-US] Whether console output is enabled.
 * @returns {void} [zh-CN] 无返回值；不抛出业务错误。 [en-US] No return value; throws no business errors.
 *
 * @example
 * ```ts
 * setConsoleLogEnabled(false);
 * ```
 */
export declare function setConsoleLogEnabled(enabled: boolean): void;
/** @internal 安装结构化日志出口；仅供 ChatClient 桥接 onLog。 */
export declare function setLogEntrySink(sink: LogEntrySink | null): void;
/**
 * 设置自定义日志器
 */
export declare function setLogger(logger: Logger): void;
/**
 * 获取当前日志器
 */
export declare function getLogger(): Logger;
/**
 * 设置日志上报开关
 */
export declare function setLogReportEnabled(enabled: boolean): void;
/** 设置 DNS 驱动的日志上报三态。 */
export declare function setLogReportState(state: LogReportState): void;
/**
 * 更新日志上报上下文
 */
export declare function updateLogReportContext(context: Partial<LogReporterContext>): void;
/** 按毫秒更新 DNS 下发的日志上报间隔；缺失时恢复默认 5 分钟。 */
export declare function setLogReportInterval(reportIntervalMs: number | undefined): void;
/**
 * 立即触发日志上报
 */
export declare function reportLogsNow(): Promise<void>;
/**
 * 停止日志上报定时器
 */
export declare function stopLogReporter(): void;
/**
 * 导出日志方法
 */
export declare const logger: Logger;
export {};
