/**
 * 消息本地 ID 与本地 URL 生成工具
 */
import type { CompatibleFile } from '../types';
/**
 * 生成本地可用的文件 URL
 */
export declare const createLocalFileUrl: (file: CompatibleFile) => string | undefined;
/**
 * 生成本地消息 ID
 */
export declare const generateMsgLocalId: () => string;
