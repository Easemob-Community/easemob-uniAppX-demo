/**
 * 日志上报器
 *
 * 支持缓存、分片与定时上报
 */
import type { LogEntry } from '../types/log';
import type { RequestAdapter } from '../platform/types';
export interface LogReporterContext {
    restBaseUrl?: string;
    appKey?: string;
    userId?: string;
    token?: string;
    resource?: string;
    requestAdapter?: RequestAdapter;
}
export interface LogReporterOptions {
    reportIntervalMs?: number;
    reportTimeoutMs?: number;
    chunkDelayMs?: number;
    maxChunkBytes?: number;
    maxBufferBytes?: number;
}
export type LogReportState = 'unknown' | 'enabled' | 'disabled';
export declare class LogReporter {
    private state;
    private reportIntervalMs;
    private readonly reportTimeoutMs;
    private readonly chunkDelayMs;
    private readonly maxChunkBytes;
    private readonly maxBufferBytes;
    private timerId;
    private reporting;
    private context;
    private buffer;
    private bufferBytes;
    constructor(options?: LogReporterOptions);
    setEnabled(enabled: boolean): void;
    setState(state: LogReportState): void;
    updateContext(context: Partial<LogReporterContext>): void;
    updateReportInterval(reportIntervalMs: number | undefined): void;
    append(entry: LogEntry): void;
    reportNow(): Promise<void>;
    stop(): void;
    private clearBuffer;
    private start;
    private normalizeReportInterval;
    private canReport;
    private formatEntry;
    private pushBuffer;
    private consumeBuffer;
    private requeueChunk;
    private reportLogs;
    private reportChunk;
}
export declare const logReporter: LogReporter;
