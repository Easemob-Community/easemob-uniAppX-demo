/**
 * 统一获取跨运行时可用的全局对象。
 */
type RuntimeHostBindings = {
    readonly wx?: unknown;
    readonly qq?: unknown;
    readonly tt?: unknown;
    readonly swan?: unknown;
    readonly my?: unknown;
    readonly dd?: unknown;
    readonly jd?: unknown;
    readonly ks?: unknown;
    readonly uni?: unknown;
};
export declare const createRuntimeInputOverlay: (standardGlobal: object | undefined, hostBindings: RuntimeHostBindings) => object;
export declare const getRuntimeGlobal: <TGlobal extends object>(runtimeInput?: TGlobal) => TGlobal;
export {};
