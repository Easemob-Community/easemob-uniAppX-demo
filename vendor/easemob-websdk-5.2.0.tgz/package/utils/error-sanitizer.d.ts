/**
 * 从公开错误详情中的 URL 删除凭据、查询参数值和 Fragment。
 */
export declare const sanitizeErrorUrl: (url: string) => string;
/**
 * 对错误详情中的 URL 字段执行统一脱敏。
 */
export declare const sanitizeErrorDetails: (details: Record<string, unknown>) => Record<string, unknown>;
