/**
 * 日志脱敏工具
 *
 * 对敏感字段进行掩码处理，遵循最小必要原则
 */
export declare const sanitizeLogArgs: (args: ReadonlyArray<unknown>) => ReadonlyArray<unknown>;
