/**
 * 跨运行时查询参数序列化。
 *
 * 微信小程序等运行时可能没有 URLSearchParams；优先复用原生实现，缺失时使用
 * application/x-www-form-urlencoded 兼容序列化，保持 REST 请求的编码语义一致。
 */
export interface QueryParams {
    set(name: string, value: string): void;
    toString(): string;
}
type QueryParamsInitialValues = Readonly<Record<string, string>>;
/**
 * 创建可在 Web、React Native 与小程序运行时使用的查询参数对象。
 */
export declare const createQueryParams: (initialValues?: QueryParamsInitialValues) => QueryParams;
export {};
