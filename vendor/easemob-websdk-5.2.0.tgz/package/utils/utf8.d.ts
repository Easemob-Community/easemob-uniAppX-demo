export declare const encodeUtf8: (value: string) => Uint8Array;
export declare const decodeUtf8: (bytes: Uint8Array) => string;
