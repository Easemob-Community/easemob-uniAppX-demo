import type { MessageDirect } from '../types';
import type { ConversationType } from '../types/conversation';
/** 会话摘要仅暴露接收者用户 ID，完整 Message 继续保留设备路由信息。 */
export declare const resolveSessionMessageTo: (options: {
    readonly conversationId: string;
    readonly conversationType: ConversationType;
    readonly currentUserId: string;
    readonly from: string;
    readonly to?: string;
    readonly direct?: MessageDirect;
}) => string;
