/**
 * 生成链路追踪 ID（时间戳 + 随机数）
 */
export declare const createTraceId: () => string;
export declare const REQUEST_ID_HEADER = "X-Request-Id";
