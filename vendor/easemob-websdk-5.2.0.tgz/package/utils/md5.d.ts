export declare const computeMd5Hex: (bytes: Uint8Array) => string;
