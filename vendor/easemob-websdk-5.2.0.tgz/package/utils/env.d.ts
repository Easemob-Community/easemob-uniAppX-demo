/**
 * 运行时环境判断
 */
export declare const isUniAppRuntime: () => boolean;
