/**
 * 判断跨平台存储错误是否表示容量或配额超限。
 */
export declare const isStorageQuotaExceededError: (error: unknown) => boolean;
/**
 * 将平台容量错误规范化为可安全 reject 的 Error，并保留原始错误作为 cause。
 */
export declare const normalizeStorageQuotaExceededError: (error: unknown) => Error;
