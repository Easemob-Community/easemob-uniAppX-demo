/**
 * 错误处理类
 *
 * 统一的错误类型和错误码定义
 */
import { type ErrorCode } from './error-codes';
/**
 * [zh-CN] SDK 错误附加详情。
 *
 * [en-US] Additional details attached to an SDK error.
 */
export type ErrorDetails = Record<string, unknown>;
/**
 * [zh-CN] SDK 错误上下文。
 *
 * [en-US] Context associated with an SDK error.
 */
export interface ErrorContext {
    /**
     * [zh-CN] 用于诊断错误的结构化附加信息。
     *
     * [en-US] Structured additional information for diagnosing the error.
     */
    details?: ErrorDetails;
}
/**
 * SDK 错误类
 */
export declare class SDKError extends Error {
    readonly code: ErrorCode;
    readonly details?: ErrorDetails;
    constructor(message: string, code?: ErrorCode, context?: ErrorContext);
    /**
     * 转换为 JSON
     */
    toJSON(): Record<string, unknown>;
}
/**
 * 网络错误
 */
export declare class NetworkError extends SDKError {
    constructor(message: string, context?: ErrorContext & {
        code?: ErrorCode;
    });
}
/**
 * 连接错误
 */
export declare class ConnectionError extends SDKError {
    constructor(message: string, context?: ErrorContext & {
        code?: ErrorCode;
    });
}
/**
 * 认证错误
 */
export declare class AuthenticationError extends SDKError {
    constructor(message: string, context?: ErrorContext & {
        code?: ErrorCode;
    });
}
/**
 * 验证错误
 */
export declare class ValidationError extends SDKError {
    constructor(message: string, context?: ErrorContext & {
        code?: ErrorCode;
    });
}
/**
 * 消息发送错误
 */
export declare class MessageSendError extends SDKError {
    constructor(message: string, context?: ErrorContext & {
        code?: ErrorCode;
    });
}
/**
 * 消息接收错误
 */
export declare class MessageReceiveError extends SDKError {
    constructor(message: string, context?: ErrorContext & {
        code?: ErrorCode;
    });
}
/**
 * 存储错误
 */
export declare class StorageError extends SDKError {
    constructor(message: string, context?: ErrorContext & {
        code?: ErrorCode;
    });
}
export declare class RestTransportError extends SDKError {
    constructor(message: string, context?: ErrorContext & {
        code?: ErrorCode;
    });
}
export declare class RestBusinessError extends SDKError {
    constructor(message: string, context?: ErrorContext & {
        code?: ErrorCode;
    });
}
/**
 * 上传错误
 */
export declare class UploadError extends SDKError {
    constructor(message: string, context?: ErrorContext & {
        code?: ErrorCode;
    });
}
/**
 * [zh-CN] 判断未知值是否为 SDK 错误。
 *
 * 除当前模块创建的实例外，该方法也支持识别 iframe、微前端或重复安装的
 * SDK 副本所创建的结构兼容错误。
 *
 * @example
 * ```ts
 * try {
 *   await client.login({ userId: 'u1', token: 'token' });
 * } catch (error: unknown) {
 *   if (isSDKError(error)) {
 *     console.error(error.toJSON());
 *   }
 * }
 * ```
 *
 * @param error [zh-CN] 需要判断的未知值。[en-US] The unknown value to inspect.
 * @returns [zh-CN] 值为 SDK 错误时返回 `true`，并将类型收窄为 `SDKError`。
 * [en-US] Returns `true` when the value is an SDK error and narrows it to `SDKError`.
 * @throws [zh-CN] 此函数不会抛出错误。[en-US] This function does not throw errors.
 *
 * [en-US] Checks whether an unknown value is an SDK error.
 *
 * In addition to instances created by this module, this function recognizes structurally
 * compatible errors created in iframes, micro-frontends, or duplicate SDK copies.
 */
export declare function isSDKError(error: unknown): error is SDKError;
