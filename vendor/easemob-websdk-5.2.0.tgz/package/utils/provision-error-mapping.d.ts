/**
 * Provision 错误码到 EMError 的映射
 */
import { type ErrorCode } from './error-codes';
/**
 * Provision 错误解析结果
 */
export interface ProvisionErrorResolution {
    readonly code: ErrorCode;
    readonly retryable: boolean;
}
/** 消息发送错误解析结果 */
export interface MessageSendErrorResolution extends ProvisionErrorResolution {
    readonly message: string;
}
export declare const resolveProvisionError: (statusCode: number | undefined, reason?: string) => ProvisionErrorResolution;
export declare const resolveProvisionErrorCode: (statusCode: number | undefined, reason?: string) => ErrorCode;
/**
 * 将消息 ACK 的状态码和原因解析为面向调用方的具体错误。
 */
export declare const resolveMessageSendError: (statusCode: number | undefined, reason?: string) => MessageSendErrorResolution;
