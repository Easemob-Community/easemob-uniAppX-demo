/**
 * [zh-CN] GroupManager 对外管理器实现。
 * [en-US] Public GroupManager implementation.
 */
import type { ChatClient } from '../chat-client';
import type { AcceptGroupJoinRequestParams, CreateGroupParams, CreateGroupResult, DeleteGroupSharedFileParams, DownloadGroupSharedFileParams, GetGroupInfoListParams, GetGroupInfoParams, GetGroupMembersAttributesParams, GroupAdminMutationParams, GroupAnnouncement, GroupAnnouncementUpdateParams, GroupBlocklistEntry, GroupBlocklistParams, GroupDetail, GroupMemberListParams, GroupMemberListResult, GroupMembersAttributesResult, GroupMuteEntry, GroupMuteListParams, GroupMutationTarget, GroupOwnerChangeParams, GroupRawNotifyEvent, GroupRawNotifyPayload, GroupSharedFileListParams, GroupSharedFileListResult, GroupUserBatchParams, GroupUserInfo, GroupJoinParams, GroupMuteMembersParams, RejectGroupJoinRequestParams, SetGroupMemberAttributesParams, UpdateGroupInfoParams, UploadGroupSharedFileParams, GroupAllowlistEntry, JoinedGroupSnapshot, JoinedGroupSummary } from '../types/group';
import type { EventHandlerId, GroupEventHandlerMap, GroupEventName as GroupEventNameType, GroupEventPayloadMap } from '../types/event-system';
import type { ManagerBase, ManagerEventContext } from '../types/manager';
import type { RawNotifyEvent } from '../types/manager';
import { Group } from './group/group';
import { GroupSyncController } from '../core/group-sync/group-sync-controller';
import type { GroupSyncControllerDependencies } from '../core/group-sync/group-sync-types';
interface GroupNamecardHydrationTarget {
    readonly userId: string;
    readonly namecardUpdateTime?: number;
}
export declare class GroupManager implements ManagerBase<ChatClient> {
    /** @internal SDK 内部管理器注册键，不对外文档暴露。 */
    static readonly key: "groupManager";
    /** @internal SDK 内部 raw notify 与群名片能力声明，不作为公开 API 使用。 */
    readonly capabilities: readonly ["rawNotify:group", "group:namecard"];
    private client;
    private eventContext;
    private restClient;
    private restBaseUrl;
    private restToken;
    private readonly groupRegistry;
    private groupRepository;
    private groupEventSync;
    /**
     * @internal
     * [zh-CN] 绑定 GroupManager 到 ChatClient，通常由 SDK 内部在 `client.groupManager` 初始化阶段调用。 [en-US] Binds GroupManager to ChatClient and is usually called internally when `client.groupManager` is initialized.
     */
    bind(client: ChatClient, context?: ManagerEventContext): void;
    /**
     * [zh-CN] 注册群组事件处理器。
     * [en-US] Registers group event handlers.
     *
     * @example [zh-CN] 监听群成员加入事件 [en-US] Listen for members joined events
     * ```ts
     * client.groupManager.addEventHandler('group-events', {
     *   onMembersJoined: event => console.log(event.groupId, event.members),
     * });
     * ```
     * @param id - [zh-CN] 事件处理器唯一 ID，用于后续移除。 [en-US] Unique handler id used for later removal.
     * @param handlers - [zh-CN] 群组事件处理器集合。 [en-US] Group event handler collection.
     * @returns {void} [zh-CN] 注册完成后无返回值。 [en-US] Returns nothing after registration.
     */
    addEventHandler(id: EventHandlerId, handlers: GroupEventHandlerMap): void;
    /**
     * [zh-CN] 移除群组事件处理器。
     * [en-US] Removes group event handlers.
     *
     * @example [zh-CN] 移除监听 [en-US] Remove a handler
     * ```ts
     * client.groupManager.removeEventHandler('group-events');
     * ```
     * @param id - [zh-CN] 待移除的事件处理器 ID。 [en-US] Handler id to remove.
     * @returns {void} [zh-CN] 移除完成后无返回值。 [en-US] Returns nothing after removal.
     */
    removeEventHandler(id: EventHandlerId): void;
    /** @internal */
    handleRawNotify(event: RawNotifyEvent): Promise<void>;
    /**
     * [zh-CN] 创建群组，可指定初始成员、公开属性、入群审批、邀请策略与最大人数。
     * [en-US] Creates a group with initial members, visibility, join joinApprovalRequired, invitation policy, and member limit.
     *
     * @example [zh-CN] 创建公开群 [en-US] Create a public group
     * ```ts
     * const result = await client.groupManager.createGroup({
     *   name: 'Developers',
     *   description: 'SDK discussion',
     *   memberIds: ['user-1', 'user-2'],
     *   public: true,
     *   joinApprovalRequired: false,
     *   allowInvites: true,
     *   inviteNeedConfirm: true,
     *   maxMembers: 200,
     * });
     * ```
     * @param params - [zh-CN] 创建群组参数。 [en-US] Group creation parameters.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：必填字段缺失、字段格式非法或成员不存在。 [en-US] Error code `110`: missing required fields, invalid field format, or member not found.
     * @throws {SDKError} [zh-CN] 错误码 `4`：群组数量、用户加入群数量或初始成员数量达到服务限制。 [en-US] Error code `4`: group count, joined group count, or initial member count exceeds service limits.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。 [en-US] Error code `202`: authentication failed.
     * @returns {Promise<CreateGroupResult>} [zh-CN] 返回创建成功后的群 ID。 [en-US] Returns the created group id.
     */
    createGroup(params: CreateGroupParams): Promise<CreateGroupResult>;
    /**
     * [zh-CN] 读取当前用户已加入群组的本地同步列表；该方法只读本地缓存和当前会话运行时数据，不发起网络请求。
     * [en-US] Reads the local synced list of groups joined by the current user. This method only reads local cache and current-session runtime data, and never sends network requests.
     *
     * @example [zh-CN] 读取已加入群本地列表 [en-US] Read local joined groups
     * ```ts
     * const groups = client.groupManager.getJoinedGroupList();
     * ```
     * @returns {ReadonlyArray<JoinedGroupSummary>} [zh-CN] 返回本地已加入群组轻量数组。 [en-US] Returns lightweight local joined groups.
     */
    getJoinedGroupList(): ReadonlyArray<JoinedGroupSummary>;
    /** @internal */
    getJoinedGroupSnapshotForSync(): JoinedGroupSnapshot;
    /** @internal */
    applyJoinedGroupSnapshot(snapshot: JoinedGroupSnapshot): void;
    /** @internal 推荐使用 groupManager.getGroup(groupId).getSummary()。 */
    getGroupSummaryForHandle(groupId: string): JoinedGroupSummary | null;
    /**
     * [zh-CN] 获取绑定指定群 ID 的单群操作对象；该方法不发起网络请求。
     * [en-US] Gets a single-group operation facade bound to the specified group id; this method does not send a network request.
     *
     * @example [zh-CN] 获取单群对象 [en-US] Get a group facade
     * ```ts
     * const group = client.groupManager.getGroup('group-1');
     * await group.getDetail();
     * ```
     * @param groupId - [zh-CN] 群组 ID。 [en-US] Group id.
     * @throws {ValidationError} [zh-CN] 错误码 `100`：`groupId` 为空。 [en-US] Error code `100`: `groupId` is empty.
     * @returns {Group} [zh-CN] 返回绑定该群 ID 的 `Group` 对象。 [en-US] Returns a `Group` facade bound to the group id.
     */
    getGroup(groupId: string): Group;
    /**
     * [zh-CN] 从服务端获取单个群组详情。
     * [en-US] Gets one group detail from the server.
     *
     * @example [zh-CN] 获取群详情 [en-US] Get group detail
     * ```ts
     * const detail = await client.groupManager.getGroupInfo({ groupId: 'group-1' });
     * ```
     * @param params - [zh-CN] 群组详情查询参数。 [en-US] Group detail query parameters.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群 ID 非法或群组不存在。 [en-US] Error code `110`: invalid group id or group not found.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。 [en-US] Error code `202`: authentication failed.
     * @returns {Promise<GroupDetail>} [zh-CN] 返回标准化群详情。 [en-US] Returns the normalized group detail.
     */
    getGroupInfo(params: GetGroupInfoParams): Promise<GroupDetail>;
    /**
     * [zh-CN] 批量获取多个群组详情。
     * [en-US] Gets details for multiple groups.
     *
     * @example [zh-CN] 批量获取群详情 [en-US] Get multiple group details
     * ```ts
     * const groups = await client.groupManager.getGroupInfoList({
     *   groupIds: ['group-1', 'group-2'],
     * });
     * ```
     * @param params - [zh-CN] 群组 ID 列表。 [en-US] Group id list.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 列表为空或包含非法 ID。 [en-US] Error code `110`: empty group id list or invalid group id.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。 [en-US] Error code `202`: authentication failed.
     * @returns {Promise<ReadonlyArray<GroupDetail>>} [zh-CN] 返回标准化群详情数组。 [en-US] Returns normalized group details.
     */
    getGroupInfoList(params: GetGroupInfoListParams): Promise<ReadonlyArray<GroupDetail>>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).getDetail()。 */
    getGroupDetailForHandle(groupId: string): Promise<GroupDetail>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).refresh()。 */
    refreshGroupDetailForHandle(groupId: string): Promise<GroupDetail>;
    /** @internal 推荐由 ChatClient logout / 会话切换清理调用。 */
    resetSessionRuntime(): void;
    /** @internal 推荐由 ChatClient 的群事件分发链路调用。 */
    buildIncomingEventPayload(eventName: GroupEventNameType, rawEvent: GroupRawNotifyEvent): Promise<GroupEventPayloadMap[GroupEventNameType] | null>;
    /** @internal 推荐由 ChatClient 的群事件分发链路调用。 */
    resolveGroupDetailForEvent(raw: GroupRawNotifyPayload): Promise<GroupDetail>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).updateInfo()。 */
    updateGroupInfo(params: UpdateGroupInfoParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).changeOwner()。 */
    changeGroupOwner(params: GroupOwnerChangeParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).destroy()。 */
    destroyGroup(params: GroupMutationTarget): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).leave()。 */
    leaveGroup(params: GroupMutationTarget): Promise<void>;
    /**
     * [zh-CN] 申请加入或直接加入指定群组，取决于群组入群审批配置。
     * [en-US] Applies to join or directly joins a group depending on the group's join joinApprovalRequired setting.
     *
     * @example [zh-CN] 加入群组 [en-US] Join a group
     * ```ts
     * await client.groupManager.joinGroup({
     *   groupId: 'group-1',
     *   message: 'Please approve my request',
     * });
     * ```
     * @param params - [zh-CN] 群组 ID 与可选申请原因。 [en-US] Group id and optional join request message.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群 ID 非法、群组不存在或已在群内。 [en-US] Error code `110`: invalid group id, group not found, or already joined.
     * @throws {SDKError} [zh-CN] 错误码 `4`：群成员数或用户加入群数量达到服务限制。 [en-US] Error code `4`: group member count or joined group count exceeds service limits.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。 [en-US] Error code `202`: authentication failed.
     * @returns {Promise<void>} [zh-CN] 成功时无返回值。 [en-US] Resolves with no payload on success.
     */
    joinGroup(params: GroupJoinParams): Promise<void>;
    /**
     * [zh-CN] 邀请用户加入指定群组。
     * [en-US] Invites users to a group.
     *
     * @example [zh-CN] 邀请成员 [en-US] Invite members
     * ```ts
     * await client.groupManager.inviteUsersToGroup({
     *   groupId: 'group-1',
     *   userIds: ['user-2', 'user-3'],
     * });
     * ```
     * @param params - [zh-CN] 群组 ID 与被邀请用户 ID 列表。 [en-US] Group id and invited user ids.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：用户列表为空、用户 ID 非法或群组不存在。 [en-US] Error code `110`: empty user list, invalid user id, or group not found.
     * @throws {SDKError} [zh-CN] 错误码 `4`：群成员数量达到服务限制。 [en-US] Error code `4`: group member count exceeds service limits.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败或无权限。 [en-US] Error code `202`: authentication failed or permission denied.
     * @returns {Promise<void>} [zh-CN] 成功时无返回值。 [en-US] Resolves with no payload on success.
     */
    inviteUsersToGroup(params: GroupUserBatchParams): Promise<void>;
    /**
     * [zh-CN] 同意用户的入群申请。
     * [en-US] Accepts a user's group join request.
     *
     * @example [zh-CN] 同意入群申请 [en-US] Accept a join request
     * ```ts
     * await client.groupManager.acceptGroupJoinRequest({
     *   groupId: 'group-1',
     *   userId: 'user-2',
     * });
     * ```
     * @param params - [zh-CN] 群组 ID 与申请人用户 ID。 [en-US] Group id and applicant user id.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：申请人 ID 非法、申请不存在或群组不存在。 [en-US] Error code `110`: invalid applicant id, request not found, or group not found.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败或无权限。 [en-US] Error code `202`: authentication failed or permission denied.
     * @returns {Promise<void>} [zh-CN] 成功时无返回值。 [en-US] Resolves with no payload on success.
     */
    acceptGroupJoinRequest(params: AcceptGroupJoinRequestParams): Promise<void>;
    /**
     * [zh-CN] 拒绝用户的入群申请。
     * [en-US] Rejects a user's group join request.
     *
     * @example [zh-CN] 拒绝入群申请 [en-US] Reject a join request
     * ```ts
     * await client.groupManager.rejectGroupJoinRequest({
     *   groupId: 'group-1',
     *   userId: 'user-2',
     *   reason: 'Group is full',
     * });
     * ```
     * @param params - [zh-CN] 群组 ID、申请人用户 ID 与拒绝原因。 [en-US] Group id, applicant user id, and rejection reason.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：申请人 ID、拒绝原因非法，申请不存在或群组不存在。 [en-US] Error code `110`: invalid applicant id or reason, request not found, or group not found.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败或无权限。 [en-US] Error code `202`: authentication failed or permission denied.
     * @returns {Promise<void>} [zh-CN] 成功时无返回值。 [en-US] Resolves with no payload on success.
     */
    rejectGroupJoinRequest(params: RejectGroupJoinRequestParams): Promise<void>;
    /**
     * [zh-CN] 接受当前用户收到的群组邀请。
     * [en-US] Accepts a group invitation received by the current user.
     *
     * @example [zh-CN] 接受群邀请 [en-US] Accept a group invitation
     * ```ts
     * await client.groupManager.acceptInvitation({ groupId: 'group-1' });
     * ```
     * @param params - [zh-CN] 群组 ID。 [en-US] Group id.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群 ID 非法、邀请不存在或群组不存在。 [en-US] Error code `110`: invalid group id, invitation not found, or group not found.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。 [en-US] Error code `202`: authentication failed.
     * @returns {Promise<void>} [zh-CN] 成功时无返回值。 [en-US] Resolves with no payload on success.
     */
    acceptInvitation(params: GroupMutationTarget): Promise<void>;
    /**
     * [zh-CN] 拒绝当前用户收到的群组邀请。
     * [en-US] Rejects a group invitation received by the current user.
     *
     * @example [zh-CN] 拒绝群邀请 [en-US] Reject a group invitation
     * ```ts
     * await client.groupManager.rejectInvitation({ groupId: 'group-1' });
     * ```
     * @param params - [zh-CN] 群组 ID。 [en-US] Group id.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群 ID 非法、邀请不存在或群组不存在。 [en-US] Error code `110`: invalid group id, invitation not found, or group not found.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。 [en-US] Error code `202`: authentication failed.
     * @returns {Promise<void>} [zh-CN] 成功时无返回值。 [en-US] Resolves with no payload on success.
     */
    rejectInvitation(params: GroupMutationTarget): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).getMembers()。 */
    getGroupMemberList(params: GroupMemberListParams): Promise<GroupMemberListResult>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).removeMembers()。 */
    removeGroupMembers(params: GroupUserBatchParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).getAdmins()。 */
    getGroupAdminList(params: GroupMutationTarget): Promise<ReadonlyArray<GroupUserInfo>>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).addAdmin()。 */
    addGroupAdmin(params: GroupAdminMutationParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).removeAdmin()。 */
    removeGroupAdmin(params: GroupAdminMutationParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).getMuteList()。 */
    getGroupMuteList(params: GroupMuteListParams): Promise<ReadonlyArray<GroupMuteEntry>>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).muteMembers()。 */
    muteGroupMembers(params: GroupMuteMembersParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).unmuteMembers()。 */
    unmuteGroupMembers(params: GroupUserBatchParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).muteAllMembers()。 */
    muteAllGroupMembers(params: GroupMutationTarget): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).unmuteAllMembers()。 */
    unmuteAllGroupMembers(params: GroupMutationTarget): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).getBlocklist()。 */
    getGroupBlocklist(params: GroupBlocklistParams): Promise<ReadonlyArray<GroupBlocklistEntry>>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).blockMembers()。 */
    blockGroupMembers(params: GroupUserBatchParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).unblockMembers()。 */
    unblockGroupMembers(params: GroupUserBatchParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).getAllowlist()。 */
    getGroupAllowlist(params: GroupMutationTarget): Promise<ReadonlyArray<GroupAllowlistEntry>>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).addUsersToAllowlist()。 */
    addUsersToGroupAllowlist(params: GroupUserBatchParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).removeUsersFromAllowlist()。 */
    removeUsersFromGroupAllowlist(params: GroupUserBatchParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).checkIfInAllowList()。 */
    checkIfInGroupAllowList(params: GroupMutationTarget): Promise<boolean>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).checkIfInMuteList()。 */
    checkIfInGroupMuteList(params: GroupMutationTarget): Promise<boolean>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).getAnnouncement()。 */
    getGroupAnnouncement(params: GroupMutationTarget): Promise<GroupAnnouncement>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).updateAnnouncement()。 */
    updateGroupAnnouncement(params: GroupAnnouncementUpdateParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).getSharedFileList()。 */
    getGroupSharedFileList(params: GroupSharedFileListParams): Promise<GroupSharedFileListResult>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).uploadSharedFile()。 */
    uploadGroupSharedFile(params: UploadGroupSharedFileParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).deleteSharedFile()。 */
    deleteGroupSharedFile(params: DeleteGroupSharedFileParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).downloadSharedFile()。 */
    downloadGroupSharedFile(params: DownloadGroupSharedFileParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).setMemberAttributes()。 */
    setGroupMemberAttributes(params: SetGroupMemberAttributesParams): Promise<void>;
    /** @internal 推荐使用 groupManager.getGroup(groupId).getMembersAttributes()。 */
    getGroupMembersAttributes(params: GetGroupMembersAttributesParams): Promise<GroupMembersAttributesResult>;
    /**
     * @internal
     * [zh-CN] 为消息资料同步链路批量补全群名片缓存。
     * [en-US] Hydrates group name card cache entries for the message profile synchronization flow.
     */
    hydrateMessageProfileGroupNamecards(groupId: string, targets: ReadonlyArray<GroupNamecardHydrationTarget>): Promise<void>;
    private runOperation;
    private normalizeSdkError;
    private getRestContextOrThrow;
    private getRestClient;
    private requireClient;
    private getGroupRepository;
    private getGroupEventSync;
    private ensureRepositorySession;
    private resolveRepositorySessionKey;
    private getCacheManager;
    private loadJoinedGroupPreviewSnapshot;
    private resolveLocalGroupName;
    private resolveMembersJoinedGroupName;
    private resolveUsableGroupName;
    private writeSelfGroupNamecardCache;
    private resolveGroupMemberAttributesUpdateTime;
    private collectUpdateTimeCandidates;
    private getUserInfoManager;
    private hasUserInfoCapabilityProvider;
    private hasUserInfoReadCapability;
    private resolveUserInfoMap;
    private collectEventUserIds;
    private pickEventUser;
    private pickEventUsers;
    private hydrateEventSharedFile;
    private syncRuntimeForEvent;
    private getMemberEventDeltaCount;
    private applyMemberCountDeltaPatch;
    private removeJoinedGroupLocal;
    private addCurrentUserJoinedGroupFromEvent;
    private addJoinedGroupIfAbsent;
    private enrichJoinedGroupFromDetail;
    private persistJoinedGroupSnapshot;
    private hydrateUserInfos;
    private fetchUserInfosFromRest;
    private hydrateEntriesWithUsers;
    private extractGroupNamecard;
    private hydrateGroupDetailUsers;
    private hydrateGroupDetailsUsers;
    private resolveGroupContextUserInfoMap;
    private resolveGroupUserInfoContexts;
    private fetchGroupUserInfos;
    private isGroupNamecardEnhancementEnabled;
    private dispatchFetchedUserInfoUpdates;
    /** @internal */
    createSyncController(deps: GroupSyncControllerDependencies): GroupSyncController;
}
export {};
