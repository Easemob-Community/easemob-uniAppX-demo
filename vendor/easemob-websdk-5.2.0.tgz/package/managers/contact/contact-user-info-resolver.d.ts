import type { CacheManager } from '../../cache/cache-manager';
import type { UserInfo } from '../../types/user-info';
import type { Contact } from '../../types/contact';
export interface ContactUserInfoFetchParams {
    readonly userIds: ReadonlyArray<string>;
}
export type ContactUserInfoFetcher = (params: ContactUserInfoFetchParams) => Promise<ReadonlyArray<UserInfo>>;
interface ContactUserInfoResolverOptions {
    readonly cacheManager: Pick<CacheManager, 'getUserInfoSummaries'> | null;
    readonly fetchUserInfos?: ContactUserInfoFetcher;
}
export declare const resolveContactUserInfoMap: (userIds: ReadonlyArray<string>, options: ContactUserInfoResolverOptions) => Promise<ReadonlyMap<string, UserInfo>>;
export declare const enrichContactsWithResolvedUserInfo: (contacts: ReadonlyArray<Contact>, options: ContactUserInfoResolverOptions) => Promise<ReadonlyArray<Contact>>;
export declare const resolveSingleContactUserInfo: (userId: string, options: ContactUserInfoResolverOptions) => Promise<UserInfo>;
export {};
