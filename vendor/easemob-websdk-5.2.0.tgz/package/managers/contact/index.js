import{C as a}from"../../chunks/index-C_EMU0-3.js";export{a as ContactManager};
