/**
 * [zh-CN] UserInfoManager 对外管理器实现，负责用户资料查询、更新与缓存桥接。
 * [en-US] Public UserInfoManager implementation for profile fetch, update, and cache projection.
 */
import type { ChatClient } from '../chat-client';
import type { EventHandlerId, UserInfoEventHandlerMap } from '../types/event-system';
import type { ManagerBase, ManagerEventContext, RawNotifyEvent } from '../types/manager';
import type { FetchUserInfoByAttributeParams, FetchUserInfoByUserIdParams, SubscribeUsersInfoParams, UnsubscribeUsersInfoParams, UpdateOwnInfoParams, UserInfoAttribute, UserInfo } from '../types/user-info';
export declare class UserInfoManager implements ManagerBase<ChatClient> {
    /** @internal SDK 内部管理器注册键，不对外文档暴露。 */
    static readonly key: "userInfoManager";
    readonly capabilities: readonly ["userInfo:read", "rawNotify:userInfo"];
    private client;
    private eventContext;
    private restClient;
    private restBaseUrl;
    private restToken;
    /**
     * @internal
     * [zh-CN] 绑定 UserInfoManager 到 ChatClient，通常由 SDK 在 `client.userInfoManager` 初始化阶段调用。
     * [en-US] Binds UserInfoManager to ChatClient and is usually called internally during `client.userInfoManager` initialization.
     *
     * @param client - [zh-CN] 已初始化的 ChatClient 实例。 [en-US] Initialized ChatClient instance.
     * @param context - [zh-CN] Manager 事件上下文。 [en-US] Manager event context.
     * @returns {void} [zh-CN] 无返回值。 [en-US] Returns nothing.
     */
    bind(client: ChatClient, context?: ManagerEventContext): void;
    /**
     * [zh-CN] 注册用户资料事件处理器，用于接收当前用户资料更新和订阅用户资料变更通知。
     * [en-US] Registers user profile event handlers for current-user updates and subscribed profile changes.
     *
     * @example [zh-CN] 调用示例（注册事件处理器） [en-US] Usage example (register event handlers)
     * ```ts
     * client.userInfoManager.addEventHandler('profile-listener', {
     *   onOwnInfoUpdated: profile => {
     *     console.log(profile.nickname);
     *   },
     *   onUserInfoUpdated: users => {
     *     console.log(users.map(user => user.userId));
     *   },
     * });
     * ```
     *
     * @param id - [zh-CN] 事件处理器 ID，同一个 ID 再次注册会覆盖旧处理器。 [en-US] Event handler ID; registering the same ID again replaces the previous handler.
     * @param handlers - [zh-CN] 用户资料事件处理器集合。 [en-US] User profile event handler map.
     * @returns {void} [zh-CN] 无返回值。 [en-US] Returns nothing.
     */
    addEventHandler(id: EventHandlerId, handlers: UserInfoEventHandlerMap): void;
    /**
     * [zh-CN] 移除指定 ID 的用户资料事件处理器，停止接收对应事件回调。
     * [en-US] Removes the user profile event handler with the specified ID and stops its callbacks.
     *
     * @example [zh-CN] 调用示例（移除事件处理器） [en-US] Usage example (remove an event handler)
     * ```ts
     * client.userInfoManager.removeEventHandler('profile-listener');
     * ```
     *
     * @param id - [zh-CN] 注册时传入的事件处理器 ID。 [en-US] Event handler ID used during registration.
     * @returns {void} [zh-CN] 无返回值。 [en-US] Returns nothing.
     */
    removeEventHandler(id: EventHandlerId): void;
    /**
     * @internal
     * [zh-CN] 处理 SDK 内部转发的用户资料原始 notify。
     * [en-US] Handles raw user-info notifies forwarded internally by the SDK.
     *
     * @param event - [zh-CN] 用户资料原始通知事件。 [en-US] Raw user-info notify event.
     * @returns {void} [zh-CN] 无返回值。 [en-US] Returns nothing.
     */
    handleRawNotify(event: RawNotifyEvent): void;
    /**
     * [zh-CN] 按用户 ID 查询用户资料属性；未指定属性时查询 SDK 默认资料字段。
     * [en-US] Fetches user profile attributes by user IDs; when no attribute projection is provided, SDK default profile fields are returned.
     *
     * @example [zh-CN] 调用示例（按用户 ID 查询） [en-US] Usage example (fetch by user IDs)
     * ```ts
     * const users = await client.userInfoManager.getUserInfoByUserId({
     *   userIds: ['alice', 'bob'],
     * });
     * console.log(users[0]?.avatarUrl);
     * ```
     *
     * @param params - [zh-CN] 包含 `userIds` 与可选成功/失败回调的参数对象。 [en-US] Parameter object containing `userIds` and optional success/error callbacks.
     * @returns {Promise<ReadonlyArray<UserInfo>>} [zh-CN] 按请求顺序返回标准化后的用户资料数组；未设置资料的用户返回仅包含 `userId` 的对象。 [en-US] Returns normalized user profiles in request order; users without profile metadata are represented by an object containing only `userId`.
     */
    getUserInfoByUserId(params: FetchUserInfoByUserIdParams): Promise<ReadonlyArray<UserInfo>>;
    /**
     * [zh-CN] 按用户 ID 和指定属性集查询用户资料，适合只读取昵称、头像等部分字段。
     * [en-US] Fetches selected user profile attributes by user IDs, useful when only fields such as nickname or avatar are needed.
     *
     * @example [zh-CN] 调用示例（按属性集查询） [en-US] Usage example (fetch by attribute projection)
     * ```ts
     * const users = await client.userInfoManager.getUserInfoByAttribute({
     *   userIds: ['alice'],
     *   attributes: ['nickname', 'avatarUrl'],
     * });
     * console.log(users[0]?.nickname);
     * ```
     *
     * @param params - [zh-CN] 包含 `userIds`、`attributes` 与可选回调的参数对象。 [en-US] Parameter object containing `userIds`, `attributes`, and optional callbacks.
     * @returns {Promise<ReadonlyArray<UserInfo>>} [zh-CN] 按请求顺序返回标准化后的用户资料数组；未设置所查询属性的用户返回仅包含 `userId` 的对象。 [en-US] Returns normalized user profiles in request order; users without the requested attributes are represented by an object containing only `userId`.
     */
    getUserInfoByAttribute(params: FetchUserInfoByAttributeParams): Promise<ReadonlyArray<UserInfo>>;
    /**
     * [zh-CN] 订阅指定陌生人用户的资料变化；订阅成功后可通过用户资料事件处理器接收变更通知。
     * [en-US] Subscribes to profile change notifications of target strangers; after subscription, changes can be received through user profile event handlers.
     *
     * @example [zh-CN] 调用示例（订阅资料变化） [en-US] Usage example (subscribe to profile changes)
     * ```ts
     * await client.userInfoManager.subscribeUsersInfo({
     *   userIds: ['alice', 'bob'],
     * });
     * ```
     *
     * @param params - [zh-CN] 包含 `userIds` 与可选回调的参数对象。 [en-US] Parameter object containing `userIds` and optional callbacks.
     * @returns {Promise<void>} [zh-CN] 成功时无返回值。 [en-US] Resolves with no payload on success.
     */
    subscribeUsersInfo(params: SubscribeUsersInfoParams): Promise<void>;
    /**
     * [zh-CN] 取消订阅指定陌生人用户的资料变化；取消后不再接收这些用户的资料变更通知。
     * [en-US] Unsubscribes from profile change notifications of target strangers; after removal, their profile changes are no longer delivered.
     *
     * @example [zh-CN] 调用示例（取消订阅资料变化） [en-US] Usage example (unsubscribe from profile changes)
     * ```ts
     * await client.userInfoManager.unsubscribeUsersInfo({
     *   userIds: ['alice'],
     * });
     * ```
     *
     * @param params - [zh-CN] 包含 `userIds` 与可选回调的参数对象。 [en-US] Parameter object containing `userIds` and optional callbacks.
     * @returns {Promise<void>} [zh-CN] 成功时无返回值。 [en-US] Resolves with no payload on success.
     */
    unsubscribeUsersInfo(params: UnsubscribeUsersInfoParams): Promise<void>;
    /**
     * [zh-CN] 查询当前用户已订阅资料变化的陌生人列表，并返回这些用户的标准化资料。
     * [en-US] Gets the strangers whose profile changes are subscribed by the current user and returns their normalized profiles.
     *
     * @example [zh-CN] 调用示例（查询已订阅用户） [en-US] Usage example (list subscribed users)
     * ```ts
     * const users = await client.userInfoManager.getSubscribedUsers();
     * console.log(users.map(user => user.userId));
     * ```
     *
     * @param this - [zh-CN] 无需传入参数。 [en-US] No parameter is required.
     * @returns {Promise<ReadonlyArray<UserInfo>>} [zh-CN] 返回标准化后的用户资料数组。 [en-US] Returns normalized subscribed user profiles.
     */
    getSubscribedUsers(): Promise<ReadonlyArray<UserInfo>>;
    /**
     * [zh-CN] 更新当前登录用户的一个或多个资料属性，例如昵称、头像、邮箱、手机号、签名或扩展字段。
     * [en-US] Updates one or more profile attributes of the currently logged-in user, such as nickname, avatar, email, phone, signature, or extension data.
     *
     * @example [zh-CN] 调用示例（整对象更新） [en-US] Usage example (patch current profile)
     * ```ts
     * const profile = await client.userInfoManager.updateOwnInfo({
     *   nickname: 'Alice',
     *   avatarUrl: 'https://example.com/avatar.png',
     * });
     * console.log(profile.userId, profile.nickname);
     * ```
     *
     * @param params - [zh-CN] 至少包含一个可更新字段的参数对象。 [en-US] Patch parameter object that must contain at least one updatable field.
     * @returns {Promise<UserInfo>} [zh-CN] 返回标准化后的当前用户资料。 [en-US] Returns the normalized current user profile.
     */
    updateOwnInfo(params: UpdateOwnInfoParams): Promise<UserInfo>;
    /**
     * [zh-CN] 更新当前登录用户的单个资料属性，适合只修改昵称、头像等一个字段的场景。
     * [en-US] Updates one profile attribute of the currently logged-in user, suitable when only one field such as nickname or avatar needs to change.
     *
     * @example [zh-CN] 调用示例（单属性更新） [en-US] Usage example (single-attribute update)
     * ```ts
     * const profile = await client.userInfoManager.updateOwnInfoByAttribute(
     *   'avatarUrl',
     *   'https://example.com/avatar.png'
     * );
     * console.log(profile.avatarUrl);
     * ```
     *
     * @param attribute - [zh-CN] 需要更新的资料属性。 [en-US] The profile attribute to update.
     * @param value - [zh-CN] 属性值；空字符串、`false`、`0` 都是合法值。 [en-US] Attribute value; empty string, `false`, and `0` are valid.
     * @returns {Promise<UserInfo>} [zh-CN] 返回标准化后的当前用户资料。 [en-US] Returns the normalized current user profile.
     */
    updateOwnInfoByAttribute(attribute: UserInfoAttribute, value: string | number | boolean): Promise<UserInfo>;
    private runOperation;
    private normalizeOperationError;
    private getRestContextOrThrow;
    private getRestClient;
    private normalizeFetchEnvelope;
    private completeFetchedProfiles;
    private normalizeUpdateEnvelope;
    private toUserInfo;
    private looksLikeUserInfoAttributes;
    private buildFallbackProfile;
    private getUpdatedFieldNames;
    private projectToSummary;
    private writeCache;
    private dispatchSelfUpdate;
}
