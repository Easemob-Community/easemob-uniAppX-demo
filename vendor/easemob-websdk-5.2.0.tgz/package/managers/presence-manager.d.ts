/**
 * [zh-CN] PresenceManager 对外管理器实现，负责在线状态发布、订阅、查询与事件分发。
 * [en-US] Public PresenceManager implementation for presence publish, subscribe, query, and event dispatch.
 */
import type { ChatClient } from '../chat-client';
import type { EventHandlerId, PresenceEventHandlerMap } from '../types/event-system';
import type { ManagerBase, ManagerEventContext } from '../types/manager';
import type { // 订阅在线状态原始响应
SubscribePresenceResponse, // 订阅列表原始响应
SubscribedPresenceListResponse } from '../types/presence';
/**
 * [zh-CN] 发布当前用户在线状态的参数。
 * [en-US] Parameters for publishing the current user's presence.
 */
export interface PublishPresenceParams {
    /** [zh-CN] 在线状态自定义状态，服务端对应 `ext` 字段。 [en-US] Custom presence status mapped to server `ext` field. */
    readonly customStatus: string;
}
/**
 * [zh-CN] 订阅用户在线状态的参数。
 * [en-US] Parameters for subscribing to users' presence.
 */
export interface SubscribePresenceParams {
    /** [zh-CN] 待订阅的用户 ID 列表，至少包含 1 项。 [en-US] Target user id list to subscribe, must contain at least one entry. */
    readonly userIds: ReadonlyArray<string>;
    /** [zh-CN] 订阅时长（秒），取值需大于等于 0。 [en-US] Subscription duration in seconds, must be greater than or equal to 0. */
    readonly expiry: number;
}
/**
 * [zh-CN] 取消订阅用户在线状态的参数。
 * [en-US] Parameters for unsubscribing from users' presence.
 */
export interface UnsubscribePresenceParams {
    /** [zh-CN] 待取消订阅的用户 ID 列表，至少包含 1 项。 [en-US] User id list to unsubscribe, must contain at least one entry. */
    readonly userIds: ReadonlyArray<string>;
}
/**
 * [zh-CN] 查询当前用户在线状态订阅列表的参数。
 * [en-US] Parameters for querying the current user's presence subscription list.
 */
export interface GetSubscribedPresenceListParams {
    /** [zh-CN] 页码，从 0 开始。 [en-US] Page number starting from 0. */
    readonly pageNum: number;
    /** [zh-CN] 每页条数，取值需大于等于 0。 [en-US] Page size, must be greater than or equal to 0. */
    readonly pageSize: number;
}
/**
 * [zh-CN] 查询用户在线状态的参数。
 * [en-US] Parameters for querying users' presence status.
 */
export interface GetPresenceStatusParams {
    /** [zh-CN] 待查询的用户 ID 列表，至少包含 1 项。 [en-US] Target user id list to query, must contain at least one entry. */
    readonly userIds: ReadonlyArray<string>;
}
/**
 * [zh-CN] PresenceManager 负责在线状态发布、订阅、查询与事件处理器管理。
 * [en-US] PresenceManager handles presence publish, subscribe, query, and event-handler management.
 *
 */
export declare class PresenceManager implements ManagerBase<ChatClient> {
    /** @internal SDK 内部管理器注册键，不对外文档暴露。 */
    static readonly key: "presenceManager";
    private client;
    private eventContext;
    private restClient;
    private restBaseUrl;
    private restToken;
    /**
     * @internal
     * [zh-CN] 绑定 PresenceManager 到 ChatClient，通常由 SDK 在 `client.presenceManager` 初始化阶段调用。 [en-US] Binds PresenceManager to ChatClient and is usually called internally during `client.presenceManager` initialization.
     *
     * @param client - [zh-CN] 已初始化的 ChatClient 实例。 [en-US] Initialized ChatClient instance.
     * @param context - [zh-CN] Presence 事件上下文，用于分发在线状态事件。 [en-US] Presence event context used to dispatch presence events.
     * @returns {void} [zh-CN] 无返回值。 [en-US] Returns nothing.
     */
    bind(client: ChatClient, context?: ManagerEventContext<PresenceEventHandlerMap>): void;
    /**
     * [zh-CN] 注册 Presence 事件处理器，用于接收在线状态变更推送。 [en-US] Registers a Presence event handler to receive presence state updates.
     *
     * @param id - [zh-CN] 事件处理器唯一 ID，用于后续移除。 [en-US] Unique handler id used for later removal.
     * @param handlers - [zh-CN] 事件处理器集合，按需实现对应回调。 [en-US] Handler collection with callbacks implemented as needed.
     * @returns {void} [zh-CN] 注册完成后无返回值。 [en-US] Returns nothing when registration succeeds.
     *
     * @example [zh-CN] 调用示例（注册在线状态事件） [en-US] Usage example (register presence handler)
     * ```ts
     * client.presenceManager.addEventHandler('presence-ui', {
     *   onPresenceStatusChange: (states) => {
     *     console.log(states);
     *   },
     * });
     * ```
     */
    addEventHandler(id: EventHandlerId, handlers: PresenceEventHandlerMap): void;
    /**
     * [zh-CN] 移除 Presence 事件处理器。 [en-US] Removes a Presence event handler.
     *
     * @param id - [zh-CN] 待移除的事件处理器 ID。 [en-US] Handler id to remove.
     * @returns {void} [zh-CN] 移除完成后无返回值。 [en-US] Returns nothing when removal succeeds.
     *
     * @example [zh-CN] 调用示例（移除在线状态事件） [en-US] Usage example (remove presence handler)
     * ```ts
     * client.presenceManager.removeEventHandler('presence-ui');
     * ```
     */
    removeEventHandler(id: EventHandlerId): void;
    /**
     * [zh-CN] 发布当前用户的自定义在线状态，该状态会作为在线状态扩展描述信息保存并下发给订阅者。
     * [en-US] Publishes the current user's custom presence status, which is saved as the presence extension description and delivered to subscribers.
     *
     * @param params - [zh-CN] 发布参数，包含在线状态扩展描述信息与可选回调。 [en-US] Publish parameters with presence extension description and optional callbacks.
     * @returns {Promise<void>} [zh-CN] 成功时 resolve，无返回业务数据。 [en-US] Resolves on success with no business payload.
     *
     * @example [zh-CN] 调用示例（发布在线状态） [en-US] Usage example (publish presence)
     * ```ts
     * await client.presenceManager.publishPresence({
     *   customStatus: 'busy',
     * });
     * ```
     */
    publishPresence(params: PublishPresenceParams): Promise<void>;
    /**
     * [zh-CN] 订阅指定用户的在线状态。订阅成功后，这些用户在线状态变更时会触发 Presence 事件回调。
     * [en-US] Subscribes to target users' presence. After success, Presence event callbacks are triggered when these users' presence changes.
     *
     * @param params - [zh-CN] 订阅参数，包含用户列表、订阅时长与可选回调。 [en-US] Subscribe parameters including user list, expiry, and optional callbacks.
     * @returns {Promise<SubscribePresenceResponse>} [zh-CN] 返回归一化后的在线状态列表。 [en-US] Returns normalized presence list.
     *
     * @example [zh-CN] 调用示例（订阅用户在线状态） [en-US] Usage example (subscribe presence)
     * ```ts
     * const result = await client.presenceManager.subscribePresence({
     *   userIds: ['userA'],
     *   expiry: 3600,
     * });
     * console.log(result[0]?.publisher);
     * ```
     */
    subscribePresence(params: SubscribePresenceParams): Promise<SubscribePresenceResponse>;
    /**
     * [zh-CN] 取消订阅指定用户的在线状态，成功后不再接收这些用户的在线状态变更事件。
     * [en-US] Unsubscribes from target users' presence; after success, presence change events for these users are no longer received.
     *
     * @param params - [zh-CN] 取消订阅参数，包含用户列表与可选回调。 [en-US] Unsubscribe parameters including user list and optional callbacks.
     * @returns {Promise<void>} [zh-CN] 成功时 resolve，无返回业务数据。 [en-US] Resolves on success with no business payload.
     *
     * @example [zh-CN] 调用示例（取消订阅） [en-US] Usage example (unsubscribe presence)
     * ```ts
     * await client.presenceManager.unsubscribePresence({
     *   userIds: ['userA'],
     * });
     * ```
     */
    unsubscribePresence(params: UnsubscribePresenceParams): Promise<void>;
    /**
     * [zh-CN] 分页查询当前用户订阅了哪些用户的在线状态。
     * [en-US] Uses pagination to get the list of users whose presence states the current user has subscribed to.
     *
     * @param params - [zh-CN] 分页参数，包含页码、每页数量与可选回调。 [en-US] Paging parameters including page number, page size, and optional callbacks.
     * @returns {Promise<SubscribedPresenceListResponse>} [zh-CN] 返回订阅用户 ID 列表。 [en-US] Returns subscribed user id list.
     *
     * @example [zh-CN] 调用示例（分页查询订阅列表） [en-US] Usage example (query subscribed list by page)
     * ```ts
     * const list = await client.presenceManager.getSubscribedPresenceList({
     *   pageNum: 1,
     *   pageSize: 20,
     * });
     * console.log(list);
     * ```
     */
    getSubscribedPresenceList(params: GetSubscribedPresenceListParams): Promise<SubscribedPresenceListResponse>;
    /**
     * [zh-CN] 查询指定用户的当前在线状态，不会建立订阅关系。
     * [en-US] Gets the current presence states of target users without creating subscriptions.
     *
     * @param params - [zh-CN] 查询参数，包含用户列表与可选回调。 [en-US] Query parameters including user list and optional callbacks.
     * @returns {Promise<SubscribePresenceResponse>} [zh-CN] 返回归一化后的在线状态列表。 [en-US] Returns normalized presence list.
     *
     * @example [zh-CN] 调用示例（查询在线状态） [en-US] Usage example (query presence status)
     * ```ts
     * const status = await client.presenceManager.getPresenceStatus({
     *   userIds: ['userA'],
     * });
     * console.log(status[0]?.statusList);
     * ```
     */
    getPresenceStatus(params: GetPresenceStatusParams): Promise<SubscribePresenceResponse>;
    private runOperation;
    private normalizeSdkError;
    private getEventContextOrThrow;
    private getClientOrThrow;
    private getRestContextOrThrow;
    private getRestClient;
    private parseAppKey;
    private validateDescription;
    private validateUserIds;
    private validateExpiry;
    private validatePage;
    private normalizeSubscribeResponse;
    private normalizeSubscribedListResponse;
    private normalizeStatusList;
    private buildValidationError;
}
