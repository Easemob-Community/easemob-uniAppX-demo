/**
 * ChatManager 管理器
 */
import type { ChatClient } from '../chat-client';
import type { ConversationFilter, ConversationItem, ConversationMarkParams, ConversationMarkMutationResult, ConversationMutationResult, DeleteConversationParams, GetPinnedMessageListParams, PinnedMessageListResult, PinMessageParams, RefreshSessionListParams, SetConversationPinnedParams } from '../types/conversation';
import type { ChatEventHandlerMap, EventHandlerId } from '../types/event-system';
import type { ChatActionResult, CreateCmdMessageParams, CreateCombineMessageParams, CreateCustomMessageParams, CreateFileMessageParams, CreateImageMessageParams, CreateLocationMessageParams, ClearConversationUnreadMessageCountParams, ConversationLocator, CreateTextMessageParams, CreateVideoMessageParams, CreateVoiceMessageParams, CreateMultiBodyMessageParams, CreateCustomMessageBodyParams, CreateFileMessageBodyParams, CreateImageMessageBodyParams, CreateLocationMessageBodyParams, CreateTextMessageBodyParams, CreateVideoMessageBodyParams, CreateVoiceMessageBodyParams, MultiBodySegment, DownloadCombineMessageInput, DownloadAttachmentParams, GetGroupMessageReadReceiptsParams, GetHistoryMessagesParams, GetReactionDetailParams, GetReactionListParams, GroupMessageReadUsersParams, GroupMessageReadUsersResult, Message, MessageAttachmentDownloadResult, MessageHistoryPage, MessageReadReceiptDetail, MessageReactionDetailPage, MessageReactionListItem, MessageTranslationResult, RecallMessageParams, ReactionOperationParams, RemoveHistoryMessagesParams, SearchMessagesParams, SearchMessagesResult, SendMessageReadReceiptsParams, SendMessageOptions, TranslationLanguage, TranslateMessageParams, UpdateMessageParams, VoiceMessageBody, VoiceParams, VoiceSourceFile, VoiceToTextResult } from '../types';
import type { ManagerBase, ManagerEventContext } from '../types/manager';
/**
 * ChatManager 负责消息域动作、查询与事件订阅
 */
export declare class ChatManager implements ManagerBase<ChatClient> {
    static readonly key: "chatManager";
    private client;
    private eventContext;
    private restClient;
    private restBaseUrl;
    private restToken;
    /**
     * @internal
     * [zh-CN] 绑定 ChatClient 实例与管理器事件上下文。该方法由 SDK 管理器注册流程调用。
     * [en-US] Binds a ChatClient instance and manager event context. This method is called by the SDK manager registration flow.
     *
     * @example
     * ```ts
     * const chatManager = new ChatManager();
     * chatManager.bind(client, context);
     * ```
     *
     * @param client - [zh-CN] ChatClient 实例。 [en-US] ChatClient instance.
     * @param context - [zh-CN] 管理器事件上下文。 [en-US] Manager event context.
     * @returns [zh-CN] 无返回值。 [en-US] No return value.
     */
    bind(client: ChatClient, context?: ManagerEventContext): void;
    /**
     * [zh-CN] 发送一条已创建的消息。文本、图片、文件、语音、视频、位置、命令、自定义和合并消息均通过该入口发送。
     *
     * 事件触发：接收方（含发送方的其他设备）会收到 `onMessage` 事件。
     * 附件类消息（图片/文件/语音/视频）会先自动上传到服务器，上传成功后再发送。
     *
     * 文本消息指定非空 `body.targetLanguages` 时，先调用翻译服务，再发送原文与 `body.translations`；翻译失败则不发送，并通过 Promise 与 `onFailed` 返回翻译错误。发送结果和回调包含译文，传入消息对象不被修改。未指定语言时不调用翻译服务。
     * [en-US] Sends a created message. Text, image, file, voice, video, location, command, custom, and combined messages are all sent via this API.
     *
     * Event triggered: Recipients (including the sender's other logged-in devices) receive the `onMessage` event.
     * For attachment messages such as image, file, voice, and video messages, the SDK automatically uploads the attachment before sending the message.
     *
     * Text messages with non-empty `body.targetLanguages` are translated before sending the original text and `body.translations`. Translation failure prevents sending and is reported through the Promise and `onFailed`. Results and callbacks contain translations without mutating the input message. No translation request is made when target languages are omitted.
     *
     * @example
     * ```ts
     * const message = chatManager.createTextMessage({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   content: 'hello',
     * });
     * const sent = await chatManager.sendMessage(message);
     * ```
     *
     * @param message - [zh-CN] 待发送消息对象。 [en-US] The message object to send.
     * @param options - [zh-CN] 发送过程回调。 [en-US] The optional callback parameters for the sending process.
     * @returns [zh-CN] 发送成功后的消息对象。 [en-US] The message object returned after the message is sent successfully.
     */
    sendMessage(message: Message, options?: SendMessageOptions): Promise<Message>;
    /**
     * [zh-CN] 创建文本消息对象。创建后需调用 {@link ChatManager.sendMessage} 发送。
     * [en-US] Creates a text message object. After the message is created, call {@link ChatManager.sendMessage} to send it.
     *
     * @example
     * ```ts
     * const message = chatManager.createTextMessage({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   content: 'hello',
     * });
     * ```
     *
     * @param params - [zh-CN] 文本消息创建参数。 [en-US] The parameters for creating the text message.
     * @returns [zh-CN] 文本消息对象。 [en-US] The text message object.
     */
    createTextMessage(params: CreateTextMessageParams): Message;
    /**
     * [zh-CN] 创建图片消息对象。支持传入本地文件或远程图片地址。
     * [en-US] Creates an image message object. Supports passing the URL of a local image file or a remote image.
     *
     * @example
     * ```ts
     * const message = chatManager.createImageMessage({
     *   conversationId: 'group_1',
     *   conversationType: 'groupChat',
     *   data: imageFile,
     * });
     * ```
     *
     * @param params - [zh-CN] 图片消息创建参数。 [en-US] The parameters for creating the image message.
     * @returns [zh-CN] 图片消息对象。 [en-US] The image message object.
     */
    createImageMessage(params: CreateImageMessageParams): Message;
    /**
     * [zh-CN] 创建文件消息对象。支持传入本地文件或远程文件地址。
     * [en-US] Creates a file message object. Supports passing the URL of a local file or a remote file.
     *
     * @example
     * ```ts
     * const message = chatManager.createFileMessage({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   data: file,
     * });
     * ```
     *
     * @param params - [zh-CN] 文件消息创建参数。 [en-US] The parameters for creating the file message.
     * @returns [zh-CN] 文件消息对象。 [en-US] The file message object.
     */
    createFileMessage(params: CreateFileMessageParams): Message;
    /**
     * [zh-CN] 创建语音消息对象。支持传入本地语音文件或远程语音地址。
     * [en-US] Creates a voice message object. Supports passing the URL of a local voice file or a remote voice.
     *
     * @example
     * ```ts
     * const message = chatManager.createVoiceMessage({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   data: voiceFile,
     *   duration: 3,
     * });
     * ```
     *
     * @param params - [zh-CN] 语音消息创建参数。 [en-US] The parameters for creating a voice message.
     * @returns [zh-CN] 语音消息对象。 [en-US] The voice message object.
     */
    createVoiceMessage(params: CreateVoiceMessageParams): Message;
    /**
     * [zh-CN] 创建视频消息对象。支持传入本地视频文件或远程视频地址。
     * [en-US] Creates a video message object. Supports passing the URL of a local video file or a remote video.
     *
     * @example
     * ```ts
     * const message = chatManager.createVideoMessage({
     *   conversationId: 'group_1',
     *   conversationType: 'groupChat',
     *   data: videoFile,
     *   duration: 12,
     * });
     * ```
     *
     * @param params - [zh-CN] 视频消息创建参数。 [en-US] The parameters for creating a video message.
     * @returns [zh-CN] 视频消息对象。 [en-US] The video message object.
     */
    createVideoMessage(params: CreateVideoMessageParams): Message;
    /**
     * [zh-CN] 创建位置消息对象。
     * [en-US] Creates a location message object.
     *
     * @example
     * ```ts
     * const message = chatManager.createLocationMessage({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   latitude: 39.9042,
     *   longitude: 116.4074,
     *   address: 'Beijing',
     * });
     * ```
     *
     * @param params - [zh-CN] 位置消息创建参数。 [en-US] The parameters for creating a location message.
     * @returns [zh-CN] 位置消息对象。 [en-US] The location message object.
     */
    createLocationMessage(params: CreateLocationMessageParams): Message;
    /**
     * [zh-CN] 创建命令消息对象。命令消息通常用于业务自定义控制信令。
     * [en-US] Creates a command message object. Command messages are typically used for custom business control signaling.
     *
     * @example
     * ```ts
     * const message = chatManager.createCmdMessage({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   action: 'typing',
     * });
     * ```
     *
     * @param params - [zh-CN] 命令消息创建参数。 [en-US] The parameters for creating a command message.
     * @returns [zh-CN] 命令消息对象。 [en-US] The command message object.
     */
    createCmdMessage(params: CreateCmdMessageParams): Message;
    /**
     * [zh-CN] 创建自定义消息对象。可通过 `event` 与 `params` 承载业务自定义内容。
     * [en-US] Creates a custom message object, using `event` and `params` to carry custom business content.`
     *
     * @example
     * ```ts
     * const message = chatManager.createCustomMessage({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   event: 'gift',
     *   params: { id: 'rose' },
     * });
     * ```
     *
     * @param params - [zh-CN] 自定义消息创建参数。 [en-US] The parameters for creating a custom message.
     * @returns [zh-CN] 自定义消息对象。 [en-US] The custom message object.
     */
    createCustomMessage(params: CreateCustomMessageParams): Message;
    /**
     * [zh-CN] 创建合并消息对象，用于发送聊天记录合集。
     * [en-US] Creates a combined message object for sending a collection of chat histories.
     *
     * @example
     * ```ts
     * const message = chatManager.createCombineMessage({
     *   conversationId: 'group_1',
     *   conversationType: 'groupChat',
     *   title: '聊天记录',
     *   summary: '3 条消息',
     *   messageList: selectedMessages,
     * });
     * ```
     *
     * @param params - [zh-CN] 合并消息创建参数。 [en-US] The parameters for creating a combined message.
     * @returns [zh-CN] 合并消息对象。 [en-US] The combined message object.
     */
    createCombineMessage(params: CreateCombineMessageParams): Message;
    /**
     * [zh-CN] 创建复合消息的文本分段。返回的对象必须原样放进 `createMultiBodyMessage`。
     * [en-US] Creates a text segment for a multi_body message. Pass the returned object unchanged to `createMultiBodyMessage`.
     *
     * @example
     * ```ts
     * const text = chatManager.createTextMessageBody({ content: '请看资料' });
     * ```
     *
     * @param params - [zh-CN] 文本分段参数。 [en-US] Text segment parameters.
     * @returns [zh-CN] 带 `type: 'text'` 的分段。 [en-US] A segment with `type: 'text'`.
     */
    createTextMessageBody(params: CreateTextMessageBodyParams): MultiBodySegment;
    /**
     * [zh-CN] 创建复合消息的图片分段。本地文件挂在返回对象上，不能复制后再组装。
     * [en-US] Creates an image segment. A local file stays attached to the returned object and the object must not be copied before assembly.
     *
     * @example
     * ```ts
     * const image = chatManager.createImageMessageBody({ originalUrl: 'https://example.com/a.jpg' });
     * ```
     *
     * @param params - [zh-CN] 图片分段参数。`data` 与 `originalUrl` 至少传一个。 [en-US] Image segment parameters. Either `data` or `originalUrl` is required.
     * @returns [zh-CN] 带 `type: 'image'` 的分段。 [en-US] A segment with `type: 'image'`.
     */
    createImageMessageBody(params: CreateImageMessageBodyParams): MultiBodySegment;
    /**
     * [zh-CN] 创建复合消息的文件分段。
     * [en-US] Creates a file segment for a multi_body message.
     *
     * @example
     * ```ts
     * const file = chatManager.createFileMessageBody({ originalUrl: 'https://example.com/a.txt' });
     * ```
     *
     * @param params - [zh-CN] 文件分段参数。`data` 与 `originalUrl` 至少传一个。 [en-US] File segment parameters. Either `data` or `originalUrl` is required.
     * @returns [zh-CN] 带 `type: 'file'` 的分段。 [en-US] A segment with `type: 'file'`.
     */
    createFileMessageBody(params: CreateFileMessageBodyParams): MultiBodySegment;
    /**
     * [zh-CN] 创建复合消息的语音分段。
     * [en-US] Creates a voice segment for a multi_body message.
     *
     * @example
     * ```ts
     * const voice = chatManager.createVoiceMessageBody({
     *   originalUrl: 'https://example.com/a.amr',
     *   duration: 3,
     * });
     * ```
     *
     * @param params - [zh-CN] 语音分段参数。 [en-US] Voice segment parameters.
     * @returns [zh-CN] 带 `type: 'voice'` 的分段。 [en-US] A segment with `type: 'voice'`.
     */
    createVoiceMessageBody(params: CreateVoiceMessageBodyParams): MultiBodySegment;
    /**
     * [zh-CN] 创建复合消息的视频分段。
     * [en-US] Creates a video segment for a multi_body message.
     *
     * @example
     * ```ts
     * const video = chatManager.createVideoMessageBody({
     *   originalUrl: 'https://example.com/a.mp4',
     *   duration: 8,
     * });
     * ```
     *
     * @param params - [zh-CN] 视频分段参数。 [en-US] Video segment parameters.
     * @returns [zh-CN] 带 `type: 'video'` 的分段。 [en-US] A segment with `type: 'video'`.
     */
    createVideoMessageBody(params: CreateVideoMessageBodyParams): MultiBodySegment;
    /**
     * [zh-CN] 创建复合消息的位置分段。
     * [en-US] Creates a location segment for a multi_body message.
     *
     * @example
     * ```ts
     * const location = chatManager.createLocationMessageBody({ latitude: 39.9, longitude: 116.4 });
     * ```
     *
     * @param params - [zh-CN] 位置分段参数。 [en-US] Location segment parameters.
     * @returns [zh-CN] 带 `type: 'location'` 的分段。 [en-US] A segment with `type: 'location'`.
     */
    createLocationMessageBody(params: CreateLocationMessageBodyParams): MultiBodySegment;
    /**
     * [zh-CN] 创建复合消息的自定义分段。
     * [en-US] Creates a custom segment for a multi_body message.
     *
     * @example
     * ```ts
     * const custom = chatManager.createCustomMessageBody({ event: 'gift', params: { id: '1' } });
     * ```
     *
     * @param params - [zh-CN] 自定义分段参数。 [en-US] Custom segment parameters.
     * @returns [zh-CN] 带 `type: 'custom'` 的分段。 [en-US] A segment with `type: 'custom'`.
     */
    createCustomMessageBody(params: CreateCustomMessageBodyParams): MultiBodySegment;
    /**
     * [zh-CN] 把 2 到 20 段内容组装成一条复合消息。分段必须是工厂返回的同一对象。少于 2 段、超过 20 段，或含命令、合并、复合消息、流式内容时抛出校验错误，且不挪走本地文件。
     * [en-US] Assembles 2 to 20 segments into one multi_body message. Segments must be the same objects returned by the factories. Fewer than two segments, more than 20 segments, or command, combined, multi_body, or stream content, throws a validation error and does not move local files.
     *
     * @example
     * ```ts
     * const message = chatManager.createMultiBodyMessage({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   bodies: [text, image],
     * });
     * ```
     *
     * @param params - [zh-CN] 复合消息参数。`bodies` 为 2 到 20 项。 [en-US] MultiBody message parameters. `bodies` must contain 2 to 20 segments.
     * @returns [zh-CN] 类型为 `multi_body` 的消息。 [en-US] A message whose type is `multi_body`.
     */
    createMultiBodyMessage(params: CreateMultiBodyMessageParams): Message;
    /**
     * [zh-CN] 从本地会话列表缓存中获取会话，支持通过 filter 过滤。
     * [en-US] Retrieves conversations from the local conversation list cache, with support for filtering via a `filter`.
     *
     * @example
     * ```ts
     * // 获取全部会话
     * const all = chatManager.getConversationList();
     * // 获取置顶会话
     * const pinned = chatManager.getConversationList({ isPinned: true });
     * // 获取指定标记的会话
     * const marked = chatManager.getConversationList({ mark: 3 });
     * ```
     *
     * @param filter - [zh-CN] 可选过滤条件。 [en-US] Optional filter criteria.
     * @returns [zh-CN] 匹配条件的会话数组。 [en-US] Array of conversations matching the filter.
     */
    getConversationList(filter?: ConversationFilter): ReadonlyArray<ConversationItem>;
    /**
     * [zh-CN] 设置当前正在浏览的会话。设置后，该会话收到在线消息时 SDK 仍会更新最后消息和列表排序，但不会累加本地未读数。该状态只保存在当前 SDK 会话内存中，切换页面或关闭会话时应调用 `resetCurrentConversation()`。
     * [en-US] Sets the conversation currently being viewed. After the conversation is set, when online messages are received in this conversation, the SDK still updates the last message and the conversation sorting, but does not increment the local unread count. This state is stored only in the memory of the current SDK conversation memory. Call `resetCurrentConversation()` when switching pages or closing the conversation.
     *
     * @example
     * ```ts
     * chatManager.setCurrentConversation({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     * });
     * ```
     *
     * @param params - [zh-CN] 当前正在浏览的会话定位参数。 [en-US]  The locator parameters of the conversation currently being viewed.
     * @returns [zh-CN] 无返回值。 [en-US] No return value.
     */
    setCurrentConversation(params: ConversationLocator): void;
    /**
     * [zh-CN] 重置当前正在浏览的会话。重置后，收到在线消息会按默认规则累加对应会话的本地未读数。
     * [en-US] Resets the conversation currently being viewed. After the reset, incoming online messages will increment the local unread count of the corresponding conversation based on default rules.
     *
     * @example
     * ```ts
     * chatManager.resetCurrentConversation();
     * ```
     *
     * @returns [zh-CN] 无返回值。 [en-US] No return value.
     */
    resetCurrentConversation(): void;
    /**
     * [zh-CN] 获取当前正在浏览的会话。
     * [en-US] Retrieves the conversation currently being viewed.
     *
     * @example
     * ```ts
     * const current = chatManager.getCurrentConversation();
     * ```
     *
     * @returns [zh-CN] 当前正在浏览的会话定位参数，未设置时为 `null`。 [en-US] The locator parameters of the conversation currently being viewed. The SDK returns `null` if no conversation is currently set.
     */
    getCurrentConversation(): ConversationLocator | null;
    /**
     * @internal
     * [zh-CN] 主动向服务端刷新会话列表，供 SDK 内部同步流程使用。
     * [en-US] Refreshes the conversation list from the server for internal SDK synchronization flows.
     *
     * @example
     * ```ts
     * const conversations = await chatManager.refreshSessionList({ includeEmpty: true });
     * ```
     *
     * @param params - [zh-CN] 刷新会话列表的选项。 [en-US] Options for refreshing the conversation list.
     * @returns [zh-CN] 刷新后的会话列表。 [en-US] Refreshed conversation list.
     */
    refreshSessionList(params?: RefreshSessionListParams): Promise<ReadonlyArray<ConversationItem>>;
    /**
     * [zh-CN] 删除指定会话，可选择同时删除服务端漫游消息。
     * 删除成功后，SDK 会同步删除本地会话列表缓存；如果本地会话列表发生变化，会触发 `onConversationListUpdate`，`reason` 为 `local`。
     * [en-US] Deletes the specified conversation. You can optionally delete the server-side roaming messages at the same time.
     * After the conversation is deleted successfully, the SDK also clears the local conversation list cache. If the local conversation list changes, the `onConversationListUpdate` event is triggered with `reason` set to `local`.
     *
     * @example
     * ```ts
     * await chatManager.deleteConversation({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   deleteRoamingMessages: false,
     * });
     * ```
     *
     * @param params - [zh-CN] 删除会话参数。 [en-US] Parameters for deleting a conversation.
     * @returns [zh-CN] 会话删除结果。 [en-US] Conversation deletion result.
     */
    deleteConversation(params: DeleteConversationParams): Promise<ConversationMutationResult>;
    /**
     * [zh-CN] 设置或取消设置会话置顶状态。
     * [en-US] Pins or unpins a conversation.
     *
     * @example
     * ```ts
     * await chatManager.setConversationPinned({
     *   conversationId: 'group_1',
     *   conversationType: 'groupChat',
     *   pinned: true,
     * });
     * ```
     *
     * @param params - [zh-CN] 会话置顶参数。 [en-US] Parameters for setting the pinned status.
     * @returns [zh-CN] 会话置顶变更结果。 [en-US] Result of the conversation pin status change.
     */
    setConversationPinned(params: SetConversationPinnedParams): Promise<ConversationMutationResult>;
    /**
     * [zh-CN] 为单个或多个会话添加标记。
     * [en-US] Adds a mark to one or more conversations.
     *
     * @example
     * ```ts
     * await chatManager.addConversationMark({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   mark: 0,
     * });
     * ```
     *
     * @param params - [zh-CN] 会话标记参数。 [en-US] Parameters for adding a conversation mark.
     * @returns [zh-CN] 会话标记添加结果。 [en-US] Result of adding the conversation mark.
     */
    addConversationMark(params: ConversationMarkParams): Promise<ConversationMarkMutationResult>;
    /**
     * [zh-CN] 从单个或多个会话移除标记。
     * [en-US] Removes a mark for one or more conversations.
     *
     * @example
     * ```ts
     * await chatManager.removeConversationMark({
     *   conversations: [
     *     { conversationId: 'user_2', conversationType: 'singleChat' },
     *   ],
     *   mark: 0,
     * });
     * ```
     *
     * @param params - [zh-CN] 会话标记参数。 [en-US] Conversation mark parameters.
     * @returns [zh-CN] 会话标记移除结果。 [en-US] Result of removing the conversation mark.
     */
    removeConversationMark(params: ConversationMarkParams): Promise<ConversationMarkMutationResult>;
    /**
     * [zh-CN] 清空当前用户的所有会话和服务端漫游消息。
     * 清空成功后，SDK 会同步清空本地 conversation/session-list 缓存；如果本地会话列表发生变化，会触发 `onConversationListUpdate`，`reason` 为 `local`。
     * [en-US] Clears all conversations and server-side roaming messages of the current user.
     * After the operation succeeds, the SDK also clears the local conversation cache and conversation list cache. If the local conversation list changes, the `onConversationListUpdate` event is triggered with `reason` set to `local`.
     *
     * @example
     * ```ts
     * await chatManager.clearAllMessagesAndConversations();
     * ```
     *
     * @returns [zh-CN] 清空完成后 resolve。 [en-US] Resolves after the cleanup completes.
     */
    clearAllMessagesAndConversations(): Promise<void>;
    /**
     * [zh-CN] 在指定会话中置顶一条消息。
     *
     * 事件触发：除当前操作设备外，会话成员及当前用户的其他设备会收到 `onPinnedMessageChanged` 事件（operation='pin'）；当前操作设备通过 Promise 处理成功结果。
     *
     * [en-US] Pins a message in the specified conversation.
     *
     * Event triggered: Conversation members and the current user's other devices, except the device performing the operation, receive `onPinnedMessageChanged` (operation='pin'). The operating device handles success through the Promise.
     *
     * @example
     * ```ts
     * await chatManager.pinMessage({
     *   conversationId: 'group_1',
     *   conversationType: 'groupChat',
     *   messageId: 'msg_1',
     * });
     * ```
     *
     * @param params - [zh-CN] 置顶消息参数。 [en-US] Parameters for pinning a message.
     * @returns [zh-CN] 置顶消息结果。 [en-US] Result of pinning the message.
     */
    pinMessage(params: PinMessageParams): Promise<void>;
    /**
     * [zh-CN] 取消置顶指定会话中的一条消息。
     *
     * 事件触发：除当前操作设备外，会话成员及当前用户的其他设备会收到 `onPinnedMessageChanged` 事件（operation='unpin'）；当前操作设备通过 Promise 处理成功结果。
     *
     * [en-US] Unpins a message in the specified conversation.
     *
     * Event triggered: Conversation members and the current user's other devices, except the device performing the operation, receive `onPinnedMessageChanged` (operation='unpin'). The operating device handles success through the Promise.
     *
     * @example
     * ```ts
     * await chatManager.unpinMessage({
     *   conversationId: 'group_1',
     *   conversationType: 'groupChat',
     *   messageId: 'msg_1',
     * });
     * ```
     *
     * @param params - [zh-CN] 取消置顶消息参数。 [en-US] Parameters for unpinning a message.
     * @returns [zh-CN] 取消置顶消息结果。 [en-US] Result of unpinning the message.
     */
    unpinMessage(params: PinMessageParams): Promise<void>;
    /**
     * [zh-CN] 获取指定会话内的置顶消息列表。该接口不分页，不接收 messageId，最多返回 20 条。
     * [en-US] Retrieves pinned messages in a conversation. This API does not support pagination and does not accept a `messageId`; it returns a maximum of 20 items.
     *
     * @example
     * ```ts
     * const result = await chatManager.getPinnedMessageList({
     *   conversationId: 'group_1',
     *   conversationType: 'groupChat',
     * });
     * ```
     *
     * @param params - [zh-CN] 会话定位参数。 [en-US] Conversation locator parameters.
     * @returns [zh-CN] 置顶消息列表。 [en-US] List of pinned messages.
     */
    getPinnedMessageList(params: GetPinnedMessageListParams): Promise<PinnedMessageListResult>;
    /**
     * [zh-CN] 注册消息域事件处理器。
     * [en-US] Registers an event handler for the message domain.
     *
     * @example
     * ```ts
     * chatManager.addEventHandler('chat-page', {
     *   onMessage: event => {
     *     console.log(event.messages);
     *   },
     * });
     * ```
     *
     * @param id - [zh-CN] 事件处理器唯一标识。 [en-US] Unique identifier of the event handler.
     * @param handlers - [zh-CN] 消息事件处理器集合。 [en-US] Message event handler map.
     * @returns [zh-CN] 无返回值。 [en-US] No return value.
     */
    addEventHandler(id: EventHandlerId, handlers: ChatEventHandlerMap): void;
    /**
     * [zh-CN] 移除已注册的消息域事件处理器。
     * [en-US] Removes an event handler for the message domain.
     *
     * @example
     * ```ts
     * chatManager.removeEventHandler('chat-page');
     * ```
     *
     * @param id - [zh-CN] 事件处理器唯一标识。 [en-US] Unique identifier of the event handler.
     * @returns [zh-CN] 无返回值。 [en-US] No return value.
     */
    removeEventHandler(id: EventHandlerId): void;
    /**
     * [zh-CN] 清空指定会话的未读消息数。
     *
     * SDK 会优先更新本地会话 unreadCount 与 readAt，并在本地快照变化时派发 `onConversationListUpdate`，随后尽力同步服务端。
     * 本地存在目标会话时，即使当前未连接或服务端同步失败，该方法也会按本地清理成功处理；本地不存在目标会话且远端同步失败时才会抛出错误。
     * 该动作不会发送给会话对端；只有当前用户的其他设备会收到 operation 为
     * `CONVERSATION_UNREAD_MESSAGE_COUNT_CLEARED` 的 `onMultiDeviceConversation`。
     *
     * [en-US] Clears unread message count for the specified conversation.
     *
     * Other devices of the current user receive `onMultiDeviceConversation` with operation
     * `CONVERSATION_UNREAD_MESSAGE_COUNT_CLEARED`; the conversation peer does not receive it.
     * The SDK clears the local unread count and read timestamp first, emits `onConversationListUpdate` with `reason` set to `local` when the snapshot changes, and then attempts to synchronize the server.
     * If the conversation exists locally, a disconnected state or remote synchronization failure is treated as local success. An error is thrown only when the conversation does not exist locally and remote synchronization also fails.
     *
     * @example
     * ```ts
     * await chatManager.clearConversationUnreadMessageCount({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     * });
     * ```
     *
     * @param params - [zh-CN] 会话定位参数。 [en-US] Conversation locator parameters.
     * @returns [zh-CN] 标记完成后 resolve。 [en-US] Resolves after the conversation is marked as read.
     */
    clearConversationUnreadMessageCount(params: ClearConversationUnreadMessageCountParams): Promise<void>;
    /**
     * [zh-CN] 批量发送消息已读回执。仅支持同一个会话内的 1 至 50 条单聊或群聊消息。
     *
     * 该接口不会推进会话 readAt，也不会直接修改本地 unreadCount。
     * 事件触发：消息原始发送方会收到 `onMessageReadReceipts`；本地调用方不会收到该事件。
     *
     * [en-US] Marks 1 to 50 messages as read in one batch. Only received one-to-one chat messages or group chat messages in the same conversation are supported.
     *
     * Event triggered: The original sender of the message receives the `onMessageReadReceipts` event, while the local caller does not.
     * Note: Group chat read receipts are valid for 3 days, support groups with up to 200 members, and require the related feature to be enabled in the Console.
     *
     * @example
     * ```ts
     * await chatManager.sendMessageReadReceipts({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   messageIds: ['msg-1', 'msg-2'],
     * });
     * ```
     *
     * @param params - [zh-CN] 批量消息已读参数：`conversationId` 为目标会话 ID，`conversationType` 仅支持 `singleChat` 或 `groupChat`，`messageIds` 为同一会话内 1 至 50 条非空消息 ID。 [en-US] Batch message read parameters: `conversationId` is the target conversation ID, `conversationType` must be `singleChat` or `groupChat`, and `messageIds` contains 1 to 50 non-empty message IDs from that conversation.
     * @returns [zh-CN] 全部已读回执发送完成后 resolve。 [en-US] Resolves after all read receipts are sent.
     */
    sendMessageReadReceipts(params: SendMessageReadReceiptsParams): Promise<void>;
    /**
     * [zh-CN] 清空所有会话的未读消息数。
     *
     * 本机调用成功后仅更新本地 unread 快照并派发 `onConversationListUpdate`；
     * 其他设备收到 operation 为 `ALL_CONVERSATIONS_UNREAD_MESSAGE_COUNT_CLEARED` 的
     * `onMultiDeviceConversation`。
     *
     * [en-US] Clears unread message count for all conversations.
     *
     * After local success, only the local unread snapshot is updated and `onConversationListUpdate` is emitted;
     * other devices receive `onMultiDeviceConversation` with operation
     * `ALL_CONVERSATIONS_UNREAD_MESSAGE_COUNT_CLEARED`.
     *
     * @example
     * ```ts
     * await chatManager.clearAllConversationUnreadMessageCount();
     * ```
     *
     * @returns [zh-CN] 清空成功后无返回值。 [en-US] Resolves with no value after the unread counts are cleared.
     */
    clearAllConversationUnreadMessageCount(): Promise<void>;
    /**
     * [zh-CN] 撤回一条已发送消息。
     *
     * 事件触发：除当前操作设备外，会话成员及撤回者的其他设备会收到 `onMessageRecalled`；当前操作设备通过 Promise 处理成功结果。
     * 注意：默认 2 分钟内可撤回（可在控制台配置最长 7 天）；群主/管理员可撤回他人消息；除 CMD 外所有类型均支持。
     *
     * [en-US] Recalls a sent message.
     *
     * Event triggered: Conversation members and the recaller's other devices, except the operating device, receive `onMessageRecalled`. The operating device handles success through the Promise.
     * Note: By default, only messages sent within 2 minutes can be recalled. This limit can be configured in the Console, up to 7 days. Group owners and admins can recall messages sent by other members. All message types except command messages support recall.
     *
     * @example
     * ```ts
     * const result = await chatManager.recallMessage({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   messageId: 'msg_1',
     * });
     * ```
     *
     * @param params - [zh-CN] 撤回消息参数。 [en-US] Parameters for recalling a message.
     * @returns [zh-CN] 撤回动作结果。 [en-US] Recall action result.
     */
    recallMessage(params: RecallMessageParams): Promise<ChatActionResult>;
    /**
     * [zh-CN] 编辑一条消息内容。文本消息可修改 `content` 和 `ext`；`body.targetLanguages` 非空时先翻译再编辑，译文写入 `body.translations`，翻译失败则抛出异常且不发送编辑。自定义消息可修改 `event`、`params` 和 `ext`；图片、语音、视频、文件、位置和合并消息仅可修改 `ext`。命令消息和复合消息不支持编辑。
     *
     * 事件触发：除当前操作设备外，会话成员及编辑者的其他设备会收到 `onMessageUpdated`；当前操作设备通过 Promise 处理成功结果。
     * 注意：最多编辑 10 次；编辑后消息漫游有效期重新计算。
     *
     * [en-US] Edits the content of a sent message. Text messages can change `content` and `ext`. Non-empty `body.targetLanguages` are translated before the edit, stored in `body.translations`, and a translation failure throws without sending the edit. Custom messages can change `event`, `params`, and `ext`. Image, voice, video, file, location, and combined messages can change `ext` only. Command and multi_body messages cannot be edited.
     *
     * Event triggered: Conversation members and the editor's other devices, except the operating device, receive `onMessageUpdated`. The operating device handles success through the Promise.
     * Note: Each message can be edited up to 10 times. After a message is edited, the validity period of message roaming is recalculated.
     *
     * @example
     * ```ts
     * const updated = await chatManager.modifyMessage({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   messageId: 'msg_1',
     *   message: {
     *     type: 'text',
     *     body: { content: 'updated text' },
     *     ext: {},
     *   },
     * });
     * ```
     *
     * @param params - [zh-CN] 编辑消息参数。 [en-US] Parameters for editing a message.
     * @returns [zh-CN] 编辑后的消息对象。 [en-US] Edited message object.
     */
    modifyMessage(params: UpdateMessageParams): Promise<Message>;
    /**
     * [zh-CN] 从服务端获取历史消息。
     * [en-US] Retrieves historical messages from the server.
     *
     * @example
     * ```ts
     * const page = await chatManager.getHistoryMessages({
     *   conversationId: 'group_1',
     *   conversationType: 'groupChat',
     *   pageSize: 20,
     *   searchDirection: 'up',
     * });
     * ```
     *
     * @param params - [zh-CN] 历史消息查询参数。 [en-US] Query parameters for historical messages.
     * @returns [zh-CN] 历史消息分页结果。 [en-US] Paginated result of historical messages.
     */
    getHistoryMessages(params: GetHistoryMessagesParams): Promise<MessageHistoryPage>;
    /**
     * [zh-CN] 服务端消息搜索，根据关键词和过滤条件搜索历史消息。
     * [en-US] Searches historical messages on the server. You can search message content by keywords and filter conditions.
     *
     * @example
     * ```ts
     * const result = await chatManager.searchMessages({
     *   option: { keywordList: ['hello'] },
     *   pageNum: 1,
     *   pageSize: 20,
     * });
     * ```
     *
     * @param params - [zh-CN] 搜索参数。 [en-US] Search parameters.
     * @returns [zh-CN] 搜索结果。 [en-US] Search result.
     */
    searchMessages(params: SearchMessagesParams): Promise<SearchMessagesResult>;
    /**
     * [zh-CN] 下载消息附件，适用于图片、语音、视频、文件和复合消息。复合消息会按分段顺序下载全部图片、语音、视频和文件。
     * [en-US] Downloads a message attachment. This applies to image, voice, video, file, and multi_body messages. A multi_body message downloads every image, voice, video, and file segment in order.
     *
     * @example
     * ```ts
     * const attachment = await chatManager.downloadAttachment({ message });
     * ```
     *
     * @param params - [zh-CN] 附件下载参数。 [en-US] Parameters for downloading an attachment.
     * @returns [zh-CN] 普通附件消息返回单个下载结果。复合消息返回全部附件下载结果。 [en-US] Returns one download result for a regular attachment message, or every attachment result for a multi_body message.
     */
    downloadAttachment(params: DownloadAttachmentParams): Promise<MessageAttachmentDownloadResult | ReadonlyArray<MessageAttachmentDownloadResult>>;
    /**
     * [zh-CN] 下载并解析合并消息内容，返回合并消息中的子消息列表。
     * [en-US] Downloads and parses a combined message, returning the original messages within it.
     *
     * @example
     * ```ts
     * const messages = await chatManager.downloadAndParseCombineMessage({ message: combineMessage });
     *
     * const messagesFromBody = await chatManager.downloadAndParseCombineMessage({
     *   url: combineMessage.body.url,
     *   secret: combineMessage.body.secret,
     * });
     * ```
     *
     * @param params - [zh-CN] 合并消息解析参数；可传完整合并消息，也可传合并消息体中的最小下载参数。 [en-US] Parameters for parsing the combined message. You can pass the complete combined message object or the minimal download parameters in the combined message body.
     * @returns [zh-CN] 合并消息中的原始消息列表。 [en-US] Original messages within the combined message.
     */
    downloadAndParseCombineMessage(params: DownloadCombineMessageInput): Promise<ReadonlyArray<Message>>;
    /**
     * [zh-CN] 删除服务端历史消息，可按消息 ID 列表或时间戳删除。
     * [en-US] Deletes server-side historical messages. You can delete messages by a list of message IDs or by timestamp.
     *
     * @example
     * ```ts
     * await chatManager.removeHistoryMessages({
     *   conversationId: 'user_2',
     *   conversationType: 'singleChat',
     *   messageIds: ['msg_1'],
     * });
     * ```
     *
     * @param params - [zh-CN] 删除历史消息参数。 [en-US] Parameters for deleting historical messages.
     * @returns [zh-CN] 删除完成后 resolve。 [en-US] Resolves after the messages are removed.
     */
    removeHistoryMessages(params: RemoveHistoryMessagesParams): Promise<void>;
    /**
     * [zh-CN] 获取指定群消息的已读成员列表。
     *
     * 启用 `enableUserInfoSync` 后，SDK 优先读取本地用户资料缓存。仅当用户资料缓存未命中时，SDK 才会同时补拉用户资料和群名片，并通过 `onUserInfoUpdated`（当前用户为 `onOwnInfoUpdated`）派发补拉到的资料。未启用时，`user` 仅保证包含 `userId`。
     * [en-US] Retrieves the list of members who have read the specified group message.
     *
     * When `enableUserInfoSync` is enabled, the SDK reads the local user-profile cache first. Only cache misses trigger concurrent user-profile and group-name-card requests, and fetched profiles are dispatched through `onUserInfoUpdated` (`onOwnInfoUpdated` for the current user). When disabled, `user` is only guaranteed to contain `userId`.
     *
     * @example
     * ```ts
     * const page = await chatManager.getGroupMessageReadUsers({
     *   groupId: 'group_1',
     *   messageId: 'msg_1',
     *   pageSize: 20,
     * });
     * ```
     *
     * @param params - [zh-CN] 群消息已读成员查询参数。 [en-US] Parameters for querying members who have read the specified group message.
     * @returns [zh-CN] 群消息已读成员分页结果。 [en-US] Paginated result of members who have read the specified group message.
     */
    getGroupMessageReadUsers(params: GroupMessageReadUsersParams): Promise<GroupMessageReadUsersResult>;
    /**
     * [zh-CN] 批量获取群消息已读回执详情。
     *
     * `messageIds` 必须为非空数组；SDK 使用单次批量 REST 请求查询，不会拆分为多次请求。
     * 服务端当前最多接受 20 条，超限时该 Promise 会以服务端 `illegal_argument` 错误 reject。
     *
     * [en-US] Fetches group message read receipt details in batch.
     *
     * `messageIds` must be non-empty. The SDK uses one batch REST request and does not split it into multiple requests.
     * The server currently accepts up to 20 items. If exceeded, this Promise rejects with the server `illegal_argument` error.
     *
     * @example
     * ```ts
     * const receipts = await chatManager.getGroupMessageReadReceipts({
     *   groupId: 'group-1',
     *   messageIds: ['msg-1', 'msg-2'],
     * });
     * ```
     *
     * @param params - [zh-CN] 群组 ID 与非空消息 ID 列表。 [en-US] Group ID and a non-empty message ID list.
     * @returns [zh-CN] 按消息返回的已读人数详情。 [en-US] Read receipt count details for the messages.
     */
    getGroupMessageReadReceipts(params: GetGroupMessageReadReceiptsParams): Promise<ReadonlyArray<MessageReadReceiptDetail>>;
    /**
     * [zh-CN] 为消息添加 Reaction。
     *
     * 事件触发：会话中的所有成员会收到 `onReactionChanged` 事件。
     * 注意：仅支持单聊和群聊，不支持聊天室；每个用户对同一消息的同一 Reaction 只能添加一次。
     *
     * [en-US] Adds a Reaction to a message.
     *
     * Event triggered: All members in the conversation receive the `onReactionChanged` event.
     * Note: Only one-to-one chats and group chats are supported. Chat rooms are not supported. A user can add the same Reaction to the same message only once.
     *
     * @example
     * ```ts
     * await chatManager.addReaction({
     *   messageId: 'msg_1',
     *   reaction: '👍',
     * });
     * ```
     *
     * @param params - [zh-CN] 添加 Reaction 参数。 [en-US] Parameters for adding a Reaction.
     * @returns [zh-CN] 添加完成后 resolve。 [en-US] Resolves after the Reaction is added.
     */
    addReaction(params: ReactionOperationParams): Promise<void>;
    /**
     * [zh-CN] 删除当前用户在消息上添加的 Reaction。
     *
     * 事件触发：会话中的所有成员会收到 `onReactionChanged` 事件。
     *
     * [en-US] Removes the Reaction added by the current user from the message.
     *
     * Event triggered: All members in the conversation receive the `onReactionChanged` event.
     *
     * @example
     * ```ts
     * await chatManager.removeReaction({
     *   messageId: 'msg_1',
     *   reaction: '👍',
     * });
     * ```
     *
     * @param params - [zh-CN] 删除 Reaction 参数。 [en-US] Parameters for removing a Reaction.
     * @returns [zh-CN] 删除完成后 resolve。 [en-US] Resolves after the Reaction is removed.
     */
    removeReaction(params: ReactionOperationParams): Promise<void>;
    /**
     * [zh-CN] 获取一条或多条消息的 Reaction 汇总列表。
     * [en-US] Retrieves the list of Reaction summaries for one or more messages.
     *
     * @example
     * ```ts
     * const list = await chatManager.getReactionList({
     *   messageId: ['msg_1', 'msg_2'],
     *   conversationType: 'groupChat',
     *   groupId: 'group_1',
     * });
     * ```
     *
     * @param params - [zh-CN] Reaction 汇总查询参数。 [en-US] Parameters for querying Reaction summaries.
     * @returns [zh-CN] 消息 Reaction 汇总列表。 [en-US] Message Reaction summary list.
     */
    getReactionList(params: GetReactionListParams): Promise<ReadonlyArray<MessageReactionListItem>>;
    /**
     * [zh-CN] 获取指定消息 Reaction 的用户详情。
     * [en-US] Retrieves the user details for a specified Reaction on a message.
     *
     * @example
     * ```ts
     * const page = await chatManager.getReactionDetail({
     *   messageId: 'msg_1',
     *   reaction: '👍',
     *   pageSize: 20,
     * });
     * ```
     *
     * @param params - [zh-CN] Reaction 详情查询参数。 [en-US] Parameters for querying Reaction details.
     * @returns [zh-CN] Reaction 用户详情分页结果。 [en-US] Paginated result of Reaction user details.
     */
    getReactionDetail(params: GetReactionDetailParams): Promise<MessageReactionDetailPage>;
    /**
     * [zh-CN] 获取翻译服务支持的语言列表。
     * [en-US] Retrieves the list of languages supported by the translation service.
     *
     * @example
     * ```ts
     * const languages = await chatManager.getSupportedTranslationLanguages();
     * ```
     *
     * @returns [zh-CN] 翻译支持语言列表。 [en-US] List of languages supported by the translation service.
     */
    getSupportedTranslationLanguages(): Promise<ReadonlyArray<TranslationLanguage>>;
    /**
     * [zh-CN] 翻译文本消息内容到一个或多个目标语言。
     * 适用于发送前或收到后的普通文本消息；仅返回翻译结果，不修改传入消息、不更新业务消息缓存。调用方可将 `result.translations` 转成语言到译文的映射用于展示。自动发送翻译请在创建消息时指定 `targetLanguages`。
     * [en-US] Translates the content of a text message into one or more target languages.
     *
     * Supports ordinary text messages before sending or after receipt. Only returns translation results; it does not mutate the input message or update application message caches. Callers can map `result.translations` by language for display. Set `targetLanguages` when creating a message to translate automatically on send.
     *
     * @example
     * ```ts
     * const result = await chatManager.translateMessage({
     *   message,
     *   targetLanguages: ['en'],
     * });
     * ```
     *
     * @param params - [zh-CN] 消息翻译参数。 [en-US] Parameters for translating a message.
     * @returns [zh-CN] 消息翻译结果。 [en-US] Message translation result.
     */
    translateMessage(params: TranslateMessageParams): Promise<MessageTranslationResult>;
    /**
     * [zh-CN] 将已发送或已接收的语音消息体转为文字。
     * [en-US] Transcribes the body of a sent or received voice message into text.
     *
     * @example
     * ```ts
     * const result = await chatManager.voiceMessageToText(voiceMessage.body, {
     *   format: 'amr',
     * });
     * ```
     *
     * @param voiceMessageBody - [zh-CN] 语音消息体。 [en-US] Voice message body.
     * @param voiceParams - [zh-CN] 语音识别参数。 [en-US] Voice recognition parameters.
     * @returns [zh-CN] 语音转文字结果。 [en-US] Voice-to-text result.
     */
    voiceMessageToText(voiceMessageBody: VoiceMessageBody, voiceParams?: VoiceParams): Promise<VoiceToTextResult>;
    /**
     * [zh-CN] 上传本地语音文件并转换为文字。
     * [en-US] Uploads a local voice file and transcribes it into text.
     *
     * @example
     * ```ts
     * const result = await chatManager.voiceFileToText(file, {
     *   format: 'amr',
     * });
     * ```
     *
     * @param file - [zh-CN] 本地语音文件。 [en-US] Local voice file.
     * @param voiceParams - [zh-CN] 语音识别参数。 [en-US] Voice recognition parameters.
     * @returns [zh-CN] 语音转文字结果。 [en-US] Voice-to-text result.
     */
    voiceFileToText(file: VoiceSourceFile, voiceParams?: VoiceParams): Promise<VoiceToTextResult>;
    private validateConversationLocator;
    private validateUnreadConversationLocator;
    private validateSendMessageReadReceiptsParams;
    private validateMessageIdList;
    private resolveDownloadCombineMessageParams;
    private validateReactionParams;
    private buildActionError;
    private requireNonEmptyString;
    private buildValidationError;
    private getEventContextOrThrow;
    private getClientOrThrow;
    private prepareEditedTextBody;
    private getRestContextOrThrow;
    private getRestClient;
    private requireConnectedClient;
    private getCurrentUserIdOrThrow;
    private buildMessageSenderOrThrow;
    private hydrateGroupMessageReadUsers;
    private getUserInfoReadCapability;
    private getGroupNamecardHydrationCapability;
    private dispatchFetchedUserInfoUpdates;
    private executeRestOperation;
    private mapRestError;
}
