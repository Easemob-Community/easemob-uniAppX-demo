import type { ChatRoomRawNotifyEvent } from '../../types/chatroom';
export interface ChatRoomMucJid {
    readonly name?: string;
    readonly clientResource?: string;
}
export interface ChatRoomMucEventInput {
    readonly operation: number;
    readonly chatRoomId: string;
    readonly chatRoomName?: string;
    readonly from?: ChatRoomMucJid;
    readonly to?: ReadonlyArray<ChatRoomMucJid>;
    readonly reason?: string;
    readonly eventExt?: string;
    readonly ext?: string;
    readonly members?: ReadonlyArray<string>;
}
export declare const mapMucOperationToChatRoomEvent: (input: ChatRoomMucEventInput) => ChatRoomRawNotifyEvent | null;
