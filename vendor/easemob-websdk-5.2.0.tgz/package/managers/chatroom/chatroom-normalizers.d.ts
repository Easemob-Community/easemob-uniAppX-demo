import type { ChatRoomAnnouncement, ChatRoomAttributeMutationResult, ChatRoomAttributesSnapshot, ChatRoomBlocklistEntry, ChatRoomDetail, ChatRoomListResult, ChatRoomMemberActionListResult, ChatRoomMemberListResult, ChatRoomMuteEntry, ChatRoomMuteStatus, ChatRoomSharedFile, ChatRoomSharedFileListResult, ChatRoomSummary, ChatRoomAllowlistEntry, ChatRoomUpdateResult } from '../../types/chatroom';
import type { UserInfo } from '../../types/user-info';
export declare const normalizeChatRoomSummary: (value: unknown, options?: {
    readonly stripOwnerAppKeyPrefix?: boolean;
}) => ChatRoomSummary | null;
export declare const normalizeChatRoomListResult: (payload: unknown, options?: {
    readonly stripOwnerAppKeyPrefix?: boolean;
}) => ChatRoomListResult;
export declare const normalizeChatRoomUpdateResult: (payload: unknown) => ChatRoomUpdateResult;
export declare const normalizeChatRoomDetail: (payload: unknown, currentUserId?: string) => ChatRoomDetail;
export declare const normalizeChatRoomMemberListResult: (payload: unknown) => ChatRoomMemberListResult;
export declare const normalizeChatRoomAdminUsers: (payload: unknown) => ReadonlyArray<UserInfo>;
export declare const normalizeChatRoomMuteEntries: (payload: unknown) => ReadonlyArray<ChatRoomMuteEntry>;
export declare const normalizeChatRoomAllowlistEntries: (payload: unknown) => ReadonlyArray<ChatRoomAllowlistEntry>;
export declare const normalizeChatRoomBlocklistEntries: (payload: unknown) => ReadonlyArray<ChatRoomBlocklistEntry>;
export declare const normalizeChatRoomAnnouncement: (payload: unknown) => ChatRoomAnnouncement;
export declare const normalizeChatRoomSharedFile: (value: unknown) => ChatRoomSharedFile | null;
export declare const normalizeChatRoomSharedFileListResult: (payload: unknown) => ChatRoomSharedFileListResult;
export declare const normalizeChatRoomAttributesSnapshot: (payload: unknown, chatRoomId: string) => ChatRoomAttributesSnapshot;
export declare const normalizeChatRoomAttributeMutationResult: (payload: unknown, chatRoomId: string) => ChatRoomAttributeMutationResult;
export declare const normalizeChatRoomMemberActionListResult: (payload: unknown) => ChatRoomMemberActionListResult;
export declare const normalizeChatRoomBooleanStatus: (payload: unknown) => boolean;
export declare const normalizeChatRoomMuteStatus: (payload: unknown) => ChatRoomMuteStatus;
