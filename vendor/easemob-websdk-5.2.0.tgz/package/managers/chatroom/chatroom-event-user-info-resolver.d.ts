import type { CacheManager } from '../../cache/cache-manager';
import type { UserInfo } from '../../types/user-info';
export interface ChatRoomUserInfoFetchParams {
    readonly userIds: ReadonlyArray<string>;
}
export type ChatRoomUserInfoFetcher = (params: ChatRoomUserInfoFetchParams) => Promise<ReadonlyArray<UserInfo>>;
interface ChatRoomUserInfoResolverOptions {
    readonly cacheManager: Pick<CacheManager, 'getUserInfoSummaries'> | null;
    readonly fetchUserInfos?: ChatRoomUserInfoFetcher;
}
export declare const buildMinimalChatRoomUserInfo: (userId: string) => UserInfo;
export declare const mergeChatRoomUserInfo: (base: UserInfo | undefined, incoming: UserInfo | undefined, userId: string) => UserInfo;
export declare const resolveChatRoomUserInfoMap: (userIds: ReadonlyArray<string>, options: ChatRoomUserInfoResolverOptions) => Promise<ReadonlyMap<string, UserInfo>>;
export declare const resolveChatRoomUserInfos: (userIds: ReadonlyArray<string>, options: ChatRoomUserInfoResolverOptions) => Promise<ReadonlyArray<UserInfo>>;
export {};
