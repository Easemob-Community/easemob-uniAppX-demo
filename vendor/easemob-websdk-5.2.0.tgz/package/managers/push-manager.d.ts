/**
 * PushManager 管理器
 */
import type { ChatClient } from '../chat-client';
import type { PushEventHandlerMap, EventHandlerId } from '../types/event-system';
import type { ManagerBase, ManagerEventContext, ManagerSessionContext, ManagerSessionEndContext } from '../types/manager';
import type { BatchConversationSilentModeResponse, ClearConversationRemindTypeParams, ConversationSilentModeResponse, GetConversationListByRemindTypeParams, GetConversationSilentModeParams, GetConversationSilentModesParams, GetGlobalSilentModeParams, GetPushLanguageParams, GlobalSilentModeResponse, MutedConversationPageResponse, PushLanguageResponse, SetConversationSilentModeParams, SetGlobalSilentModeParams, SetPushLanguageParams, SetNativePushOptions, UploadPushTokenParams } from '../types/push';
/**
 * PushManager 负责 push token、免打扰与语言偏好管理
 */
export declare class PushManager implements ManagerBase<ChatClient> {
    /** @internal SDK 内部管理器注册键，不对外文档暴露。 */
    static readonly key: "pushManager";
    private client;
    private restClient;
    private restBaseUrl;
    private restToken;
    private eventContext;
    private readonly nativePushController;
    /**
     * @internal
     * [zh-CN] 绑定 PushManager 到 ChatClient，通常由 SDK 内部在 `client.pushManager` 初始化阶段调用。 [en-US] Binds PushManager to ChatClient and is usually called internally when `client.pushManager` is initialized.
     *
     * @param client - [zh-CN] 已初始化的 ChatClient 实例。 [en-US] Initialized ChatClient instance.
     * @param context - [zh-CN] 管理器事件上下文，用于注册和派发脱敏诊断事件。 [en-US] Manager event context used to register and dispatch sanitized diagnostic events.
     * @returns {void} [zh-CN] 无返回值。 [en-US] Returns nothing.
     */
    bind(client: ChatClient, context?: ManagerEventContext<PushEventHandlerMap>): void;
    /** @internal [zh-CN] 当前 IM 会话就绪时启动原生 Token 注册。 [en-US] Starts native token registration when the IM session becomes ready. */
    onSessionReady(context: ManagerSessionContext): void;
    /** @internal [zh-CN] 当前 IM 会话结束前尝试解绑原生 Token。 [en-US] Attempts to remove the native token before the IM session ends. */
    onSessionEnding(context: ManagerSessionEndContext): Promise<void>;
    /** @internal [zh-CN] 清理当前会话的原生推送运行时状态。 [en-US] Clears native push runtime state for the current session. */
    resetSessionRuntime(): void;
    /**
     * [zh-CN] 配置 uni-app UTS 原生推送插件与环信证书。配置同步完成，Token 注册和绑定在后台执行。
     * [en-US] Configures the uni-app UTS native push plugin and Easemob certificates. Configuration is synchronous; token registration and binding run in the background.
     *
     * @example [zh-CN] 配置 UTS 插件 [en-US] Configure a UTS plugin
     * ```ts
     * client.pushManager.setNativePush({
     *   plugin: { onRegister, unRegister },
     *   certificates: { fcm: 'fcm-certificate', apns: 'apns-certificate' },
     * });
     * ```
     * @param options - [zh-CN] 插件函数对象和至少一个通道证书名称。 [en-US] Plugin function object and at least one channel certificate name.
     * @returns {void} [zh-CN] 无返回值；绑定结果通过 PushManager 事件通知。 [en-US] Returns nothing; binding results are delivered through PushManager events.
     */
    setNativePush(options: SetNativePushOptions): void;
    /**
     * [zh-CN] 移除当前设备的原生 Push Token。成功后插件保持停用，需再次调用 `setNativePush()` 才会启用。
     * [en-US] Removes the native push token for the current device. The plugin remains disabled until `setNativePush()` is called again.
     *
     * @example [zh-CN] 关闭当前设备离线推送 [en-US] Disable offline push for the current device
     * ```ts
     * await client.pushManager.removePushToken();
     * ```
     * @returns {Promise<void>} [zh-CN] 服务端解绑成功或当前无已知绑定时 resolve。 [en-US] Resolves after server removal succeeds or when no binding is known.
     */
    removePushToken(): Promise<void>;
    /**
     * [zh-CN] 注册 PushManager 事件处理器。
     * [en-US] Registers PushManager event handlers.
     * @example
     * ```ts
     * client.pushManager.addEventHandler('push', { onPushTokenBound: console.log });
     * ```
     * @param id - [zh-CN] 处理器唯一 ID。 [en-US] Unique handler ID.
     * @param handlers - [zh-CN] 原生推送事件处理器。 [en-US] Native push event handlers.
     * @returns {void} [zh-CN] 无返回值。 [en-US] Returns nothing.
     */
    addEventHandler(id: EventHandlerId, handlers: PushEventHandlerMap): void;
    /**
     * [zh-CN] 移除 PushManager 事件处理器。
     * [en-US] Removes PushManager event handlers.
     * @example
     * ```ts
     * client.pushManager.removeEventHandler('push');
     * ```
     * @param id - [zh-CN] 处理器唯一 ID。 [en-US] Unique handler ID.
     * @returns {void} [zh-CN] 无返回值。 [en-US] Returns nothing.
     */
    removeEventHandler(id: EventHandlerId): void;
    /**
     * [zh-CN] 上传或覆盖设备 Push Token。成功时仅表示请求完成，不返回业务数据。 [en-US] Uploads or replaces the device push token. On success it only resolves and returns no business payload.
     *
     * @example [zh-CN] 调用示例（上传设备 token） [en-US] Usage example (upload device token)
     * ```ts
     * await client.pushManager.uploadPushToken({
     *   deviceId: 'web-device-001',
     *   deviceToken: 'token-from-push-provider',
     *   notifierName: 'FCM',
     * });
     * ```
     *
     * @param params - [zh-CN] 上传参数，包含设备标识、设备 token 与推送通道标识。 [en-US] Upload parameters including device id, device token, and notifier name.
     * @returns {Promise<void>} [zh-CN] 成功时 resolve，无返回值。 [en-US] Resolves on success with no return value.
     */
    uploadPushToken(params: UploadPushTokenParams): Promise<void>;
    private requestNativePushToken;
    /**
     * [zh-CN] 设置 App 级（全局）免打扰规则，支持提醒类型、持续时长、时间区间三种模式。 [en-US] Sets app-level (global) silent mode rule, supporting remind type, duration, and interval modes.
     *
     * @example [zh-CN] 调用示例（设置全局提醒类型） [en-US] Usage example (set global remind type)
     * ```ts
     * const result = await client.pushManager.setGlobalSilentMode({
     *   rule: { mode: 'REMIND_TYPE', remindType: 'AT' },
     * });
     * console.log(result.rule.remindType);
     * ```
     *
     * @param params - [zh-CN] 全局免打扰设置参数。 [en-US] Parameters for setting global silent mode.
     * @returns {Promise<GlobalSilentModeResponse>} [zh-CN] 返回全局规则快照。 [en-US] Returns the global silent mode snapshot.
     */
    setGlobalSilentMode(params: SetGlobalSilentModeParams): Promise<GlobalSilentModeResponse>;
    /**
     * [zh-CN] 查询 App 级（全局）免打扰规则。 [en-US] Gets the app-level (global) silent mode rule.
     *
     * @example [zh-CN] 调用示例（查询全局规则） [en-US] Usage example (get global rule)
     * ```ts
     * const result = await client.pushManager.getGlobalSilentMode();
     * console.log(result.rule);
     * ```
     *
     * @param params - [zh-CN] 查询参数（当前无字段）。 [en-US] Query parameters (currently empty).
     * @returns {Promise<GlobalSilentModeResponse>} [zh-CN] 返回全局规则快照。 [en-US] Returns the global silent mode snapshot.
     */
    getGlobalSilentMode(params?: GetGlobalSilentModeParams): Promise<GlobalSilentModeResponse>;
    /**
     * [zh-CN] 设置单会话免打扰规则，仅支持单聊与群聊。 [en-US] Sets silent mode rule for a specific conversation, supporting only single chat and group chat.
     *
     * @example [zh-CN] 调用示例（设置会话时长免打扰） [en-US] Usage example (set conversation duration mode)
     * ```ts
     * const result = await client.pushManager.setConversationSilentMode({
     *   conversationId: 'group_123',
     *   conversationType: 'groupChat',
     *   rule: { mode: 'DURATION', duration: 60 },
     * });
     * console.log(result.rule.expireTimestamp);
     * ```
     *
     * @param params - [zh-CN] 会话维度的免打扰设置参数。 [en-US] Conversation-level silent mode parameters.
     * @returns {Promise<ConversationSilentModeResponse>} [zh-CN] 返回目标会话与规则快照。 [en-US] Returns target conversation with its rule snapshot.
     */
    setConversationSilentMode(params: SetConversationSilentModeParams): Promise<ConversationSilentModeResponse>;
    /**
     * [zh-CN] 查询单会话免打扰规则。 [en-US] Gets silent mode rule for a specific conversation.
     *
     * @example [zh-CN] 调用示例（查询会话规则） [en-US] Usage example (get conversation rule)
     * ```ts
     * const result = await client.pushManager.getConversationSilentMode({
     *   conversationId: 'user_001',
     *   conversationType: 'singleChat',
     * });
     * console.log(result.rule.remindType);
     * ```
     *
     * @param params - [zh-CN] 会话查询参数。 [en-US] Conversation query parameters.
     * @returns {Promise<ConversationSilentModeResponse>} [zh-CN] 返回目标会话的规则快照。 [en-US] Returns rule snapshot of the target conversation.
     */
    getConversationSilentMode(params: GetConversationSilentModeParams): Promise<ConversationSilentModeResponse>;
    /**
     * [zh-CN] 清除会话提醒类型配置，恢复服务端默认提醒策略。 [en-US] Clears conversation remind type and restores server-side default remind policy.
     *
     * @example [zh-CN] 调用示例（清除会话提醒类型） [en-US] Usage example (clear conversation remind type)
     * ```ts
     * const result = await client.pushManager.clearConversationRemindType({
     *   conversationId: 'group_123',
     *   conversationType: 'groupChat',
     * });
     * console.log(result.rule.remindType);
     * ```
     *
     * @param params - [zh-CN] 清除会话提醒类型所需参数。 [en-US] Parameters required to clear conversation remind type.
     * @returns {Promise<ConversationSilentModeResponse>} [zh-CN] 返回清除后的会话规则快照。 [en-US] Returns conversation rule snapshot after clearing.
     */
    clearConversationRemindType(params: ClearConversationRemindTypeParams): Promise<ConversationSilentModeResponse>;
    /**
     * [zh-CN] 批量查询多个会话的免打扰规则，单次最多 20 条。 [en-US] Batch queries silent mode rules for multiple conversations, up to 20 items per request.
     *
     * @example [zh-CN] 调用示例（批量查询） [en-US] Usage example (batch query)
     * ```ts
     * const result = await client.pushManager.getConversationSilentModes({
     *   conversationList: [
     *     { conversationId: 'user_001', conversationType: 'singleChat' },
     *     { conversationId: 'group_123', conversationType: 'groupChat' },
     *   ],
     * });
     * console.log(result.conversations);
     * ```
     *
     * @param params - [zh-CN] 批量查询参数。 [en-US] Batch query parameters.
     * @returns {Promise<BatchConversationSilentModeResponse>} [zh-CN] 返回与输入顺序对齐的会话规则列表。 [en-US] Returns conversation rules aligned with the input order.
     */
    getConversationSilentModes(params: GetConversationSilentModesParams): Promise<BatchConversationSilentModeResponse>;
    /**
     * [zh-CN] 设置推送翻译语言。 [en-US] Sets push notification translation language.
     *
     * @example [zh-CN] 调用示例（设置推送语言） [en-US] Usage example (set push language)
     * ```ts
     * await client.pushManager.setPushLanguage({ language: 'zh-Hans' });
     * ```
     *
     * @param params - [zh-CN] 语言设置参数。 [en-US] Language setting parameters.
     * @returns {Promise<void>} [zh-CN] 成功时 resolve，无返回值。 [en-US] Resolves on success with no return value.
     */
    setPushLanguage(params: SetPushLanguageParams): Promise<void>;
    /**
     * [zh-CN] 查询当前推送翻译语言。 [en-US] Gets current push notification translation language.
     *
     * @example [zh-CN] 调用示例（查询推送语言） [en-US] Usage example (get push language)
     * ```ts
     * const result = await client.pushManager.getPushLanguage();
     * console.log(result.language);
     * ```
     *
     * @param params - [zh-CN] 查询参数（当前无字段）。 [en-US] Query parameters (currently empty).
     * @returns {Promise<PushLanguageResponse>} [zh-CN] 返回当前语言值。 [en-US] Returns the current language value.
     */
    getPushLanguage(params?: GetPushLanguageParams): Promise<PushLanguageResponse>;
    /**
     * [zh-CN] 分页查询已设置提醒类型的会话列表。 [en-US] Paginates conversations that have explicit remind type settings.
     *
     * @example [zh-CN] 调用示例（分页查询） [en-US] Usage example (pagination query)
     * ```ts
     * const result = await client.pushManager.getConversationListByRemindType({
     *   pageSize: 20,
     *   cursor: '',
     * });
     * console.log(result.conversations, result.cursor);
     * ```
     *
     * @param params - [zh-CN] 分页参数，包含页大小与可选游标。 [en-US] Paging parameters including page size and optional cursor.
     * @returns {Promise<MutedConversationPageResponse>} [zh-CN] 返回会话列表与下一页游标。 [en-US] Returns conversation list and next cursor.
     */
    getConversationListByRemindType(params: GetConversationListByRemindTypeParams): Promise<MutedConversationPageResponse>;
    private runOperation;
    private normalizeSdkError;
    private getRestContextOrThrow;
    private getRestClient;
    private getClientOrThrow;
    private parseAppKey;
    private validateUploadPushTokenParams;
    private validateConversationId;
    private validateConversationType;
    private validateConversationList;
    private validateLanguage;
    private validateNonEmptyString;
    private validateRuleInput;
    private ensureNoConflictFields;
    private validateTimePoint;
    private buildSilentModePayload;
    private normalizeRuleView;
    private parseRuleView;
    private parseInterval;
    private toRuleViewFromFallback;
    private formatIntervalSegment;
    private resolveConversationRuleMap;
    private resolveSilentModeRuleSource;
    private normalizeRemindType;
    private resolvePushLanguage;
    private mapConversationTypeToPath;
    private buildValidationError;
}
