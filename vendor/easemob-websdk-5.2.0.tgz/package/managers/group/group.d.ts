/**
 * [zh-CN] 轻量 Group 单群对象。
 * [en-US] Lightweight single-group object.
 */
import type { GroupManager } from '../group-manager';
import type { GroupAllowlistEntry, GroupAnnouncement, GroupAnnouncementUpdateInput, GroupBlocklistEntry, GroupDeleteSharedFileInput, GroupDetail, GroupDownloadSharedFileInput, GroupGetMembersAttributesInput, GroupMemberListQuery, GroupMemberListResult, GroupMembersAttributesResult, GroupMuteEntry, GroupMuteListQuery, GroupMuteMembersInput, JoinedGroupSummary, NumberPageParams, GroupOwnerChangeInput, GroupSetMemberAttributesInput, GroupSharedFileListQuery, GroupSharedFileListResult, GroupUpdateConfigsInput, GroupUpdateInfoInput, GroupUploadSharedFileInput, GroupUserBatchInput, GroupUserInfo } from '../../types/group';
/**
 * [zh-CN] 绑定固定 `groupId` 的单群上下文对象。
 * [en-US] Single-group context object bound to a fixed `groupId`.
 */
export declare class Group {
    readonly groupId: string;
    private readonly manager;
    constructor(groupId: string, manager: GroupManager);
    /**
     * [zh-CN] 读取当前会话或本地预览中已知的已加入群轻量摘要。该方法不会发起网络请求，返回结果也不等同于完整群组详情。
     * [en-US] Retrieves the lightweight summaries of known joined groups in the current conversation or local preview. This method does not send a network request, and the result is not equivalent to the full group detail.
     *
     * @example [zh-CN] 读取本地轻量摘要。 [en-US] Read the local lightweight summary.
     * ```ts
     * const group = client.groupManager.getGroup('group-1');
     * const summary = group.getSummary();
     * ```
     * @returns {JoinedGroupSummary | null} [zh-CN] 返回本地已知的群组轻量摘要；如果当前没有可用摘要，则返回 `null`。 [en-US] Returns the locally known lightweight group summary, or `null` if no summary is currently available.
     */
    getSummary(): JoinedGroupSummary | null;
    /**
     * [zh-CN] 获取当前群组详情。该方法会优先复用当前会话中的可用快照，必要时再从服务端拉取最新数据。
     * [en-US] Retrieves the details of the current group. This method prioritizes reusing available snapshots within the current conversation, pulling the latest data from the server only when necessary.
     *
     * @example [zh-CN] 获取群详情 [en-US] Retrieve group details.
     * ```ts
     * const group = client.groupManager.getGroup('group-1');
     * const detail = await group.getDetail();
     * ```
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 不合法，或目标群组不存在。确认 `groupId` 合法且目标群组存在。 [en-US] Error code `110`: The group ID is invalid, or the target group does not exist. Verify that `groupId` is valid and that the target group exists.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<GroupDetail>} [zh-CN] 返回标准化群组详情。 [en-US] Returns the normalized group details.
     */
    getDetail(): Promise<GroupDetail>;
    /**
     * [zh-CN] 强制从服务端拉取并刷新当前群组详情。
     * [en-US] Forces a fetch from the server to refresh the current group details.
     *
     * @example [zh-CN] 刷新群详情 [en-US] Refresh group details.
     * ```ts
     * const detail = await client.groupManager.getGroup('group-1').refresh();
     * ```
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 不合法，或目标群组不存在。 [en-US] Error code `110`: The group ID is invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<GroupDetail>} [zh-CN] 返回刷新后的标准化群组详情。 [en-US] Returns the refreshed and normalized group detail.
     */
    refresh(): Promise<GroupDetail>;
    /**
     * [zh-CN] 更新当前群组的基础资料，例如群组名称、群组描述、头像或扩展信息。
     * [en-US] Updates the basic profile of the current group, such as the group name, description, avatar, or extension information.
     *
     * @example [zh-CN] 更新群名称 [en-US] Update group name.
     * ```ts
     * await client.groupManager.getGroup('group-1').updateInfo({ name: 'New group name' });
     * ```
     * @param input - [zh-CN] 需要更新的群组资料字段。 [en-US] The group profile fields to update.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：参数不合法，或目标群组不存在。 [en-US] Error code `110`: Invalid parameters, or the target group does not exist. Check if the input fields are valid, and confirm that the target group exists.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<void>} [zh-CN] 更新成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    updateInfo(input: GroupUpdateInfoInput): Promise<void>;
    /**
     * [zh-CN] 更新当前群组的配置，例如是否公开、入群审批方式、普通成员邀请权限以及群成员人数上限。
     * [en-US] Updates the current group configuration, such as publicity settings, join approval type, regular member invitation permissions, and the maximum member limit.
     *
     * @example [zh-CN] 关闭成员邀请 [en-US] Disable member invitations.
     * ```ts
     * await client.groupManager.getGroup('group-1').updateConfigs({ allowInvites: false });
     * ```
     * @param input - [zh-CN] 需要更新的群组配置字段。 [en-US] The group configuration fields to update.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：参数不合法，或目标群组不存在。 [en-US] Error code `110`: Invalid parameters, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<void>} [zh-CN] 更新成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    updateConfigs(input: GroupUpdateConfigsInput): Promise<void>;
    /**
     * [zh-CN] 转让当前群组的所有权。
     * [en-US] Transfers ownership of the current group to another user.
     *
     * @example [zh-CN] 转让群主 [en-US] Transfer the group owner.
     * ```ts
     * await client.groupManager.getGroup('group-1').changeOwner({ newOwner: 'user-2' });
     * ```
     * @param input - [zh-CN] 新群主的用户 ID。 [en-US] The user ID of the new group owner.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：新群主不合法、新群主不在群组中，或目标群组不存在。 [en-US] Error code `110`: The new owner is invalid, the new owner is not in the group, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<void>} [zh-CN] 转让成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    changeOwner(input: GroupOwnerChangeInput): Promise<void>;
    /**
     * [zh-CN] 解散当前群组。
     * [en-US] Disbands the current group.
     *
     * @example [zh-CN] 解散群组 [en-US] Destroy a group.
     * ```ts
     * await client.groupManager.getGroup('group-1').destroy();
     * ```
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 不合法，或目标群组不存在。 [en-US] Error code `110`: The group ID is invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限解散该群组。[en-US] Error code `202`: Authentication failed, or the current user does not have permission to disband this group.
     * @returns {Promise<void>} [zh-CN] 解散成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    destroy(): Promise<void>;
    /**
     * [zh-CN] 当前登录用户主动退出群组。
     * [en-US] Actively leave the group as the current logged-in user.
     *
     * @example [zh-CN] 退出群组 [en-US] Leave a group.
     * ```ts
     * await client.groupManager.getGroup('group-1').leave();
     * ```
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 不合法、目标群组不存在，或当前用户不在该群组中。 [en-US] Error code `110`: The group ID is invalid, the target group does not exist, or the current user is not in the group.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<void>} [zh-CN] 退出成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    leave(): Promise<void>;
    /**
     * [zh-CN] 分页获取当前群组的成员列表。
     * [en-US] Retrieves the member list of the current group with pagination.
     *
     * @example [zh-CN] 获取群成员 [en-US] Retrieve group members.
     * ```ts
     * const page = await client.groupManager.getGroup('group-1').getMembers({ pageSize: 20 });
     * ```
     * @param query - [zh-CN] 可选分页参数。 [en-US] Optional pagination parameters.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 或分页参数不合法。 [en-US] Error code `110`: The group ID or pagination parameters are invalid.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<GroupMemberListResult>} [zh-CN] 返回群成员分页结果。 [en-US] Returns the paginated results of group members.
     */
    getMembers(query?: GroupMemberListQuery): Promise<GroupMemberListResult>;
    /**
     * [zh-CN] 从当前群组中移除指定成员。
     * [en-US] Removes members from the current group.
     *
     * @example [zh-CN] 移除群成员 [en-US] Remove group members.
     * ```ts
     * await client.groupManager.getGroup('group-1').removeMembers({ userIds: ['user-2'] });
     * ```
     * @param input - [zh-CN] 待移除成员的用户 ID 列表。 [en-US] The list of user IDs of the members to remove.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：成员列表为空、成员用户 ID 不合法，或目标群组不存在。 [en-US] Error code `110`: The member list is empty, a member user ID is invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限移除群成员。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to remove group members.
     * @returns {Promise<void>} [zh-CN] 移除成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    removeMembers(input: GroupUserBatchInput): Promise<void>;
    /**
     * [zh-CN] 获取当前群组的管理员列表。
     * [en-US] Retrieves the list of admins in the current group.
     *
     * @example [zh-CN] 获取管理员 [en-US] Get group admins.
     * ```ts
     * const admins = await client.groupManager.getGroup('group-1').getAdmins();
     * ```
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 不合法，或目标群组不存在。 [en-US] Error code `110`: The group ID is invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<ReadonlyArray<GroupUserInfo>>} [zh-CN] 返回管理员的群上下文用户资料列表。 [en-US] Returns group-context user profiles for the admins.
     */
    getAdmins(): Promise<ReadonlyArray<GroupUserInfo>>;
    /**
     * [zh-CN] 添加群组管理员。
     * [en-US] Adds a group admin.
     *
     * @example [zh-CN] 添加管理员 [en-US] Add an admin.
     * ```ts
     * await client.groupManager.getGroup('group-1').addAdmin({ userId: 'user-2' });
     * ```
     * @param input - [zh-CN] 待设为管理员的用户 ID。 [en-US] The user ID to grant admin privileges to.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：用户 ID 不合法、目标用户不在群组中，或目标群组不存在。 [en-US] Error code `110`: The user ID is invalid, the specified user is not in the group, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限添加管理员。[en-US] Error code `202`: Authentication failed, or the current user does not have permission to add an admin.
     * @returns {Promise<void>} [zh-CN] 设置成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    addAdmin(input: {
        userId: string;
    }): Promise<void>;
    /**
     * [zh-CN] 移除群管理员。
     * [en-US] Removes a group admin.
     *
     * @example [zh-CN] 移除管理员 [en-US] Remove an admin.
     * ```ts
     * await client.groupManager.getGroup('group-1').removeAdmin({ userId: 'user-2' });
     * ```
     * @param input - [zh-CN] 待移除管理员权限的用户 ID。 [en-US] The user ID whose admin privileges will be removed.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：用户 ID 不合法、目标用户不是管理员，或目标群组不存在。 [en-US] Error code `110`: The user ID is invalid, the specified user is not an admin, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限移除管理员。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to remove an admin.
     * @returns {Promise<void>} [zh-CN] 移除成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    removeAdmin(input: {
        userId: string;
    }): Promise<void>;
    /**
     * [zh-CN] 获取当前群组的禁言列表。
     * [en-US] Retrieves the mute list of the current group.
     *
     * @example [zh-CN] 获取禁言列表 [en-US] Retrieve mute list.
     * ```ts
     * const mutes = await client.groupManager.getGroup('group-1').getMuteList({ pageSize: 20 });
     * ```
     * @param page - [zh-CN] 可选分页参数。 [en-US] Optional pagination parameters.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 或分页参数不合法。 [en-US] Error code `110`: The group ID or pagination parameters are invalid.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。 [en-US] Error code `202`: Authentication failed.
     * @returns {Promise<ReadonlyArray<GroupMuteEntry>>} [zh-CN] 返回禁言成员列表。 [en-US] Returns the list of muted members.
     */
    getMuteList(page?: GroupMuteListQuery): Promise<ReadonlyArray<GroupMuteEntry>>;
    /**
     * [zh-CN] 将当前群组中的指定成员加入禁言列表。
     * [en-US] Mutes specified members in the current group.
     *
     * @example [zh-CN] 禁言成员 [en-US] Mute members.
     * ```ts
     * await client.groupManager.getGroup('group-1').muteMembers({
     *   userIds: ['user-2'],
     *   muteDuration: 3_600_000,
     * });
     * ```
     * @param input - [zh-CN] 待禁言成员的用户 ID 列表，以及禁言时长（单位：毫秒）。 [en-US] The list of user IDs to mute and the mute duration, in milliseconds.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：成员列表为空、成员用户 ID 不合法，或禁言时长不合法。 [en-US] Error code `110`: The member list is empty, one or more member user IDs are invalid, or the mute duration is invalid.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限禁言成员。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to mute members.
     * @returns {Promise<void>} [zh-CN] 禁言成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    muteMembers(input: GroupMuteMembersInput): Promise<void>;
    /**
     * [zh-CN] 解除当前群组中指定成员的禁言状态。
     * [en-US] Unmutes specified members in the current group.
     *
     * @example [zh-CN] 解除禁言 [en-US] Unmute members.
     * ```ts
     * await client.groupManager.getGroup('group-1').unmuteMembers({ userIds: ['user-2'] });
     * ```
     * @param input - [zh-CN] 待解除禁言成员的用户 ID 列表。 [en-US] The list of user IDs to unmute.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：成员列表为空，或成员用户 ID 不合法。 [en-US] Error code `110`: The member list is empty, or one or more member user IDs are invalid.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限解除禁言。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to unmute members.
     * @returns {Promise<void>} [zh-CN] 解除成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    unmuteMembers(input: GroupUserBatchInput): Promise<void>;
    /**
     * [zh-CN] 开启当前群组的全员禁言。
     * [en-US] Enables all-member mute for the current group.
     *
     * @example [zh-CN] 开启全员禁言 [en-US] Enable all-member mute.
     * ```ts
     * await client.groupManager.getGroup('group-1').muteAllMembers();
     * ```
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 不合法，或目标群组不存在。 [en-US] Error code `110`: The group ID is invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限开启全员禁言。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to enable all-member mute.
     * @returns {Promise<void>} [zh-CN] 开启成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    muteAllMembers(): Promise<void>;
    /**
     * [zh-CN] 关闭当前群组的全员禁言。
     * [en-US] Disables all-member mute for the current group.
     *
     * @example [zh-CN] 关闭全员禁言 [en-US] Disable all-member mute.
     * ```ts
     * await client.groupManager.getGroup('group-1').unmuteAllMembers();
     * ```
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 不合法，或目标群组不存在。 [en-US] Error code `110`: The group ID is invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限关闭全员禁言。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to disable all-member mute.
     * @returns {Promise<void>} [zh-CN] 关闭成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    unmuteAllMembers(): Promise<void>;
    /**
     * [zh-CN] 获取当前群组的黑名单列表。
     * [en-US] Retrieves the block list of the current group.
     *
     * @example [zh-CN] 获取群黑名单。 [en-US] Get the group block list.
     * ```ts
     * const blocklist = await client.groupManager.getGroup('group-1').getBlocklist({ pageSize: 20 });
     * ```
     * @param page - [zh-CN] 可选分页参数。 [en-US] Optional pagination parameters.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 或分页参数不合法。 [en-US] Error code `110`: The group ID or pagination parameters are invalid.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<ReadonlyArray<GroupBlocklistEntry>>} [zh-CN] 返回黑名单成员列表。 [en-US] Returns the list of members in the block list.
     */
    getBlocklist(page?: NumberPageParams): Promise<ReadonlyArray<GroupBlocklistEntry>>;
    /**
     * [zh-CN] 将指定成员加入当前群组的黑名单。
     * [en-US] Adds specified members to the block list of the current group.
     *
     * @example [zh-CN] 加入黑名单。 [en-US] Add members to the block list.
     * ```ts
     * await client.groupManager.getGroup('group-1').blockMembers({ userIds: ['user-2'] });
     * ```
     * @param input - [zh-CN] 待加入黑名单成员的用户 ID 列表。 [en-US] The list of user IDs to add to the block list.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：成员列表为空、成员用户 ID 不合法，或目标群组不存在。 [en-US] Error code `110`: The member list is empty, one or more member user IDs are invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限操作黑名单。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to manage the block list.
     * @returns {Promise<void>} [zh-CN] 加入成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    blockMembers(input: GroupUserBatchInput): Promise<void>;
    /**
     * [zh-CN] 将指定成员移出当前群组的黑名单。
     * [en-US] Removes specified members from the block list of the current group.
     *
     * @example [zh-CN] 移出黑名单。 [en-US] Remove members from the block list.
     * ```ts
     * await client.groupManager.getGroup('group-1').unblockMembers({ userIds: ['user-2'] });
     * ```
     * @param input - [zh-CN] 待移出黑名单成员的用户 ID 列表。 [en-US] The list of user IDs to remove from the block list.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：成员列表为空，或成员用户 ID 不合法。 [en-US] Error code `110`: The member list is empty, or one or more member user IDs are invalid.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限操作黑名单。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to manage the block list.
     * @returns {Promise<void>} [zh-CN] 移出成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    unblockMembers(input: GroupUserBatchInput): Promise<void>;
    /**
     * [zh-CN] 获取当前群组的白名单列表。
     * [en-US] Retrieves the allow list of the current group.
     *
     * @example [zh-CN] 获取白名单。 [en-US] Retrieve the allow list.
     * ```ts
     * const allowlist = await client.groupManager.getGroup('group-1').getAllowlist();
     * ```
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 不合法，或目标群组不存在。 [en-US] Error code `110`: The group ID is invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<ReadonlyArray<GroupAllowlistEntry>>} [zh-CN] 返回白名单成员列表。 [en-US] Returns the list of members in the allow list.
     */
    getAllowlist(): Promise<ReadonlyArray<GroupAllowlistEntry>>;
    /**
     * [zh-CN] 将指定成员加入当前群组的白名单。
     * [en-US] Adds specified members to the allow list of the current group.
     *
     * @example [zh-CN] 加入白名单。 [en-US] Add members to the allow list.
     * ```ts
     * await client.groupManager.getGroup('group-1').addUsersToAllowlist({ userIds: ['user-2'] });
     * ```
     * @param input - [zh-CN] 待加入白名单成员的用户 ID 列表。 [en-US] The list of user IDs to add to the allow list.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：成员列表为空、成员用户 ID 不合法，或目标群组不存在。 [en-US] Error code `110`: The member list is empty, one or more member user IDs are invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限操作白名单。使用具备权限的账号重试，并确认鉴权状态有效。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to manage the allow list. Retry with an authorized account and confirm that the authentication state is valid.
     * @returns {Promise<void>} [zh-CN] 加入成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    addUsersToAllowlist(input: GroupUserBatchInput): Promise<void>;
    /**
     * [zh-CN] 将指定成员移出当前群组的白名单。
     * [en-US] Removes specified members from the allow list of the current group.
     *
     * @example [zh-CN] 移出白名单。 [en-US] Remove members from the allow list.
     * ```ts
     * await client.groupManager.getGroup('group-1').removeUsersFromAllowlist({ userIds: ['user-2'] });
     * ```
     * @param input - [zh-CN] 待移出白名单成员的用户 ID 列表。 [en-US] The list of user IDs to remove from the allow list.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：成员列表为空，或成员用户 ID 不合法。[en-US] Error code `110`: The member list is empty, or one or more member user IDs are invalid.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限操作白名单。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to manage the allow list.
     * @returns {Promise<void>} [zh-CN] 移出成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    removeUsersFromAllowlist(input: GroupUserBatchInput): Promise<void>;
    /**
     * [zh-CN] 查询当前用户是否在当前群组的白名单中。
     * [en-US] Checks whether the current user is in the allow list of the current group.
     *
     * @example [zh-CN] 查询是否在白名单 [en-US] Check allow list membership.
     * ```ts
     * const inAllowlist = await client.groupManager.getGroup('group-1').checkIfInAllowList();
     * ```
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 不合法，或目标群组不存在。 [en-US] Error code `110`: The group ID is invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<boolean>} [zh-CN] 如果当前登录用户在白名单中，则返回 `true`；否则返回 `false`。 [en-US] Returns `true` if the current user is in the allow list; otherwise returns `false`.
     */
    checkIfInAllowList(): Promise<boolean>;
    /**
     * [zh-CN] 查询当前用户是否在当前群组的禁言列表中。
     * [en-US] Checks whether the current user is in the mute list of the current group.
     *
     * @example [zh-CN] 查询是否被禁言 [en-US] Check mute list membership.
     * ```ts
     * const muted = await client.groupManager.getGroup('group-1').checkIfInMuteList();
     * ```
     * @operation checkIfInGroupMuteList
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 不合法，或目标群组不存在。 [en-US] Error code `110`: The group ID is invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<boolean>} [zh-CN] 如果当前登录用户在禁言列表中，则返回 `true`；否则返回 `false`。 [en-US] Returns `true` if the current user is in the mute list; otherwise returns `false`.
     */
    checkIfInMuteList(): Promise<boolean>;
    /**
     * [zh-CN] 获取当前群组公告。
     * [en-US] Retrieves the current group announcement.
     *
     * @example [zh-CN] 获取群公告 [en-US] Retrieve the group announcement.
     * ```ts
     * const announcement = await client.groupManager.getGroup('group-1').getAnnouncement();
     * ```
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 不合法，或目标群组不存在。 [en-US] Error code `110`: The group ID is invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<GroupAnnouncement>} [zh-CN] 返回群公告对象。 [en-US] Returns the group announcement object.
     */
    getAnnouncement(): Promise<GroupAnnouncement>;
    /**
     * [zh-CN] 更新当前群组公告。
     * [en-US] Updates the current group announcement.
     *
     * @example [zh-CN] 更新群公告 [en-US] Update the group announcement.
     * ```ts
     * await client.groupManager.getGroup('group-1').updateAnnouncement({ announcement: 'Welcome' });
     * ```
     * @param input - [zh-CN] 新的群公告内容。 [en-US] New announcement content.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：公告内容不合法，或目标群组不存在。[en-US] Error code `110`: The announcement content is invalid, or the target group does not exist.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限修改群公告。[en-US] Error code `202`: Authentication failed, or the current user does not have permission to update the group announcement.
     * @returns {Promise<void>} [zh-CN] 更新成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    updateAnnouncement(input: GroupAnnouncementUpdateInput): Promise<void>;
    /**
     * [zh-CN] 分页获取当前群组的共享文件列表。
     * [en-US] Retrieves the shared file list of the current group with pagination.
     *
     * @example [zh-CN] 获取共享文件 [en-US] Retrieve shared files.
     * ```ts
     * const files = await client.groupManager.getGroup('group-1').getSharedFileList({ pageSize: 20 });
     * ```
     * @param query - [zh-CN] 可选分页参数。 [en-US] Optional pagination parameters.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 或分页参数不合法。 [en-US] Error code `110`: The group ID or pagination parameters are invalid.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<GroupSharedFileListResult>} [zh-CN] 返回共享文件分页结果。 [en-US] Returns the paginated results of shared files.
     */
    getSharedFileList(query?: GroupSharedFileListQuery): Promise<GroupSharedFileListResult>;
    /**
     * [zh-CN] 上传文件到当前群组的共享文件列表中。
     * [en-US] Uploads a file within the current group. The file will then be included in the shared file list of the current group.
     *
     * @example [zh-CN] 上传共享文件 [en-US] Upload a shared file.
     * ```ts
     * await client.groupManager.getGroup('group-1').uploadSharedFile({
     *   file,
     *   onFileUploadProgress: event => console.log(event.loaded),
     * });
     * ```
     * @param input - [zh-CN] 文件对象及上传回调。 [en-US] The file object and upload callbacks.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 或文件参数不合法。 [en-US] Error code `110`: The group ID or file parameters are invalid.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限上传共享文件。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to upload shared files.
     * @throws {SDKError} [zh-CN] 错误码 `1`：上传被取消，或当前平台上传失败。检查上传环境和网络状态后重试。 [en-US] Error code `1`: The upload was canceled, or the upload failed on the current platform. Check the upload environment and network status, and then try again.
     * @returns {Promise<void>} [zh-CN] 上传成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    uploadSharedFile(input: GroupUploadSharedFileInput): Promise<void>;
    /**
     * [zh-CN] 删除当前群组中的共享文件。
     * [en-US] Deletes a shared file from the current group.
     *
     * @example [zh-CN] 删除共享文件 [en-US] Delete a shared file.
     * ```ts
     * await client.groupManager.getGroup('group-1').deleteSharedFile({ fileId: 'file-1' });
     * ```
     * @param input - [zh-CN] 待删除共享文件的文件 ID。 [en-US] The file ID of the shared file to delete.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 或文件 ID 不合法。 [en-US] Error code `110`: The group ID or file ID is invalid.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限删除共享文件。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to delete shared files.
     * @returns {Promise<void>} [zh-CN] 删除成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    deleteSharedFile(input: GroupDeleteSharedFileInput): Promise<void>;
    /**
     * [zh-CN] 下载当前群组中的共享文件。下载完成后，会通过回调返回 `Blob` 数据。
     * [en-US] Downloads a shared file from the current group. After the download completes, the file data is returned as a `Blob` through the callback.
     *
     * @example [zh-CN] 下载共享文件 [en-US] Download a shared file.
     * ```ts
     * await client.groupManager.getGroup('group-1').downloadSharedFile({
     *   fileId: 'file-1',
     *   onFileDownloadComplete: blob => console.log(blob.size),
     * });
     * ```
     * @param input - [zh-CN] 文件 ID、可选 `secret` 以及下载回调。 [en-US] The file ID, optional `secret`, and download callbacks.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：群组 ID 或文件 ID 不合法。 [en-US] Error code `110`: The group ID or file ID is invalid.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @throws {SDKError} [zh-CN] 错误码 `303`：HTTP 下载失败。检查网络状态和文件资源后重试。 [en-US] Error code `303`: The HTTP download failed. Check the network status and file resource, and then try again.
     * @returns {Promise<void>} [zh-CN] 下载流程完成时 resolve。 [en-US] Resolves when the download flow completes.
     */
    downloadSharedFile(input: GroupDownloadSharedFileInput): Promise<void>;
    /**
     * [zh-CN] 设置当前群组中指定成员的自定义属性，常用于设置群成员名片。
     * [en-US] Sets custom attributes for a specified member in the current group. This is commonly used to set a group member card.
     *
     * @example [zh-CN] 设置群名片 [en-US] Set a group name card.
     * ```ts
     * await client.groupManager.getGroup('group-1').setMemberAttributes({
     *   userId: 'user-1',
     *   memberAttributes: { groupNamecard: 'Alice' },
     * });
     * ```
     * @param input - [zh-CN] 成员用户 ID 及成员属性键值对。 [en-US] The member user ID and the key-value pairs of member attributes.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：成员用户 ID、属性 key 或属性 value 不合法。 [en-US] Error code `110`: The member user ID, attribute key, or attribute value is invalid.
     * @throws {SDKError} [zh-CN] 错误码 `4`：成员属性数量或属性长度超过服务限制。 [en-US] Error code `4`: The number of member attributes or the attribute length exceeds the service limit.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败，或当前用户无权限设置成员属性。 [en-US] Error code `202`: Authentication failed, or the current user does not have permission to set member attributes.
     * @returns {Promise<void>} [zh-CN] 设置成功后无返回值。 [en-US] Resolves with no return value on success.
     */
    setMemberAttributes(input: GroupSetMemberAttributesInput): Promise<void>;
    /**
     * [zh-CN] 批量获取当前群组中多个成员的自定义属性。
     * [en-US] Retrieves custom attributes of multiple members in the current group in batch.
     *
     * @example [zh-CN] 批量获取成员属性。 [en-US] Retrieve custom attributes of multiple members.
     * ```ts
     * const result = await client.groupManager.getGroup('group-1').getMembersAttributes({
     *   userIds: ['user-1', 'user-2'],
     *   keys: ['groupNamecard'],
     * });
     * ```
     * @param input - [zh-CN] 成员用户 ID 列表，以及可选的属性 key 列表。 [en-US] The list of member user IDs and the optional list of attribute keys.
     * @throws {ValidationError} [zh-CN] 错误码 `110`：成员列表为空、成员用户 ID 不合法，或属性 key 不合法。 [en-US] Error code `110`: The member list is empty, a member user ID is invalid, or an attribute key is invalid.
     * @throws {AuthenticationError} [zh-CN] 错误码 `202`：鉴权失败。重新登录或刷新鉴权信息后重试。 [en-US] Error code `202`: Authentication failed. Log in again or refresh the authentication state, and then try again.
     * @returns {Promise<GroupMembersAttributesResult>} [zh-CN] 返回按成员用户 ID 索引的属性集合。 [en-US] Returns the attribute collection indexed by member user ID.
     */
    getMembersAttributes(input: GroupGetMembersAttributesInput): Promise<GroupMembersAttributesResult>;
    private toTarget;
    private toUserBatchParams;
}
