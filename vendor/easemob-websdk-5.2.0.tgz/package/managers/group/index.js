import{G as r,a as o}from"../../chunks/index-BxMCMoWN.js";export{r as Group,o as GroupManager};
