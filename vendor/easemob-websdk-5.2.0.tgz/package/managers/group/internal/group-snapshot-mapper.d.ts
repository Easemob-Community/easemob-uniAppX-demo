import type { GroupDetail, GroupSummary } from '../../../types/group';
import { InternalGroup } from './internal-group';
export declare class GroupSnapshotMapper {
    toSummary(group: InternalGroup): GroupSummary | null;
    toDetail(group: InternalGroup): GroupDetail | null;
}
