import type { GroupDetail, GroupSummary } from '../../../types/group';
export declare class InternalGroup {
    readonly groupId: string;
    private summarySnapshot;
    private detailSnapshot;
    private loadedSummary;
    private stale;
    private loadedDetail;
    private lastPatchedAt;
    private lastHydratedAt;
    constructor(groupId: string);
    mergeSummary(summary: GroupSummary): void;
    mergeDetail(detail: GroupDetail): void;
    markStale(): void;
    clear(): void;
    getSummarySnapshot(): GroupSummary | null;
    getDetailSnapshot(): GroupDetail | null;
    isStale(): boolean;
    hasLoadedSummary(): boolean;
    hasLoadedDetail(): boolean;
    getLastPatchedAt(): number | null;
    getLastHydratedAt(): number | null;
    private toSummaryFromDetail;
}
