import type { GroupDetail } from '../../../types/group';
import { GroupRepository } from './group-repository';
export interface GroupEventPatch {
    readonly groupId: string;
    readonly groupName?: string;
    readonly groupPatch?: Partial<GroupDetail>;
    readonly shouldMarkStale?: boolean;
}
export declare class GroupEventSync {
    private readonly repository;
    constructor(repository: GroupRepository);
    applyPatch(patch: GroupEventPatch): GroupDetail | null;
}
