import type { CacheManager } from '../../cache/cache-manager';
import type { UserInfo } from '../../types/user-info';
export interface GroupUserInfoFetchParams {
    readonly userIds: ReadonlyArray<string>;
}
export type GroupUserInfoFetcher = (params: GroupUserInfoFetchParams) => Promise<ReadonlyArray<UserInfo>>;
interface GroupUserInfoResolverOptions {
    readonly cacheManager: Pick<CacheManager, 'getUserInfoSummaries'> | null;
    readonly fetchUserInfos?: GroupUserInfoFetcher;
}
export declare const buildMinimalGroupUserInfo: (userId: string) => UserInfo;
export declare const mergeGroupUserInfo: (base: UserInfo | undefined, incoming: UserInfo | undefined, userId: string) => UserInfo;
export declare const resolveGroupUserInfoMap: (userIds: ReadonlyArray<string>, options: GroupUserInfoResolverOptions) => Promise<ReadonlyMap<string, UserInfo>>;
export declare const resolveGroupUserInfos: (userIds: ReadonlyArray<string>, options: GroupUserInfoResolverOptions) => Promise<ReadonlyArray<UserInfo>>;
export {};
