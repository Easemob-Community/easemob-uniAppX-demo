import type { GroupRawNotifyEvent } from '../../types/group';
export interface GroupMucJid {
    readonly name?: string;
    readonly clientResource?: string;
}
export interface GroupMucEventInput {
    readonly operation: number;
    readonly groupId: string;
    readonly groupName?: string;
    readonly from?: GroupMucJid;
    readonly to?: ReadonlyArray<GroupMucJid>;
    readonly reason?: string;
    readonly eventExt?: string;
    readonly ext?: string;
    readonly members?: ReadonlyArray<string>;
    readonly source?: 'direct' | 'multiDevice';
}
export declare const mapMucOperationToGroupEvent: (input: GroupMucEventInput) => GroupRawNotifyEvent | null;
