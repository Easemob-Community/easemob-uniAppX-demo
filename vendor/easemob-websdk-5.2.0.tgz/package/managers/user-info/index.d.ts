/**
 * 用户信息管理器导出
 */
export { UserInfoManager } from '../user-info-manager';
