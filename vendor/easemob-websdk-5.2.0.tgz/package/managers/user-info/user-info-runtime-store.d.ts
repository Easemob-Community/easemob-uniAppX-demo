import type { UserInfoSummary } from '../../cache/cache-types';
import type { UserInfo, UserInfoNotifyPatch } from '../../types/user-info';
export type UserInfoRuntimeSource = 'fetch' | 'update' | 'subscription_notify' | 'contact_notify' | 'own_notify';
export interface UserInfoRuntimeRecord {
    readonly profile: UserInfo;
    readonly lastModified: number;
    readonly lastAccess: number;
    readonly source: UserInfoRuntimeSource;
}
export interface UserInfoRuntimeUpsertRecord {
    readonly profile: UserInfo;
    readonly lastModified?: number;
    readonly source: UserInfoRuntimeSource;
}
export interface UserInfoRuntimeMergeResult {
    readonly applied: boolean;
    readonly reason: 'applied' | 'stale' | 'duplicate';
    readonly record: UserInfoRuntimeRecord;
}
export declare const buildUserInfoFromSummary: (summary: UserInfoSummary) => UserInfo;
export declare const projectUserInfoToSummary: (record: UserInfoRuntimeRecord) => UserInfoSummary;
export declare class UserInfoRuntimeStore {
    private readonly records;
    clear(): void;
    get(userId: string, updateAccess?: boolean, now?: number): UserInfoRuntimeRecord | null;
    setAll(records: ReadonlyArray<UserInfoRuntimeUpsertRecord>, now?: number): void;
    applyPatch(patch: UserInfoNotifyPatch, fallbackProfile?: Partial<UserInfo>, now?: number): UserInfoRuntimeMergeResult;
}
