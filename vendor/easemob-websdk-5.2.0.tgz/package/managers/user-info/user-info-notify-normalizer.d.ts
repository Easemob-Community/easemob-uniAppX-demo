import type { UserInfoNotifyPatch, UserInfoRawNotifyEvent } from '../../types/user-info';
export declare const normalizeUserInfoNotify: (event: UserInfoRawNotifyEvent) => UserInfoNotifyPatch | null;
