import{P as a}from"../../chunks/push-manager-BO3xq-7O.js";export{a as PushManager};
