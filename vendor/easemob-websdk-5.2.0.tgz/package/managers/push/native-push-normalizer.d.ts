import type { NativePushCertificates, NativePushChannel, NativePushPlugin, NativePushTokenResult, NativePushTypeCode, SetNativePushOptions } from '../../types/push';
export interface NormalizedNativePushConfig {
    readonly plugin: NativePushPlugin;
    readonly certificates: Readonly<NativePushCertificates>;
    readonly signature: string;
}
export interface NormalizedNativePushToken {
    readonly token: string;
    readonly channel: Exclude<NativePushChannel, 'normal'>;
    readonly notifierName: string;
}
export declare const nativePushChannelFromCode: (code: NativePushTypeCode) => NativePushChannel;
export declare const normalizeNativePushOptions: (options: SetNativePushOptions) => NormalizedNativePushConfig;
export declare const isNativePushTokenResult: (value: unknown) => value is NativePushTokenResult;
export declare const normalizeNativePushToken: (value: unknown, config: NormalizedNativePushConfig) => NormalizedNativePushToken | null;
