/**
 * [zh-CN] ContactManager 对外管理器实现，负责读取联系人快照、联系人关系写操作和黑名单管理。
 * [en-US] Public ContactManager implementation for reading contact snapshots, mutating contact relations, and managing blocklist APIs.
 */
import type { ChatClient } from '../chat-client';
import type { AddContactParams, BlocklistAddResult, BlocklistMutationParams, Contact, ContactEventHandlerMap, ContactMutationTarget, SetContactRemarkParams } from '../types';
import type { ManagerBase, ManagerEventContext } from '../types/manager';
import type { UserInfo } from '../types/user-info';
import { RosterSyncController } from '../core/contact-sync/roster-sync-controller';
import type { ContactSyncDependencies } from '../core/contact-sync/roster-sync-types';
export declare class ContactManager implements ManagerBase<ChatClient> {
    /** @internal SDK 内部管理器注册键，不对外文档暴露。 */
    static readonly key: "contactManager";
    private client;
    private eventContext;
    private restClient;
    private restBaseUrl;
    private restToken;
    private blocklistSnapshot;
    private blocklistSessionKey;
    /**
     * @internal
     * [zh-CN] 绑定 ContactManager 到 ChatClient，通常由 SDK 在 `client.contactManager` 初始化阶段调用。
     * [en-US] Binds ContactManager to ChatClient and is usually called internally during `client.contactManager` initialization.
     *
     * @param client - [zh-CN] 已初始化的 ChatClient 实例。 [en-US] Initialized ChatClient instance.
     * @param context - [zh-CN] 联系人事件上下文，用于注册与移除联系人同步事件处理器。 [en-US] Contact event context used to register and remove contact sync handlers.
     * @returns {void} [zh-CN] 无返回值。 [en-US] Returns nothing.
     */
    bind(client: ChatClient, context?: ManagerEventContext): void;
    /**
     * [zh-CN] 获取当前内存中的联系人列表视图。
     * [en-US] Gets the current in-memory contact list view.
     *
     * @example [zh-CN] 调用示例（读取联系人列表） [en-US] Usage example (read contact list)
     * ```ts
     * const contacts = client.contactManager.getContacts();
     * console.log(contacts[0]?.userId);
     * ```
     *
     * @returns {ReadonlyArray<Contact>} [zh-CN] 返回当前联系人列表；若暂无可用数据则返回空数组。 [en-US] Returns the current contact list, or an empty array when no usable data is available.
     */
    getContacts(): ReadonlyArray<Contact>;
    /**
     * [zh-CN] 发送联系人申请。
     * [en-US] Sends a contact invitation.
     *
     * @example [zh-CN] 调用示例（发送联系人申请） [en-US] Usage example (send a contact invitation)
     * ```ts
     * await client.contactManager.addContact({
     *   userId: 'user-1',
     *   message: '我是 Alice',
     * });
     * ```
     *
     * @param params - [zh-CN] 目标用户与可选验证消息。 [en-US] Target user and optional invitation message.
     * @returns {Promise<void>} [zh-CN] 成功时仅表示请求完成。 [en-US] Resolves on success with no business payload.
     */
    addContact(params: AddContactParams): Promise<void>;
    /**
     * [zh-CN] 删除联系人，并立即修补当前会话中的联系人快照。
     * [en-US] Deletes a contact and immediately patches the in-session contact snapshot.
     *
     * @example [zh-CN] 调用示例（删除联系人） [en-US] Usage example (delete a contact)
     * ```ts
     * await client.contactManager.deleteContact({
     *   userId: 'user-1',
     * });
     * ```
     *
     * @param params - [zh-CN] 目标用户。 [en-US] Target user.
     * @returns {Promise<void>} [zh-CN] 成功时仅表示请求完成。 [en-US] Resolves on success with no business payload.
     */
    deleteContact(params: ContactMutationTarget): Promise<void>;
    /**
     * [zh-CN] 接受联系人申请，并触发受控联系人刷新。
     * [en-US] Accepts a contact invitation and triggers a controlled contact refresh.
     *
     * @example [zh-CN] 调用示例（接受联系人申请） [en-US] Usage example (accept a contact invitation)
     * ```ts
     * await client.contactManager.acceptContactInvite({
     *   userId: 'user-1',
     * });
     * ```
     *
     * @param params - [zh-CN] 目标用户。 [en-US] Target user.
     * @returns {Promise<void>} [zh-CN] 成功时仅表示请求完成。 [en-US] Resolves on success with no business payload.
     */
    acceptContactInvite(params: ContactMutationTarget): Promise<void>;
    /**
     * [zh-CN] 拒绝联系人申请。
     * [en-US] Declines a contact invitation.
     *
     * @example [zh-CN] 调用示例（拒绝联系人申请） [en-US] Usage example (decline a contact invitation)
     * ```ts
     * await client.contactManager.declineContactInvite({
     *   userId: 'user-1',
     * });
     * ```
     *
     * @param params - [zh-CN] 目标用户。 [en-US] Target user.
     * @returns {Promise<void>} [zh-CN] 成功时仅表示请求完成。 [en-US] Resolves on success with no business payload.
     */
    declineContactInvite(params: ContactMutationTarget): Promise<void>;
    /**
     * [zh-CN] 设置联系人备注，允许传入空字符串以清空备注；设置成功后会同步刷新已有单聊会话的显示名称。
     * [en-US] Sets a contact remark. An empty string clears the remark; after success, the display name of an existing one-to-one conversation is refreshed immediately.
     *
     * @example [zh-CN] 调用示例（设置联系人备注） [en-US] Usage example (set a contact remark)
     * ```ts
     * await client.contactManager.setContactRemark({
     *   userId: 'user-1',
     *   remark: '产品同学',
     * });
     * ```
     *
     * @param params - [zh-CN] 目标用户与备注内容。 [en-US] Target user and remark content.
     * @returns {Promise<void>} [zh-CN] 成功时无业务返回值；若本地存在对应单聊会话，会同步更新其显示名称并派发会话列表更新事件。 [en-US] Resolves with no business payload; if a matching local one-to-one conversation exists, its display name is updated and a conversation-list update event is emitted.
     */
    setContactRemark(params: SetContactRemarkParams): Promise<void>;
    /**
     * [zh-CN] 获取当前用户的黑名单列表。
     * [en-US] Gets the current user's blocklist.
     *
     * @example [zh-CN] 调用示例（获取黑名单） [en-US] Usage example (get blocklist)
     * ```ts
     * const blocklist = await client.contactManager.getBlocklist();
     * console.log(blocklist.map(item => item.userId));
     * ```
     *
     * @returns {Promise<ReadonlyArray<UserInfo>>} [zh-CN] 返回黑名单用户资料列表。 [en-US] Returns blocked user profiles.
     */
    getBlocklist(): Promise<ReadonlyArray<UserInfo>>;
    /**
     * [zh-CN] 批量添加黑名单用户，重复值会在请求前去重并保持原始顺序。
     * [en-US] Adds users to the blocklist. Duplicate values are deduplicated before request while preserving input order.
     *
     * @example [zh-CN] 调用示例（添加黑名单） [en-US] Usage example (add users to blocklist)
     * ```ts
     * const result = await client.contactManager.addUsersToBlocklist({
     *   userIds: ['user-1', 'user-2'],
     * });
     * ```
     *
     * @param params - [zh-CN] 待加入黑名单的用户 ID 列表。 [en-US] User ids to add to the blocklist.
     * @returns {Promise<BlocklistAddResult>} [zh-CN] 返回成功与失败两类用户资料列表。 [en-US] Returns succeeded and failed user profile lists.
     */
    addUsersToBlocklist(params: BlocklistMutationParams): Promise<BlocklistAddResult>;
    /**
     * [zh-CN] 批量移除黑名单用户，重复值会在请求前去重并保持原始顺序。
     * [en-US] Removes users from the blocklist. Duplicate values are deduplicated before request while preserving input order.
     *
     * @example [zh-CN] 调用示例（移除黑名单） [en-US] Usage example (remove users from blocklist)
     * ```ts
     * await client.contactManager.removeUserFromBlocklist({
     *   userIds: ['user-1'],
     * });
     * ```
     *
     * @param params - [zh-CN] 待移除的黑名单用户 ID 列表。 [en-US] User ids to remove from the blocklist.
     * @returns {Promise<void>} [zh-CN] 成功时仅表示请求完成。 [en-US] Resolves on success with no business payload.
     */
    removeUserFromBlocklist(params: BlocklistMutationParams): Promise<void>;
    /**
     * [zh-CN] 注册联系人事件处理器，用于接收联系人关系事件；自动同步进度请在 ChatClient 级监听统一同步事件。
     * [en-US] Registers contact event handlers for contact relation events. Observe automatic sync progress through ChatClient-level unified sync events.
     *
     * @example [zh-CN] 调用示例（监听联系人添加事件） [en-US] Usage example (listen for contact added events)
     * ```ts
     * client.contactManager.addEventHandler('contact-ui', {
     *   onContactAdded: event => {
     *     console.log(event.from);
     *   },
     * });
     * ```
     *
     * @param id - [zh-CN] 事件处理器唯一 ID，用于后续移除。 [en-US] Unique handler id used for later removal.
     * @param handlers - [zh-CN] 联系人事件处理器集合，按需实现对应回调。 [en-US] Contact handler collection with callbacks implemented as needed.
     * @returns {void} [zh-CN] 注册完成后无返回值。 [en-US] Returns nothing after registration.
     */
    addEventHandler(id: string, handlers: ContactEventHandlerMap): void;
    /**
     * [zh-CN] 移除已注册的联系人同步事件处理器。
     * [en-US] Removes a previously registered contact sync event handler.
     *
     * @example [zh-CN] 调用示例（移除联系人事件处理器） [en-US] Usage example (remove a contact event handler)
     * ```ts
     * client.contactManager.removeEventHandler('contact-ui');
     * ```
     *
     * @param id - [zh-CN] 待移除的事件处理器 ID。 [en-US] Handler id to remove.
     * @returns {void} [zh-CN] 移除完成后无返回值。 [en-US] Returns nothing after removal.
     */
    removeEventHandler(id: string): void;
    private runOperation;
    private normalizeSdkError;
    private requireClient;
    private getRestContextOrThrow;
    private getRestClient;
    private ensureBlocklistSession;
    private patchBlocklistSnapshotWithAdditions;
    private patchBlocklistSnapshotWithRemovals;
    private validateUserId;
    private validateOptionalString;
    private validateRemark;
    private buildValidationError;
    private enrichBlocklistUsers;
    private fetchUserInfos;
    private fetchUserInfosFromRest;
    private getUserInfoManager;
    private hasUserInfoCapabilityProvider;
    private hasUserInfoReadCapability;
    /** @internal */
    createSyncController(deps: ContactSyncDependencies): RosterSyncController;
}
