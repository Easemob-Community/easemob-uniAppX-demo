import type { ChatClient } from '../chat-client';
import type { ChatThreadDetail, ChatThreadEventHandlerMap, ChatThreadMutationTarget, ChatThreadListResult, ChatThreadLastMessageListResult, ChatThreadMemberListResult, CreateChatThreadParams, CreateChatThreadResult, GetChatThreadInfoParams, GetChatThreadLastMessageListParams, GetChatThreadListParams, GetChatThreadMemberListParams, GetJoinedChatThreadListParams, RemoveChatThreadMemberParams, UpdateChatThreadNameParams } from '../types/chat-thread';
import type { EventHandlerId } from '../types/event-system';
import type { ManagerBase, ManagerEventContext, RawNotifyEvent } from '../types/manager';
import { ChatThread } from './chat-thread/chat-thread';
/**
 * [zh-CN] 消息话题管理器，负责消息话题创建、查询、成员管理、生命周期操作和事件监听。
 * [en-US] Manager for message thread creation, queries, member management, lifecycle operations, and event listening.
 */
export declare class ChatThreadManager implements ManagerBase<ChatClient> {
    static readonly key: "chatThreadManager";
    readonly capabilities: readonly ["rawNotify:chatThread"];
    private client;
    private eventContext;
    private restClient;
    private restBaseUrl;
    private restToken;
    private readonly registry;
    /** @internal SDK 管理器注册流程使用，不作为公开 API。 */
    bind(client: ChatClient, context?: ManagerEventContext): void;
    /**
     * [zh-CN] 注册 ChatThread 事件处理器。
     * [en-US] Registers ChatThread event handlers.
     *
     * @example [zh-CN] 调用示例（监听消息话题创建） [en-US] Usage example (listen for thread creation)
     * ```ts
     * client.chatThreadManager.addEventHandler('thread-ui', {
     *   onChatThreadCreated: event => {
     *     console.log(event.chatThreadId);
     *   },
     * });
     * ```
     *
     * @param id - [zh-CN] 事件处理器 ID。使用相同 ID 重复注册时，会覆盖此前的处理器。 [en-US] Event handler ID; using the same ID replaces the previous handler.
     * @param handlers - [zh-CN] 消息话题事件处理器映射。 [en-US] Chat thread event handler map.
     * @returns {void} [zh-CN] 无返回值。 [en-US] No return value.
     */
    addEventHandler(id: EventHandlerId, handlers: ChatThreadEventHandlerMap): void;
    /**
     * [zh-CN] 移除指定的消息话题事件处理器。
     * [en-US] Removes a message thread event handler by ID.
     *
     * @example [zh-CN] 调用示例（取消监听） [en-US] Usage example (remove listener)
     * ```ts
     * client.chatThreadManager.removeEventHandler('thread-ui');
     * ```
     *
     * @param id - [zh-CN] 要移除的事件处理器 ID。 [en-US] ID of the event handler to remove.
     * @returns {void} [zh-CN] 无返回值。 [en-US] No return value.
     */
    removeEventHandler(id: EventHandlerId): void;
    /**
     * @internal
     * [zh-CN] 处理 MSync Thread 原始通知并归一为公开 Thread 事件。
     * [en-US] Handles raw MSync thread notifications and normalizes them into public thread events.
     *
     * @param event - [zh-CN] 内部原始通知事件。 [en-US] Internal raw notify event.
     * @returns {void} [zh-CN] 无返回值。 [en-US] Returns nothing.
     */
    handleRawNotify(event: RawNotifyEvent): void;
    /**
     * [zh-CN] 获取绑定指定 `chatThreadId` 的 ChatThread 实体对象。
     * [en-US] Retrieves the ChatThread entity object bound to the specified `chatThreadId`.
     *
     * @example [zh-CN] 调用示例（获取实体对象） [en-US] Usage example (get the entity object)
     * ```ts
     * const thread = client.chatThreadManager.getChatThread('thread-1');
     * const detail = await thread.getInfo();
     * ```
     *
     * @param chatThreadId - [zh-CN] 消息话题 ID。 [en-US] Chat thread ID.
     * @returns {ChatThread} [zh-CN] 返回可复用的 ChatThread 实体对象。 [en-US] Returns a reusable ChatThread entity object.
     */
    getChatThread(chatThreadId: string): ChatThread;
    /**
     * [zh-CN] 创建消息话题。
     * [en-US] Creates a message thread.
     *
     * @example [zh-CN] 调用示例（创建消息话题） [en-US] Usage example (create a thread)
     * ```ts
     * const result = await client.chatThreadManager.createChatThread({
     *   parentId: 'group-1',
     *   name: 'Topic',
     *   messageId: 'msg-1',
     * });
     * ```
     *
     * @param params - [zh-CN] 创建参数，包含父群组 ID、消息话题名称和父消息 ID。 [en-US] Creation parameters including parent group ID, thread name, and parent message ID.
     * @operation createChatThread
     * @returns {Promise<CreateChatThreadResult>} [zh-CN] 返回新建消息话题 ID。 [en-US] Returns the created message thread ID.
     */
    createChatThread(params: CreateChatThreadParams): Promise<CreateChatThreadResult>;
    /**
     * [zh-CN] 查询指定群组下的消息话题列表。
     * [en-US] Lists message threads under a parent group.
     *
     * @example [zh-CN] 调用示例（查询群内消息话题） [en-US] Usage example (list group threads)
     * ```ts
     * const page = await client.chatThreadManager.getChatThreadList({
     *   parentId: 'group-1',
     *   pageSize: 20,
     * });
     * ```
     *
     * @param params - [zh-CN] 查询参数，包含父群组 ID、分页大小和游标。 [en-US] Query parameters including parent group ID, page size, and cursor.
     * @operation getChatThreadList
     * @returns {Promise<ChatThreadListResult>} [zh-CN] 返回消息话题列表和下一页游标。 [en-US] Returns message threads and the next cursor.
     */
    getChatThreadList(params: GetChatThreadListParams): Promise<ChatThreadListResult>;
    /**
     * [zh-CN] 查询当前用户已加入的消息话题列表。
     * [en-US] Lists message threads joined by the current user.
     *
     * @example [zh-CN] 调用示例（查询已加入消息话题） [en-US] Usage example (list joined threads)
     * ```ts
     * const page = await client.chatThreadManager.getJoinedChatThreadList({
     *   parentId: 'group-1',
     * });
     * ```
     *
     * @param params - [zh-CN] 查询参数；`parentId` 可选。 [en-US] Query parameters; `parentId` is optional.
     * @operation getJoinedChatThreadList
     * @returns {Promise<ChatThreadListResult>} [zh-CN] 返回已加入消息话题列表和下一页游标。 [en-US] Returns joined message threads and the next cursor.
     */
    getJoinedChatThreadList(params?: GetJoinedChatThreadListParams): Promise<ChatThreadListResult>;
    /**
     * [zh-CN] 查询消息话题详情。
     * [en-US] Retrieves message thread details.
     *
     * @example [zh-CN] 调用示例（查询详情） [en-US] Usage example (get details)
     * ```ts
     * const detail = await client.chatThreadManager.getChatThreadInfo({
     *   chatThreadId: 'thread-1',s
     * });
     * ```
     *
     * @param params - [zh-CN] 查询参数，包含消息话题 ID。 [en-US] Query parameters including the message thread ID.
     * @operation getChatThreadInfo
     * @returns {Promise<ChatThreadDetail>} [zh-CN] 返回消息话题详情。 [en-US] Returns message thread details.
     */
    getChatThreadInfo(params: GetChatThreadInfoParams): Promise<ChatThreadDetail>;
    /**
     * [zh-CN] 加入消息话题。
     * [en-US] Joins a message thread.
     *
     * @example [zh-CN] 调用示例（加入消息话题） [en-US] Usage example (join a thread)
     * ```ts
     * await client.chatThreadManager.joinChatThread({ chatThreadId: 'thread-1' });
     * ```
     *
     * @param params - [zh-CN] 操作目标，包含消息话题 ID。 [en-US] Operation target including the message thread ID.
     * @operation joinChatThread
     * @returns {Promise<void>} [zh-CN] 成功时无返回业务数据。 [en-US] Resolves with no business data on success.
     */
    joinChatThread(params: ChatThreadMutationTarget): Promise<void>;
    /**
     * [zh-CN] 退出消息话题。
     * [en-US] Leaves a message thread.
     *
     * @example [zh-CN] 调用示例（退出消息话题） [en-US] Usage example (leave thread)
     * ```ts
     * await client.chatThreadManager.leaveChatThread({ chatThreadId: 'thread-1' });
     * ```
     *
     * @param params - [zh-CN] 操作目标，包含消息话题 ID。 [en-US] Operation target including the message thread ID.
     * @operation leaveChatThread
     * @returns {Promise<void>} [zh-CN] 成功时无返回业务数据。 [en-US] Resolves with no business data on success.
     */
    leaveChatThread(params: ChatThreadMutationTarget): Promise<void>;
    /**
     * [zh-CN] 解散消息话题。
     * [en-US] Destroys a message thread.
     *
     * @example [zh-CN] 调用示例（解散消息话题） [en-US] Usage example (destroy thread)
     * ```ts
     * await client.chatThreadManager.destroyChatThread({ chatThreadId: 'thread-1' });
     * ```
     *
     * @param params - [zh-CN] 操作目标，包含消息话题 ID。 [en-US] Operation target including the message thread ID.
     * @operation destroyChatThread
     * @returns {Promise<void>} [zh-CN] 成功时无返回业务数据。 [en-US] Resolves with no business data on success.
     */
    destroyChatThread(params: ChatThreadMutationTarget): Promise<void>;
    /**
     * [zh-CN] 更新消息话题名称。
     * [en-US] Updates a message thread name.
     *
     * @example [zh-CN] 调用示例（更新名称） [en-US] Usage example (update name)
     * ```ts
     * await client.chatThreadManager.updateChatThreadName({
     *   chatThreadId: 'thread-1',
     *   name: 'New topic',
     * });
     * ```
     *
     * @param params - [zh-CN] 更新参数，包含消息话题 ID 和新名称。 [en-US] Update parameters including the message thread ID and new name.
     * @operation updateChatThreadName
     * @returns {Promise<void>} [zh-CN] 成功时无返回业务数据。 [en-US] Resolves with no business data on success.
     */
    updateChatThreadName(params: UpdateChatThreadNameParams): Promise<void>;
    /**
     * [zh-CN] 查询消息话题成员列表。
     * [en-US] Lists message thread members.
     *
     * @example [zh-CN] 调用示例（查询成员） [en-US] Usage example (list members)
     * ```ts
     * const page = await client.chatThreadManager.getChatThreadMemberList({
     *   chatThreadId: 'thread-1',
     *   pageSize: 20,
     * });
     * ```
     *
     * @param params - [zh-CN] 查询参数，包含消息话题 ID、分页大小和游标。 [en-US] Query parameters including message thread ID, page size, and cursor.
     * @operation getChatThreadMemberList
     * @returns {Promise<ChatThreadMemberListResult>} [zh-CN] 返回成员列表和下一页游标。 [en-US] Returns members and the next cursor.
     */
    getChatThreadMemberList(params: GetChatThreadMemberListParams): Promise<ChatThreadMemberListResult>;
    /**
     * [zh-CN] 从消息话题移除成员。
     * [en-US] Removes a member from a message thread.
     *
     * @example [zh-CN] 调用示例（移除成员） [en-US] Usage example (remove member)
     * ```ts
     * await client.chatThreadManager.removeChatThreadMember({
     *   chatThreadId: 'thread-1',
     *   memberId: 'user-1',
     * });
     * ```
     *
     * @param params - [zh-CN] 移除参数，包含消息话题 ID 和成员 ID。 [en-US] Removal parameters including message thread ID and member ID.
     * @operation removeChatThreadMember
     * @returns {Promise<void>} [zh-CN] 成功时无返回业务数据。 [en-US] Resolves with no business data on success.
     */
    removeChatThreadMember(params: RemoveChatThreadMemberParams): Promise<void>;
    /**
     * [zh-CN] 批量查询消息话题最后一条消息。
     * [en-US] Gets the last messages of message threads in batch.
     *
     * @example [zh-CN] 调用示例（查询最后消息） [en-US] Usage example (get last messages)
     * ```ts
     * const result = await client.chatThreadManager.getChatThreadLastMessageList({
     *   chatThreadIds: ['thread-1', 'thread-2'],
     * });
     * ```
     *
     * @param params - [zh-CN] 查询参数，包含最多 20 个消息话题 ID。 [en-US] Query parameters including up to 20 message thread IDs.
     * @operation getChatThreadLastMessageList
     * @returns {Promise<ChatThreadLastMessageListResult>} [zh-CN] 返回各消息话题的最后一条消息摘要。 [en-US] Returns the last message snippet for each message thread.
     */
    getChatThreadLastMessageList(params: GetChatThreadLastMessageListParams): Promise<ChatThreadLastMessageListResult>;
    private getClientOrThrow;
    private getRestContextOrThrow;
    private getEventContextOrThrow;
    private getRestClient;
    private runOperation;
    private buildChatThreadPublicEvent;
    private tryBuildThreadMessageSnippet;
}
