import{C as a}from"../../chunks/chat-manager-BB7wYWYG.js";export{a as ChatManager};
