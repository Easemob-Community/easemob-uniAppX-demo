/**
 * [zh-CN] ChatClient 实现。
 * [en-US] ChatClient implementation.
 */
import { CacheManager } from './cache';
import { SharedSyncWebSocketSession } from './core/sync/shared-sync-websocket-session';
import type { RequestAdapter, UploadAdapter } from './platform';
import type { AuthContext, ConnectionState, GetRTCTokenInfoParams, InitConfig, LoginOptions, RestContext, SelfIdsOnOtherPlatform, RTCTokenInfo, RTCUidUserIdMap, ServerUrlsConfig, TokenRenewalResult } from './types/chat-client';
import type { EventHandlerMap, EventHandlerId } from './types/event-system';
import type { ConversationListUpdateReason } from './cache/cache-types';
import type { ConversationItem, ConversationType } from './types/conversation';
import type { ContactSnapshot } from './types/contact';
import type { SyncDataFinishedPayload, SyncDataType } from './types/sync-data';
import type { ManagerBase, ManagerCapability, ManagerConstructor, ManagerRegistration, WithManager, WithManagers } from './types/manager';
import type { // 连接事件载荷
DownloadCombineMessageParams, // 下载并解析合并消息详情入参
MessageAttachmentDownloadResult, Message, // 消息类型
SendMessageOptions } from './types';
import type { MessageActionRequest, ActionAckResult } from './core/message/message-action-types';
import type { ChatRoomOperationRequest } from './core/message/chatroom-operation-types';
import type { UserInfo } from './types/user-info';
import type { RefreshSessionListParams } from './types/conversation';
/**
 * [zh-CN] ChatClient 是 SDK 的主入口，负责连接生命周期管理、消息发送、事件分发、缓存访问和管理器注册。
 * [en-US] ChatClient is the main entry point for the SDK, responsible for connection lifecycle management, message sending, event dispatch, cache access, and manager registration.
 */
export declare class ChatClient {
    private static instance;
    private config;
    private core;
    private cacheManager;
    private cacheUserId;
    private state;
    private loginAttempt;
    private eventHub;
    private currentUserId;
    private activeAppKey;
    private logReportEnabled;
    private readonly managerRegistry;
    private readonly managerCapabilities;
    private readonly managerEventContext;
    private restBaseUrl;
    private authToken;
    private clientResource;
    private platformAdapter;
    private contactSyncController;
    private groupSyncController;
    private syncConversationListConfigController;
    private syncWebSocketSession;
    private contactSyncWsUrls;
    private syncConversationListConfigWsUrls;
    private contactSyncDnsResolved;
    private readonly userInfoHydrationQueue;
    private readonly groupNamecardHydrationQueue;
    private conversationListVersion;
    private conversationListSnapshot;
    private readonly activeIncomingStreamMessageIds;
    private managerSessionGeneration;
    private activeManagerSessionContext;
    private managerSessionEndingPromise;
    private postLoginTaskContext;
    private terminalSessionCleanupTask;
    private constructor();
    /**
     * [zh-CN] 初始化 ChatClient 单例。首次调用时创建实例；后续若使用相同配置调用，将复用该实例，并支持追加注册管理器。
     * [en-US] Initializes the ChatClient singleton. The first call creates the instance. Subsequent calls with the same configuration will reuse the existing instance and allow registering additional managers.
     *
     * @example [zh-CN] 初始化并注册管理器 [en-US] Initialize and register managers.
     * ```ts
     * const client = ChatClient.init({
     *   appKey: 'org#app',
     *   managers: [ChatManager, GroupManager],
     * });
     * ```
     * @example [zh-CN] 使用 App ID 初始化；登录时 SDK 会通过 DNSConfig 解析对应的 App Key。 [en-US] Initialize with an App ID; the SDK resolves its App Key through DNSConfig during login.
     * ```ts
     * const client = ChatClient.init({ appId: 'application-id' });
     * await client.login({ userId: 'user-id', token: 'token' });
     * ```
     * @param config - [zh-CN] 初始化配置，必须且只能包含 App Key 或 App ID 之一，并可包含服务接入参数与管理器列表。 [en-US] Initialization options containing exactly one of App Key or App ID, plus optional service access parameters and managers.
     * @returns {WithManagers<ChatClient, Managers>} [zh-CN] 返回带已注册管理器类型增强的 ChatClient 实例。 [en-US] Returns the ChatClient instance enhanced with with the types of the registered managers.
     */
    static init<Managers extends ReadonlyArray<ManagerRegistration<ChatClient>> = []>(config: InitConfig & {
        managers?: Managers;
    }): WithManagers<ChatClient, Managers>;
    /**
     * [zh-CN] 登录并建立到消息服务的长连接。Promise resolve 时必要登录态与本地缓存已就绪；会话、好友、群组和用户资料等网络同步随后在后台执行，不属于登录 Promise 的完成条件。
     * [en-US] Logs in and establishes a persistent connection to the messaging service. When the Promise resolves, the required login state and local cache are ready. Network synchronization for conversations, contacts, groups, and user profiles continues in the background and is not part of the login Promise completion condition.
     *
     * @example [zh-CN] 登录 SDK [en-US] Log in to the SDK.
     * ```ts
     * await client.login({
     *   userId: 'alice',
     *   token: 'your-im-token',
     * });
     *
     * await client.login(
     *   { userId: 'alice', token: 'your-im-token' },
     *   { timeoutMs: 30000 }
     * );
     * ```
     *
     * @param params - [zh-CN] 登录参数，包含用户 ID 和 Token。 [en-US] Login parameters, including the user ID and token.
     * @param options - [zh-CN] 单次首次登录选项；`timeoutMs` 为覆盖服务发现、建连、重试和 Provision 响应到达前的总预算，默认 30000ms，范围 5000～120000ms。 [en-US] Options for this initial login. `timeoutMs` is the total budget covering service discovery, connection, retries, and the wait until a Provision response arrives. It defaults to 30000ms and accepts 5000–120000ms.
     * @returns {Promise<void>} [zh-CN] 长连接建立且必要登录态提交完成时 resolve；不等待登录后网络同步。请通过 `onSyncDataFinished` / `onConversationListUpdate` 观察后台同步，或显式调用对应刷新接口并等待其 Promise。 [en-US] Resolves after the persistent connection is established and the required login state is committed. It does not wait for post-login network synchronization. Observe background synchronization through `onSyncDataFinished` / `onConversationListUpdate`, or explicitly call and await the corresponding refresh API.
     */
    login(params: AuthContext, options?: LoginOptions): Promise<void>;
    private startPostLoginTasks;
    private cancelPostLoginTasks;
    private isPostLoginTaskActive;
    private runPostLoginTasks;
    private runPostLoginTask;
    /**
     * [zh-CN] 登出并关闭当前连接，同时清理登录态、运行时缓存引用与日志上报状态。
     * [en-US] Logs out and disconnects the current connection, while clearing the login state, runtime cache references, and log reporting status.
     *
     * @example [zh-CN] 登出 SDK [en-US] Log out of the SDK.
     * ```ts
     * await client.logout();
     * ```
     * @returns {Promise<void>} [zh-CN] 登出成功时 resolve；该 Promise 不携带任何返回值。 [en-US] Resolves when the logout succeeds. This Promise carries no return value.
     */
    logout(): Promise<void>;
    /**
     * [zh-CN] 获取当前连接状态。
     * [en-US] Gets the current connection state.
     *
     * @example [zh-CN] 读取连接状态。 [en-US] Read the connection state.
     * ```ts
     * const state = client.getConnectionState();
     * ```
     * @returns {ConnectionState} [zh-CN] 返回当前连接状态枚举值。 [en-US] Returns the enum value of the current connection state.
     */
    getConnectionState(): ConnectionState;
    /**
     * [zh-CN] 获取 SDK 版本号。
     * [en-US] Returns the SDK version.
     *
     * @example
     * ```ts
     * const version = client.getVersion();
     * ```
     * @returns {string} [zh-CN] SDK 版本号。 [en-US] The SDK version.
     */
    getVersion(): string;
    /**
     * [zh-CN] 获取当前登录用户 ID。
     * [en-US] Gets the current logged-in user ID.
     *
     * @example [zh-CN] 读取当前登录用户 [en-US] Read the current logged-in user.
     * ```ts
     * const userId = client.getCurrentUserId();
     * ```
     * @returns {string | null} [zh-CN] 返回当前登录用户 ID；未登录时返回 `null`。 [en-US] Returns the current logged-in user ID, or `null` when the user is not logged in.
     */
    getCurrentUserId(): string | null;
    /**
     * [zh-CN] 获取当前连接的设备资源标识。
     * [en-US] Gets the resource identifier of the currently connected device.
     *
     * @example [zh-CN] 读取当前设备资源标识 [en-US] Read the resource identifier of the currently connected device.
     * ```ts
     * const clientResource = client.getClientResource();
     * ```
     * @returns {string | null} [zh-CN] 返回当前连接的设备资源标识；若未连接或尚未完成登录握手，则返回 `null`。 [en-US] Returns the resource identifier of the currently connected device, or `null` if the SDK is disconnected or the login handshake is incomplete.
     */
    getClientResource(): string | null;
    /**
     * @internal
     * [zh-CN] 提供消息创建包装层需要的内部配置。
     * [en-US] Provides the internal configuration required by the message creation wrapper layer.
     */
    getMessageCreationOptions(): {
        readonly useCustomAttachmentUpload: boolean;
    };
    /**
     * @internal
     * [zh-CN] 获取当前登录会话的 REST 访问上下文，供 SDK Manager 内部复用统一鉴权与地址信息。
     * [en-US] Gets the REST access context for the current login session so SDK managers can internally reuse authentication and routing information.
     *
     * @example [zh-CN] 读取 REST 上下文。 [en-US] Read the  REST context.
     * ```ts
     * const context = client.getRestContext();
     * ```
     * @returns {RestContext} [zh-CN] 返回当前登录会话对应的 REST 上下文。 [en-US] Returns the REST context of the current logged-in session.
     */
    getRestContext(): RestContext;
    /**
     * [zh-CN] 更新当前登录会话的 IM token，并重置 token 生命周期提醒。
     * [en-US] Updates the IM token for the current login session and resets the token lifecycle alerts.
     *
     * @example [zh-CN] 续期 IM 登录 Token [en-US] Renew the login token.
     * ```ts
     * const result = await client.renewToken(newToken);
     * ```
     * @param token - [zh-CN] 新的 IM Token。该参数必传。 [en-US] The new token. This parameter is required.
     * @returns {Promise<TokenRenewalResult>} [zh-CN] 返回已应用的新 Token 和过期时间。 [en-US] Returns the newly applied token and its expiration time.
     */
    renewToken(token: string): Promise<TokenRenewalResult>;
    /**
     * [zh-CN] 获取当前用户的 RTC token 信息。
     * [en-US] Gets RTC token of the current user.
     *
     * @example [zh-CN] 查询 RTC token [en-US] Query the RTC token.
     * ```ts
     * const rtc = await client.getRTCTokenInfo({ channelName: 'demo' });
     * ```
     * @param params - [zh-CN] RTC Token 查询参数。可选。若传入 channelName，则返回该特定频道的 Token。 [en-US] RTC token query parameters. This parameter is optional. If `channelName` is provided, the SDK returns the token of the specific channel.
     * @returns {Promise<RTCTokenInfo>} [zh-CN] 返回 RTC App ID、Token、频道名、UID 和过期时间。 [en-US] Returns the app ID, token, channel name, UID, and expiration time of RTC.
     */
    getRTCTokenInfo(params?: GetRTCTokenInfoParams): Promise<RTCTokenInfo>;
    /**
     * [zh-CN] 批量查询映射到 RTC UID 的 IM 用户 ID。
     * [en-US] Batch queries Chat user IDs mapped to RTC UIDs.
     *
     * @example [zh-CN] 查询 RTC UID 映射 [en-US] Query Chat user IDs mapped to RTC UIDs.
     * ```ts
     * const users = await client.getUserIdsWithRTCUids([123456]);
     * ```
     * @param rtcUids - [zh-CN] RTC UID 列表。该参数必传，列表中的元素必须为合法数字。 [en-US] An array of RTC UIDs, where all elements must be valid numbers. This parameter is required.
     * @returns {Promise<RTCUidUserIdMap>} [zh-CN] 返回 RTC UID 到 IM user ID 的映射；未命中的 UID 不会出现在结果中。 [en-US] Returns the mapping from RTC UIDs to IM user IDs. Unmatched UIDs are omitted.
     */
    getUserIdsWithRTCUids(rtcUids: ReadonlyArray<number>): Promise<RTCUidUserIdMap>;
    /**
     * [zh-CN] 获取当前用户在其他已登录设备上的登录 ID 列表。登录 ID 由 user ID + "/" + resource (设备的识别号)组成。
     * [en-US] Gets the list of login IDs of other devices where the current user is logged in. The login ID is in the format of "user ID + "/" + resource (device ID)".
     *
     * @example [zh-CN] 查询其他平台登录 ID [en-US] Query the login IDs of devices on other platforms where the current account is logged in.
     * ```ts
     * const ids = await client.getSelfIdsOnOtherPlatform();
     * ```
     * @returns {Promise<SelfIdsOnOtherPlatform>} [zh-CN] 返回当前用户在其他设备上的 `userId/resource` 列表；当前设备会被自动过滤。 [en-US] Returns an array of `userId/resource` strings from other logged-in devices, automatically excluding the current device.
     */
    getSelfIdsOnOtherPlatform(): Promise<SelfIdsOnOtherPlatform>;
    /**
     * @internal
     * [zh-CN] 获取当前登录会话绑定的缓存管理器实例，供 SDK 内部缓存与同步链路使用。
     * [en-US] Gets the cache manager bound to the current login session for internal cache and synchronization flows.
     *
     * @example [zh-CN] 读取缓存管理器 [en-US] Read cache manager.
     * ```ts
     * const cacheManager = client.getCacheManager();
     * ```
     * @returns {CacheManager | null} [zh-CN] 返回缓存管理器；未登录或缓存未初始化时返回 `null`。 [en-US] Returns the cache manager, or `null` when the user is not logged in or the cache is not initialized.
     */
    getCacheManager(): CacheManager | null;
    /**
     * @internal
     * [zh-CN] 按能力查询已注册 Manager。该方法仅返回显式注册的能力，不会隐式创建管理器。
     * [en-US] Gets a registered manager by capability. This method only returns explicitly registered capabilities and will not implicitly create any managers.
     */
    getManagerByCapability(capability: ManagerCapability): ManagerBase<ChatClient> | undefined;
    /**
     * @internal
     * [zh-CN] 获取当前平台适配层暴露的上传适配器，供 SDK 内部附件与共享文件上传链路使用。
     * [en-US] Gets the upload adapter exposed by the current platform adapter for internal attachment and shared-file upload flows.
     *
     * @example [zh-CN] 读取上传适配器 [en-US] Read the upload adapter.
     * ```ts
     * const uploadAdapter = client.getUploadAdapter();
     * ```
     * @returns {UploadAdapter | null} [zh-CN] 返回上传适配器；当前平台未提供时返回 `null`。 [en-US] Returns the upload adapter, or `null` when the current platform does not provide one.
     */
    getUploadAdapter(): UploadAdapter | null;
    /** @internal */
    getRequestAdapter(): RequestAdapter | undefined;
    /**
     * @internal
     * [zh-CN] 向内部事件总线注入事件，仅供 SDK 内部桥接使用。
     * [en-US] Dispatches an event into the internal event bus and is intended for SDK-internal bridging only.
     */
    addInternalEvent<K extends keyof import('./types/event-system').EventPayloadMap>(eventName: K, payload: import('./types/event-system').EventPayloadMap[K]): void;
    /**
     * @internal
     * [zh-CN] 主动刷新会话列表。SDK 会根据当前能力状态决定走新同步链路还是兼容回退链路。
     * [en-US] Actively refreshes the session list. The SDK chooses the new sync path or the compatibility fallback path based on current capability state.
     *
     * @example [zh-CN] 刷新会话列表 [en-US] Refresh session list
     * ```ts
     * const sessions = await client.refreshSessionList({
     *   includeEmpty: false,
     * });
     * ```
     * @param params - [zh-CN] 刷新参数，控制是否拉取空会话；会话标记会始终同步。 [en-US] Refresh options that control whether empty conversations are requested. Conversation marks are always synced.
     * @returns {Promise<ReadonlyArray<ConversationItem>>} [zh-CN] 返回刷新后的会话列表；当前未登录或缓存未初始化时返回空数组。 [en-US] Returns the refreshed conversation list. If the user is not logged in or the cache is not initialized, an empty array is returned.
     */
    refreshSessionList(params?: RefreshSessionListParams): Promise<ReadonlyArray<ConversationItem>>;
    /**
     * [zh-CN] 获取当前固定的服务地址配置；仅在初始化时传入了 `serviceConfig.serverUrls` 才会返回有效值。
     * [en-US] Gets the current fixed server address configuration. This returns a value only if the SDK was initialized with `serviceConfig.serverUrls`.
     *
     * @example [zh-CN] 读取固定的服务地址配置 [en-US] Read the current fixed server address configuration.
     * ```ts
     * const serverUrls = client.getServerUrlsConfig();
     * ```
     * @returns {ServerUrlsConfig | undefined} [zh-CN] 返回固定服务地址配置；若未配置返回 `undefined`。 [en-US] Returns the fixed server configuration, or `undefined` when not configured.
     */
    getServerUrlsConfig(): ServerUrlsConfig | undefined;
    /**
     * @internal
     * [zh-CN] 获取带鉴权参数的会话列表同步 WebSocket 地址列表。
     * [en-US] Gets session-list sync WebSocket URLs with authentication parameters attached.
     */
    getSessionListSyncWsUrls(): ReadonlyArray<string>;
    /**
     * @internal
     * [zh-CN] 判断当前登录会话是否已有 REST 地址派生的同步 WebSocket 地址。
     * [en-US] Indicates whether the current login session has a sync WebSocket URL derived from REST.
     */
    hasSessionListSyncWsUrl(): boolean;
    /**
     * @internal
     * [zh-CN] 获取登录会话内共享的数据同步 WebSocket 会话。
     * [en-US] Gets the shared WebSocket connection for data synchronization within the login session.
     */
    getSharedSyncWebSocketSession(): SharedSyncWebSocketSession;
    /**
     * @internal
     * [zh-CN] 判断当前会话列表能力是否允许进行 DNS 探测。
     * [en-US] Indicates whether session-list capability probing through DNS is available.
     */
    isSessionListDnsProbeAvailable(): boolean;
    /**
     * @internal
     * [zh-CN] 获取会话列表同步能力状态。
     * [en-US] Gets the session-list sync capability state.
     */
    getSessionListSyncCapabilityState(): import('./cache/cache-types').SessionListCapabilityState | null;
    /**
     * @internal
     * [zh-CN] 标记指定会话被访问，用于缓存层更新访问时间。
     * [en-US] Marks specified conversations as accessed so the cache layer can update access timestamps.
     */
    markConversationAccess(targets: ReadonlyArray<{
        conversationId: string;
        type: ConversationType;
    }>): void;
    /** @internal [zh-CN] 更新匹配的最后消息并派发会话更新。 [en-US] Updates the matching last message and emits a conversation update. */
    patchConversationLastMessage(target: {
        readonly conversationId: string;
        readonly conversationType: ConversationType;
        readonly messageId: string;
    }, patch: Partial<NonNullable<ConversationItem['lastMessage']>>): void;
    private handleIncomingConversationMessage;
    private handleIncomingConversationStreamMessage;
    private applyIncomingConversationMessagePatch;
    private handleOutgoingConversationMessage;
    private handleMultiDeviceConversationEvent;
    /**
     * @internal
     * [zh-CN] 在群组解散后按初始化配置清理对应的本地群会话，并派发会话列表更新。
     * [en-US] Cleans up the corresponding local group conversation after group destruction according to the initialization option and emits a conversation-list update.
     */
    handleGroupDestroyedConversation(groupId: string): Promise<void>;
    private handleMultiDeviceContactEvent;
    /**
     * @internal
     * [zh-CN] 获取当前好友快照缓存，供 SDK 内部联系人和资料同步链路使用。
     * [en-US] Gets the cached friend snapshot for internal contact and profile synchronization flows.
     *
     * @example [zh-CN] 读取好友快照 [en-US] Read the friend snapshot.
     * ```ts
     * const snapshot = client.getContactSnapshot();
     * ```
     * @returns {ContactSnapshot | null} [zh-CN] 返回好友快照；若缓存未初始化则返回 `null`。 [en-US] Returns the friend snapshot, or `null` when the cache is uninitialized.
     */
    getContactSnapshot(): ContactSnapshot | null;
    private handleIncomingContactRosterEvent;
    private resolveContactRosterTargetUserId;
    private hydrateContactRosterPayload;
    private fetchContactEventUserInfos;
    private isMessageProfileSyncEnabled;
    /**
     * @internal
     * [zh-CN] 判断是否启用了用户资料同步增强能力。
     * [en-US] Indicates whether enhanced user-profile sync is enabled.
     */
    isUserInfoSyncEnabled(): boolean;
    private syncSelfUserInfoAfterLogin;
    private handleIncomingMessageProfileSync;
    private attachOutgoingMessageProfileVersions;
    private resolveCurrentUserInfoUpdateTime;
    private resolveCurrentGroupNamecardUpdateTime;
    private shouldHydrateUserInfo;
    private shouldHydrateGroupNamecard;
    private flushUserInfoHydrationTargets;
    private flushGroupNamecardHydrationBatch;
    /**
     * @internal
     * [zh-CN] 受控刷新好友快照，复用 024 好友同步控制器。
     * [en-US] Refreshes the friend snapshot in a controlled way by reusing the 024 friend sync controller.
     */
    refreshContactSnapshot(): Promise<void>;
    /**
     * [zh-CN] 注册 ChatClient 事件处理器，用于监听日志、连接、消息、好友、群组等 SDK 公开事件。登出不会清理处理器；不再需要时请显式移除。
     * [en-US] Registers a ChatClient event handler for public SDK events such as logs, connection state, messages, friends, and groups. Logout does not clear handlers; remove them explicitly when no longer needed.
     *
     * @example [zh-CN] 监听连接状态变化 [en-US] Listen for connection state changes.
     * ```ts
     * client.addEventHandler('client-events', {
     *   onConnected: () => console.log('connected'),
     *   onLog: entry => applicationLogger.write(entry),
     * });
     * ```
     * @param id - [zh-CN] 事件处理器唯一 ID，用于后续移除。`id` 区分大小写。 [en-US] The unique handler ID, used for subsequent removal. `id` is case-sensitive.
     * @param handlers - [zh-CN] 事件处理器对象，按需实现对应的回调函数。 [en-US] The event handler object. Implement only the callbacks you need.
     * @returns {void} [zh-CN] 注册成功后无返回值。 [en-US] This method carries no return value after successful registration.
     */
    addEventHandler(id: EventHandlerId, handlers: EventHandlerMap): void;
    /**
     * [zh-CN] 移除指定的 ChatClient 事件处理器。
     * [en-US] Removes the specified ChatClient event handler set.
     *
     * @example [zh-CN] 移除事件处理器 [en-US] Remove event handlers.
     * ```ts
     * client.removeEventHandler('client-events');
     * ```
     * @param id - [zh-CN] 待移除的事件处理器 ID。 [en-US] The ID of the handler to remove.
     * @returns {void} [zh-CN] 移除完成后无返回值。 [en-US] This method does not return a value.
     */
    removeEventHandler(id: EventHandlerId): void;
    /**
     * [zh-CN] 注册一个管理器构造器，并返回带该管理器类型增强的 ChatClient 实例。
     * [en-US] Registers a manager constructor and returns the ChatClient instance enhanced with that manager typing.
     *
     * @example [zh-CN] 手动注册管理器 [en-US] Register a manager manually
     * ```ts
     * const client = ChatClient.init({ appKey: 'org#app' }).use(ChatManager);
     * ```
     * @param ManagerCtor - [zh-CN] 管理器构造器。该参数必传。 [en-US] The manager constructor. This parameter is required.
     * @returns {WithManager<this, Key, Manager>} [zh-CN] 返回带管理器类型增强的当前 ChatClient 实例。 [en-US] Returns the current ChatClient instance enhanced with the manager typing.
     */
    use<Manager extends ManagerBase<ChatClient>, Key extends string>(ManagerCtor: ManagerConstructor<ChatClient, Manager, Key>): WithManager<this, Key, Manager>;
    /**
     * @internal
     * [zh-CN] 执行底层消息发送流程，供 `ChatManager.sendMessage` 内部调用。
     * 文本消息的 `body.targetLanguages` 非空时，先翻译再发送；译文位于返回消息的 `body.translations`，原文保留，传入对象不被修改。翻译失败时不发送并返回翻译错误。
     * [en-US] Runs the low-level message sending flow for internal use by `ChatManager.sendMessage`.
     *
     * Text messages with non-empty `body.targetLanguages` are translated before sending. Translations appear in the returned message's `body.translations`; the original text is preserved and the input is not mutated. Translation failure prevents sending and returns the translation error.
     *
     * @example [zh-CN] 发送消息 [en-US] Send a message.
     * ```ts
     * const sent = await client.sendMessage(message);
     * ```
     * @param message - [zh-CN] 必传。待发送的消息对象。`message.sender.userId` 必须与当前登录用户 ID 一致。 [en-US] Required. The message object to send. `message.sender.userId` must match the current logged-in user ID.
     * @param options - [zh-CN] 可选。发送配置项，例如进度回调函数。[en-US] Optional. Sending configuration options, such as progress callbacks.
     * @returns {Promise<Message>} [zh-CN] 返回经过发送流程处理后的消息对象。 [en-US] Returns the message object after the sending pipeline completes.
     */
    sendMessage(message: Message, options?: SendMessageOptions): Promise<Message>;
    private sendTranslatedMessage;
    private waitForSendConnectionRecovery;
    /**
     * @internal
     * [zh-CN] 派发当前用户资料更新事件。
     * [en-US] Dispatches the current-user profile updated event.
     */
    dispatchOwnInfoUpdated(userInfo: UserInfo): void;
    /**
     * @internal
     * [zh-CN] 派发批量用户资料更新事件。
     * [en-US] Dispatches the batch user-profile updated event.
     */
    dispatchUserInfoUpdated(userInfos: ReadonlyArray<UserInfo>): void;
    /**
     * @internal
     * [zh-CN] 根据用户资料变化刷新本地会话列表展示字段。
     * [en-US] Refreshes local conversation-list display fields from user-profile changes.
     */
    refreshConversationDisplayFromUserInfos(targets: ReadonlyArray<{
        readonly userId: string;
        readonly lastModified?: number;
    }>, reason?: ConversationListUpdateReason): void;
    /**
     * @internal
     * [zh-CN] 根据已加入群组同步结果刷新本地群会话展示字段。
     * [en-US] Refreshes local group-conversation display fields from joined-group sync results.
     */
    refreshConversationDisplayFromJoinedGroups(groups: ReadonlyArray<import('./types/group').JoinedGroupSummary>, reason?: ConversationListUpdateReason, options?: {
        readonly onlyWhenNameMissing?: boolean;
    }): void;
    private enqueueMissingGroupSessionSenderUserInfos;
    /**
     * @internal
     * [zh-CN] 派发用户群名片更新事件。
     * [en-US] Dispatches the user group-namecard updated event.
     */
    dispatchUserGroupNamecardUpdated(groupId: string, userId: string, namecard: string): void;
    protected downloadAndParseCombinePayload(params: DownloadCombineMessageParams): Promise<ReadonlyArray<Message>>;
    /**
     * @internal
     * [zh-CN] 发送消息 action 请求，例如已读、Reaction、Thread 相关的 ACK 驱动操作。
     * [en-US] Sends a message-action request such as ACK-driven operations for read state, reactions, or threads.
     *
     * @example [zh-CN] 发送消息 action [en-US] Send a message action
     * ```ts
     * const result = await client.sendMessageAction(actionRequest);
     * ```
     * @param action - [zh-CN] 消息 action 请求体。该参数必传。 [en-US] The message action request payload. This parameter is required.
     * @param createAckError - [zh-CN] 可选 ACK 错误构造器，用于自定义 ACK 失败错误。 [en-US] Optional ACK error factory for customizing ACK failure errors.
     * @returns {Promise<ActionAckResult>} [zh-CN] 返回消息 action 的 ACK 结果。 [en-US] Returns the ACK result of the message action.
     */
    sendMessageAction(action: MessageActionRequest, createAckError?: (statusCode: number, reason?: string) => Error): Promise<ActionAckResult>;
    /**
     * @internal
     * [zh-CN] 发送聊天室 action 请求，用于聊天室内的 ACK 驱动操作。
     * [en-US] Sends a chatroom-action request for ACK-driven operations within a chat room.
     *
     * @example [zh-CN] 发送聊天室 action [en-US] Send a chatroom action
     * ```ts
     * const result = await client.sendChatRoomOperation(request);
     * ```
     * @param request - [zh-CN] 聊天室 action 请求体。该参数必传。 [en-US] The chat room action request payload. This parameter is required.
     * @param createAckError - [zh-CN] 可选 ACK 错误构造器，用于自定义 ACK 失败错误。 [en-US] Optional ACK error factory for customizing ACK failure errors.
     * @returns {Promise<ActionAckResult>} [zh-CN] 返回聊天室 action 的 ACK 结果。 [en-US] Returns the ACK result of the chat room action.
     */
    sendChatRoomOperation(request: ChatRoomOperationRequest, createAckError?: (statusCode: number, reason?: string) => Error): Promise<ActionAckResult>;
    /**
     * @internal
     * [zh-CN] 下载消息附件。
     * [en-US] Downloads the attachment of a message.
     *
     * @example [zh-CN] 下载消息附件 [en-US] Download a message attachment
     * ```ts
     * const file = await client.downloadAttachment(message);
     * ```
     * @param message - [zh-CN] 包含附件信息的消息对象。该参数必传。 [en-US] The message object containing attachment metadata. This parameter is required.
     * @returns {Promise<MessageAttachmentDownloadResult | ReadonlyArray<MessageAttachmentDownloadResult>>} [zh-CN] 普通附件消息返回单个下载结果。复合消息按分段顺序返回全部图片、语音、视频和文件附件。 [en-US] Returns one download result for a regular attachment message. A multi_body message returns every image, voice, video, and file attachment in segment order.
     */
    downloadAttachment(message: Message): Promise<MessageAttachmentDownloadResult | ReadonlyArray<MessageAttachmentDownloadResult>>;
    /**
     * @internal
     * [zh-CN] 解析服务端消息元数据载荷为标准消息对象。
     * [en-US] Decodes server message metadata payload into a normalized message object.
     *
     * @example [zh-CN] 解析服务端消息元数据 [en-US] Decode server message metadata
     * ```ts
     * const message = client.decodeServerMessageMeta(metaPayload);
     * ```
     * @param metaPayload - [zh-CN] 服务端下发的消息元数据二进制载荷。该参数必传。 [en-US] The binary payload of server-delivered message metadata. This parameter is required.
     * @returns {Message | null} [zh-CN] 返回解析后的消息对象；无法解析时返回 `null`。 [en-US] Returns the decoded message object, or `null` if decoding fails.
     */
    decodeServerMessageMeta(metaPayload: Uint8Array): Message | null;
    private registerManagers;
    private registerManagerInput;
    private registerManagerConstructor;
    private registerManagerInstance;
    private registerManagerCapabilities;
    private dispatchRawNotifyToCapability;
    private getUserInfoReadCapability;
    private getGroupNamecardHydrationCapability;
    private validateOptionalCapabilityDependencies;
    private hasUserInfoReadCapability;
    private hasGroupNamecardHydrationCapability;
    private buildMissingCapabilityError;
    private resolveManagerKey;
    private getManagerKeyFromConstructor;
    private getManagerKeyFromInstance;
    private attachManager;
    private isValidManagerKey;
    private getManagerNameFromConstructor;
    private getManagerNameFromInstance;
    private buildManagerValidationError;
    private buildManagerConflictError;
    private static isManagerConstructor;
    private updateState;
    private throwIfLoginSessionCancelled;
    private initCacheManager;
    private loadCachedConversations;
    private loadCachedUserInfo;
    /**
     * @internal
     * [zh-CN] 根据当前缓存快照派发会话列表更新事件。
     * [en-US] Dispatches a conversation list update from the current cache snapshot.
     */
    emitConversationListUpdate(reason: ConversationListUpdateReason, reset?: boolean): void;
    private buildConversationListPatch;
    private buildConversationListKey;
    private isConversationListItemEqual;
    private triggerContactSync;
    private triggerConfiguredSyncDataAfterLogin;
    private triggerGroupSync;
    private ensureSessionListSyncController;
    private ensureContactSyncController;
    private ensureGroupSyncController;
    /**
     * @internal
     * [zh-CN] 派发统一数据同步开始事件。
     * [en-US] Emits the unified data-sync start event.
     */
    emitSyncDataStart(dataType: SyncDataType): void;
    /**
     * @internal
     * [zh-CN] 派发统一数据同步完成事件。
     * [en-US] Emits the unified data-sync finished event.
     */
    emitSyncDataFinished(payload: SyncDataFinishedPayload): void;
    private requireCacheManager;
    private resolveContactSyncUrls;
    private buildAuthenticatedContactSyncUrls;
    private buildAuthenticatedSessionListSyncUrls;
    private requireContactSyncToken;
    private buildContactSyncSocketUrl;
    private shuffleContactSyncUrls;
    private buildContactRosterRequest;
    private detachSessionListSyncController;
    private resetCore;
    private clearCoreSessionState;
    private requireConfiguredAppKey;
    private requireActiveAppKey;
    private resetManagerSessionRuntimes;
    private notifyManagersSessionReady;
    private notifyManagerSessionReady;
    private notifyManagersSessionEnding;
    private isTerminalManagerSessionDisconnect;
    private startTerminalSessionCleanup;
    private waitForTerminalSessionCleanup;
    private finishTerminalSessionCleanup;
    private static isSameConfig;
    private static normalizeServiceConfig;
    private static normalizeFixedWebSocketUrl;
    private static normalizeSyncDataTypes;
    private static isSameStringArray;
    private static isSameServiceConfig;
    private static isSameServerUrls;
}
