import type { ConversationItem, SessionMessageSnippet } from '../../types/conversation';
import type { SessionListMeta, SessionListRequest, SessionListRequestParams, SessionListResponse } from './types';
export declare const buildSessionListRequest: (options: {
    readonly requestId: string;
    readonly resource: string;
    readonly org: string;
    readonly app: string;
    readonly username: string;
    readonly lastSyncTime: number;
    readonly params?: SessionListRequestParams;
    readonly protocolVersion?: number;
}) => SessionListRequest;
export declare const toSessionMessageSnippet: (meta: SessionListMeta | undefined, payloadBody: Record<string, unknown>, options: {
    readonly conversationId: string;
    readonly conversationType: ConversationItem["conversationType"];
    readonly currentUserId: string;
    readonly ext?: Record<string, unknown>;
    readonly payload?: Record<string, unknown> | null;
    readonly useCustomAttachmentUpload?: boolean;
    readonly org: string;
    readonly app: string;
    readonly singleChatPeerDisplay?: Pick<ConversationItem, "conversationName" | "conversationAvatar">;
}) => SessionMessageSnippet | null;
export declare const toSessionListItems: (response: SessionListResponse, currentUserId: string, org: string, app: string, options?: {
    readonly useCustomAttachmentUpload?: boolean;
}) => ReadonlyArray<ConversationItem>;
