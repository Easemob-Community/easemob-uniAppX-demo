import type { SessionMessageSnippet } from '../../types/conversation';
export declare const decodeSessionListPayload: (payload?: Uint8Array) => {
    readonly body: Record<string, unknown> | ReadonlyArray<Record<string, unknown>>;
    readonly ext: Record<string, unknown>;
};
export declare const decodeSessionListPayloadRecord: (payload?: Uint8Array) => Record<string, unknown> | null;
export declare const mapSessionListPayload: (decoded: Record<string, unknown> | null, options: {
    readonly currentUserId: string;
    readonly conversationType: NonNullable<SessionMessageSnippet["conversationType"]>;
    readonly from: string;
    readonly useCustomAttachmentUpload?: boolean;
}) => Partial<SessionMessageSnippet>;
export declare const decodeSessionListPayloadBody: (payload?: Uint8Array) => Record<string, unknown> | ReadonlyArray<Record<string, unknown>>;
