import type { SessionListRemindType } from '../../types/conversation';
export declare const SessionListMessageType: {
    readonly UNSPECIFIED: 0;
    readonly ERROR: 5;
    readonly GET_SESSION_LIST_REQUEST: 10;
    readonly GET_SESSION_LIST_RESPONSE: 11;
};
export declare const SessionListProtocolSessionType: {
    readonly SINGLE_CHAT: 0;
    readonly GROUP_CHAT: 1;
    readonly CHAT_ROOM: 2;
};
export declare const SessionListProtocolRemindType: {
    readonly DEFAULT: 0;
    readonly ALL: 1;
    readonly AT: 2;
    readonly NONE: 3;
};
export interface SessionListGatewayHeader {
    readonly resource: string;
    readonly timestamp: number;
    readonly requestId: string;
    readonly protocolVersion: number;
}
export interface SessionListJid {
    readonly appKey?: string;
    readonly name?: string;
    readonly domain?: string;
    readonly clientResource?: string;
}
export interface SessionListMeta {
    readonly id?: string;
    readonly from?: SessionListJid;
    readonly timestamp?: number;
    readonly payload?: Uint8Array;
}
export interface SessionListRequest {
    readonly type: typeof SessionListMessageType.GET_SESSION_LIST_REQUEST;
    readonly header?: SessionListGatewayHeader;
    readonly org: string;
    readonly app: string;
    readonly username: string;
    readonly lastSyncTime?: number;
    readonly includeEmpty?: boolean;
    readonly includeMark?: boolean;
}
export interface SessionListRequestParams {
    readonly includeEmpty?: boolean;
    readonly includeMark?: boolean;
}
export interface SessionListProtocolItem {
    readonly session_id?: string;
    readonly session_type?: number;
    readonly last_message?: SessionListMeta;
    readonly updated_at?: number;
    readonly pinned_time?: number;
    readonly unread_count?: number;
    readonly marks?: ReadonlyArray<string>;
    readonly read_receipt?: number;
    readonly remind_type?: number;
    readonly group_name?: string;
    readonly group_avatar?: string;
    readonly metadata?: string;
    readonly display_source?: string;
}
export interface SessionListResponse {
    readonly type: typeof SessionListMessageType.GET_SESSION_LIST_RESPONSE;
    readonly header?: SessionListGatewayHeader;
    readonly sessions: ReadonlyArray<SessionListProtocolItem>;
    readonly isLastBatch?: boolean;
    readonly lastSyncFinishedTs?: number;
}
export interface SessionListErrorDetail {
    readonly type: typeof SessionListMessageType.ERROR;
    readonly header?: SessionListGatewayHeader;
    readonly code: number;
    readonly message: string;
}
export type SessionListDecodedMessage = SessionListRequest | SessionListResponse | SessionListErrorDetail | {
    readonly type: number;
};
export declare const mapProtocolSessionTypeToPublic: (value: number | undefined) => "singleChat" | "groupChat" | "chatRoom";
export declare const mapProtocolRemindTypeToPublic: (value: number | undefined) => SessionListRemindType;
