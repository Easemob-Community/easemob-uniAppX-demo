import type { SessionListDecodedMessage, SessionListRequest } from './types';
export declare class SessionListCodec {
    private readonly requestType;
    private readonly responseType;
    private readonly errorType;
    encodeRequest(payload: SessionListRequest): Uint8Array;
    decode(payload: Uint8Array): SessionListDecodedMessage;
    private tryDecodeRequest;
    private tryDecodeResponse;
    private tryDecodeError;
}
