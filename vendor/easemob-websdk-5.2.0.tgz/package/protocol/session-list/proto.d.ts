declare const proto: {
    readonly nested: {
        readonly easemob: {
            readonly nested: {
                readonly sessionlist: {
                    readonly nested: {
                        readonly GatewayHeader: {
                            readonly fields: {
                                readonly resource: {
                                    readonly type: "string";
                                    readonly id: 1;
                                };
                                readonly timestamp: {
                                    readonly type: "int64";
                                    readonly id: 2;
                                };
                                readonly request_id: {
                                    readonly type: "string";
                                    readonly id: 3;
                                };
                                readonly protocol_version: {
                                    readonly type: "int32";
                                    readonly id: 4;
                                };
                            };
                        };
                        readonly JID: {
                            readonly fields: {
                                readonly app_key: {
                                    readonly type: "string";
                                    readonly id: 1;
                                };
                                readonly name: {
                                    readonly type: "string";
                                    readonly id: 2;
                                };
                                readonly domain: {
                                    readonly type: "string";
                                    readonly id: 3;
                                };
                                readonly client_resource: {
                                    readonly type: "string";
                                    readonly id: 4;
                                };
                            };
                        };
                        readonly Meta: {
                            readonly fields: {
                                readonly id: {
                                    readonly type: "uint64";
                                    readonly id: 1;
                                };
                                readonly from: {
                                    readonly type: "JID";
                                    readonly id: 2;
                                };
                                readonly timestamp: {
                                    readonly type: "uint64";
                                    readonly id: 4;
                                };
                                readonly payload: {
                                    readonly type: "bytes";
                                    readonly id: 6;
                                };
                            };
                        };
                        readonly SessionItem: {
                            readonly fields: {
                                readonly session_id: {
                                    readonly type: "string";
                                    readonly id: 1;
                                };
                                readonly session_type: {
                                    readonly type: "int32";
                                    readonly id: 2;
                                };
                                readonly last_message: {
                                    readonly type: "Meta";
                                    readonly id: 3;
                                };
                                readonly updated_at: {
                                    readonly type: "int64";
                                    readonly id: 6;
                                };
                                readonly pinned_time: {
                                    readonly type: "int64";
                                    readonly id: 7;
                                };
                                readonly unread_count: {
                                    readonly type: "uint32";
                                    readonly id: 8;
                                };
                                readonly marks: {
                                    readonly rule: "repeated";
                                    readonly type: "string";
                                    readonly id: 9;
                                };
                                readonly read_receipt: {
                                    readonly type: "int64";
                                    readonly id: 10;
                                };
                                readonly remind_type: {
                                    readonly type: "int32";
                                    readonly id: 11;
                                };
                                readonly group_name: {
                                    readonly type: "string";
                                    readonly id: 12;
                                };
                                readonly group_avatar: {
                                    readonly type: "string";
                                    readonly id: 13;
                                };
                                readonly metadata: {
                                    readonly type: "string";
                                    readonly id: 14;
                                };
                            };
                        };
                        readonly GetSessionListRequest: {
                            readonly fields: {
                                readonly type: {
                                    readonly type: "int32";
                                    readonly id: 1;
                                };
                                readonly header: {
                                    readonly type: "GatewayHeader";
                                    readonly id: 2;
                                };
                                readonly org: {
                                    readonly type: "string";
                                    readonly id: 3;
                                };
                                readonly app: {
                                    readonly type: "string";
                                    readonly id: 4;
                                };
                                readonly username: {
                                    readonly type: "string";
                                    readonly id: 5;
                                };
                                readonly last_sync_time: {
                                    readonly type: "int64";
                                    readonly id: 6;
                                };
                                readonly need_empty_session: {
                                    readonly type: "bool";
                                    readonly id: 7;
                                };
                                readonly need_session_mark: {
                                    readonly type: "bool";
                                    readonly id: 8;
                                };
                            };
                        };
                        readonly GetSessionListResponse: {
                            readonly fields: {
                                readonly type: {
                                    readonly type: "int32";
                                    readonly id: 1;
                                };
                                readonly header: {
                                    readonly type: "GatewayHeader";
                                    readonly id: 2;
                                };
                                readonly sessions: {
                                    readonly rule: "repeated";
                                    readonly type: "SessionItem";
                                    readonly id: 3;
                                };
                                readonly is_last_batch: {
                                    readonly type: "bool";
                                    readonly id: 4;
                                };
                                readonly last_sync_finished_ts: {
                                    readonly type: "int64";
                                    readonly id: 5;
                                };
                            };
                        };
                        readonly ErrorDetail: {
                            readonly fields: {
                                readonly type: {
                                    readonly type: "int32";
                                    readonly id: 1;
                                };
                                readonly header: {
                                    readonly type: "GatewayHeader";
                                    readonly id: 2;
                                };
                                readonly code: {
                                    readonly type: "uint32";
                                    readonly id: 3;
                                };
                                readonly message: {
                                    readonly type: "string";
                                    readonly id: 4;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
};
export default proto;
