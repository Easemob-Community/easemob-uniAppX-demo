/**
 * 由 scripts/generate-msync-proto.js 自动生成，请勿手动修改。
 */
declare const proto: {
    nested: {
        easemob: {
            nested: {
                pb: {
                    nested: {
                        MessageBody: {
                            fields: {
                                type: {
                                    type: string;
                                    id: number;
                                };
                                from: {
                                    type: string;
                                    id: number;
                                };
                                to: {
                                    type: string;
                                    id: number;
                                };
                                contents: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                ext: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                ackMessageId: {
                                    type: string;
                                    id: number;
                                };
                                msgConfig: {
                                    type: string;
                                    id: number;
                                };
                                ackContent: {
                                    type: string;
                                    id: number;
                                };
                                meta: {
                                    type: string;
                                    id: number;
                                };
                                editMessageId: {
                                    type: string;
                                    id: number;
                                };
                                editScope: {
                                    type: string;
                                    id: number;
                                };
                                stream: {
                                    type: string;
                                    id: number;
                                };
                                userInfoUpdateTime: {
                                    type: string;
                                    id: number;
                                };
                                namecardUpdateTime: {
                                    type: string;
                                    id: number;
                                };
                                sendToPeer: {
                                    type: string;
                                    id: number;
                                };
                                ackMessageIds: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                clearAllUnreadMessageCount: {
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                Content: {
                                    fields: {
                                        type: {
                                            type: string;
                                            id: number;
                                        };
                                        text: {
                                            type: string;
                                            id: number;
                                        };
                                        latitude: {
                                            type: string;
                                            id: number;
                                        };
                                        longitude: {
                                            type: string;
                                            id: number;
                                        };
                                        address: {
                                            type: string;
                                            id: number;
                                        };
                                        displayName: {
                                            type: string;
                                            id: number;
                                        };
                                        remotePath: {
                                            type: string;
                                            id: number;
                                        };
                                        secretKey: {
                                            type: string;
                                            id: number;
                                        };
                                        fileLength: {
                                            type: string;
                                            id: number;
                                        };
                                        action: {
                                            type: string;
                                            id: number;
                                        };
                                        params: {
                                            rule: string;
                                            type: string;
                                            id: number;
                                        };
                                        duration: {
                                            type: string;
                                            id: number;
                                        };
                                        size: {
                                            type: string;
                                            id: number;
                                        };
                                        thumbnailRemotePath: {
                                            type: string;
                                            id: number;
                                        };
                                        thumbnailSecretKey: {
                                            type: string;
                                            id: number;
                                        };
                                        thumbnailDisplayName: {
                                            type: string;
                                            id: number;
                                        };
                                        thumbnailFileLength: {
                                            type: string;
                                            id: number;
                                        };
                                        thumbnailSize: {
                                            type: string;
                                            id: number;
                                        };
                                        customEvent: {
                                            type: string;
                                            id: number;
                                        };
                                        customExts: {
                                            rule: string;
                                            type: string;
                                            id: number;
                                        };
                                        buildingName: {
                                            type: string;
                                            id: number;
                                        };
                                        subType: {
                                            type: string;
                                            id: number;
                                        };
                                        title: {
                                            type: string;
                                            id: number;
                                        };
                                        summary: {
                                            type: string;
                                            id: number;
                                        };
                                        combineLevel: {
                                            type: string;
                                            id: number;
                                        };
                                        imageType: {
                                            type: string;
                                            id: number;
                                        };
                                    };
                                    nested: {
                                        Type: {
                                            values: {
                                                TEXT: number;
                                                IMAGE: number;
                                                VIDEO: number;
                                                LOCATION: number;
                                                VOICE: number;
                                                FILE: number;
                                                COMMAND: number;
                                                CUSTOM: number;
                                                COMBINE: number;
                                            };
                                        };
                                        Size: {
                                            fields: {
                                                width: {
                                                    type: string;
                                                    id: number;
                                                };
                                                height: {
                                                    type: string;
                                                    id: number;
                                                };
                                            };
                                        };
                                        SubType: {
                                            values: {
                                                COMBINE: number;
                                                GIF: number;
                                                SUB_STREAM: number;
                                            };
                                        };
                                    };
                                };
                                Type: {
                                    values: {
                                        NORMAL: number;
                                        CHAT: number;
                                        GROUPCHAT: number;
                                        CHATROOM: number;
                                        READ_ACK: number;
                                        DELIVER_ACK: number;
                                        RECALL: number;
                                        CHANNEL_ACK: number;
                                        EDIT: number;
                                    };
                                };
                                EditScope: {
                                    values: {
                                        BODY: number;
                                        BODY_AND_EXT: number;
                                    };
                                };
                                MessageConfig: {
                                    fields: {
                                        allowGroupAck: {
                                            type: string;
                                            id: number;
                                        };
                                    };
                                };
                                Stream: {
                                    fields: {
                                        streamType: {
                                            type: string;
                                            id: number;
                                        };
                                        streamSeq: {
                                            type: string;
                                            id: number;
                                        };
                                        streamStatus: {
                                            type: string;
                                            id: number;
                                        };
                                        streamError: {
                                            type: string;
                                            id: number;
                                        };
                                        streamFinishReason: {
                                            type: string;
                                            id: number;
                                        };
                                    };
                                    nested: {
                                        StreamStatus: {
                                            values: {
                                                STREAM_START: number;
                                                STREAM_START_COMPLETED: number;
                                                STREAM_IN_PROGRESS: number;
                                                STREAM_COMPLETED: number;
                                                STREAM_FULL: number;
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        KeyValue: {
                            oneofs: {
                                value: {
                                    oneof: string[];
                                };
                            };
                            fields: {
                                key: {
                                    type: string;
                                    id: number;
                                };
                                type: {
                                    type: string;
                                    id: number;
                                };
                                varintValue: {
                                    type: string;
                                    id: number;
                                };
                                floatValue: {
                                    type: string;
                                    id: number;
                                };
                                doubleValue: {
                                    type: string;
                                    id: number;
                                };
                                stringValue: {
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                ValueType: {
                                    values: {
                                        BOOL: number;
                                        INT: number;
                                        UINT: number;
                                        LLINT: number;
                                        FLOAT: number;
                                        DOUBLE: number;
                                        STRING: number;
                                        JSON_STRING: number;
                                    };
                                };
                            };
                        };
                        JID: {
                            fields: {
                                appKey: {
                                    type: string;
                                    id: number;
                                };
                                name: {
                                    type: string;
                                    id: number;
                                };
                                domain: {
                                    type: string;
                                    id: number;
                                };
                                clientResource: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        ConferenceBody: {
                            fields: {
                                sessionId: {
                                    type: string;
                                    id: number;
                                };
                                operation: {
                                    type: string;
                                    id: number;
                                };
                                conferenceId: {
                                    type: string;
                                    id: number;
                                };
                                type: {
                                    type: string;
                                    id: number;
                                };
                                content: {
                                    type: string;
                                    id: number;
                                };
                                network: {
                                    type: string;
                                    id: number;
                                };
                                version: {
                                    type: string;
                                    id: number;
                                };
                                identity: {
                                    type: string;
                                    id: number;
                                };
                                duration: {
                                    type: string;
                                    id: number;
                                };
                                peerName: {
                                    type: string;
                                    id: number;
                                };
                                endReason: {
                                    type: string;
                                    id: number;
                                };
                                status: {
                                    type: string;
                                    id: number;
                                };
                                isDirect: {
                                    type: string;
                                    id: number;
                                };
                                controlType: {
                                    type: string;
                                    id: number;
                                };
                                routeFlag: {
                                    type: string;
                                    id: number;
                                };
                                routeKey: {
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                Status: {
                                    fields: {
                                        errorCode: {
                                            type: string;
                                            id: number;
                                        };
                                    };
                                };
                                Operation: {
                                    values: {
                                        JOIN: number;
                                        INITIATE: number;
                                        ACCEPT_INITIATE: number;
                                        ANSWER: number;
                                        TERMINATE: number;
                                        REMOVE: number;
                                        STREAM_CONTROL: number;
                                        MEDIA_REQUEST: number;
                                    };
                                };
                                Type: {
                                    values: {
                                        VOICE: number;
                                        VIDEO: number;
                                    };
                                };
                                Identity: {
                                    values: {
                                        CALLER: number;
                                        CALLEE: number;
                                    };
                                };
                                EndReason: {
                                    values: {
                                        HANGUP: number;
                                        NORESPONSE: number;
                                        REJECT: number;
                                        BUSY: number;
                                        FAIL: number;
                                        UNSUPPORTED: number;
                                        OFFLINE: number;
                                    };
                                };
                                StreamControlType: {
                                    values: {
                                        PAUSE_VOICE: number;
                                        RESUME_VOICE: number;
                                        PAUSE_VIDEO: number;
                                        RESUME_VIDEO: number;
                                    };
                                };
                            };
                        };
                        MSync: {
                            fields: {
                                version: {
                                    type: string;
                                    id: number;
                                    options: {
                                        default: string;
                                    };
                                };
                                guid: {
                                    type: string;
                                    id: number;
                                };
                                auth: {
                                    type: string;
                                    id: number;
                                };
                                compressAlgorimth: {
                                    type: string;
                                    id: number;
                                };
                                crypto: {
                                    type: string;
                                    id: number;
                                };
                                userAgent: {
                                    type: string;
                                    id: number;
                                };
                                pov: {
                                    type: string;
                                    id: number;
                                };
                                command: {
                                    type: string;
                                    id: number;
                                };
                                deviceId: {
                                    type: string;
                                    id: number;
                                };
                                encryptType: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                    options: {
                                        packed: boolean;
                                    };
                                };
                                encryptKey: {
                                    type: string;
                                    id: number;
                                };
                                payload: {
                                    type: string;
                                    id: number;
                                };
                                traceId: {
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                Version: {
                                    values: {
                                        MSYNC_V1: number;
                                        MSYNC_V2: number;
                                    };
                                };
                                Command: {
                                    values: {
                                        SYNC: number;
                                        UNREAD: number;
                                        NOTICE: number;
                                        PROVISION: number;
                                        LOGOUT: number;
                                    };
                                };
                            };
                        };
                        EncryptType: {
                            values: {
                                ENCRYPT_NONE: number;
                                ENCRYPT_AES_128_CBC: number;
                                ENCRYPT_AES_256_CBC: number;
                            };
                        };
                        CommSyncUL: {
                            fields: {
                                meta: {
                                    type: string;
                                    id: number;
                                };
                                key: {
                                    type: string;
                                    id: number;
                                };
                                queue: {
                                    type: string;
                                    id: number;
                                };
                                isRoam: {
                                    type: string;
                                    id: number;
                                };
                                lastFullRoamKey: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        CommSyncDL: {
                            fields: {
                                status: {
                                    type: string;
                                    id: number;
                                };
                                metaId: {
                                    type: string;
                                    id: number;
                                };
                                serverId: {
                                    type: string;
                                    id: number;
                                };
                                metas: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                nextKey: {
                                    type: string;
                                    id: number;
                                };
                                queue: {
                                    type: string;
                                    id: number;
                                };
                                isLast: {
                                    type: string;
                                    id: number;
                                };
                                timestamp: {
                                    type: string;
                                    id: number;
                                };
                                isRoam: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        CommNotice: {
                            fields: {
                                queue: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        CommUnreadUL: {
                            fields: {};
                        };
                        CommUnreadDL: {
                            fields: {
                                status: {
                                    type: string;
                                    id: number;
                                };
                                unread: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                timestamp: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        MetaQueue: {
                            fields: {
                                queue: {
                                    type: string;
                                    id: number;
                                };
                                n: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        Meta: {
                            fields: {
                                id: {
                                    type: string;
                                    id: number;
                                };
                                from: {
                                    type: string;
                                    id: number;
                                };
                                to: {
                                    type: string;
                                    id: number;
                                };
                                timestamp: {
                                    type: string;
                                    id: number;
                                };
                                ns: {
                                    type: string;
                                    id: number;
                                };
                                payload: {
                                    type: string;
                                    id: number;
                                };
                                routetype: {
                                    type: string;
                                    id: number;
                                };
                                ext: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                meta: {
                                    type: string;
                                    id: number;
                                };
                                directedUsers: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                env: {
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                NameSpace: {
                                    values: {
                                        STATISTIC: number;
                                        CHAT: number;
                                        MUC: number;
                                        ROSTER: number;
                                        CONFERENCE: number;
                                        NOTIFY: number;
                                        QUERY: number;
                                    };
                                };
                                RouteType: {
                                    values: {
                                        ROUTE_ALL: number;
                                        ROUTE_ONLINE: number;
                                        ROUTE_DIRECT: number;
                                    };
                                };
                            };
                        };
                        Status: {
                            fields: {
                                errorCode: {
                                    type: string;
                                    id: number;
                                };
                                reason: {
                                    type: string;
                                    id: number;
                                };
                                redirectInfo: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                ErrorCode: {
                                    values: {
                                        OK: number;
                                        FAIL: number;
                                        UNAUTHORIZED: number;
                                        MISSING_PARAMETER: number;
                                        WRONG_PARAMETER: number;
                                        REDIRECT: number;
                                        TOKEN_EXPIRED: number;
                                        PERMISSION_DENIED: number;
                                        NO_ROUTE: number;
                                        UNKNOWN_COMMAND: number;
                                        PB_PARSER_ERROR: number;
                                        BIND_ANOTHER_DEVICE: number;
                                        IM_FORBIDDEN: number;
                                        TOO_MANY_DEVICES: number;
                                        PLATFORM_LIMIT: number;
                                        USER_MUTED: number;
                                        ENCRYPT_DISABLE: number;
                                        ENCRYPT_ENABLE: number;
                                        DECRYPT_FAILURE: number;
                                        PERMISSION_DENIED_EXTERNAL: number;
                                    };
                                };
                            };
                        };
                        RedirectInfo: {
                            fields: {
                                host: {
                                    type: string;
                                    id: number;
                                };
                                port: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        Provision: {
                            fields: {
                                osType: {
                                    type: string;
                                    id: number;
                                };
                                version: {
                                    type: string;
                                    id: number;
                                };
                                networkType: {
                                    type: string;
                                    id: number;
                                };
                                appSign: {
                                    type: string;
                                    id: number;
                                };
                                compressType: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                    options: {
                                        packed: boolean;
                                    };
                                };
                                encryptType: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                    options: {
                                        packed: boolean;
                                    };
                                };
                                encryptKey: {
                                    type: string;
                                    id: number;
                                };
                                status: {
                                    type: string;
                                    id: number;
                                };
                                deviceUuid: {
                                    type: string;
                                    id: number;
                                };
                                isManualLogin: {
                                    type: string;
                                    id: number;
                                };
                                password: {
                                    type: string;
                                    id: number;
                                };
                                deviceName: {
                                    type: string;
                                    id: number;
                                };
                                resource: {
                                    type: string;
                                    id: number;
                                };
                                auth: {
                                    type: string;
                                    id: number;
                                };
                                serviceId: {
                                    type: string;
                                    id: number;
                                };
                                actionVersion: {
                                    type: string;
                                    id: number;
                                };
                                authToken: {
                                    type: string;
                                    id: number;
                                };
                                osCustomValue: {
                                    type: string;
                                    id: number;
                                };
                                sessionId: {
                                    type: string;
                                    id: number;
                                };
                                reason: {
                                    type: string;
                                    id: number;
                                };
                                protocolCompressType: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                protocolCompressDirection: {
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                OsType: {
                                    values: {
                                        OS_IOS: number;
                                        OS_ANDROID: number;
                                        OS_LINUX: number;
                                        OS_OSX: number;
                                        OS_WIN: number;
                                        OS_CUSTOM: number;
                                        OS_OTHER: number;
                                    };
                                };
                                NetworkType: {
                                    values: {
                                        NETWORK_NONE: number;
                                        NETWORK_WIFI: number;
                                        NETWORK_4G: number;
                                        NETWORK_3G: number;
                                        NETWORK_2G: number;
                                        NETWORK_WIRE: number;
                                    };
                                };
                                CompressType: {
                                    values: {
                                        COMPRESS_NONE: number;
                                        COMPRESS_ZLIB: number;
                                        COMPRESS_LZ4: number;
                                    };
                                };
                                CompressDirection: {
                                    values: {
                                        ONLY_UP: number;
                                        ONLY_DOWN: number;
                                        BI: number;
                                    };
                                };
                            };
                        };
                        Logout: {
                            fields: {
                                sessionId: {
                                    type: string;
                                    id: number;
                                };
                                reason: {
                                    type: string;
                                    id: number;
                                };
                                status: {
                                    type: string;
                                    id: number;
                                };
                            };
                        };
                        MUCBody: {
                            fields: {
                                mucId: {
                                    type: string;
                                    id: number;
                                };
                                operation: {
                                    type: string;
                                    id: number;
                                };
                                from: {
                                    type: string;
                                    id: number;
                                };
                                to: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                setting: {
                                    type: string;
                                    id: number;
                                };
                                reason: {
                                    type: string;
                                    id: number;
                                };
                                isChatroom: {
                                    type: string;
                                    id: number;
                                };
                                status: {
                                    type: string;
                                    id: number;
                                };
                                isThread: {
                                    type: string;
                                    id: number;
                                };
                                mucParentId: {
                                    type: string;
                                    id: number;
                                };
                                mucName: {
                                    type: string;
                                    id: number;
                                };
                                eventInfo: {
                                    type: string;
                                    id: number;
                                };
                                mucMemberCount: {
                                    type: string;
                                    id: number;
                                };
                                ext: {
                                    type: string;
                                    id: number;
                                };
                                leaveOtherRooms: {
                                    type: string;
                                    id: number;
                                };
                                members: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                Operation: {
                                    values: {
                                        CREATE: number;
                                        DESTROY: number;
                                        JOIN: number;
                                        LEAVE: number;
                                        APPLY: number;
                                        APPLY_ACCEPT: number;
                                        APPLY_DECLINE: number;
                                        INVITE: number;
                                        INVITE_ACCEPT: number;
                                        INVITE_DECLINE: number;
                                        KICK: number;
                                        GET_BLACKLIST: number;
                                        BAN: number;
                                        ALLOW: number;
                                        UPDATE: number;
                                        BLOCK: number;
                                        UNBLOCK: number;
                                        PRESENCE: number;
                                        ABSENCE: number;
                                        DIRECT_JOINED: number;
                                        ASSIGN_OWNER: number;
                                        ADD_ADMIN: number;
                                        REMOVE_ADMIN: number;
                                        ADD_MUTE: number;
                                        REMOVE_MUTE: number;
                                        UPDATE_ANNOUNCEMENT: number;
                                        DELETE_ANNOUNCEMENT: number;
                                        UPLOAD_FILE: number;
                                        DELETE_FILE: number;
                                        ADD_USER_WHITE_LIST: number;
                                        REMOVE_USER_WHITE_LIST: number;
                                        BAN_GROUP: number;
                                        REMOVE_BAN_GROUP: number;
                                        THREAD_CREATE: number;
                                        THREAD_DESTROY: number;
                                        THREAD_JOIN: number;
                                        THREAD_LEAVE: number;
                                        THREAD_KICK: number;
                                        THREAD_UPDATE: number;
                                        THREAD_PRESENCE: number;
                                        THREAD_ABSENCE: number;
                                        DISABLE_GROUP: number;
                                        ABLE_GROUP: number;
                                        SET_METADATA: number;
                                        DELETE_METADATA: number;
                                        GROUP_MEMBER_METADATA_UPDATE: number;
                                    };
                                };
                                Setting: {
                                    fields: {
                                        name: {
                                            type: string;
                                            id: number;
                                        };
                                        desc: {
                                            type: string;
                                            id: number;
                                        };
                                        type: {
                                            type: string;
                                            id: number;
                                        };
                                        maxUsers: {
                                            type: string;
                                            id: number;
                                        };
                                        owner: {
                                            type: string;
                                            id: number;
                                        };
                                    };
                                    nested: {
                                        Type: {
                                            values: {
                                                PRIVATE_OWNER_INVITE: number;
                                                PRIVATE_MEMBER_INVITE: number;
                                                PUBLIC_JOIN_APPROVAL: number;
                                                PUBLIC_JOIN_OPEN: number;
                                                PUBLIC_ANONYMOUS: number;
                                            };
                                        };
                                    };
                                };
                                Status: {
                                    fields: {
                                        errorCode: {
                                            type: string;
                                            id: number;
                                        };
                                        description: {
                                            type: string;
                                            id: number;
                                        };
                                        chatroomInfo: {
                                            type: string;
                                            id: number;
                                        };
                                    };
                                    nested: {
                                        ErrorCode: {
                                            values: {
                                                OK: number;
                                                PERMISSION_DENIED: number;
                                                WRONG_PARAMETER: number;
                                                MUC_NOT_EXIST: number;
                                                USER_NOT_EXIST: number;
                                                UNKNOWN: number;
                                            };
                                        };
                                    };
                                };
                                EventInfo: {
                                    fields: {
                                        eventType: {
                                            type: string;
                                            id: number;
                                            options: {
                                                default: string;
                                            };
                                        };
                                        ext: {
                                            type: string;
                                            id: number;
                                        };
                                    };
                                    nested: {
                                        EventType: {
                                            values: {
                                                EVENT_NONE: number;
                                                CIRCLE_CHANNEL: number;
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        RosterBody: {
                            fields: {
                                operation: {
                                    type: string;
                                    id: number;
                                };
                                status: {
                                    type: string;
                                    id: number;
                                };
                                from: {
                                    type: string;
                                    id: number;
                                };
                                to: {
                                    rule: string;
                                    type: string;
                                    id: number;
                                };
                                reason: {
                                    type: string;
                                    id: number;
                                };
                                rosterVer: {
                                    type: string;
                                    id: number;
                                };
                                biDirection: {
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                Operation: {
                                    values: {
                                        GET_ROSTER: number;
                                        GET_BLACKLIST: number;
                                        ADD: number;
                                        REMOVE: number;
                                        ACCEPT: number;
                                        DECLINE: number;
                                        BAN: number;
                                        ALLOW: number;
                                        REMOTE_ACCEPT: number;
                                        REMOTE_DECLINE: number;
                                    };
                                };
                                Status: {
                                    fields: {
                                        errorCode: {
                                            type: string;
                                            id: number;
                                        };
                                        description: {
                                            type: string;
                                            id: number;
                                        };
                                    };
                                    nested: {
                                        ErrorCode: {
                                            values: {
                                                OK: number;
                                                USER_NOT_EXIST: number;
                                                USER_ALREADY_FRIEND: number;
                                                USER_ALREADY_BLACKLIST: number;
                                            };
                                        };
                                    };
                                };
                            };
                        };
                        StatisticsBody: {
                            fields: {
                                operation: {
                                    type: string;
                                    id: number;
                                };
                                os: {
                                    type: string;
                                    id: number;
                                };
                                version: {
                                    type: string;
                                    id: number;
                                };
                                network: {
                                    type: string;
                                    id: number;
                                };
                                imTime: {
                                    type: string;
                                    id: number;
                                };
                                chatTime: {
                                    type: string;
                                    id: number;
                                };
                                location: {
                                    type: string;
                                    id: number;
                                };
                                reason: {
                                    type: string;
                                    id: number;
                                };
                            };
                            nested: {
                                Operation: {
                                    values: {
                                        INFORMATION: number;
                                        USER_REMOVED: number;
                                        USER_LOGIN_ANOTHER_DEVICE: number;
                                        USER_KICKED_BY_CHANGE_PASSWORD: number;
                                        USER_KICKED_BY_OTHER_DEVICE: number;
                                    };
                                };
                                OsType: {
                                    values: {
                                        OS_IOS: number;
                                        OS_ANDROID: number;
                                        OS_LINUX: number;
                                        OS_OSX: number;
                                        OS_WIN: number;
                                        OS_CUSTOM: number;
                                        OS_OTHER: number;
                                    };
                                };
                                NetworkType: {
                                    values: {
                                        NETWORK_NONE: number;
                                        NETWORK_WIFI: number;
                                        NETWORK_4G: number;
                                        NETWORK_3G: number;
                                        NETWORK_2G: number;
                                        NETWORK_WIRE: number;
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
};
export default proto;
export { proto };
