import type { Message, MessageBody, MessageModifiedInfo, StreamMessageMeta, StreamMessageStatus } from '../../types';
import type { ChatConversationType } from '../../types/chat-manager';
import type { ChatThreadMessageContext, ChatThreadOverview } from '../../types/chat-thread';
export declare const readMessageContent: (body: Record<string, unknown>) => Record<string, unknown> | undefined;
/** @internal Shared message payload mapping for realtime and session-list protocols. */
export declare class MessagePayloadDecoder {
    private readonly userId;
    private readonly useCustomAttachmentUpload;
    constructor(userId: string, useCustomAttachmentUpload?: boolean);
    decodeMetadata(body: Record<string, unknown>, conversationType: ChatConversationType, direct: Message['direct'], fallbackMeta?: unknown): Omit<Partial<Message>, 'body'>;
    decodeContent(content: Record<string, unknown>, metaPayload?: unknown): {
        type: Message['type'];
        body: MessageBody;
    } | null;
    decodeStreamMeta(rawStream: unknown, content: Record<string, unknown> | undefined): StreamMessageMeta | undefined;
    mapStreamStatus(rawStatus: number, errorType: number): StreamMessageStatus;
    resolveContentText(content: Record<string, unknown> | undefined): string;
    resolveContentReplaced(metaPayload: unknown): boolean | undefined;
    resolveMessageMetaPayload(primaryPayload: unknown, fallbackPayload: unknown): unknown;
    resolvePeerRead(metaPayload: unknown, conversationType: ChatConversationType, direct: Message['direct']): boolean | undefined;
    resolveGroupReadCount(metaPayload: unknown, conversationType: ChatConversationType): number | undefined;
    resolveModifiedInfo(metaPayload: unknown): MessageModifiedInfo | undefined;
    resolveChatThreadMessageContext(metaPayload: unknown): ChatThreadMessageContext | undefined;
    resolveChatThreadOverview(metaPayload: unknown): ChatThreadOverview | undefined;
    resolveChatThreadOverviewLastMessage(rawLastMessage: unknown, chatThreadId: string): ChatThreadOverview['lastMessage'] | undefined;
    resolveThreadLastMessagePayload(rawLastMessage: Record<string, unknown>): Record<string, unknown> | null;
    composeThreadBodies(bodies: ReadonlyArray<unknown>): {
        type: Message['type'];
        body: MessageBody;
    } | null;
    mapThreadMessageType(rawType: string | undefined): Message['type'];
    normalizeThreadLastMessageBody(type: Message['type'], firstBody: Record<string, unknown> | null, rawLastMessage: Record<string, unknown>): MessageBody;
    readString(value: unknown): string | undefined;
    numberField<Key extends string>(key: Key, value: unknown): Record<Key, number> | object;
    parseMetaPayload(metaPayload: unknown): Record<string, unknown> | null;
    toFiniteNumber(value: unknown): number | undefined;
    resolveReactions(metaPayload: unknown): Message['reactions'];
    normalizeMetaPayload(payload: unknown): Uint8Array | null;
}
