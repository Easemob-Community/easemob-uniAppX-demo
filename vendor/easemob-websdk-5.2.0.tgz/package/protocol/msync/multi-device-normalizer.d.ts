/**
 * MultiDevice 事件归一化器。
 *
 * 负责把原始协议载荷收敛为公开 MultiDevice payload，并处理设备来源归一、同设备过滤与 unknown operation。
 */
import type { MultiDeviceContactEvent, MultiDeviceConversationEvent, MultiDeviceEventCategory, MultiDeviceGroupEvent, MultiDeviceMessageRemovedEvent, MultiDeviceThreadEvent } from '../../types/multi-device';
export interface MultiDeviceNormalizeContext {
    readonly userId: string;
    readonly clientResource?: string;
}
interface JidLike {
    readonly name?: string;
    readonly clientResource?: string;
    readonly domain?: string;
}
interface MultiDeviceRawRecord {
    readonly [key: string]: unknown;
}
declare const resolveDeviceId: (...candidates: ReadonlyArray<unknown>) => string | undefined;
declare const isSameDeviceEcho: (deviceId: string | undefined, clientResource: string | undefined) => boolean;
export declare const normalizeMultiDeviceContactEvent: (input: {
    readonly operation: number;
    readonly from?: JidLike;
    readonly to?: ReadonlyArray<JidLike>;
    readonly rosterVersion?: string;
    readonly ext?: string;
    readonly timestamp?: number;
    readonly raw?: MultiDeviceRawRecord;
}, context: MultiDeviceNormalizeContext) => MultiDeviceContactEvent | null;
export declare const normalizeMultiDeviceGroupEvent: (input: {
    readonly operation: number;
    readonly groupId: string;
    readonly groupName?: string;
    readonly from?: JidLike;
    readonly to?: ReadonlyArray<JidLike>;
    readonly reason?: string;
    readonly eventExt?: string;
    readonly members?: ReadonlyArray<string>;
    readonly timestamp?: number;
    readonly raw?: MultiDeviceRawRecord;
}, context: MultiDeviceNormalizeContext) => MultiDeviceGroupEvent | null;
export declare const normalizeMultiDeviceThreadEvent: (input: {
    readonly operation: number;
    readonly threadId: string;
    readonly threadName?: string;
    readonly parentId?: string;
    readonly from?: JidLike;
    readonly to?: ReadonlyArray<JidLike>;
    readonly members?: ReadonlyArray<string>;
    readonly timestamp?: number;
    readonly raw?: MultiDeviceRawRecord;
}, context: MultiDeviceNormalizeContext) => MultiDeviceThreadEvent | null;
export declare const normalizeMultiDeviceConversationEvent: (input: {
    readonly operation: string;
    readonly id: string;
    readonly type?: string;
    readonly from?: string;
    readonly res?: string;
    readonly ts?: unknown;
    readonly ext?: string;
    readonly raw?: MultiDeviceRawRecord;
}, context: MultiDeviceNormalizeContext) => MultiDeviceConversationEvent | null;
export declare const normalizeMultiDeviceMessageRemovedEvent: (input: {
    readonly chatType?: string;
    readonly to?: string;
    readonly resource?: string;
    readonly msgIdList?: ReadonlyArray<string>;
    readonly deleteTime?: unknown;
    readonly lastMsgId?: string;
    readonly messageRoamingType?: string;
    readonly raw?: MultiDeviceRawRecord;
}, context: MultiDeviceNormalizeContext) => MultiDeviceMessageRemovedEvent | null;
export declare const normalizeMultiDeviceConversationMuteEvents: (values: unknown, context: MultiDeviceNormalizeContext) => ReadonlyArray<MultiDeviceConversationEvent>;
export declare const getMultiDeviceEventName: (category: MultiDeviceEventCategory) => "onMultiDeviceContact" | "onMultiDeviceGroup" | "onMultiDeviceThread" | "onMultiDeviceConversation" | "onMultiDeviceMessageRemoved";
export { resolveDeviceId, isSameDeviceEcho };
