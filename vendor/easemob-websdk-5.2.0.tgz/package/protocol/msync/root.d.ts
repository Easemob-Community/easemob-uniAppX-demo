/**
 * MSync protobuf Root 单例
 */
import type { Root } from 'protobufjs/light';
export declare function getMsyncRoot(): Root;
