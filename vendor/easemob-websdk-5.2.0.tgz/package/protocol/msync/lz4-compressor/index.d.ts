/**
 * 压缩模式枚举
 */
export declare enum CompressionMode {
    /** 不压缩 */
    NONE = -1,
    /** 只上行压缩 */
    UPLINK_ONLY = 0,
    /** 只下行压缩 */
    DOWNLINK_ONLY = 1,
    /** 双向压缩 */
    BIDIRECTIONAL = 2
}
/**
 * LZ4 压缩器
 */
export declare class LZ4Compressor {
    private encoder;
    private decoder;
    /** 压缩模式 */
    mode: CompressionMode;
    /** 是否启用上行压缩 */
    enableUplinkCompression: boolean;
    /** 是否启用下行压缩 */
    enableDownlinkCompression: boolean;
    constructor();
    /**
     * 压缩数据
     */
    compress(data: ArrayBuffer | Uint8Array): Uint8Array;
    /**
     * 解压缩数据
     */
    decompress(compressedData: ArrayBuffer | Uint8Array): Uint8Array;
    /**
     * 重置编码器和解码器状态
     */
    reset(): void;
}
export declare function createLZ4Compressor(): LZ4Compressor;
