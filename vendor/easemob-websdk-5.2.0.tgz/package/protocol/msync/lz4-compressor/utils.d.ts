/** 解码状态，用于追踪偏移量 */
export interface DecodeState {
    offset: number;
}
/** CRC32 支持的输入类型 */
export type CRC32Input = Uint8Array | Int8Array | number[];
/**
 * 计算 CRC32 校验值
 * @param data - 输入数据（二进制数组）
 * @returns 无符号 32 位 CRC32 值
 */
export declare function crc32(data: CRC32Input): number;
/**
 * LEB128 变长编码（Little Endian Base 128）
 * @param length - 要编码的长度值 (0 ~ 2^28-1，约 256MB)
 * @returns 编码后的字节数组（最多 4 字节）
 * @throws 当输入为负数或超出范围时抛出异常
 */
export declare function encodeLength(length: number): Uint8Array;
/**
 * LEB128 变长解码
 * @param data - 二进制数据
 * @param state - 包含 offset 的状态对象，用于追踪读取位置
 * @returns 解码后的长度值
 * @throws 当编码超过 4 字节或数据不完整时抛出异常
 */
export declare function decodeLength(data: Uint8Array, state: DecodeState): number;
