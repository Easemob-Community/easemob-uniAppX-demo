/**
 * MSync 常量定义
 */
export declare const MsyncCommand: {
    readonly SYNC: 0;
    readonly UNREAD: 1;
    readonly NOTICE: 2;
    readonly PROVISION: 3;
    readonly LOGOUT: 4;
};
export declare const MsyncMessageType: {
    readonly NORMAL: 0;
    readonly SINGLECHAT: 1;
    readonly GROUPCHAT: 2;
    readonly CHATROOM: 3;
    readonly READ_ACK: 4;
    readonly DELIVER_ACK: 5;
    readonly RECALL: 6;
    readonly CHANNEL_ACK: 7;
    readonly EDIT: 8;
};
export declare const ContentType: {
    readonly TEXT: 0;
    readonly IMAGE: 1;
    readonly VIDEO: 2;
    readonly LOCATION: 3;
    readonly VOICE: 4;
    readonly FILE: 5;
    readonly COMMAND: 6;
    readonly CUSTOM: 7;
    readonly COMBINE: 8;
};
export declare const MsyncStreamStatus: {
    readonly STREAM_START: 0;
    readonly STREAM_START_COMPLETED: 1;
    readonly STREAM_IN_PROGRESS: 2;
    readonly STREAM_COMPLETED: 3;
    readonly STREAM_FULL: 4;
};
export declare const NameSpace: {
    readonly STATISTIC: 0;
    readonly CHAT: 1;
    readonly MUC: 2;
    readonly ROSTER: 3;
    readonly CONFERENCE: 4;
    readonly NOTIFY: 5;
    readonly QUERY: 6;
};
export declare const RouteType: {
    readonly ROUTE_ALL: 0;
    readonly ROUTE_ONLINE: 1;
    readonly ROUTE_DIRECT: 2;
};
export declare const EncryptType: {
    readonly ENCRYPT_NONE: 0;
    readonly ENCRYPT_AES_128_CBC: 1;
    readonly ENCRYPT_AES_256_CBC: 2;
};
export declare const CompressType: {
    readonly COMPRESS_NONE: 0;
    readonly COMPRESS_ZLIB: 1;
    readonly COMPRESS_LZ4: 2;
};
export declare const ProvisionErrorCode: {
    readonly OK: 0;
    readonly FAIL: 1;
    readonly UNAUTHORIZED: 2;
    readonly MISSING_PARAMETER: 3;
    readonly WRONG_PARAMETER: 4;
    readonly REDIRECT: 5;
    readonly TOKEN_EXPIRED: 6;
    readonly PERMISSION_DENIED: 7;
    readonly NO_ROUTE: 8;
    readonly UNKNOWN_COMMAND: 9;
    readonly PB_PARSER_ERROR: 10;
    readonly BIND_ANOTHER_DEVICE: 11;
    readonly IM_FORBIDDEN: 12;
    readonly TOO_MANY_DEVICES: 13;
    readonly PLATFORM_LIMIT: 14;
    readonly USER_MUTED: 15;
    readonly ENCRYPT_DISABLE: 16;
    readonly ENCRYPT_ENABLE: 17;
    readonly DECRYPT_FAILURE: 18;
    readonly PERMISSION_DENIED_EXTERNAL: 19;
    readonly RESOURCE_CHANGED: 20;
};
export declare const KeyValueType: {
    readonly BOOL: 1;
    readonly INT: 2;
    readonly UINT: 3;
    readonly LLINT: 4;
    readonly FLOAT: 5;
    readonly DOUBLE: 6;
    readonly STRING: 7;
    readonly JSON_STRING: 8;
};
