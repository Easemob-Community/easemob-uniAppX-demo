/**
 * MSync 编解码器
 *
 * 负责 provision、消息编码、消息解码的核心流程。
 */
import { type MsyncContextOptions, type MsyncContextState } from './context';
import type { Message } from '../../types';
import type { JoinChatRoomInfo } from '../../types/chatroom';
import type { MessageActionRequest } from '../../core/message/message-action-types';
import type { ChatRoomOperationRequest } from '../../core/message/chatroom-operation-types';
export interface ProvisionResult {
    ok: boolean;
    statusCode: number;
    reason?: string;
    resource?: string;
    authToken?: string;
    protocolCompressType?: number[];
    protocolCompressDirection?: number;
}
export interface AckResult {
    protocolId: string;
    serverId: string;
    ok: boolean;
    statusCode: number;
    reason?: string;
    chatRoomInfo?: JoinChatRoomInfo;
}
export interface NotifyEvent {
    readonly type: string;
    readonly eventName?: string;
    readonly data: unknown;
}
export interface StatisticOperationResult {
    readonly operation: number;
    readonly reason?: string;
}
export interface LogoutResult {
    readonly sessionId?: string;
    readonly reason?: string;
    readonly statusCode?: number;
}
export interface SyncDecodeResult {
    ack?: AckResult;
    messages: Message[];
    notifies?: ReadonlyArray<NotifyEvent>;
    metaId?: string;
    queue?: Record<string, unknown>;
    nextKey?: string;
    isLast?: boolean;
    replacedMessage?: Message;
}
export declare class MsyncCodec {
    private context;
    private compressor;
    private compressionFailureCount;
    private readonly maxCompressionFailures;
    private useReplacedMessageContents;
    private readonly payloadDecoder;
    constructor(options: MsyncContextOptions);
    updateToken(token: string): void;
    updateResource(resource: string | undefined): void;
    getContext(): MsyncContextState;
    /**
     * 生成 provision 登录握手消息
     */
    encodeProvision(): Uint8Array;
    /**
     * 编码心跳探测消息（UNREAD）
     */
    encodeHeartbeat(): Uint8Array;
    encodeStatisticRebuild(): Uint8Array;
    /**
     * 解析 provision 回包
     */
    decodeProvision(payload: Uint8Array): ProvisionResult;
    decodeLogout(payload: Uint8Array): LogoutResult;
    decodeSyncStatisticOperations(payload: Uint8Array): ReadonlyArray<StatisticOperationResult>;
    /**
     * 解析 MSync 外层包
     */
    decodeMsync(data: Uint8Array): {
        command: number;
        payload: Uint8Array;
    };
    private normalizeBinaryPayload;
    /**
     * 解码下行 SYNC（CommSyncDL），拆分 ACK 与消息
     */
    decodeSync(payload: Uint8Array): SyncDecodeResult;
    private decodeReplacedMessage;
    private decodeChatMeta;
    private decodeChatActionMeta;
    private decodeNotifyMeta;
    private decodeStatisticGroupReceiptNotifies;
    private decodeStatisticMeta;
    private decodeRosterMeta;
    private readRosterJid;
    private readRosterJidList;
    private readJid;
    private decodeMucMeta;
    private mapRosterOperationToEvent;
    private decodeNotifyPayload;
    private readMetaTimestamp;
    private msyncCodecContext;
    private createMultiDeviceNotify;
    decodeNotice(payload: Uint8Array): {
        queue?: Record<string, unknown>;
    };
    decodeUnread(payload: Uint8Array): {
        queues: Record<string, unknown>[];
    };
    encodeBackQueue(queue: Record<string, unknown>): Uint8Array;
    encodeLastSession(queue: Record<string, unknown>, nextKey: string): Uint8Array;
    /**
     * 编码聊天消息（文本/命令/自定义）
     */
    encodeChatMessage(message: Message, protocolId: string): Uint8Array;
    /**
     * 编码合并消息文件中的单条 Meta，保持与旧 Web SDK 的合并消息格式兼容。
     */
    encodeCombineMessageMeta(message: Message): Uint8Array;
    private buildChatMeta;
    encodeActionMessage(action: MessageActionRequest, protocolId: string): Uint8Array;
    encodeChatRoomOperation(request: ChatRoomOperationRequest, protocolId: string): Uint8Array;
    decodeServerMessageMeta(metaPayload: Uint8Array): Message | null;
    /**
     * 将 WebSocket 数据统一为 Uint8Array
     */
    normalizeIncoming(data: unknown): Promise<Uint8Array>;
    /**
     * 解压下行消息（根据 provision 协商的压缩模式）
     */
    decompressIncoming(data: Uint8Array): Uint8Array | null;
    /**
     * 压缩上行消息（根据 provision 协商的压缩模式）
     */
    prepareOutgoing(data: Uint8Array): Uint8Array;
    /**
     * 为新的 WebSocket Provision 握手重置连接级压缩状态。
     * 保留累计失败次数，使发生过解压失败后的下一次握手不再请求压缩。
     */
    resetCompressionNegotiation(): void;
    /**
     * 为 msgLocalId 生成可用的协议 ID（必须为纯数字）
     */
    toProtocolId(msgLocalId: string): string;
    private decodeChatRoomJoinInfo;
    private decodeAck;
    private decodeMessage;
    private resolveMessageProfileVersionFields;
    private buildMessageMeta;
    private buildMessageMetaFromBody;
    private buildTranslationsMeta;
    private resolveProfileVersionTime;
    private isPublicMessageType;
    private resolveMessageIsOnline;
    private buildContents;
    private buildContent;
    private decodeContent;
    private resolveChatType;
    private resolveActionConversationType;
    private resolveConversationTypeFromMeta;
    private resolveActionConversationId;
    private resolveOutboundMessageTarget;
    private resolveIncomingMessageParties;
    private resolveActionMessageType;
    private resolveConversationType;
    private resolveDirectedUsers;
    private resolveDeliverOnlineOnly;
    private resolveMetaExt;
    private resolveRouteType;
    private resolveBroadcast;
    private resolvePriority;
    private mapPriorityToTag;
    private getRequestedCompressTypes;
    private configureCompression;
    private resolveCompressionMode;
    private disableCompression;
}
