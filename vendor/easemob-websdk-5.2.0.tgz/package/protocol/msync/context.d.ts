/**
 * MSync 上下文配置
 */
export interface MsyncContextOptions {
    appKey: string;
    userId: string;
    token: string;
    domain?: string;
    version?: string;
    osType?: number;
    useReplacedMessageContents?: boolean;
    useFixedDeviceId?: boolean;
    deviceId?: string;
    customDeviceName?: string;
    customOSPlatform?: number;
    uiKitVersion?: string;
    useCustomAttachmentUpload?: boolean;
    loginExtensionInfo?: string;
    serviceId?: string;
}
export interface MsyncContextState {
    appKey: string;
    userId: string;
    token: string;
    domain: string;
    version: string;
    uiKitVersion?: string;
    osType: number;
    deviceId: string;
    deviceName: string;
    deviceUuid: string;
    clientResource: string;
    customOSPlatform?: number;
    loginExtensionInfo?: string;
    encryptType: number[];
    compressType: number[];
    sessionId: string;
    serviceId?: string;
}
export declare const createMsyncContext: (options: MsyncContextOptions) => MsyncContextState;
