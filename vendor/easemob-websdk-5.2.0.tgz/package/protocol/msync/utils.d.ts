/**
 * MSync 工具方法
 */
export interface DeviceInfo {
    deviceId: string;
    deviceName: string;
    deviceUuid: string;
}
export interface DeviceInfoOptions {
    useFixedDeviceId: boolean;
    deviceId: string;
    customOSPlatform?: number;
    customDeviceName?: string;
}
export interface Jid {
    appKey?: string;
    name: string;
    domain?: string;
    clientResource?: string;
}
export declare const buildDeviceInfo: (options: DeviceInfoOptions) => DeviceInfo;
export declare const buildJid: (params: Jid) => Jid;
export declare const toNumericId: (value: string) => string;
export declare const longToString: (value: unknown) => string;
export declare const encodeKeyValueRecord: (record: Record<string, unknown>) => Array<Record<string, unknown>>;
export declare const decodeKeyValueList: (list?: Array<Record<string, unknown>>) => Record<string, unknown>;
