/** Returns a payload user ID when present, falling back to the envelope JID. */
export declare const resolveMessageJidName: (payloadJid: unknown, envelopeJid: unknown) => string;
