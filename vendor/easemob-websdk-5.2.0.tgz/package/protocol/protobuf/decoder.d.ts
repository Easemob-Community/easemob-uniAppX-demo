/**
 * Protobuf 消息解码器
 *
 * 将二进制解码为 Message 对象，包含会话定位字段
 * 参考：engineCore/mSync.ts, handleMessages/handleChatMsg.ts
 */
import type { Message } from '../../types';
/**
 * Protobuf 消息解码器
 */
export declare class ProtobufDecoder {
    private readonly useCustomAttachmentUpload;
    constructor(options?: {
        useCustomAttachmentUpload?: boolean;
    });
    /**
     * 解码消息
     *
     * TODO: 实际实现中需要使用 protobufjs-lite 从 messages.proto 生成解码器
     * 这里先提供接口和简化实现
     */
    decode(data: ArrayBuffer | Uint8Array): Message;
    /**
     * 推断会话类型
     */
    private inferConversationType;
    private parseBody;
    private parseTextBody;
    private parseImageBody;
    private resolveImageType;
    private static toRecord;
    private static readRecord;
    private static isRecord;
    private static readString;
    private static readNumber;
    private static readBoolean;
    private static hasValue;
    private static readMessageType;
    private static readMessageSendStatus;
    private static readConversationType;
    private static isMessageType;
    private static isMessageSendStatus;
    private static isConversationType;
}
