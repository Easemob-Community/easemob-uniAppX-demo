/**
 * Protobuf 消息编码器
 *
 * 将 Message 对象编码为二进制，包含会话定位字段
 * 参考：engineCore/mSync.ts
 */
import { Message } from '../../types';
/**
 * Protobuf 消息编码器
 */
export declare class ProtobufEncoder {
    /**
     * 编码消息
     *
     * TODO: 实际实现中需要使用 protobufjs-lite 从 messages.proto 生成编码器
     * 这里先提供接口和简化实现
     */
    encode(message: Message): ArrayBuffer;
    /**
     * 编码消息（返回 Uint8Array）
     */
    encodeToUint8Array(message: Message): Uint8Array;
}
