/**
 * Roster 协议类型
 */
export declare const RosterMessageType: {
    readonly UNSPECIFIED: 0;
    readonly PING: 1;
    readonly PONG: 2;
    readonly REQUEST: 3;
    readonly RESPONSE: 4;
    readonly ERROR: 5;
};
export declare const RosterServerStatus: {
    readonly OK: 0;
    readonly BUSY: 1;
};
export declare const RosterResponseType: {
    readonly UNSPECIFIED: 0;
    readonly INCREMENTAL: 1;
    readonly FULL: 2;
};
export interface RosterGatewayHeader {
    readonly resource: string;
    readonly timestamp: number;
    readonly requestId: string;
    readonly protocolVersion: number;
}
export interface RosterBaseMessage {
    readonly type: number;
}
export interface RosterPingRequest extends RosterBaseMessage {
    readonly type: typeof RosterMessageType.PING;
}
export interface RosterPongResponse extends RosterBaseMessage {
    readonly type: typeof RosterMessageType.PONG;
    readonly status: number;
}
export interface RosterErrorDetail extends RosterBaseMessage {
    readonly type: typeof RosterMessageType.ERROR;
    readonly header?: RosterGatewayHeader;
    readonly code: string;
    readonly message: string;
}
export type RosterUnknownMessage = RosterBaseMessage;
export interface RosterRequest extends RosterBaseMessage {
    readonly type: typeof RosterMessageType.REQUEST;
    readonly header: RosterGatewayHeader;
    readonly org: string;
    readonly app: string;
    readonly username: string;
    readonly version: string;
    readonly cursor: number;
}
export interface RosterItem {
    readonly contact: string;
    readonly remark: string;
    readonly metadata: string;
    readonly createdAt: number;
    readonly updatedAt: number;
    readonly metadataUpdatedAt: number;
}
export interface RosterResponse extends RosterBaseMessage {
    readonly type: typeof RosterMessageType.RESPONSE;
    readonly header?: RosterGatewayHeader;
    readonly data: ReadonlyArray<RosterItem>;
    readonly cursor: number;
    readonly version: string;
    readonly responseType: number;
}
export type RosterDecodedMessage = RosterPingRequest | RosterPongResponse | RosterResponse | RosterErrorDetail | RosterUnknownMessage;
/**
 * Gateway API 错误码常量（4 位 uint32）。
 * 前 2 位为领域（10=common, 11=roster），后 2 位为领域内序号。
 */
export declare const RosterApiCode: {
    readonly INVALID_REQUEST: 1001;
    readonly UNAUTHORIZED: 1002;
    readonly RATE_LIMIT_EXCEEDED: 1003;
    readonly METHOD_NOT_ALLOWED: 1004;
    readonly INTERNAL_ERROR: 1005;
    readonly INVALID_ROSTER_REQUEST: 1101;
    readonly GET_ROSTER_FAILED: 1102;
};
export type RosterApiCode = (typeof RosterApiCode)[keyof typeof RosterApiCode];
