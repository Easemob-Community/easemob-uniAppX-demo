/**
 * Roster 编解码器
 */
import type { RosterDecodedMessage, RosterRequest } from './types';
export declare class RosterCodec {
    encodeRequest(payload: RosterRequest): Uint8Array;
    encodePong(status?: number): Uint8Array;
    decode(payload: Uint8Array): RosterDecodedMessage;
}
