/**
 * 由 scripts/generate-roster-proto.js 自动生成，请勿手动修改。
 */
declare const proto: {
    nested: {
        easemob: {
            nested: {
                imfusion: {
                    nested: {
                        gateway: {
                            nested: {
                                v1: {
                                    nested: {
                                        MessageType: {
                                            values: {
                                                MESSAGE_TYPE_UNSPECIFIED: number;
                                                MESSAGE_TYPE_PING: number;
                                                MESSAGE_TYPE_PONG: number;
                                                MESSAGE_TYPE_ROSTER_REQUEST: number;
                                                MESSAGE_TYPE_ROSTER_RESPONSE: number;
                                                MESSAGE_TYPE_ERROR: number;
                                            };
                                        };
                                        ServerStatus: {
                                            values: {
                                                SERVER_STATUS_OK: number;
                                                SERVER_STATUS_BUSY: number;
                                            };
                                        };
                                        RosterResponseType: {
                                            values: {
                                                ROSTER_RESPONSE_TYPE_UNSPECIFIED: number;
                                                ROSTER_RESPONSE_TYPE_INCREMENTAL: number;
                                                ROSTER_RESPONSE_TYPE_FULL: number;
                                            };
                                        };
                                        BaseMessage: {
                                            fields: {
                                                type: {
                                                    type: string;
                                                    id: number;
                                                };
                                            };
                                        };
                                        GatewayHeader: {
                                            fields: {
                                                resource: {
                                                    type: string;
                                                    id: number;
                                                };
                                                timestamp: {
                                                    type: string;
                                                    id: number;
                                                };
                                                requestId: {
                                                    type: string;
                                                    id: number;
                                                };
                                                protocolVersion: {
                                                    type: string;
                                                    id: number;
                                                };
                                            };
                                        };
                                        PingRequest: {
                                            fields: {
                                                type: {
                                                    type: string;
                                                    id: number;
                                                };
                                            };
                                        };
                                        PongResponse: {
                                            fields: {
                                                type: {
                                                    type: string;
                                                    id: number;
                                                };
                                                status: {
                                                    type: string;
                                                    id: number;
                                                };
                                            };
                                        };
                                        ErrorDetail: {
                                            fields: {
                                                type: {
                                                    type: string;
                                                    id: number;
                                                };
                                                code: {
                                                    type: string;
                                                    id: number;
                                                };
                                                message: {
                                                    type: string;
                                                    id: number;
                                                };
                                                header: {
                                                    type: string;
                                                    id: number;
                                                };
                                            };
                                        };
                                        GetRosterRequest: {
                                            fields: {
                                                type: {
                                                    type: string;
                                                    id: number;
                                                };
                                                header: {
                                                    type: string;
                                                    id: number;
                                                };
                                                org: {
                                                    type: string;
                                                    id: number;
                                                };
                                                app: {
                                                    type: string;
                                                    id: number;
                                                };
                                                username: {
                                                    type: string;
                                                    id: number;
                                                };
                                                version: {
                                                    type: string;
                                                    id: number;
                                                };
                                                cursor: {
                                                    type: string;
                                                    id: number;
                                                };
                                            };
                                        };
                                        RosterItem: {
                                            fields: {
                                                contact: {
                                                    type: string;
                                                    id: number;
                                                };
                                                remark: {
                                                    type: string;
                                                    id: number;
                                                };
                                                metadata: {
                                                    type: string;
                                                    id: number;
                                                };
                                                createdAt: {
                                                    type: string;
                                                    id: number;
                                                };
                                                updatedAt: {
                                                    type: string;
                                                    id: number;
                                                };
                                                metadataUpdatedAt: {
                                                    type: string;
                                                    id: number;
                                                };
                                            };
                                        };
                                        GetRosterResponse: {
                                            fields: {
                                                type: {
                                                    type: string;
                                                    id: number;
                                                };
                                                header: {
                                                    type: string;
                                                    id: number;
                                                };
                                                data: {
                                                    rule: string;
                                                    type: string;
                                                    id: number;
                                                };
                                                cursor: {
                                                    type: string;
                                                    id: number;
                                                };
                                                version: {
                                                    type: string;
                                                    id: number;
                                                };
                                                responseType: {
                                                    type: string;
                                                    id: number;
                                                };
                                            };
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };
        };
    };
};
export default proto;
export { proto };
