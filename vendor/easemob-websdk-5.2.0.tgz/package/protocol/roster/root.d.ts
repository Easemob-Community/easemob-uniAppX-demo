/**
 * Roster protobuf Root 单例
 */
import { Root } from 'protobufjs/light';
export declare const getRosterRoot: () => Root;
