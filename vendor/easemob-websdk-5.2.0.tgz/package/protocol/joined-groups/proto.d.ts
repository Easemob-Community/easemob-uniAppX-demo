declare const proto: {
    readonly nested: {
        readonly easemob: {
            readonly nested: {
                readonly joinedgroups: {
                    readonly nested: {
                        readonly GatewayHeader: {
                            readonly fields: {
                                readonly resource: {
                                    readonly type: "string";
                                    readonly id: 1;
                                };
                                readonly timestamp: {
                                    readonly type: "int64";
                                    readonly id: 2;
                                };
                                readonly request_id: {
                                    readonly type: "string";
                                    readonly id: 3;
                                };
                                readonly protocol_version: {
                                    readonly type: "int32";
                                    readonly id: 4;
                                };
                            };
                        };
                        readonly GetJoinedGroupsRequest: {
                            readonly fields: {
                                readonly type: {
                                    readonly type: "int32";
                                    readonly id: 1;
                                };
                                readonly header: {
                                    readonly type: "GatewayHeader";
                                    readonly id: 2;
                                };
                                readonly org: {
                                    readonly type: "string";
                                    readonly id: 3;
                                };
                                readonly app: {
                                    readonly type: "string";
                                    readonly id: 4;
                                };
                                readonly username: {
                                    readonly type: "string";
                                    readonly id: 5;
                                };
                                readonly last_sync_time: {
                                    readonly type: "int64";
                                    readonly id: 6;
                                };
                                readonly cursor: {
                                    readonly type: "string";
                                    readonly id: 7;
                                };
                            };
                        };
                        readonly GroupItem: {
                            readonly fields: {
                                readonly group_id: {
                                    readonly type: "string";
                                    readonly id: 1;
                                };
                                readonly group_name: {
                                    readonly type: "string";
                                    readonly id: 2;
                                };
                                readonly group_owner: {
                                    readonly type: "string";
                                    readonly id: 3;
                                };
                                readonly members_count: {
                                    readonly type: "int64";
                                    readonly id: 4;
                                };
                                readonly mute_all: {
                                    readonly type: "bool";
                                    readonly id: 5;
                                };
                                readonly disabled: {
                                    readonly type: "bool";
                                    readonly id: 6;
                                };
                                readonly description: {
                                    readonly type: "string";
                                    readonly id: 7;
                                };
                                readonly group_avatar: {
                                    readonly type: "string";
                                    readonly id: 8;
                                };
                                readonly role: {
                                    readonly type: "uint32";
                                    readonly id: 9;
                                };
                                readonly mute_expiration: {
                                    readonly type: "int64";
                                    readonly id: 10;
                                };
                                readonly remind_type: {
                                    readonly type: "int32";
                                    readonly id: 11;
                                };
                                readonly create_at: {
                                    readonly type: "uint64";
                                    readonly id: 12;
                                };
                                readonly update_at: {
                                    readonly type: "uint64";
                                    readonly id: 13;
                                };
                                readonly joined_timestamp: {
                                    readonly type: "int64";
                                    readonly id: 14;
                                };
                            };
                        };
                        readonly GetJoinedGroupsResponse: {
                            readonly fields: {
                                readonly type: {
                                    readonly type: "int32";
                                    readonly id: 1;
                                };
                                readonly header: {
                                    readonly type: "GatewayHeader";
                                    readonly id: 2;
                                };
                                readonly groups: {
                                    readonly rule: "repeated";
                                    readonly type: "GroupItem";
                                    readonly id: 3;
                                };
                                readonly is_last_batch: {
                                    readonly type: "bool";
                                    readonly id: 4;
                                };
                                readonly last_sync_finished_ts: {
                                    readonly type: "int64";
                                    readonly id: 5;
                                };
                                readonly cursor: {
                                    readonly type: "string";
                                    readonly id: 6;
                                };
                            };
                        };
                        readonly ErrorDetail: {
                            readonly fields: {
                                readonly type: {
                                    readonly type: "int32";
                                    readonly id: 1;
                                };
                                readonly header: {
                                    readonly type: "GatewayHeader";
                                    readonly id: 2;
                                };
                                readonly code: {
                                    readonly type: "uint32";
                                    readonly id: 3;
                                };
                                readonly message: {
                                    readonly type: "string";
                                    readonly id: 4;
                                };
                            };
                        };
                    };
                };
            };
        };
    };
};
export default proto;
