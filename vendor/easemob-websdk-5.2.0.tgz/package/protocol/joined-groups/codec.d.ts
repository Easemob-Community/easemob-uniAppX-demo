import type { JoinedGroupsDecodedMessage, JoinedGroupsRequest } from './types';
export declare class JoinedGroupsCodec {
    private readonly requestType;
    private readonly responseType;
    private readonly errorType;
    encodeRequest(payload: JoinedGroupsRequest): Uint8Array;
    decode(payload: Uint8Array): JoinedGroupsDecodedMessage;
    private tryDecodeRequest;
    private tryDecodeResponse;
    private tryDecodeError;
}
