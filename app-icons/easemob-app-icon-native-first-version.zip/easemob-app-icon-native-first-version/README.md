# 第一版 App 图标原生资源包

基于蓝底白色对话气泡 Logo 制作，不包含 uniApp 角标或三角形标识。

## 预览

`preview/AppIcon-1024.png` 为 1024×1024 主图。

## Android

将 `android/res/` 下的目录合并到 Android 模块的 `src/main/res/`。

包含：

- `mipmap-mdpi` 至 `mipmap-xxxhdpi` 的 `ic_launcher.png` 普通图标。
- 各密度的 `ic_launcher_round.png` 圆形图标。
- Android 8.0（API 26）及以上的自适应图标：`mipmap-anydpi-v26` XML、各密度的前景和背景 PNG。

Manifest 通常引用：

```xml
android:icon="@mipmap/ic_launcher"
android:roundIcon="@mipmap/ic_launcher_round"
```

合并前请备份原有资源；若项目使用其他资源名，请相应调整引用。

## iOS

使用 `ios/Assets.xcassets/AppIcon.appiconset/` 替换 Xcode 项目 Assets 中的同名 AppIcon 集合。

已包含 iPhone、iPad、App Store Marketing 所需尺寸及 `Contents.json`。所有 iOS PNG 均为无透明通道的 RGB 图片。

## HarmonyOS

`harmonyos/AppScope/resources/base/media/` 和 `harmonyos/entry/src/main/resources/base/media/` 均提供：

- `background.png`
- `foreground.png`
- `layered_image.json`

按项目实际结构合并对应目录，图标引用为 `$media:layered_image`。`entry` 目录名如与实际模块不同，请调整为实际模块名。
